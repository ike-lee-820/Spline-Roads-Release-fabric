package net.minecraftforge.registries;

import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraftforge.eventbus.api.IEventBus;

/**
 * Fabric port: entries are registered immediately with Registry.register(), so
 * RegistryObject.get() is valid during static initialization just like Forge.
 */
public final class DeferredRegister<T> {
  private final class_2378<T> registry;
  private final String modid;

  private DeferredRegister(class_2378<T> registry, String modid) {
    this.registry = registry;
    this.modid = modid;
  }

  public static <T> DeferredRegister<T> create(class_2378<T> registry, String modid) {
    return new DeferredRegister<>(registry, modid);
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  public static <T> DeferredRegister<T> create(class_5321<? extends class_2378<T>> key, String modid) {
    class_2378<T> registry;
    if ("creative_mode_tab".equals(key.method_29177().method_12832())) {
      registry = (class_2378<T>) class_7923.field_44687;
    } else {
      registry = (class_2378<T>) class_7923.field_41167.method_10223(key.method_29177());
    }
    return new DeferredRegister<>(registry, modid);
  }

  public <I extends T> RegistryObject<I> register(String name, Supplier<? extends I> supplier) {
    I value = supplier.get();
    class_2960 id = new class_2960(modid, name);
    class_2378.method_10230(registry, id, value);
    return new RegistryObject<>(value);
  }

  /** Registration already happened; retained for source compatibility. */
  public void register(IEventBus bus) { }
}
