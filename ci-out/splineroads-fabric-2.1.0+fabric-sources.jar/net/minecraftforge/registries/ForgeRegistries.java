package net.minecraftforge.registries;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

public final class ForgeRegistries {
  public static final class_2378<class_2248> BLOCKS = class_7923.field_41175;
  public static final class_2378<class_1792> ITEMS = class_7923.field_41178;
  @SuppressWarnings("unchecked")
  public static final class_2378<class_2591<?>> BLOCK_ENTITY_TYPES =
      (class_2378<class_2591<?>>) (class_2378<?>) class_7923.field_41181;
  private ForgeRegistries() {}
}
