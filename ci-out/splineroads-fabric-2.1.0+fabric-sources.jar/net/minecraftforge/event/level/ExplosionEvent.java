package net.minecraftforge.event.level;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraftforge.eventbus.api.Event;

public abstract class ExplosionEvent extends Event {
  private final class_1937 level;
  protected ExplosionEvent(class_1937 level) { this.level = level; }
  public class_1937 getLevel() { return level; }

  public static final class Detonate extends ExplosionEvent {
    private final List<class_2338> affected;
    public Detonate(class_1937 level, List<class_2338> affected) {
      super(level); this.affected = new ArrayList<>(affected);
    }
    public List<class_2338> getAffectedBlocks() { return affected; }
  }
}
