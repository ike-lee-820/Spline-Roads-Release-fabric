package net.minecraftforge.event.level;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.eventbus.api.Event;

public abstract class BlockEvent extends Event {
  private final class_1937 level;
  private final class_2338 pos;
  private final class_2680 state;
  protected BlockEvent(class_1937 level, class_2338 pos, class_2680 state) {
    this.level = level; this.pos = pos; this.state = state;
  }
  public class_1937 getLevel() { return level; }
  public class_2338 getPos() { return pos; }
  public class_2680 getState() { return state; }

  public static class BreakEvent extends BlockEvent {
    private final class_1657 player;
    public BreakEvent(class_1937 level, class_2338 pos, class_2680 state, class_1657 player) {
      super(level, pos, state); this.player = player;
    }
    public class_1657 getPlayer() { return player; }
  }

  public static class EntityPlaceEvent extends BlockEvent {
    private final BlockSnapshot snapshot;
    private final class_1657 player;
    public EntityPlaceEvent(BlockSnapshot snapshot, class_2680 placedAgainst, class_1657 player) {
      super((class_1937) null, snapshot == null ? class_2338.field_10980 : snapshot.getPos(), placedAgainst);
      this.snapshot = snapshot; this.player = player;
    }
    public BlockSnapshot getSnapshot() { return snapshot; }
    public class_1657 getPlayer() { return player; }
    public class_2680 getPlacedBlock() { return getState(); }
  }
}
