package net.minecraftforge.event.level;

import net.minecraft.class_1923;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraftforge.eventbus.api.Event;

/** Synthesized by the Fabric bridge from each player's chunk tracking view. */
public abstract class ChunkWatchEvent extends Event {
  private final class_3222 player;
  private final class_1923 pos;
  private final class_3218 level;
  protected ChunkWatchEvent(class_3222 player, class_1923 pos, class_3218 level) {
    this.player = player; this.pos = pos; this.level = level;
  }
  public class_3222 getPlayer() { return player; }
  public class_1923 getPos() { return pos; }
  public class_3218 getLevel() { return level; }

  public static final class Watch extends ChunkWatchEvent {
    public Watch(class_3222 p, class_1923 c, class_3218 l) { super(p, c, l); }
  }
  public static final class UnWatch extends ChunkWatchEvent {
    public UnWatch(class_3222 p, class_1923 c, class_3218 l) { super(p, c, l); }
  }
}
