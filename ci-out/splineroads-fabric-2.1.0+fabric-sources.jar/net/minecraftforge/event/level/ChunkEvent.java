package net.minecraftforge.event.level;

import net.minecraft.class_1937;
import net.minecraft.class_2818;
import net.minecraftforge.eventbus.api.Event;

public abstract class ChunkEvent extends Event {
  private final class_1937 level;
  private final class_2818 chunk;
  protected ChunkEvent(class_1937 level, class_2818 chunk) { this.level = level; this.chunk = chunk; }
  public class_1937 getLevel() { return level; }
  public class_2818 getChunk() { return chunk; }

  public static final class Load extends ChunkEvent {
    public Load(class_1937 level, class_2818 chunk) { super(level, chunk); }
  }
  public static final class Unload extends ChunkEvent {
    public Unload(class_1937 level, class_2818 chunk) { super(level, chunk); }
  }
}
