package net.minecraftforge.event.entity.player;

import net.minecraft.class_1657;
import net.minecraftforge.eventbus.api.Event;

public abstract class PlayerEvent extends Event {
  private final class_1657 player;
  protected PlayerEvent(class_1657 player) { this.player = player; }
  public class_1657 getEntity() { return player; }

  public static final class PlayerLoggedOutEvent extends PlayerEvent {
    public PlayerLoggedOutEvent(class_1657 player) { super(player); }
  }
  public static final class PlayerChangedDimensionEvent extends PlayerEvent {
    public PlayerChangedDimensionEvent(class_1657 player) { super(player); }
  }
  public static final class PlayerLoggedInEvent extends PlayerEvent {
    public PlayerLoggedInEvent(class_1657 player) { super(player); }
  }
}
