package net.minecraftforge.event.entity.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3965;
import net.minecraftforge.eventbus.api.Event;

public abstract class PlayerInteractEvent extends Event {
  private final class_1657 player;
  private final class_1268 hand;
  private final class_1799 stack;
  private class_1269 cancellationResult = class_1269.field_5811;
  protected PlayerInteractEvent(class_1657 player, class_1268 hand, class_1799 stack) {
    this.player = player; this.hand = hand; this.stack = stack;
  }
  public class_1657 getEntity() { return player; }
  public class_1268 getHand() { return hand; }
  public class_1799 getItemStack() { return stack; }
  public class_1269 getCancellationResult() { return cancellationResult; }
  public void setCancellationResult(class_1269 result) { this.cancellationResult = result; }

  public static class RightClickBlock extends PlayerInteractEvent {
    private final class_1937 level;
    private final class_2338 pos;
    private final class_2350 face;
    private final class_3965 hit;
    public RightClickBlock(class_1937 level, class_1657 player, class_1268 hand, class_1799 stack,
                           class_2338 pos, class_2350 face, class_3965 hit) {
      super(player, hand, stack);
      this.level = level; this.pos = pos; this.face = face; this.hit = hit;
    }
    public class_1937 getLevel() { return level; }
    public class_2338 getPos() { return pos; }
    public class_2350 getFace() { return face; }
    public class_3965 getHitVec() { return hit; }
  }

  public static final class InteractionKeyMappingTriggered extends PlayerInteractEvent {
    private final boolean useItem;
    private boolean swingHand = true;
    public InteractionKeyMappingTriggered(class_1657 player, class_1268 hand, class_1799 stack, boolean useItem) {
      super(player, hand, stack); this.useItem = useItem;
    }
    public boolean isUseItem() { return useItem; }
    public boolean isSwingHand() { return swingHand; }
    public void setSwingHand(boolean value) { this.swingHand = value; }
  }
}
