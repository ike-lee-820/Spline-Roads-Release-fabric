package net.minecraftforge.client;

import java.util.*;
import net.minecraft.class_1921;

/** Fabric port: vanilla chunk rebuild only uses the solid layer here. */
public final class ChunkRenderTypeSet {
  private static final ChunkRenderTypeSet NONE = new ChunkRenderTypeSet(Set.of());
  private final Set<class_1921> types;

  private ChunkRenderTypeSet(Set<class_1921> types) { this.types = types; }
  public static ChunkRenderTypeSet of(class_1921... layers) {
    Set<class_1921> set = Collections.newSetFromMap(new IdentityHashMap<>());
    Collections.addAll(set, layers);
    return new ChunkRenderTypeSet(Collections.unmodifiableSet(set));
  }
  public static ChunkRenderTypeSet none() { return NONE; }
  public static ChunkRenderTypeSet union(ChunkRenderTypeSet a, ChunkRenderTypeSet b) {
    Set<class_1921> set = Collections.newSetFromMap(new IdentityHashMap<>());
    set.addAll(a.types); set.addAll(b.types);
    return new ChunkRenderTypeSet(Collections.unmodifiableSet(set));
  }
  public boolean contains(class_1921 layer) { return layer == null || types.contains(layer); }
  public boolean isEmpty() { return types.isEmpty(); }
}
