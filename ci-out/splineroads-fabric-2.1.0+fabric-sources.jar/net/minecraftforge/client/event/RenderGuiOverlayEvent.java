package net.minecraftforge.client.event;

import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraftforge.eventbus.api.Event;

public abstract class RenderGuiOverlayEvent extends Event {
  private final class_332 graphics;
  private final Overlay overlay;
  protected RenderGuiOverlayEvent(class_332 graphics, Overlay overlay) {
    this.graphics = graphics; this.overlay = overlay;
  }
  public class_332 getGuiGraphics() { return graphics; }
  public Overlay getOverlay() { return overlay; }

  public static final class Overlay {
    private final class_2960 id;
    public Overlay(class_2960 id) { this.id = id; }
    public class_2960 id() { return id; }
  }

  public static class Post extends RenderGuiOverlayEvent {
    public Post(class_332 graphics, Overlay overlay) { super(graphics, overlay); }
  }
}
