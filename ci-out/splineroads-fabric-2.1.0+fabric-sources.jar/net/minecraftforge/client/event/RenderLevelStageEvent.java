package net.minecraftforge.client.event;

import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraftforge.eventbus.api.Event;
import org.joml.Matrix4f;

/** Fabric port: carries the WorldRenderContext state the renderer needs. */
public final class RenderLevelStageEvent extends Event {
  public enum Stage {
    AFTER_SKY, AFTER_SOLID_BLOCKS, AFTER_CUTOUT_BLOCKS, AFTER_BLOCK_ENTITIES,
    AFTER_TRANSLUCENT_BLOCKS, AFTER_TRIPWIRE_BLOCKS, AFTER_PARTICLES, AFTER_WEATHER, AFTER_LEVEL
  }
  private final Stage stage;
  private final class_4587 pose;
  private final class_4184 camera;
  private final Matrix4f projection;
  private final class_4604 frustum;
  private final float tickDelta;

  public RenderLevelStageEvent(Stage stage, class_4587 pose, class_4184 camera, Matrix4f projection,
                               class_4604 frustum, float tickDelta) {
    this.stage = stage; this.pose = pose; this.camera = camera;
    this.projection = projection; this.frustum = frustum; this.tickDelta = tickDelta;
  }
  public Stage getStage() { return stage; }
  public class_4587 getPoseStack() { return pose; }
  public class_4184 getCamera() { return camera; }
  public Matrix4f getProjectionMatrix() { return projection; }
  public class_4604 getFrustum() { return frustum; }
  public float getPartialTick() { return tickDelta; }
}
