package net.minecraftforge.client.event;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import net.minecraftforge.eventbus.api.Event;

/**
 * Fabric port of Forge's RegisterShadersEvent.
 * The preferred path delegates to Fabric API's CoreShaderRegistrationCallback,
 * which loads assets/&lt;namespace&gt;/shaders/core/*.json, adds the programs to
 * GameRenderer and reloads them with the vanilla shader cycle. The legacy
 * path (a ResourceManager) is kept for callers that still construct shaders
 * directly.
 */
public final class RegisterShadersEvent extends Event {
  private static final List<class_5944> REGISTERED = new ArrayList<>();
  private final CoreShaderRegistrationCallback.RegistrationContext core;
  private final class_5912 provider;

  public RegisterShadersEvent(Object source) {
    if (source instanceof CoreShaderRegistrationCallback.RegistrationContext context) {
      this.core = context;
      this.provider = location -> Optional.empty();
    } else {
      this.core = null;
      class_3300 manager = source instanceof class_3300 ready ? ready : null;
      this.provider = location -> {
        class_2960 key = location;
        if ("minecraft".equals(key.method_12836()) && key.method_12832().startsWith("shaders/core/road_world_")) {
          key = new class_2960("splineroads", key.method_12832());
        }
        if (manager == null) return Optional.empty();
        return manager.method_14486(key);
      };
    }
  }

  public class_5912 getResourceProvider() { return provider; }

  /** Registers a core shader through Fabric's reload-aware pipeline. */
  public void registerShader(class_2960 id, class_293 format,
                             Consumer<class_5944> callback) throws IOException {
    if (core == null) {
      registerShader(new class_5944(provider, id.method_12832(), format), callback);
      return;
    }
    try {
      Method register = CoreShaderRegistrationCallback.RegistrationContext.class
          .getMethod("register", class_2960.class, class_293.class, Consumer.class);
      register.invoke(core, id, format, callback);
    } catch (InvocationTargetException failure) {
      Throwable cause = failure.getCause();
      if (cause instanceof IOException io) throw io;
      throw new IOException(cause == null ? failure : cause);
    } catch (ReflectiveOperationException failure) {
      throw new IOException(failure);
    }
  }

  public void registerShader(class_5944 shader, Consumer<class_5944> consumer) {
    REGISTERED.add(shader);
    consumer.accept(shader);
  }
  public static List<class_5944> registered() { return REGISTERED; }
}
