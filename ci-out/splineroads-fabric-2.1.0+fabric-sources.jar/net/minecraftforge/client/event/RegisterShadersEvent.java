package net.minecraftforge.client.event;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import net.minecraftforge.eventbus.api.Event;

/**
 * Fabric port of Forge's RegisterShadersEvent.
 * On 1.20.1 vanilla, ShaderInstance takes a String shader name and resolves
 * {@code minecraft:shaders/core/<name>.json}; our shader JSONs live in the
 * mod namespace, so the provider transparently rewrites only those lookups.
 */
public final class RegisterShadersEvent extends Event {
  private static final List<class_5944> REGISTERED = new ArrayList<>();
  private final class_5912 provider;

  public RegisterShadersEvent(Object source) {
    class_3300 manager = source instanceof class_3300 ready ? ready : null;
    this.provider = location -> {
      class_2960 key = location;
      if ("minecraft".equals(key.method_12836()) && key.method_12832().startsWith("shaders/core/road_world_")) {
        key = new class_2960("splineroads", key.method_12832());
      }
      try {
        if (manager != null) return manager.method_14486(key);
        Method getter = source.getClass().getMethod("getResource", class_2960.class);
        Object value = getter.invoke(source, key);
        return value instanceof Optional<?> optional
            ? (Optional<class_3298>) optional
            : Optional.empty();
      } catch (Throwable failure) {
        return Optional.empty();
      }
    };
  }

  public class_5912 getResourceProvider() { return provider; }
  public void registerShader(class_5944 shader, Consumer<class_5944> consumer) {
    REGISTERED.add(shader);
    consumer.accept(shader);
  }
  public static List<class_5944> registered() { return REGISTERED; }
}
