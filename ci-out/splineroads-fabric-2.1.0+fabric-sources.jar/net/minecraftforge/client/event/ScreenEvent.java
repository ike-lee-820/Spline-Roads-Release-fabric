package net.minecraftforge.client.event;

import net.minecraft.class_437;
import net.minecraftforge.eventbus.api.Event;

public abstract class ScreenEvent extends Event {
  private final class_437 oldScreen;
  protected ScreenEvent(class_437 oldScreen) { this.oldScreen = oldScreen; }
  public class_437 getScreen() { return oldScreen; }

  public static final class Opening extends ScreenEvent {
    private class_437 newScreen;
    public Opening(class_437 oldScreen, class_437 newScreen) { super(oldScreen); this.newScreen = newScreen; }
    public class_437 getNewScreen() { return newScreen; }
    public void setNewScreen(class_437 screen) { this.newScreen = screen; }
  }
}
