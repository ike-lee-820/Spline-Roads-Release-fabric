package net.minecraftforge.client.event;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraftforge.eventbus.api.Event;

public final class RegisterClientCommandsEvent extends Event {
  private final CommandDispatcher<class_2168> dispatcher;
  public RegisterClientCommandsEvent(CommandDispatcher<class_2168> dispatcher) { this.dispatcher = dispatcher; }
  public CommandDispatcher<class_2168> getDispatcher() { return dispatcher; }
}
