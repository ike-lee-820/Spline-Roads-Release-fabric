package net.minecraftforge.client.event;

import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraftforge.eventbus.api.Event;

public abstract class ModelEvent extends Event {
  public static final class ModifyBakingResult extends ModelEvent {
    private final Map<class_2960, class_1087> models;
    public ModifyBakingResult(Map<class_2960, class_1087> models) { this.models = models; }
    public Map<class_2960, class_1087> getModels() { return models; }
  }
  public static final class BakingCompleted extends ModelEvent {
    private final class_1092 manager;
    public BakingCompleted(class_1092 manager) { this.manager = manager; }
    public class_1092 getModelManager() { return manager; }
  }
}
