package net.minecraftforge.client.model;

import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_806;
import net.minecraft.class_809;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.data.ModelData;
import net.minecraftforge.client.model.data.ModelDataContext;

/**
 * Fabric port of Forge's wrapper. The five-argument getQuads()/getRenderTypes()
 * are ordinary methods on this class (not vanilla interface methods), so the
 * original annotations keep compiling. The three-argument vanilla
 * entry point forwards into them with ModelData.EMPTY.
 */
public class BakedModelWrapper<T extends class_1087> implements ForgeBakedModel {
  protected final T originalModel;

  public BakedModelWrapper(T originalModel) { this.originalModel = originalModel; }

  public List<class_777> method_4707(class_2680 state, class_2350 side, class_5819 random) {
    return getQuads(state, side, random, ModelDataContext.current(), null);
  }
  public boolean method_4708() { return originalModel.method_4708(); }
  public boolean method_4712() { return originalModel.method_4712(); }
  public boolean method_24304() { return originalModel.method_24304(); }
  public boolean method_4713() { return originalModel.method_4713(); }
  public class_1058 method_4711() { return originalModel.method_4711(); }
  public class_809 method_4709() { return originalModel.method_4709(); }
  public class_806 method_4710() { return originalModel.method_4710(); }

  public ModelData getModelData(class_1920 level, class_2338 pos, class_2680 state, ModelData input) {
    return ForgeBakedModel.super.getModelData(level, pos, state, input);
  }
  public List<class_777> getQuads(class_2680 state, class_2350 side, class_5819 random,
                                            ModelData data, class_1921 layer) {
    return originalModel.method_4707(state, side, random);
  }
  public ChunkRenderTypeSet getRenderTypes(class_2680 state, class_5819 random, ModelData data) {
    return ChunkRenderTypeSet.of(class_1921.method_23577());
  }
  public boolean useAmbientOcclusion(class_2680 state) { return method_4708(); }
  public boolean useAmbientOcclusion(class_2680 state, class_1921 layer) { return method_4708(); }
}
