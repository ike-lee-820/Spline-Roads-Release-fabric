package net.minecraftforge.client.model;

import java.lang.reflect.Method;
import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.data.ModelData;

/**
 * Fabric port: Forge patches BakedModel with these overloads. On Fabric that
 * patch does not exist, so the extra methods live on this sub-interface.
 * Vanilla's three-argument getQuads() still drives rendering; getModelData()
 * recovers per-block data from the BlockEntity (e.g. RoadFillEntity) by reflection.
 */
public interface ForgeBakedModel extends class_1087 {
  default ModelData getModelData(class_1920 level, class_2338 pos, class_2680 state, ModelData input) {
    ModelData result = input == null ? ModelData.EMPTY : input;
    if (level == null || pos == null) return result;
    try {
      class_2586 entity = level.method_8321(pos);
      if (entity == null) return result;
      Method accessor = entity.getClass().getMethod("getModelData");
      Object value = accessor.invoke(entity);
      if (value instanceof ModelData data) return ModelData.merge(result, data);
    } catch (Throwable ignored) {
      // Plain vanilla block entities have no getModelData().
    }
    return result;
  }

  default List<class_777> getQuads(class_2680 state, class_2350 side, class_5819 random,
                                   ModelData data, class_1921 layer) {
    return method_4707(state, side, random);
  }
  default ChunkRenderTypeSet getRenderTypes(class_2680 state, class_5819 random, ModelData data) {
    return ChunkRenderTypeSet.of(class_1921.method_23577());
  }
  default boolean useAmbientOcclusion(class_2680 state) { return method_4708(); }
  default boolean useAmbientOcclusion(class_2680 state, class_1921 layer) { return method_4708(); }
  default boolean isVanillaAdapter() { return true; }
}
