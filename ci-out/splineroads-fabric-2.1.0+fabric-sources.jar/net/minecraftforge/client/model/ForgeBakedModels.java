package net.minecraftforge.client.model;

import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;

/** Adapts a plain vanilla BakedModel to the Forge-style extension interface. */
public final class ForgeBakedModels {
  public static ForgeBakedModel of(class_1087 model) {
    if (model instanceof ForgeBakedModel extended) return extended;
    return new Plain(model);
  }

  private static final class Plain implements ForgeBakedModel {
    private final class_1087 delegate;
    private Plain(class_1087 delegate) { this.delegate = delegate; }
    public List<class_777> method_4707(class_2680 state, class_2350 side, class_5819 random) {
      return delegate.method_4707(state, side, random);
    }
    public boolean method_4708() { return delegate.method_4708(); }
    public boolean method_4712() { return delegate.method_4712(); }
    public boolean method_24304() { return delegate.method_24304(); }
    public boolean method_4713() { return delegate.method_4713(); }
    public class_1058 method_4711() { return delegate.method_4711(); }
    public net.minecraft.class_809 method_4709() {
      return delegate.method_4709();
    }
    public net.minecraft.class_806 method_4710() {
      return delegate.method_4710();
    }
  }
  private ForgeBakedModels() {}
}
