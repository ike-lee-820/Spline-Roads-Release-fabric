package net.minecraftforge.network;

import java.util.concurrent.Executor;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public final class NetworkEvent {
  public static final class Context {
    private final MinecraftServer server;
    private final class_3222 sender;
    private final Executor executor;
    private volatile boolean handled;

    public Context(MinecraftServer server, class_3222 sender, Executor executor) {
      this.server = server; this.sender = sender; this.executor = executor;
    }
    public void enqueueWork(Runnable work) { executor.execute(work); }
    public void setPacketHandled(boolean value) { this.handled = value; }
    public boolean getPacketHandled() { return handled; }
    public class_3222 getSender() { return sender; }
    public MinecraftServer getServer() { return server; }
  }
  private NetworkEvent() {}
}
