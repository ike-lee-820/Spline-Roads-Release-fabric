package net.minecraftforge.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_638;

/** Client-only half of the Forge SimpleChannel bridge. Never loaded on a dedicated server. */
public final class ClientNetworkSupport {

  public static void register(class_2960 id, FabricNetworkSupport.Receiver receiver) {
    ClientPlayNetworking.registerGlobalReceiver(id,
        (client, handler, buf, responseSender) -> receiver.receive(buf, null, null));
  }

  public static void send(class_2960 id, class_2540 buf) {
    ClientPlayNetworking.send(id, buf);
  }

  public static String dimension() {
    var level = net.minecraft.class_310.method_1551().field_1687;
    return level == null ? null : level.method_27983().method_29177().toString();
  }

  private ClientNetworkSupport() {}
}
