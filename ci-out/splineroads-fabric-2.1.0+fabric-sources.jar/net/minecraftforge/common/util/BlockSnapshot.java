package net.minecraftforge.common.util;

import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_5321;

/** Fabric port: a lightweight immutable description of a block location. */
public final class BlockSnapshot {
  private final class_5321<class_1937> dimension;
  private final class_2338 pos;
  private final class_2680 state;

  private BlockSnapshot(class_5321<class_1937> dimension, class_2338 pos, class_2680 state) {
    this.dimension = dimension; this.pos = pos; this.state = state;
  }

  public static BlockSnapshot create(class_5321<class_1937> dimension, class_1936 level, class_2338 pos) {
    return new BlockSnapshot(dimension, pos.method_10062(), level.method_8320(pos));
  }

  public class_5321<class_1937> getDimension() { return dimension; }
  public class_2338 getPos() { return pos; }
  public class_2680 getState() { return state; }
  public class_2680 getReplacedBlock() { return state; }
}
