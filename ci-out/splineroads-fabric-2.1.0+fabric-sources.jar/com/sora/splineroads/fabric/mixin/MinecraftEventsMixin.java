package com.sora.splineroads.fabric.mixin;

import com.sora.splineroads.fabric.ScreenEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.ForgeEventBus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Supplies the two client events Fabric API does not expose directly. */
@Mixin(class_310.class)
public abstract class MinecraftEventsMixin {
  @Inject(method = "setScreen(Lnet/minecraft/client/gui/screens/Screen;)V",
      at = @At("HEAD"), cancellable = true, require = 1)
  private void sr$opening(class_437 requested, CallbackInfo info) {
    if (ScreenEvents.redirecting()) return;
    class_310 mc = class_310.method_1551();
    ScreenEvent.Opening event = new ScreenEvent.Opening(mc.field_1755, requested);
    ForgeEventBus.post(event);
    class_437 replacement = event.getNewScreen();
    if (replacement != requested) {
      ScreenEvents.redirect(() -> mc.method_1507(replacement));
      info.cancel();
    }
  }

  @Inject(method = "startUseItem()V", at = @At("HEAD"), cancellable = true, require = 1)
  private void sr$useItem(CallbackInfo info) {
    class_310 mc = class_310.method_1551();
    class_1657 player = mc.field_1724;
    if (player == null) return;
    class_1799 stack = player.method_5998(class_1268.field_5808);
    InputEvent.InteractionKeyMappingTriggered event =
        new InputEvent.InteractionKeyMappingTriggered(true, class_1268.field_5808);
    ForgeEventBus.post(event);
    if (event.isCanceled()) info.cancel();
  }
}
