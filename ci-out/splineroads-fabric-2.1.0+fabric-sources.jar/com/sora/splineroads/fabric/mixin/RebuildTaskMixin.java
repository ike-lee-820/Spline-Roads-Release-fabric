package com.sora.splineroads.fabric.mixin;

import com.sora.splineroads.client.RoadTerrainHandoff;
import com.sora.splineroads.fabric.FabricApiBridge;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiFunction;
import net.minecraft.class_1921;
import net.minecraft.class_287;
import net.minecraft.class_291;
import net.minecraft.class_750;
import net.minecraft.class_846;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fabric equivalent of Forge's terrain_upload.js vanilla transformer.
 * All lambda-targeted injects are optional (require = 0): if a future mapping
 * renames the synthetic methods the game still starts and the VBO renderer
 * keeps working. Field lookups are by type so mojmap / intermediary field
 * names do not matter.
 */
@Mixin(targets = "net.minecraft.client.renderer.chunk.ChunkRenderDispatcher$RenderChunk$RebuildTask")
public abstract class RebuildTaskMixin {
  private static final String DO_TASK =
      "doTask(Lnet/minecraft/client/renderer/ChunkBufferBuilderPack;)Ljava/util/concurrent/CompletableFuture;";
  private static final String UPLOAD_LAMBDA =
      "lambda$doTask$0(Ljava/util/List;Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$CompiledChunk;Lnet/minecraft/client/renderer/RenderType;Lcom/mojang/blaze3d/vertex/BufferBuilder$RenderedBuffer;)V";
  private static final String FINISH_LAMBDA =
      "lambda$doTask$1(Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$CompiledChunk;Ljava/util/List;Ljava/lang/Throwable;)Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher$ChunkTaskResult;";
  private static final ThreadLocal<class_1921> LAYER = new ThreadLocal<>();

  @Inject(method = DO_TASK, at = @At("HEAD"), require = 0)
  private void sr$begin(class_750 pack, CallbackInfo info) {
    try {
      Object chunk = FabricApiBridge.field(this, class_846.class_851.class);
      AtomicBoolean cancelled = (AtomicBoolean) FabricApiBridge.field(this, AtomicBoolean.class);
      class_846 dispatcher = chunk == null ? null
          : (class_846) FabricApiBridge.field(chunk, class_846.class);
      if (chunk != null && cancelled != null && dispatcher != null)
        RoadTerrainHandoff.beginVanilla(this, (class_846.class_851) chunk, cancelled, dispatcher);
    } catch (Throwable ignored) { }
  }

  @Inject(method = DO_TASK, at = @At("RETURN"), require = 0)
  @SuppressWarnings("rawtypes")
  private void sr$end(class_750 pack, CallbackInfoReturnable<CompletableFuture> info) {
    try { RoadTerrainHandoff.endVanilla(info.getReturnValue(), this); }
    catch (Throwable ignored) { }
  }

  @Redirect(method = DO_TASK, require = 0,
      at = @At(value = "INVOKE",
          target = "Ljava/util/concurrent/CompletableFuture;handle(Ljava/util/function/BiFunction;)Ljava/util/concurrent/CompletableFuture;"))
  @SuppressWarnings({"rawtypes", "unchecked"})
  private CompletableFuture sr$complete(CompletableFuture future, BiFunction handler) {
    try { return RoadTerrainHandoff.completeVanilla(future, handler, this); }
    catch (Throwable ignored) { return future.handle(handler); }
  }

  @Inject(method = UPLOAD_LAMBDA, at = @At("HEAD"), require = 0)
  private void sr$layer(List<?> list, class_846.class_849 compiled,
                        class_1921 layer, class_287.class_7433 buffer, CallbackInfo info) {
    LAYER.set(layer);
  }

  @Redirect(method = UPLOAD_LAMBDA, require = 0,
      at = @At(value = "INVOKE",
          target = "Lnet/minecraft/client/renderer/chunk/ChunkRenderDispatcher;uploadChunkLayer(Lcom/mojang/blaze3d/vertex/BufferBuilder$RenderedBuffer;Lcom/mojang/blaze3d/vertex/VertexBuffer;)Ljava/util/concurrent/CompletableFuture;"))
  private CompletableFuture<Void> sr$upload(class_846 dispatcher,
                                            class_287.class_7433 data, class_291 live) {
    class_1921 layer = LAYER.get();
    if (layer == null) return dispatcher.method_3635(data, live);
    try { return RoadTerrainHandoff.uploadVanilla(dispatcher, data, live, this, layer); }
    catch (Throwable ignored) { return dispatcher.method_3635(data, live); }
  }

  @Inject(method = FINISH_LAMBDA, at = @At("HEAD"), require = 0)
  private void sr$beforeCommit(class_846.class_849 compiled, List<?> list,
                               Throwable failure, CallbackInfo info) {
    try { RoadTerrainHandoff.beforeCommit(this, failure); }
    catch (Throwable ignored) { }
  }

  @Redirect(method = FINISH_LAMBDA, require = 0,
      at = @At(value = "INVOKE",
          target = "Ljava/util/concurrent/atomic/AtomicReference;set(Ljava/lang/Object;)V"))
  private void sr$commit(AtomicReference<Object> reference, Object compiled) {
    try { RoadTerrainHandoff.commitVanilla(reference, compiled, this); }
    catch (Throwable ignored) { reference.set(compiled); }
  }
}
