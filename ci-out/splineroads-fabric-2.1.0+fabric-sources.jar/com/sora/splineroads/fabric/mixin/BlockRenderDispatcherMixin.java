package com.sora.splineroads.fabric.mixin;

import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import net.minecraftforge.client.model.data.ModelDataContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Equivalent of Forge's patched BlockRenderDispatcher.renderBatched, which
 * computes BakedModel.getModelData(level, pos, state, EMPTY) before meshing.
 * The mixin is deliberately descriptor-free (renderBatched is unique in 1.20.1)
 * and only handles a thread-local context, so it is safe if other renderers
 * are installed.
 */
@Mixin(class_776.class)
public abstract class BlockRenderDispatcherMixin {
  @Inject(method = "renderBatched", at = @At("HEAD"))
  private void sr$begin(class_2680 state, class_2338 pos, class_1920 level,
                        class_4587 pose, class_4588 consumer, boolean checkSides,
                        class_5819 random, CallbackInfo info) {
    class_1087 model = ((class_776) (Object) this).method_3349(state);
    ModelDataContext.begin(level, pos, state, model);
  }

  @Inject(method = "renderBatched", at = @At("RETURN"))
  private void sr$end(class_2680 state, class_2338 pos, class_1920 level,
                      class_4587 pose, class_4588 consumer, boolean checkSides,
                      class_5819 random, CallbackInfo info) { ModelDataContext.end(); }
}
