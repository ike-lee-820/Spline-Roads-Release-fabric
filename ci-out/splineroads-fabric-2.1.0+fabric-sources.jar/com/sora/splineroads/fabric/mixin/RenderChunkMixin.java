package com.sora.splineroads.fabric.mixin;

import com.sora.splineroads.client.RoadChunkBuffers;
import com.sora.splineroads.client.RoadTerrainHandoff;
import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_291;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces the Forge coremod's interface injection on RenderChunk. */
@Mixin(targets = "net.minecraft.client.renderer.chunk.ChunkRenderDispatcher$RenderChunk")
public abstract class RenderChunkMixin implements RoadChunkBuffers {
  @Shadow @Final private Map<class_1921, class_291> buffers;

  @Override public Map<class_1921, class_291> splineroads$buffers() { return buffers; }

  @Inject(method = "reset", at = @At("HEAD"))
  private void sr$release(CallbackInfo info) {
    RoadTerrainHandoff.release(this);
  }
}
