package com.sora.splineroads.fabric.mixin;

import com.sora.splineroads.fabric.PersistentData;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Persists planner settings in the player's own NBT, like Forge's ForgeData. */
@Mixin(class_1657.class)
public abstract class PlayerDataMixin {
  private static final String SR_KEY = "SplineRoadsPlanner";

  @Inject(method = "addAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V", at = @At("TAIL"))
  private void sr$save(class_2487 tag, CallbackInfo info) {
    class_1657 self = (class_1657) (Object) this;
    if (!(self instanceof class_3222)) return;
    class_2487 data = PersistentData.snapshot(self.method_5667());
    if (data != null) tag.method_10566(SR_KEY, data);
  }

  @Inject(method = "readAdditionalSaveData(Lnet/minecraft/nbt/CompoundTag;)V", at = @At("TAIL"))
  private void sr$load(class_2487 tag, CallbackInfo info) {
    class_1657 self = (class_1657) (Object) this;
    if (tag.method_10573(SR_KEY, 10)) PersistentData.restore(self.method_5667(), tag.method_10562(SR_KEY));
  }
}
