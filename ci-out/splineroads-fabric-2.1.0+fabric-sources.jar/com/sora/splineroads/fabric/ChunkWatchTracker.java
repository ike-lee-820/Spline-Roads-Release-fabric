package com.sora.splineroads.fabric;

import java.util.*;
import net.minecraft.class_1923;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.event.level.ChunkWatchEvent;
import net.minecraftforge.eventbus.api.ForgeEventBus;

/**
 * Approximates Forge's ChunkWatchEvent.Watch / UnWatch from each player's
 * tracking radius. RoadNetwork.watch() only needs the set of visible chunks,
 * which this reproduces without a mixin into the chunk tracker.
 */
public final class ChunkWatchTracker {
  private static final Map<UUID, Set<Long>> LAST = new HashMap<>();

  public static void tick(MinecraftServer server) {
    if (server == null || server.method_3780() % 5 != 0) return;
    int radius = Math.max(2, server.method_3760().method_14568());
    Set<UUID> online = new HashSet<>();
    for (class_3222 player : server.method_3760().method_14571()) {
      UUID id = player.method_5667();
      online.add(id);
      int cx = ((int) Math.floor(player.method_23317())) >> 4;
      int cz = ((int) Math.floor(player.method_23321())) >> 4;
      Set<Long> now = new HashSet<>();
      for (int x = -radius; x <= radius; x++)
        for (int z = -radius; z <= radius; z++)
          now.add(class_1923.method_8331(cx + x, cz + z));
      Set<Long> previous = LAST.getOrDefault(id, Set.of());
      class_3218 level = player.method_51469();
      for (long packed : now) if (!previous.contains(packed))
        ForgeEventBus.post(new ChunkWatchEvent.Watch(player, unpack(packed), level));
      for (long packed : previous) if (!now.contains(packed))
        ForgeEventBus.post(new ChunkWatchEvent.UnWatch(player, unpack(packed), level));
      LAST.put(id, now);
    }
    LAST.keySet().retainAll(online);
  }

  private static class_1923 unpack(long packed) {
    return new class_1923((int) packed, (int) (packed >> 32));
  }
  public static void clear() { LAST.clear(); }
  private ChunkWatchTracker() {}
}
