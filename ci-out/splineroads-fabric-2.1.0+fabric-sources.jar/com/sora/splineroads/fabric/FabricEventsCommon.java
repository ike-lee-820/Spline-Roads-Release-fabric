package com.sora.splineroads.fabric;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.ForgeEventBus;

/** Server-side event mapping. Only common (non-client) Fabric APIs are linked. */
public final class FabricEventsCommon {
  public static void register() {
    ServerTickEvents.END_SERVER_TICK.register(server -> {
      ForgeEventBus.post(new TickEvent.ServerTickEvent(TickEvent.Phase.END, server));
      ChunkWatchTracker.tick(server);
    });
    ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
      ForgeEventBus.post(new ServerStoppingEvent(server));
      ChunkWatchTracker.clear();
    });
    ServerLifecycleEvents.SERVER_STOPPED.register(server ->
        ForgeEventBus.post(new ServerStoppedEvent(server)));
    ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
      class_3222 player = (class_3222) FabricApiBridge.field(handler, class_3222.class);
      if (player != null) ForgeEventBus.post(new PlayerEvent.PlayerLoggedOutEvent(player));
    });
    CommandRegistrationCallback.EVENT.register((dispatcher, access, environment) -> {
      @SuppressWarnings("unchecked")
      CommandDispatcher<class_2168> typed =
          (CommandDispatcher<class_2168>) (Object) dispatcher;
      ForgeEventBus.post(new RegisterCommandsEvent(typed));
    });
    ServerChunkEvents.CHUNK_LOAD.register((world, chunk) -> postChunk(world, chunk, true));
    ServerChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> postChunk(world, chunk, false));
    PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, entity) -> {
      Object[] args = {world, player, pos, state, entity};
      class_1937 level = FabricApiBridge.arg(class_1937.class, args);
      class_1657 who = FabricApiBridge.arg(class_1657.class, args);
      class_2338 at = FabricApiBridge.arg(class_2338.class, args);
      class_2680 block = FabricApiBridge.arg(class_2680.class, args);
      if (level == null || who == null || at == null || block == null) return true;
      BlockEvent.BreakEvent event = new BlockEvent.BreakEvent(level, at, block, who);
      ForgeEventBus.post(event);
      return !event.isCanceled();
    });
    UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
      Object[] args = {player, world, hand, hitResult};
      class_1657 who = FabricApiBridge.arg(class_1657.class, args);
      class_1937 level = FabricApiBridge.arg(class_1937.class, args);
      class_1268 used = FabricApiBridge.arg(class_1268.class, args);
      class_3965 hit = FabricApiBridge.arg(class_3965.class, args);
      if (who == null || level == null || hit == null) return class_1269.field_5811;
      class_1268 actual = used == null ? class_1268.field_5808 : used;
      PlayerInteractEvent.RightClickBlock event = new PlayerInteractEvent.RightClickBlock(
          level, who, actual, who.method_5998(actual),
          hit.method_17777(), hit.method_17780(), hit);
      ForgeEventBus.post(event);
      return event.isCanceled() ? event.getCancellationResult() : class_1269.field_5811;
    });
    // Optional: dimension change is only a convenience for clearing drafts.
    FabricApiBridge.on("net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents", "AFTER_RESPAWN", args -> {
      class_3222 player = FabricApiBridge.arg(class_3222.class, args);
      if (player != null) ForgeEventBus.post(new PlayerEvent.PlayerChangedDimensionEvent(player));
      return null;
    });
  }

  private static void postChunk(Object world, Object chunk, boolean load) {
    class_1937 level = FabricApiBridge.arg(class_1937.class, new Object[]{world});
    class_2818 section = FabricApiBridge.arg(class_2818.class, new Object[]{chunk});
    if (level == null || section == null) return;
    ForgeEventBus.post(load ? new ChunkEvent.Load(level, section)
                            : new ChunkEvent.Unload(level, section));
  }
  private FabricEventsCommon() {}
}
