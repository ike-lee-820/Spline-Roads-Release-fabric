package com.sora.splineroads.fabric;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2487;
import net.minecraft.class_3222;

/**
 * Fabric port of Forge's Entity.getPersistentData() for planner settings.
 * Values are mirrored into the player's saved NBT by PlayerDataMixin, so the
 * radius / undo / cache settings survive a server restart.
 */
public final class PersistentData {
  private static final Map<UUID, class_2487> DATA = new ConcurrentHashMap<>();

  public static class_2487 of(class_3222 player) {
    return DATA.computeIfAbsent(player.method_5667(), key -> new class_2487());
  }
  public static class_2487 snapshot(UUID id) {
    class_2487 tag = DATA.get(id);
    return tag == null || tag.method_33133() ? null : tag.method_10553();
  }
  public static void restore(UUID id, class_2487 tag) {
    if (tag != null && !tag.method_33133()) DATA.put(id, tag.method_10553());
  }
  public static void clear(UUID id) { DATA.remove(id); }
  public static void clear() { DATA.clear(); }
  private PersistentData() {}
}
