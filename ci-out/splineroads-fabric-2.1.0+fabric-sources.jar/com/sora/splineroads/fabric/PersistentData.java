package com.sora.splineroads.fabric;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2487;
import net.minecraft.class_3222;

/**
 * Fabric port of Forge's Entity.getPersistentData() for the planner settings.
 * Values live for the lifetime of the server process (they are not written to
 * player NBT); see MIGRATION.md.
 */
public final class PersistentData {
  private static final Map<UUID, class_2487> DATA = new ConcurrentHashMap<>();

  public static class_2487 of(class_3222 player) {
    return DATA.computeIfAbsent(player.method_5667(), key -> new class_2487());
  }
  public static void clear(UUID id) { DATA.remove(id); }
  public static void clear() { DATA.clear(); }
  private PersistentData() {}
}
