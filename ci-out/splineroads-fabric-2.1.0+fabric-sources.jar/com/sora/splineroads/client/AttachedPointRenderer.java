package com.sora.splineroads.client;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.world.*;
import com.sora.splineroads.world.RoadIndex.Built;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_761;
import net.minecraft.client.renderer.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT)
public final class AttachedPointRenderer {
  private static boolean accepts(class_1799 s){return s.method_7909() instanceof RoadTool||s.method_7909() instanceof ElevatedPointTool||s.method_7909() instanceof AttachedPointTool||s.method_7909() instanceof LaneLineTool||s.method_7909() instanceof InterchangeTool;}
  @SubscribeEvent public static void render(RenderLevelStageEvent e){
    if(e.getStage()!=RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES)return;var mc=class_310.method_1551();if(mc.field_1724==null||LanePointRenderer.accepts(mc.field_1724.method_6047())||LanePointRenderer.accepts(mc.field_1724.method_6079())||!(accepts(mc.field_1724.method_6047())||accepts(mc.field_1724.method_6079())))return;
    var camera=e.getCamera().method_19326();var pose=e.getPoseStack();var buffer=mc.method_22940().method_23000();var lines=buffer.getBuffer(class_1921.method_23594());
    pose.method_22903();pose.method_22904(-camera.field_1352,-camera.field_1351,-camera.field_1350);
    for(var road:ClientToolIndex.near(camera.field_1352,camera.field_1350,false))if(ClientRoads.active(road.record.id()))for(var p:road.record.settings().options().attachments().points()){
      if(road.record.settings().options().routing().controls().stream().anyMatch(c->c.id().equals(p.id())))continue;var v=p.position();if(camera.method_1028(v.x(),v.y(),v.z())>96*96)continue;
      class_761.method_22982(pose,lines,new class_238(v.x()-.22,v.y()+1.65,v.z()-.22,v.x()+.22,v.y()+2.15,v.z()+.22),p.elevated()?.2f:1f,p.elevated()?.8f:.12f,p.elevated()?1f:.12f,1f);
      class_761.method_22982(pose,lines,new class_238(v.x()-.025,v.y()+.05,v.z()-.025,v.x()+.025,v.y()+1.65,v.z()+.025),1f,.45f,.35f,1f);
    }pose.method_22909();buffer.method_22994(class_1921.method_23594());
  }
}
