package com.sora.splineroads.client;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Control;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.world.*;
import com.sora.splineroads.world.RoadIndex.Built;
import com.mojang.blaze3d.vertex.*;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.*;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2902;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

/** A client-only view of session-resident terrain and authoritative road/point records. */
public final class ManualPlannerScreen extends class_437 {
  final UUID session;private class_2487 state;private double cx,cz,zoom=3;private int tool=1,arms=4,endpointMode;
  private final List<class_4185> toolbar=new ArrayList<>();
  private class_4185 resumePreview;
  private String status="选择工具后单击地图；右键点可打开菜单";private boolean help;
  private record Point(String kind,UUID road,UUID id,class_2338 pos,V at){}
  private Point selected;private UUID selectedRoad;private final List<Point> points=new ArrayList<>();
  private boolean pressed,dragged,moving,openSelected;
  private final Set<UUID> hidden=new HashSet<>();
  private final Map<UUID,RoadIndex.Built> mapRoads=new LinkedHashMap<>();
  // Geometry/occlusion is independent of the mouse, selection tint and player
  // cursor. Reuse it until a map snapshot, node tile, hidden set or view changes.
  private long mapRevision,preparedRevision=-1;
  private double preparedCx,preparedCz,preparedZoom;
  private int preparedWidth,preparedHeight;
  private Set<UUID> preparedHidden=Set.of();
  private final List<Strip> preparedStrips=new ArrayList<>();
  private final List<Point> displayedPoints=new ArrayList<>();
  private UUID snapshot;private int nextPage,pageCount,expectedRoads,expectedNodes;private long snapshotAt;
  private final Map<UUID,RoadIndex.Built> pendingRoads=new LinkedHashMap<>();
  private final Map<Long,class_2487> pendingNodes=new HashMap<>();
  private final Map<Long,MapTile> tiles=new HashMap<>();private final Map<Long,class_2487> mapNodes=new HashMap<>();private int terrainStep=1,loadedTiles,totalTiles;
  private record MapTile(int[] colors,int[] heights){}
  /** Surface data only: no session, road, node, selection or editor state survives closing. */
  static final class SurfaceCache {
    final Map<Long,MapTile> tiles;class_1043 terrain;class_2960 texture;
    SurfaceCache(Map<Long,MapTile> tiles,class_1043 terrain,class_2960 texture){this.tiles=tiles;this.terrain=terrain;this.texture=texture;}
    void release(){if(texture!=null)class_310.method_1551().method_1531().method_4615(texture);terrain=null;texture=null;tiles.clear();}
  }
  void invalidateSurface(){
    tiles.clear();if(texture!=null)class_310.method_1551().method_1531().method_4615(texture);texture=null;
    if(terrain!=null){terrain=new class_1043(new class_1011(1024,1024,false));texture=class_310.method_1551().method_1531().method_4617("sr_manual_map",terrain);terrainReady=false;resetTerrain();}
  }
  int cacheSeconds(){return Math.max(0,Math.min(60,state.method_10550("CacheSeconds")));}
  int cacheRadius(){return Math.max(16,Math.min(2048,state.method_10550("Radius")));}
  SurfaceCache detachSurface(){var saved=new SurfaceCache(new HashMap<>(tiles),terrain,texture);tiles.clear();terrain=null;texture=null;return saved;}
  void restoreSurface(SurfaceCache saved){tiles.putAll(saved.tiles);saved.tiles.clear();terrain=saved.terrain;texture=saved.texture;saved.terrain=null;saved.texture=null;terrainReady=false;}
private double pressX,pressY,pressCenterX,pressCenterZ,pressAt;private V movingAt;private int axis;private long confirmAt;private double confirmX,confirmY;
  private int menuX=-1,menuY,terrainX,terrainZ,terrainCursor;private long terrainUploaded,terrainFinished;private int terrainScanStart;private boolean terrainReady,terrainDirty;private final int[] heights=new int[1024*1024];
  private class_1043 terrain;private class_2960 texture;private final Set<Integer> keys=new HashSet<>();
  ManualPlannerScreen(class_2487 t){super(class_2561.method_43470("Spline Roads · 手动规划"));session=t.method_25926("PlannerSession");state=t.method_10553();var p=class_310.method_1551().field_1724;cx=p.method_23317();cz=p.method_23321();Arrays.fill(heights,Integer.MIN_VALUE);}
  void state(class_2487 t){interchangePending=false;if(t.method_10545("MapRoads")||t.method_10545("Nodes"))mapRevision++;state=t.method_10553();tool=t.method_10550("Tool");arms=t.method_10550("Arms");endpointMode=Math.max(0,Math.min(3,t.method_10550("EndpointMode")));if(t.method_10545("MapRoads")){var ids=new HashSet<UUID>();for(class_2520 value:t.method_10554("MapRoads",class_2520.field_33260)){var r=RoadRecord.load((class_2487)value);ids.add(r.id());var old=mapRoads.get(r.id());if(old==null||!old.record.equals(r))mapRoads.put(r.id(),RoadIndex.Built.loading(r));}mapRoads.keySet().retainAll(ids);hidden.retainAll(ids);}if(t.method_10545("Nodes")){mapNodes.clear();for(class_2520 value:t.method_10554("Nodes",class_2520.field_33260)){var n=(class_2487)value;mapNodes.put(n.method_10537("Pos"),n);}}updateToolbar();}
  void beginSnapshot(class_2487 t){snapshot=t.method_25926("MapSnapshot");nextPage=0;pageCount=t.method_10550("Pages");expectedRoads=t.method_10550("RoadCount");expectedNodes=t.method_10550("NodeCount");pendingRoads.clear();pendingNodes.clear();snapshotAt=net.minecraft.class_156.method_658();if(expectedRoads<0||expectedNodes<0||pageCount<1||pageCount>Math.max(1,(long)expectedRoads+expectedNodes))throw new IllegalArgumentException("规划地图批次数量错误，请重新打开");status="正在加载规划道路…";}
  boolean loading(){return snapshot!=null;}
  boolean snapshotExpired(long now){return loading()&&now-snapshotAt>30000;}
  void failSnapshot(String message){snapshot=null;pendingRoads.clear();pendingNodes.clear();status=message;}
  void page(class_2487 t){
    if(snapshot==null||!t.method_25928("MapSnapshot")||!snapshot.equals(t.method_25926("MapSnapshot")))return;
    if(t.method_10550("Pages")!=pageCount||t.method_10550("Page")!=nextPage)throw new IllegalArgumentException("规划地图分批顺序错误，请重新打开");
    for(class_2520 value:t.method_10554("MapRoads",class_2520.field_33260)){var r=RoadRecord.load((class_2487)value);var old=mapRoads.get(r.id());pendingRoads.put(r.id(),old!=null&&old.record.equals(r)?old:RoadIndex.Built.loading(r));}
    for(class_2520 value:t.method_10554("Nodes",class_2520.field_33260)){var node=(class_2487)value;pendingNodes.put(node.method_10537("Pos"),node);}
    if(pendingRoads.size()>expectedRoads||pendingNodes.size()>expectedNodes)throw new IllegalArgumentException("规划地图数据数量错误，请重新打开");
    snapshotAt=net.minecraft.class_156.method_658();
    if(++nextPage==pageCount){
      if(pendingRoads.size()!=expectedRoads||pendingNodes.size()!=expectedNodes)throw new IllegalArgumentException("规划地图数据不完整，请重新打开");
      mapRevision++;mapRoads.clear();mapRoads.putAll(pendingRoads);mapNodes.clear();mapNodes.putAll(pendingNodes);hidden.retainAll(mapRoads.keySet());pendingRoads.clear();pendingNodes.clear();snapshot=null;status=hint();
    }
  }
  void result(boolean success,String message){if(!message.isEmpty())status=message.equals("已选择地图工具")?hint():message;}
  void refresh(){if(field_22787==null)return;var t=command("manualRefresh");ClientRoads.sendAction(t);}
  private class_2487 command(String action){var t=new class_2487();t.method_10582("Action",action);t.method_25927("PlannerSession",session);return t;}
  private int left(){return 116;}private int top(){return 36;}private int right(){return field_22789-8;}private int bottom(){return field_22790-43;}
  private double sx(double x){return (left()+right())*.5+(x-cx)*zoom;}private double sy(double z){return (top()+bottom())*.5+(z-cz)*zoom;}
  private double wx(double x){return cx+(x-(left()+right())*.5)/zoom;}private double wz(double y){return cz+(y-(top()+bottom())*.5)/zoom;}
  private boolean map(double x,double y){return x>=left()&&x<right()&&y>=top()&&y<bottom();}
  @Override protected void method_25426(){
    toolbar.clear();String[] labels={"1  指针","2  端点","3  道路连接","4  匝道连接","5  自动立交","6  收费站","7  环岛"};
    int step=Math.min(25,Math.max(10,(field_22790-(field_22790>=240?144:120))/7));
    for(int i=0;i<7;i++){int n=i+1;toolbar.add(method_37063(class_4185.method_46430(class_2561.method_43470(labels[i]),b->choose(n)).method_46434(8,38+i*step,100,step-3).method_46431()));}
    method_37063(class_4185.method_46430(class_2561.method_43470("清除选点"),b->{selected=null;selectedRoad=null;moving=false;menuX=-1;confirmAt=0;send("manualClear",null,null,0,0);}).method_46434(8,41+7*step,100,20).method_46431());
    if(field_22790>=240)method_37063(class_4185.method_46430(class_2561.method_43470("回到玩家"),b->{cx=field_22787.field_1724.method_23317();cz=field_22787.field_1724.method_23321();resetTerrain();}).method_46434(8,65+7*step,100,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("设置"),b->field_22787.method_1507(new PlannerSettings())).method_46434(field_22789-158,8,50,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("? 操作说明"),b->help=!help).method_46434(field_22789-102,8,94,20).method_46431());
    resumePreview=method_37063(class_4185.method_46430(class_2561.method_43470("返回设置"),b->ManualPlannerClient.resumeMapPreview()).method_46434(8,field_22790-54,100,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("关闭地图"),b->method_25419()).method_46434(8,field_22790-28,100,20).method_46431());
    updateToolbar();if(terrain==null){terrain=new class_1043(new class_1011(1024,1024,false));texture=field_22787.method_1531().method_4617("sr_manual_map",terrain);}resetTerrain();
  }
  private void updateToolbar(){for(int i=0;i<toolbar.size();i++){var text=toolbar.get(i).method_25369().getString();if(i==4)text="5  "+arms+"向立交";if(i==1)text="2  "+endpointName();toolbar.get(i).method_25355(class_2561.method_43470(text).method_27692(i+1==tool?net.minecraft.class_124.field_1075:net.minecraft.class_124.field_1068));}}
  private void choose(int n){interchangePending=false;if(tool!=n){selected=null;selectedRoad=null;openSelected=false;}tool=n;updateToolbar();menuX=-1;moving=false;var t=command("manualTool");t.method_10569("Tool",tool);t.method_10569("Arms",arms);t.method_10569("EndpointMode",endpointMode);ClientRoads.sendAction(t);status=hint();}
  private String hint(){return switch(tool){case 2->"Ctrl＋滚轮切换：道路端点 → 路口点 → 附属点 → 出入点；当前："+endpointName();case 3->"选择端点或附属点 A → B；Ctrl：经过点；左 Alt：控制点";case 4->"Ctrl：创建车道点；选 A / B；左 Alt：匝道放置点";case 5->"双击主路依次选 AB、CD、EF；3/5向末端选 C/E；Ctrl＋滚轮切换向数";case 6->"单击道路断面，或依次选择端点 A / B";case 7->"单击空闲端点作为环岛圆心";default->"首次单击选中，再次单击打开；右键菜单；H 恢复隐藏";};}
  private void resetTerrain(){
    int step=Math.max(1,(int)Math.ceil(Math.max((right()-left())/zoom,(bottom()-top())/zoom)/1024));
    int nx=((int)Math.floor(cx)-512*step)&~15,nz=((int)Math.floor(cz)-512*step)&~15;
    if(terrainReady&&nx==terrainX&&nz==terrainZ&&step==terrainStep)return;
    terrainX=nx;terrainZ=nz;terrainStep=step;terrainReady=true;terrainCursor=0;
    var image=terrain.method_4525();for(int z=0;z<1024;z++)for(int x=0;x<1024;x++){
      int bx=terrainX+x*step,bz=terrainZ+z*step;var tile=tiles.get(net.minecraft.class_1923.method_8331(bx>>4,bz>>4));int at=(bz&15)*16+(bx&15);
      image.method_4305(x,z,tile==null?0xff252b30:tile.colors()[at]);heights[z*1024+x]=tile==null?Integer.MIN_VALUE:tile.heights()[at];
    }terrainDirty=true;
  }
  void terrain(class_2487 t){
    if(t.method_10545("Error")){status=t.method_10558("Error");return;}
    int[] colors=t.method_10561("Colors"),values=t.method_10561("Heights");if(colors.length!=256||values.length!=256)return;
    mapRevision++;int x=t.method_10550("ChunkX"),z=t.method_10550("ChunkZ");tiles.put(net.minecraft.class_1923.method_8331(x,z),new MapTile(colors,values));
    if(tiles.size()>60000){var player=class_310.method_1551().field_1724;tiles.keySet().removeIf(key->{var c=new net.minecraft.class_1923(key);return Math.hypot(c.field_9181*16+8-player.method_23317(),c.field_9180*16+8-player.method_23321())>2080;});}
    mapNodes.entrySet().removeIf(e->{var pos=class_2338.method_10092(e.getKey());return pos.method_10263()>>4==x&&pos.method_10260()>>4==z;});
    for(class_2520 item:t.method_10554("Nodes",class_2520.field_33260)){var n=(class_2487)item;mapNodes.put(n.method_10537("Pos"),n);}
    loadedTiles=t.method_10550("Loaded");totalTiles=t.method_10550("Total");paintTile(x,z);
  }
  private void paintTile(int cx,int cz){
    if(terrain==null)return;var tile=tiles.get(net.minecraft.class_1923.method_8331(cx,cz));var image=terrain.method_4525();boolean changed=false;
    for(int z=Math.max(0,Math.floorDiv(cz*16-terrainZ+terrainStep-1,terrainStep));z<1024&&terrainZ+z*terrainStep<cz*16+16;z++)
      for(int x=Math.max(0,Math.floorDiv(cx*16-terrainX+terrainStep-1,terrainStep));x<1024&&terrainX+x*terrainStep<cx*16+16;x++){
        int i=((terrainZ+z*terrainStep)&15)*16+((terrainX+x*terrainStep)&15);image.method_4305(x,z,tile.colors()[i]);heights[z*1024+x]=tile.heights()[i];changed=true;
      }
    if(changed)terrainDirty=true;
  }
  void release(){if(texture!=null)class_310.method_1551().method_1531().method_4615(texture);terrain=null;texture=null;tiles.clear();mapNodes.clear();mapRoads.clear();pendingRoads.clear();pendingNodes.clear();snapshot=null;hidden.clear();points.clear();displayedPoints.clear();preparedStrips.clear();preparedHidden=Set.of();mapRevision++;preparedRevision=-1;}
  @Override public void method_25393(){
    if(field_22787.field_1687==null||terrain==null)return;double step=(keys.contains(GLFW.GLFW_KEY_LEFT_SHIFT)?12:5)/zoom;if(keys.contains(GLFW.GLFW_KEY_W))cz-=step;if(keys.contains(GLFW.GLFW_KEY_S))cz+=step;if(keys.contains(GLFW.GLFW_KEY_A))cx-=step;if(keys.contains(GLFW.GLFW_KEY_D))cx+=step;
    double dx=cx-field_22787.field_1724.method_23317(),dz=cz-field_22787.field_1724.method_23321(),distance=Math.hypot(dx,dz);if(distance>2048){cx=field_22787.field_1724.method_23317()+dx*2048/distance;cz=field_22787.field_1724.method_23321()+dz*2048/distance;}
    int wanted=Math.max(1,(int)Math.ceil(Math.max((right()-left())/zoom,(bottom()-top())/zoom)/1024));
    if(Math.abs(cx-(terrainX+512*terrainStep))>192*terrainStep||Math.abs(cz-(terrainZ+512*terrainStep))>192*terrainStep||wanted!=terrainStep)resetTerrain();
    // Immediately seed visible loaded chunks; remote tiles arrive independently from the server.
    long end=System.nanoTime()+3_000_000;int read=0;while(read++<4096&&System.nanoTime()<end){
      int at=terrainCursor++&4095,x=(terrainX>>4)+(at&63),z=(terrainZ>>4)+(at>>6);long key=net.minecraft.class_1923.method_8331(x,z);if(tiles.containsKey(key))continue;
      var chunk=field_22787.field_1687.method_2935().method_2857(x,z,class_2806.field_12803,false);if(chunk==null)continue;
      int[] colors=new int[256],height=new int[256];for(int j=0;j<16;j++)for(int i=0;i<16;i++){int y=chunk.method_12005(class_2902.class_2903.field_13202,i,j);var pos=new class_2338(x*16+i,y,z*16+j);int color=chunk.method_8320(pos).method_26205(field_22787.field_1687,pos).field_16011;if(color==0)color=0x777777;int north=chunk.method_12005(class_2902.class_2903.field_13202,i,Math.max(0,j-1)),shade=y>north?255:y<north?175:220;colors[j*16+i]=0xff000000|((color&255)*shade/255<<16)|(((color>>8)&255)*shade/255<<8)|((color>>16)&255)*shade/255;height[j*16+i]=y+1;}tiles.put(key,new MapTile(colors,height));paintTile(x,z);
    }
  }
  private V terrain(double x,double y){int bx=(int)Math.floor(wx(x)),bz=(int)Math.floor(wz(y));var tile=tiles.get(net.minecraft.class_1923.method_8331(bx>>4,bz>>4));return tile==null?null:new V(wx(x),tile.heights()[(bz&15)*16+(bx&15)],wz(y));}
  private boolean interchangePending;private long roadClickAt;private double roadClickX,roadClickY;private UUID roadClickId;
  private boolean interchangeTerminal(){int count=state.method_10562("Selection").method_10565("Points").length;return (arms==3||arms==5)&&count==arms-1;}
  private boolean nodeVisible(class_2338 pos){boolean linked=false;for(var b:mapRoads.values())if(b.record.a().equals(pos)||b.record.b().equals(pos)){linked=true;if(!hidden.contains(b.record.id()))return true;}return !linked;}
  private void collect(){
    if(preparedRevision==mapRevision&&preparedCx==cx&&preparedCz==cz&&preparedZoom==zoom&&preparedWidth==field_22789&&preparedHeight==field_22790&&preparedHidden.equals(hidden))return;
    preparedRevision=-1;collectPoints();preparedStrips.clear();displayedPoints.clear();
    for(var b:mapRoads.values()){if(hidden.contains(b.record.id())||!visible(b.mesh))continue;var samples=b.mesh.samples();for(int i=1;i<samples.size();i++)preparedStrips.add(new Strip(b,samples.get(i-1),samples.get(i)));}
    preparedStrips.sort(Comparator.comparingDouble(Strip::height).thenComparing(q->q.road().record.id()));
    for(var p:points){var cover=road(sx(p.at().x()),sy(p.at().z()));if(cover!=null){var q=RoadQueries.horizontal(cover.mesh,p.at());if(q.horizontalDistance()<q.sample().halfWidth()&&q.sample().center().y()>p.at().y()+.1)continue;}displayedPoints.add(p);}
    preparedCx=cx;preparedCz=cz;preparedZoom=zoom;preparedWidth=field_22789;preparedHeight=field_22790;preparedHidden=Set.copyOf(hidden);preparedRevision=mapRevision;
  }
  private void collectPoints(){points.clear();var nodes=new HashSet<class_2338>();for(class_2520 value:mapNodes.values()){var t=(class_2487)value;var pos=class_2338.method_10092(t.method_10537("Pos"));if(!nodeVisible(pos))continue;nodes.add(pos);points.add(new Point(t.method_10577("JunctionMarker")?"junction":"node",null,null,pos,RoadRecord.readNode(t.method_10562("Node")).position()));}
    for(var b:mapRoads.values()){var r=b.record;if(hidden.contains(b.record.id())||!visible(b.mesh))continue;if(r.railway()){for(boolean first:new boolean[]{true,false})points.add(new Point("rail",r.id(),null,null,(first?r.start():r.end()).position()));continue;}if(!r.settings().style().ramp()&&LaneTopology.metadata(r).link()==null)for(boolean first:new boolean[]{true,false}){var pos=first?r.a():r.b();if(nodes.add(pos))points.add(new Point("node",null,null,pos,(first?r.start():r.end()).position()));}
      for(var p:LaneTopology.visiblePoints(r))points.add(new Point("lane",r.id(),p.id(),null,p.position()));var controls=new HashSet<UUID>();for(var p:r.settings().options().routing().controls()){controls.add(p.id());points.add(new Point("control",r.id(),p.id(),null,p.position()));}for(var p:r.settings().options().attachments().points())if(!controls.contains(p.id()))points.add(new Point(p.elevated()?"elevated":"attached",r.id(),p.id(),null,p.position()));
    }
  }
  private boolean visible(Mesh mesh){return sx(mesh.max().x())>=left()&&sx(mesh.min().x())<=right()&&sy(mesh.max().z())>=top()&&sy(mesh.min().z())<=bottom();}
  private Point pick(double x,double y){Point best=null;double distance=8;for(var p:points){double d=Math.hypot(sx(p.at().x())-x,sy(p.at().z())-y);if(d<8&&(best==null||p.at().y()>best.at().y()+.01||Math.abs(p.at().y()-best.at().y())<=.01&&d<distance)){var cover=road(x,y);if(cover!=null){var q=RoadQueries.horizontal(cover.mesh,p.at());if(q.horizontalDistance()<q.sample().halfWidth()&&q.sample().center().y()>p.at().y()+.1)continue;}distance=d;best=p;}}return best;}
  private RoadIndex.Built road(double x,double y){V hit=new V(wx(x),0,wz(y));RoadIndex.Built best=null;double height=-Double.MAX_VALUE,distance=Double.MAX_VALUE;for(var b:mapRoads.values()){if(hidden.contains(b.record.id())||!visible(b.mesh))continue;var q=RoadQueries.horizontal(b.mesh,hit);double h=q.sample().center().y();if(q.horizontalDistance()<=Math.max(q.sample().halfWidth(),5/zoom)&&(h>height+.01||Math.abs(h-height)<=.01&&(q.horizontalDistance()<distance||q.horizontalDistance()==distance&&(best==null||b.record.id().compareTo(best.record.id())<0)))){distance=q.horizontalDistance();height=h;best=b;}}return best;}
  private void target(class_2487 t,Point point,UUID road,V at){t.method_10549("X",at.x());t.method_10549("Y",at.y());t.method_10549("Z",at.z());if(point!=null){t.method_10582("PointKind",point.kind());if(point.pos()!=null)t.method_10544("Pos",point.pos().method_10063());if(point.id()!=null){t.method_25927("Point",point.id());t.method_10582("PointKind",point.kind());}if(point.road()!=null)t.method_25927("Road",point.road());}else if(road!=null)t.method_25927("Road",road);}
  private void send(String action,Point point,UUID id,double mx,double my){var t=command(action);if(point!=null||id!=null||action.equals("manualClick")){V at=point!=null?point.at():terrain(mx,my);if(id!=null&&point==null){var b=mapRoads.get(id);if(b!=null){var q=RoadQueries.horizontal(b.mesh,new V(wx(mx),0,wz(my)));at=new V(wx(mx),q.sample().center().y(),wz(my));}}if(at==null){status="该位置尚未加载，请靠近后重试";return;}target(t,point,id,at);}t.method_10556("Ctrl",method_25441());t.method_10556("Alt",net.minecraft.class_3675.method_15987(field_22787.method_22683().method_4490(),GLFW.GLFW_KEY_LEFT_ALT));ClientRoads.sendAction(t);}
  @Override public boolean method_25402(double x,double y,int button){
    if(menuX>=0){if(button==0&&x>=menuX&&x<menuX+122&&y>=menuY&&y<menuY+menuRows()*22){int item=(int)(y-menuY)/22;menuX=-1;if(item==0){if(selected!=null&&!selected.kind().equals("rail"))field_22787.method_1507(new PointDetails(selected));else send("manualDetails",selected,selectedRoad,x,y);}if(item==1)remove();if(item==2&&selectedRoad!=null){hidden.add(selectedRoad);selectedRoad=null;selected=null;status="已暂时隐藏；按 H 恢复全部";}if(item==2&&selectedRoad==null&&selected!=null){moving=true;movingAt=selected.at();axis=0;confirmAt=0;status="拖动 X / Z 箭头；双击左键确认，右键取消";}return true;}menuX=-1;}
    if(moving&&map(x,y)){
      if(button==1){moving=false;confirmAt=0;return true;}if(button!=0)return true;
      double px=sx(movingAt.x()),py=sy(movingAt.z());
      if(Math.abs(y-py)<7&&x>px+8&&x<px+55){axis=1;confirmAt=0;return true;}
      if(Math.abs(x-px)<7&&y>py+8&&y<py+55){axis=2;confirmAt=0;return true;}
      long now=net.minecraft.class_156.method_658();
      if(confirmAt!=0&&now-confirmAt<=300&&Math.hypot(x-confirmX,y-confirmY)<=5){move(movingAt);moving=false;confirmAt=0;}
      else {confirmAt=now;confirmX=x;confirmY=y;}
      return true;
    }
    if(tool==5&&interchangePending&&button==0&&map(x,y)){status="正在同步已选主路，请稍候选择下一条";return true;}
    if(super.method_25402(x,y,button))return true;if(!map(x,y))return false;collect();var previousPoint=selected;var previousRoad=selectedRoad;selected=tool==5&&!interchangeTerminal()?null:pick(x,y);var road=selected==null?road(x,y):null;selectedRoad=selected!=null&&selected.kind().equals("rail")?selected.road():road==null?null:road.record.id();openSelected=selected!=null&&previousPoint!=null&&same(selected,previousPoint)||selected==null&&selectedRoad!=null&&selectedRoad.equals(previousRoad);
    if(button==0&&selected!=null&&selected.kind().equals("rail")&&tool!=1){status="铁路端点 · 使用指针再次单击打开编辑";return true;}
    if(button==1){if(selected!=null||selectedRoad!=null){menuX=Math.min((int)x,right()-122);menuY=Math.min((int)y,bottom()-menuRows()*22);}return true;}
    if(button==0){pressed=true;dragged=false;pressX=x;pressY=y;pressCenterX=cx;pressCenterZ=cz;pressAt=net.minecraft.class_156.method_658();return true;}return false;
  }
  @Override public boolean method_25403(double x,double y,int button,double dx,double dy){if(moving&&axis!=0){movingAt=new V(axis==1?wx(x):movingAt.x(),movingAt.y(),axis==2?wz(y):movingAt.z());return true;}if(pressed&&button==0&&(dragged||net.minecraft.class_156.method_658()-pressAt>160&&Math.hypot(x-pressX,y-pressY)>3)){dragged=true;cx=pressCenterX-(x-pressX)/zoom;cz=pressCenterZ-(y-pressY)/zoom;return true;}return super.method_25403(x,y,button,dx,dy);}
  @Override public boolean method_25406(double x,double y,int button){if(moving&&axis!=0){axis=0;return true;}if(pressed&&button==0){pressed=false;if(dragged&&tool==1){selected=null;selectedRoad=null;openSelected=false;}if(dragged){roadClickAt=0;roadClickId=null;}if(!dragged&&map(x,y)){if(tool==5&&!interchangeTerminal()){
      long now=net.minecraft.class_156.method_658();if(selectedRoad!=null&&selectedRoad.equals(roadClickId)&&now-roadClickAt<=300&&Math.hypot(x-roadClickX,y-roadClickY)<=5){interchangePending=true;send("manualClick",null,selectedRoad,x,y);roadClickAt=0;roadClickId=null;}else{roadClickAt=now;roadClickId=selectedRoad;roadClickX=x;roadClickY=y;status="双击此主路以选择一对端点";}
    }else if(tool!=1||openSelected)send("manualClick",selected,selectedRoad,x,y);else status="已选中，再次单击打开设置；右键打开菜单";}return true;}return super.method_25406(x,y,button);}
  @Override public boolean method_25401(double x,double y,double delta){if(method_25441()&&tool==2){cycleEndpointMode(delta);return true;}if(method_25441()&&tool==5){cycleArms(delta);return true;}if(!map(x,y))return false;double beforeX=wx(x),beforeZ=wz(y);zoom=Math.max(minimumZoom(),Math.min(24,zoom*Math.pow(1.2,delta)));cx+=beforeX-wx(x);cz+=beforeZ-wz(y);return true;}
  private String endpointName(){return switch(endpointMode){case 1->"路口点";case 2->"附属点";case 3->"出入点";default->"道路端点";};}
  void cycleEndpointMode(double delta){if(delta==0)return;endpointMode=Math.floorMod(endpointMode+(delta>0?1:-1),4);choose(tool);}
  private double minimumZoom(){return Math.max(.025,Math.min(right()-left(),bottom()-top())/(4096.0*1.1));}
  void cycleArms(double delta){if(delta==0)return;arms=3+Math.floorMod(arms-3+(delta>0?1:-1),4);choose(tool);}
  @Override public boolean method_25404(int key,int scan,int modifiers){if(key>=GLFW.GLFW_KEY_1&&key<=GLFW.GLFW_KEY_7){choose(key-GLFW.GLFW_KEY_1+1);return true;}if(method_25441()&&(key==GLFW.GLFW_KEY_Z||key==GLFW.GLFW_KEY_Y)){ClientRoads.sendAction(command(key==GLFW.GLFW_KEY_Z?"manualUndo":"manualRedo"));return true;}if(key==GLFW.GLFW_KEY_H){hidden.clear();status="已恢复全部道路和铁路路基";return true;}if(key==GLFW.GLFW_KEY_DELETE){remove();return true;}if(ManualPlannerClient.KEY.method_1417(key,scan)){method_25419();return true;}if(Set.of(GLFW.GLFW_KEY_W,GLFW.GLFW_KEY_A,GLFW.GLFW_KEY_S,GLFW.GLFW_KEY_D,GLFW.GLFW_KEY_LEFT_SHIFT).contains(key)){keys.add(key);return true;}return super.method_25404(key,scan,modifiers);}
  @Override public boolean method_16803(int key,int scan,int modifiers){keys.remove(key);return super.method_16803(key,scan,modifiers);}
  private void remove(){if(selected!=null)send("manualDelete",selected,null,sx(selected.at().x()),sy(selected.at().z()));else if(selectedRoad!=null){var b=mapRoads.get(selectedRoad);if(b!=null)send("manualDelete",null,selectedRoad,sx(b.mesh.first().center().x()),sy(b.mesh.first().center().z()));}}
  private void move(V at){var t=command("manualMove");target(t,selected,null,at);ClientRoads.sendAction(t);}
  @Override public void method_25419(){ManualPlannerClient.close();}
  @Override public void method_25432(){keys.clear();pressed=false;}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    g.method_25294(0,0,field_22789,field_22790,0xff141d27);g.method_51433(field_22793,"SR · 手动道路规划",10,13,0xfff2f4fa,false);g.method_51433(field_22793,"撤销 "+state.method_10550("Undo")+"  /  重做 "+state.method_10550("Redo"),left()+8,14,0xff9bacbf,false);
    g.method_25294(left(),top(),right(),bottom(),0xff252b30);g.method_44379(left(),top(),right(),bottom());
    if(terrainDirty&&terrain!=null){terrain.method_4524();terrainDirty=false;}
    if(texture!=null){int x=(int)Math.floor(sx(terrainX)),y=(int)Math.floor(sy(terrainZ)),size=(int)Math.ceil(1024*terrainStep*zoom);g.method_25293(texture,x,y,size,size,0,0,1024,1024,1024,1024);}
    drawRoads(g);drawPreview(g);collect();
    for(var p:displayedPoints){int x=(int)sx(p.at().x()),y=(int)sy(p.at().z());int color=switch(p.kind()){case "junction"->0xff73f07b;case "rail"->0xffc9a3ff;case "lane"->0xff4db8ff;case "control"->0xffde76ff;case "attached"->0xffff7571;case "elevated"->0xff33ccff;default->0xffffd36b;};g.method_25294(x-2,y-2,x+3,y+3,color);if(p.kind().equals("rail"))g.method_49601(x-3,y-3,7,7,0xff7858a3);if(selected!=null&&same(selected,p)){g.method_49601(x-5,y-5,11,11,0xffffffff);}}
    var selection=state.method_10562("Selection");var selectedNodes=new HashSet<Long>();if(selection.method_10545("Start"))selectedNodes.add(selection.method_10537("Start"));for(long pos:selection.method_10565("Points"))selectedNodes.add(pos);for(var p:points)if(p.pos()!=null&&selectedNodes.contains(p.pos().method_10063())||selection.method_25928("SidePoint")&&selection.method_25926("SidePoint").equals(p.id()))g.method_49601((int)sx(p.at().x())-6,(int)sy(p.at().z())-6,13,13,0xff74ffae);
    int px=(int)sx(field_22787.field_1724.method_23317()),py=(int)sy(field_22787.field_1724.method_23321());g.method_25294(px-3,py-3,px+4,py+4,0xffffffff);g.method_51433(field_22793,"你",px+6,py-3,0xffffffff,false);
    if(moving)drawMoveAxes(g,mx,my);
    g.method_44380();g.method_51433(field_22793,field_22793.method_27523(status,field_22789-left()-15),left()+4,field_22790-33,0xffd5e2ee,false);
    V at=map(mx,my)?terrain(mx,my):null;String coords=at==null?"地表加载中 "+loadedTiles+" / "+totalTiles:String.format(Locale.ROOT,"X %.2f  Y %.1f  Z %.2f",at.x(),at.y(),at.z());g.method_51433(field_22793,coords,field_22789-field_22793.method_1727(coords)-12,field_22790-17,0xff9fb9cc,false);
    resumePreview.field_22764=ManualPlannerClient.hasMapPreview();resumePreview.field_22763=resumePreview.field_22764;
    if(field_22790>330&&!resumePreview.field_22764)g.method_51433(field_22793,"工具 "+tool+(tool==5?" · "+arms+" 向":""),10,field_22790-54,0xff74ffae,false);
    super.method_25394(g,mx,my,dt);
    if(menuX>=0){g.method_25294(menuX,menuY,menuX+122,menuY+menuRows()*22,0xf5213142);String[] rows=selectedRoad!=null?new String[]{"详细设置","删除","暂时隐藏（H 恢复）","取消"}:new String[]{"详细设置 / XYZ","删除","移动","取消"};for(int i=0;i<rows.length;i++){if(mx>=menuX&&mx<menuX+122&&my>=menuY+i*22&&my<menuY+(i+1)*22)g.method_25294(menuX+1,menuY+i*22,menuX+121,menuY+(i+1)*22,0xff34536b);g.method_51433(field_22793,rows[i],menuX+9,menuY+i*22+7,0xffffffff,false);}}
    if(help){String[] lines={"W A S D 平移；滚轮缩放；长按左键拖动", "主键盘 1–7 切换工具（不含小键盘）", "Delete 删除；Ctrl Z 撤销；Ctrl Y 重做", "道路：A → 经过点/控制点 → B", "Ctrl 经过点在路上；左 Alt 控制点影响弯曲", "同一路段只能使用其中一种点", "端点：Ctrl＋滚轮切换四种点", "立交：Ctrl＋滚轮选择 3–6 向", "右键点：详细设置、删除、XZ 移动", "拖动箭头后双击确认；右键取消移动", "高架：深蓝/深紫；地下：灰/浅灰", "实景预览后按 P 返回设置；Esc 返回地图", "缓存关闭延时0–60秒；离开加载半径立即释放", "操作半径2048格；H 恢复全部隐藏道路"};int x=Math.max(left()+8,field_22789-365),y=38;g.method_25294(x-8,y-8,field_22789-8,y+lines.length*16+8,0xf5162533);for(int i=0;i<lines.length;i++)g.method_51433(field_22793,lines[i],x,y+i*16,0xffe1eaf0,false);}
  }
  private void drawMoveAxes(class_332 g,int mx,int my){
    int x=(int)sx(movingAt.x()),y=(int)sy(movingAt.z());
    int red=axis==1||Math.abs(my-y)<7&&mx>x+8&&mx<x+55?0xffffb0a7:0xffef796f;
    int blue=axis==2||Math.abs(mx-x)<7&&my>y+8&&my<y+55?0xffc0edff:0xff75ccef;
    g.method_25294(x+6,y-2,x+46,y+3,0xb0162533);g.method_25294(x-2,y+6,x+3,y+46,0xb0162533);
    g.method_25294(x+6,y,x+46,y+1,red);g.method_25294(x,y+6,x+1,y+46,blue);
    for(int i=0;i<6;i++){g.method_25294(x+46+i,y-5+i,x+47+i,y+6-i,red);g.method_25294(x-5+i,y+46+i,x+6-i,y+47+i,blue);}
    g.method_25294(x-5,y-5,x+6,y+6,0xff203345);g.method_49601(x-5,y-5,11,11,0xffdcebf7);g.method_25294(x-1,y-1,x+2,y+2,0xffdcebf7);
    g.method_25294(x+55,y-7,x+68,y+7,0xe51a2a38);g.method_51433(field_22793,"X",x+59,y-3,red,false);
    g.method_25294(x-7,y+55,x+7,y+69,0xe51a2a38);g.method_51433(field_22793,"Z",x-3,y+59,blue,false);
  }
  private static boolean same(Point a,Point b){return Objects.equals(a.kind(),b.kind())&&Objects.equals(a.id(),b.id())&&Objects.equals(a.road(),b.road())&&Objects.equals(a.pos(),b.pos());}
  private int menuRows(){return 4;}
  static int roadColor(RoadIndex.Built b,Sample at){boolean rail=b.record.railway();if(RoadStreetscape.underground(b.mesh,at.distance()))return rail?0xffe3e3eb:0xff8b9097;if(RoadStreetscape.raised(b.mesh,at))return rail?0xff51316f:0xff234e86;return rail?0xff9075ad:b.record.toll()!=null?0xffc99c68:b.record.junction()!=null?0xff8aadc1:0xff627c91;}
  private record Strip(RoadIndex.Built road,Sample a,Sample b){double height(){return (a.center().y()+b.center().y())/2;}}
  private void drawRoads(class_332 g){
    collect();var strips=preparedStrips;
    g.method_51452();RenderSystem.disableCull();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.setShader(class_757::method_34540);var buffer=class_289.method_1348().method_1349();buffer.method_1328(class_293.class_5596.field_27382,class_290.field_1576);var pose=g.method_51448().method_23760().method_23761();
    for(var strip:strips){var b=strip.road();var a=strip.a();var c=strip.b();int color=b.record.id().equals(selectedRoad)?0xffffd76b:roadColor(b,a);V[] quad={a.at(a.halfWidth(),0),a.at(-a.halfWidth(),0),c.at(-c.halfWidth(),0),c.at(c.halfWidth(),0)};for(V p:quad)buffer.method_22918(pose,(float)sx(p.x()),(float)sy(p.z()),0).method_1336((color>>16)&255,(color>>8)&255,color&255,255).method_1344();}class_286.method_43433(buffer.method_1326());RenderSystem.disableBlend();RenderSystem.enableCull();
  }
  private List<Mesh> previewMeshes(){
    if(!ManualPlannerClient.hasMapPreview()||ClientRoads.conflictPreview)return List.of();
    var meshes=new ArrayList<Mesh>(ClientRoads.nodePreviews);if(ClientRoads.preview!=null&&!meshes.contains(ClientRoads.preview))meshes.add(ClientRoads.preview);return meshes;
  }
  private void drawPreview(class_332 g){
    var meshes=previewMeshes();if(meshes.isEmpty())return;
    g.method_51452();RenderSystem.disableCull();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.setShader(class_757::method_34540);
    var buffer=class_289.method_1348().method_1349();buffer.method_1328(class_293.class_5596.field_27382,class_290.field_1576);var pose=g.method_51448().method_23760().method_23761();
    for(var mesh:meshes){if(!visible(mesh))continue;var samples=mesh.samples();for(int i=1;i<samples.size();i++){var a=samples.get(i-1);var b=samples.get(i);for(V p:List.of(a.at(a.halfWidth(),0),a.at(-a.halfWidth(),0),b.at(-b.halfWidth(),0),b.at(b.halfWidth(),0)))buffer.method_22918(pose,(float)sx(p.x()),(float)sy(p.z()),0).method_1336(67,221,136,235).method_1344();}}
    class_286.method_43433(buffer.method_1326());RenderSystem.disableBlend();RenderSystem.enableCull();g.method_51433(field_22793,"绿色：待建预览",left()+8,top()+8,0xff74ffae,false);
  }
  final class PlannerSettings extends class_437 {
    private int radius=state.method_10545("Radius")?state.method_10550("Radius"):256,steps=state.method_10545("MaxUndo")?state.method_10550("MaxUndo"):30,cacheSeconds=ManualPlannerScreen.this.cacheSeconds();
    PlannerSettings(){super(class_2561.method_43470("道路规划设置"));}
    @Override protected void method_25426(){int x=field_22789/2-140,y=field_22790/2-76;
      method_37063(new SettingSlider(x,y,0,radius,16,2048));
      method_37063(new SettingSlider(x,y+28,1,steps,1,30));
      method_37063(new SettingSlider(x,y+56,2,cacheSeconds,0,60));
      method_37063(class_4185.method_46430(class_2561.method_43470("保存"),b->{var t=command("manualSettings");t.method_10569("Radius",radius);t.method_10569("MaxUndo",steps);t.method_10569("CacheSeconds",cacheSeconds);ClientRoads.sendAction(t);method_25419();}).method_46434(x,y+108,133,20).method_46431());
      method_37063(class_4185.method_46430(class_2561.method_43470("返回"),b->method_25419()).method_46434(x+147,y+108,133,20).method_46431());ManualPlannerClient.child(this);ClientRoads.beginEditor(this);}
    @Override public void method_25419(){field_22787.method_1507(ManualPlannerScreen.this);ClientRoads.beginEditor(ManualPlannerScreen.this);}
    @Override public boolean method_25421(){return false;}
    @Override public void method_25394(class_332 g,int x,int y,float dt){method_25420(g);g.method_27534(field_22793,field_22785,field_22789/2,field_22790/2-102,0xffffffff);super.method_25394(g,x,y,dt);for(var child:method_25396())if(child instanceof SettingSlider slider&&slider.method_25405(x,y)){g.method_51436(field_22793,field_22793.method_1728(class_2561.method_43470(slider.hint()),Math.max(1,Math.min(300,field_22789-16))),(sw,sh,mx,my,tw,th)->new org.joml.Vector2i(Math.max(4,Math.min(mx+12,sw-tw-4)),Math.max(4,Math.min(my+12,sh-th-6))),x,y);break;}}
    final class SettingSlider extends class_357 {
      private final int setting,min,max;
      SettingSlider(int x,int y,int setting,int current,int min,int max){super(x,y,280,22,class_2561.method_43473(),(current-min)/(double)(max-min));this.setting=setting;this.min=min;this.max=max;method_25346();}
      String hint(){return switch(setting){case 0->"以打开地图的位置为中心加载地表；离开此范围会释放缓存";case 1->"最多保留的规划撤销步骤数";default->"关闭后按时释放；离开打开位置超过加载半径即释放";};}
      protected void method_25346(){method_25355(class_2561.method_43470(switch(setting){case 0->"地表加载半径："+radius+" 格";case 1->"撤销最大步："+steps;default->"关闭后释放地表缓存："+cacheSeconds+" 秒";}));}
      protected void method_25344(){int n=min+(int)Math.round(field_22753*(max-min));switch(setting){case 0->radius=n;case 1->steps=n;default->cacheSeconds=n;}method_25346();}
    }
  }
  final class PointDetails extends class_437 {
    private final Point point;private final class_342[] xyz=new class_342[3];private String message="坐标修改与原有道路校验同时执行";
    void result(boolean success,String text){message=text;if(success){method_25419();status=text;}}
    PointDetails(Point p){super(class_2561.method_43470("点的详细设置"));point=p;}
    @Override protected void method_25426(){int x=field_22789/2-140,y=field_22790/2-70;double[] values={point.at().x(),point.at().y(),point.at().z()};for(int i=0;i<3;i++){xyz[i]=new class_342(field_22793,x+30,y+i*27,235,20,class_2561.method_43470("XYZ".substring(i,i+1)));xyz[i].method_1880(24);xyz[i].method_1852(String.format(Locale.ROOT,"%.3f",values[i]));method_37063(xyz[i]);}method_37063(class_4185.method_46430(class_2561.method_43470("保存坐标"),b->{try{var at=new V(Double.parseDouble(xyz[0].method_1882()),Double.parseDouble(xyz[1].method_1882()),Double.parseDouble(xyz[2].method_1882()));selected=point;var t=command("manualMove");target(t,point,null,at);ClientRoads.sendAction(t);}catch(IllegalArgumentException e){message="请输入有效坐标";}}).method_46434(x,y+89,87,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("原有设置"),b->{field_22787.method_1507(ManualPlannerScreen.this);send("manualDetails",point,null,sx(point.at().x()),sy(point.at().z()));}).method_46434(x+94,y+89,87,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("返回地图"),b->method_25419()).method_46434(x+188,y+89,87,20).method_46431());ManualPlannerClient.child(this);ClientRoads.beginEditor(this);}
    @Override public void method_25419(){field_22787.method_1507(ManualPlannerScreen.this);ClientRoads.beginEditor(ManualPlannerScreen.this);}
    @Override public boolean method_25421(){return false;}
    @Override public void method_25394(class_332 g,int x,int y,float dt){method_25420(g);int left=field_22789/2-140,top=field_22790/2-70;g.method_51439(field_22793,field_22785,left,top-22,0xffffffff,false);for(int i=0;i<3;i++)g.method_51433(field_22793,"XYZ".substring(i,i+1),left,top+i*27+6,0xffffffff,false);g.method_51433(field_22793,field_22793.method_27523(message,290),left,top+117,0xffb8ccd9,false);super.method_25394(g,x,y,dt);}
  }
}
