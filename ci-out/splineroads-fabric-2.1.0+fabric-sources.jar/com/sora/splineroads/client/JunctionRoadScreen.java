package com.sora.splineroads.client;

import ;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Piece;
import com.sora.splineroads.core.JunctionPlanner.Plan;
import com.sora.splineroads.core.RoadSidewalks.Finish;
import com.sora.splineroads.core.RoadSidewalks.Side;
import com.sora.splineroads.core.RoadStructures.Part;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;

/** Road settings for an owned manual approach, without intersection controls. */
public final class JunctionRoadScreen extends class_437 {
  private final class_2487 payload,values;private final JunctionSpec spec;private final int arm;
  private final Map<String,class_342> fields=new LinkedHashMap<>();
  private int x,y,page,debounce;private String status="";private boolean pending;private class_4185 apply;
  public JunctionRoadScreen(class_2487 t){super(class_2561.method_43470("道路设置 · 路口接入路段"));payload=t.method_10553();spec=JunctionCodec.read(t.method_10562("Spec"));arm=t.method_10550("Arm");values=JunctionRoads.fields(spec.arms().get(arm));}
  @Override protected void method_25426(){x=12;y=Math.max(0,(field_22790-238)/2);fields.clear();
    button(page==0?"道路断面 → 人行道设置":"人行道设置 → 道路断面",x+12,y+29,264,()->{if(capture()){page=1-page;method_41843();}});
    if(page==0){
      field("入向车道数","Incoming",x+12,y+65);field("出向车道数","Outgoing",x+146,y+65);
      field("道路总宽 / 格","Width",x+12,y+106);field("中央分隔宽 / 格","Median",x+146,y+106);
      field("非机动车道宽 / 单侧","CycleWidth",x+12,y+147);field("路缘宽 / 单侧","CurbWidth",x+146,y+147);
      button("中央："+medianLabel(),x+12,y+174,128,()->{if(capture()){var a=new RoadProfile.Median[]{RoadProfile.Median.DOUBLE_YELLOW,RoadProfile.Median.RAIL,RoadProfile.Median.GREEN};int i=Arrays.asList(a).indexOf(RoadProfile.Median.valueOf(values.method_10558("MedianKind")));values.method_10582("MedianKind",a[(i+1)%a.length].name());edited();method_41843();}});
      button(values.method_10577("CycleAsphalt")?"非机动车：沥青":"非机动车：绿色",x+146,y+174,130,()->{if(capture()){values.method_10556("CycleAsphalt",!values.method_10577("CycleAsphalt"));edited();method_41843();}});
    }else{
      button(values.method_10577("Walk")?"人行道：显示":"人行道：隐藏",x+12,y+60,128,()->toggle("Walk"));
      button("侧别："+RoadSidewalks.Side.valueOf(values.method_10558("WalkSide")).label,x+146,y+60,130,()->{if(capture()){var v=RoadSidewalks.Side.valueOf(values.method_10558("WalkSide"));values.method_10582("WalkSide",RoadSidewalks.Side.values()[(v.ordinal()+1)%3].name());edited();method_41843();}});
      field("人行道宽 / 格","WalkWidth",x+12,y+107);
      button("材质："+RoadSidewalks.Finish.of(values.method_10558("WalkMaterial")).label,x+146,y+107,130,()->{if(capture()){var v=RoadSidewalks.Finish.of(values.method_10558("WalkMaterial"));values.method_10582("WalkMaterial",RoadSidewalks.Finish.values()[(v.ordinal()+1)%RoadSidewalks.Finish.values().length].id);edited();method_41843();}});
      button(values.method_10577("Tactile")?"盲道：显示":"盲道：隐藏",x+12,y+144,264,()->toggle("Tactile"));
    }
    apply=button("更新此路段",x+12,y+207,128,this::send);apply.field_22763=!pending;
    button("取消",x+146,y+207,130,this::method_25419);preview();
  }
  private void edited(){ClientRoads.editorChanged(this);pending=false;if(apply!=null)apply.field_22763=true;}
  private String medianLabel(){return switch(RoadProfile.Median.valueOf(values.method_10558("MedianKind"))){case RAIL->"护栏";case GREEN->"绿化带";case DOUBLE_YELLOW->"双黄线";case DASHED_YELLOW->"黄虚线";case NONE->"无";};}
  private void toggle(String k){if(capture()){values.method_10556(k,!values.method_10577(k));edited();method_41843();}}
  private class_4185 button(String title,int a,int b,int w,Runnable action){return method_37063(class_4185.method_46430(class_2561.method_43470(title),v->action.run()).method_46434(a,b,w,20).method_46431());}
  private void field(String label,String key,int a,int b){var f=new class_342(field_22793,a,b,128,18,class_2561.method_43470(label));f.method_1880(8);f.method_1852(Double.toString(values.method_10574(key)));f.method_1863(v->{edited();debounce=8;if(apply!=null)apply.field_22763=!pending;});fields.put(key,f);method_37063(f);}
  private boolean capture(){try{for(var entry:fields.entrySet()){double n=Double.parseDouble(entry.getValue().method_1882());if(!Double.isFinite(n))throw new NumberFormatException();if(Set.of("Incoming","Outgoing","WalkWidth").contains(entry.getKey())){if(n!=Math.rint(n))throw new NumberFormatException();values.method_10569(entry.getKey(),(int)n);}else values.method_10549(entry.getKey(),n);}return true;}catch(IllegalArgumentException e){status="请输入有效数值；车道数和人行道宽须为整数";return false;}}
  private boolean preview(){if(!capture())return false;try{
    var arms=new ArrayList<>(spec.arms());arms.set(arm,JunctionRoads.change(arms.get(arm),values));var plan=JunctionPlanner.plan(spec.arms(arms));
    ClientRoads.nodePreviews=plan.pieces().stream().map(JunctionPlanner.Piece::mesh).toList();ClientRoads.preview=plan.pieces().get(arm).mesh();JunctionScreen.previewMesh=ClientRoads.preview;
    var faces=new ArrayList<RoadSurface.Face>();for(var p:plan.pieces()){faces.addAll(p.paint());for(var part:p.structures())faces.addAll(part.faces());}JunctionScreen.previewFaces=List.copyOf(faces);
    status="仅编辑接入路段 "+(arm+1)+"；路口配时、转向请用普通路口编辑器。";return true;
  }catch(IllegalArgumentException e){status=e.getMessage();return false;}}
  @Override public void method_25393(){super.method_25393();if(debounce>0&&--debounce==0&&!pending)preview();}
  private void send(){if(pending||!preview())return;var t=new class_2487();t.method_10582("Action","junctionRoad");t.method_25927("Id",payload.method_25926("Id"));t.method_10569("Arm",arm);t.method_10569("Signature",payload.method_10550("Signature"));t.method_10566("Fields",values.method_10553());pending=true;apply.field_22763=false;ClientRoads.sendAction(t);}
  public void failed(String text){pending=false;status=text;apply.field_22763=true;}
  @Override public void method_25419(){JunctionScreen.clear();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();super.method_25419();}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){g.method_25294(x,y,x+288,y+238,0xed15212c);g.method_51439(field_22793,field_22785,x+12,y+12,0xffffff,false);
    for(var f:fields.values())g.method_51439(field_22793,f.method_25369(),f.method_46426(),f.method_46427()-11,0xbbd3dc,false);
    super.method_25394(g,mx,my,dt);
    if(field_22789>=480)g.method_51440(field_22793,class_2561.method_43470(status),x+302,y+20,Math.max(130,field_22789-x-312),0xffffff);
    else if(my>=y+195&&my<y+207)g.method_51438(field_22793,class_2561.method_43470(status),mx,my);
    else g.method_51433(field_22793,field_22793.method_27523(status,264),x+12,y+195,0xbbd3dc,false);
  }
}
