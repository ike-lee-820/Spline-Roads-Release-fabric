package com.sora.splineroads.client;

import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** A section marker has no geometry controls. Bezier handles stay in the road editor. */
public final class AttachedPointScreen extends class_437 {
  private final class_2487 payload;
  private class_4185 delete;
  private String status="";
  private int x,y,w;
  public AttachedPointScreen(class_2487 payload){super(class_2561.method_43470(payload.method_10577("Elevated")?"高架出入点":"道路附属点"));this.payload=payload.method_10553();}
  @Override protected void method_25426(){
    w=Math.min(300,field_22789-16);x=(field_22789-w)/2;y=Math.max(4,(field_22790-122)/2);
    delete=method_37063(class_4185.method_46430(class_2561.method_43470(payload.method_10577("Elevated")?"删除出入点":"删除附属点"),b->{
      var t=new class_2487();t.method_10582("Action","attachedPoint");t.method_25927("Id",payload.method_25926("Id"));
      t.method_25927("Point",payload.method_25926("Point"));t.method_10569("Signature",payload.method_10550("Signature"));t.method_10556("Delete",true);
      ClientRoads.sendAction(t);delete.field_22763=false;
    }).method_46434(x+12,y+70,(w-32)/2,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("关闭"),b->method_25419()).method_46434(x+20+(w-32)/2,y+70,(w-32)/2,20).method_46431());
  }
  public void failed(String text){status=text;delete.field_22763=true;}
  @Override public void method_25393(){if(payload.method_10577("PlannerDelete")&&delete!=null){payload.method_10551("PlannerDelete");delete.method_25306();}}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    method_25420(g);g.method_25294(x,y,x+w,y+122,0xf015222e);g.method_51439(field_22793,field_22785,x+12,y+12,0xffffff,false);
    g.method_51440(field_22793,class_2561.method_43470(payload.method_10577("Elevated")?"用道路连接器选择此点和高处的尽头端点，设置高架上下坡连接。":"固定在所选道路断面中央，用于标线分段和道路选择。"),x+12,y+34,w-24,0xbbd3dc);
    super.method_25394(g,mx,my,dt);g.method_51440(field_22793,class_2561.method_43470(status),x+12,y+98,w-24,0xffbb88);
  }
}
