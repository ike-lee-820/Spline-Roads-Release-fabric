package com.sora.splineroads.client;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePointPreview.Marker;
import com.sora.splineroads.core.RoadGeometry.Mesh;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.nbt.*;
import java.util.concurrent.*;

/** Click the actual motor lane; only the lane changes, never the longitudinal anchor. */
public final class LanePointScreen extends class_437 {
  private static final ExecutorService PREVIEW=Executors.newSingleThreadExecutor(r->{var t=new Thread(r,"SR lane point view");t.setDaemon(true);return t;});
  private final class_2487 payload;
  private final RoadRecord road;
  private final Mesh mesh;
  private final LanePoints.Point point;
  private int lane,x,y,w,h,viewX,viewY,viewW,viewH,requestedLane;
  private String status="";
  private class_4185 apply,remove,merge,expand;
  private boolean confirm,pending;
  private LanePointPreview.Image image;
  private CompletableFuture<LanePointPreview.Image> drawing;

  public LanePointScreen(class_2487 t){
    super(class_2561.method_43470("蓝色车道点"));payload=t.method_10553();road=RoadRecord.load(t.method_10562("Road"));
    point=LaneTopology.point(road,t.method_25926("Point"));lane=point.lane();mesh=road.mesh();
  }
  @Override protected void method_25426(){
    w=Math.min(460,field_22789-16);h=Math.min(310,field_22790-16);x=(field_22789-w)/2;y=(field_22790-h)/2;
    viewX=x+12;viewY=y+36;viewW=w-24;viewH=h-110;
    if(image!=null&&(image.width()!=viewW||image.height()!=viewH))image=null;
    if(drawing!=null){drawing.cancel(false);drawing=null;}
    method_37063(class_4185.method_46430(class_2561.method_43470("关闭"),b->method_25419()).method_46434(x+w-56,y+8,44,20).method_46431());
    apply=method_37063(class_4185.method_46430(class_2561.method_43470("应用"),b->send(false)).method_46434(x+12,y+h-30,88,20).method_46431());
    remove=method_37063(class_4185.method_46430(class_2561.method_43470("删除"),b->{
      if(!payload.method_10554("Dependencies",class_2520.field_33258).isEmpty()&&!confirm){field_22787.method_1507(new LaneDeleteConfirmScreen(this,payload.method_10554("Dependencies",class_2520.field_33258),()->{confirm=true;send(true);}));return;}
      send(true);
    }).method_46434(x+w-100,y+h-30,88,20).method_46431());
    merge=method_37063(class_4185.method_46430(class_2561.method_43470(point.mergeLength()>0?"取消合流缩减":"外侧合流缩减"),b->mergeLane()).method_46434(x+104,y+h-30,108,20).method_46431());
    expand=method_37063(class_4185.method_46430(class_2561.method_43470(point.mergeLength()<0?"取消外侧扩流":"外侧扩流加道"),b->expandLane()).method_46434(x+216,y+h-30,108,20).method_46431());
    buttons();requestView();
  }
  private void buttons(){if(merge!=null)merge.field_22763=point.mergeLength()>=0&&!point.automatic()&&!pending&&lane==point.lane()&&payload.method_10577("Supported")&&(point.mergeLength()>0||LaneMerge.allowed(mesh,point));if(expand!=null)expand.field_22763=point.mergeLength()<=0&&!point.automatic()&&!pending&&lane==point.lane()&&payload.method_10577("Supported")&&(point.mergeLength()<0||LaneExpansion.allowed(mesh,point));apply.field_22763=!point.automatic()&&!pending&&lane!=point.lane();remove.field_22763=!point.automatic()&&!pending;}
  private void requestView(){
    if(drawing!=null)return;requestedLane=lane;int chosen=lane,vw=viewW,vh=viewH;
    drawing=CompletableFuture.supplyAsync(()->LanePointPreview.render(mesh,point,vw,vh,chosen),PREVIEW);
  }
  @Override public void method_25393(){
    super.method_25393();
    if(payload.method_10577("PlannerDelete")&&remove!=null){payload.method_10551("PlannerDelete");if(remove.field_22763)remove.method_25306();}
    if(drawing!=null&&drawing.isDone()){
      try{image=drawing.join();}catch(CompletionException e){status="道路视图加载失败："+e.getCause().getMessage();}
      drawing=null;if(requestedLane!=lane)requestView();
    }
  }
  @Override public boolean method_25402(double mx,double my,int button){
    if(button==0&&!point.automatic()&&!pending&&image!=null&&mx>=viewX&&my>=viewY&&mx<viewX+viewW&&my<viewY+viewH){
      int selected=image.laneAt((int)(mx-viewX),(int)(my-viewY));
      if(selected>=0){lane=selected;status="";buttons();requestView();}else status="请点击机动车道；隔离带和人行道不能选作车道。";
      return true;
    }
    return super.method_25402(mx,my,button);
  }
  private void mergeLane(){
    if(pending||point.automatic())return;
    var t=new class_2487();t.method_25927("Id",payload.method_25926("Id"));t.method_25927("Point",point.id());t.method_10569("Signature",payload.method_10550("Signature"));
    t.method_10582("Action","lanePoint");t.method_10549("MergeLength",point.mergeLength()>0?0:32);
    pending=true;status="正在提交合流缩减；不创建汇出匝道…";buttons();ClientRoads.sendAction(t);
  }
  private void expandLane(){
    if(pending||point.automatic())return;
    var t=new class_2487();t.method_25927("Id",payload.method_25926("Id"));t.method_25927("Point",point.id());t.method_10569("Signature",payload.method_10550("Signature"));
    t.method_10582("Action","lanePoint");t.method_10549("MergeLength",point.mergeLength()<0?0:-32);
    pending=true;status="正在提交外侧扩流…";buttons();ClientRoads.sendAction(t);
  }
  private void send(boolean delete){
    if(pending||point.automatic()||!delete&&lane==point.lane())return;
    var t=new class_2487();t.method_25927("Id",payload.method_25926("Id"));t.method_25927("Point",payload.method_25926("Point"));t.method_10569("Signature",payload.method_10550("Signature"));
    t.method_10582("Action","lanePoint");t.method_10556("Delete",delete);t.method_10569("Lane",lane);
    if(confirm)t.method_10566("ConfirmDependencies",payload.method_10554("Dependencies",class_2520.field_33258).method_10612());
    pending=true;status="正在提交…";buttons();ClientRoads.sendAction(t);
  }
  public void failed(String s){status=s;pending=false;buttons();}
  @Override public void method_25419(){if(drawing!=null)drawing.cancel(false);super.method_25419();}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    method_25420(g);g.method_25294(x,y,x+w,y+h,0xf015222e);
    g.method_51433(field_22793,"蓝色车道点 · "+(point.automatic()?"自动尽头":"手动创建"),x+12,y+14,0x66b5ff,false);
    g.method_25294(viewX-1,viewY-1,viewX+viewW+1,viewY+viewH+1,0xff647a87);
    g.method_25294(viewX,viewY,viewX+viewW,viewY+viewH,0xff28382e);
    if(image!=null){
      for(int row=0;row<viewH;row++)for(int col=0;col<viewW;){int start=col,color=image.pixels()[row*viewW+col];while(col<viewW&&image.pixels()[row*viewW+col]==color)col++;g.method_25294(viewX+start,viewY+row,viewX+col,viewY+row+1,color);}
      for(var marker:image.markers())if(marker.lane()==lane){int px=viewX+marker.x(),py=viewY+marker.y();g.method_25294(px-5,py-5,px+6,py+6,0xffbce7ff);g.method_25294(px-3,py-3,px+4,py+4,0xff2384ff);}
      int hover=image.laneAt(mx-viewX,my-viewY);
      String label=hover>=0?LanePoints.label(mesh,LanePoints.lane(mesh,point).station(),hover):"道路实景俯视 · 沿路方向 ↑";
      g.method_25294(viewX+3,viewY+3,viewX+9+field_22793.method_1727(label),viewY+16,0xdd15222e);g.method_51433(field_22793,label,viewX+6,viewY+6,0xe7f2f9,false);
    }else g.method_25300(field_22793,"正在加载道路视图…",viewX+viewW/2,viewY+viewH/2,0xcbd9e5);
    int infoY=viewY+viewH+7;
    String selected="所属："+LanePoints.label(mesh,LanePoints.lane(mesh,point).station(),lane)+(LaneSections.active(mesh,LanePoints.lane(mesh,point).station(),lane)?"":"（分离空位）")+"   匝道引用："+payload.method_10554("Dependencies",class_2520.field_33258).size()+" 条";
    g.method_51433(field_22793,selected,x+12,infoY,0x99ccff,false);
    String hint=!status.isEmpty()?status:point.automatic()?"自动尽头点只能查看，不能换车道或删除。":payload.method_10577("Supported")?"点击车道选择；灰色预留槽可用作补入目标，不可从空位汇出。":"可选择车道；此类道路不支持匝道连接器。";
    g.method_51440(field_22793,class_2561.method_43470(hint),x+12,infoY+14,w-24,0xffcf8c);
    super.method_25394(g,mx,my,dt);
  }
}
