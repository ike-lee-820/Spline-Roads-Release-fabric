package com.sora.splineroads.client;
import com.sora.splineroads.core.RoadSlicing;
import com.sora.splineroads.core.RoadSlicing.Connection;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import com.sora.splineroads.config.RoadClientConfig;
/** Intentionally only the connection choice; road properties remain in the road editor. */
public final class RoadSplitScreen extends class_437 {
  public RoadSplitScreen(){super(class_2561.method_43470("道路分割器"));}
  @Override protected void method_25426(){int x=(field_22789-220)/2,y=(field_22790-94)/2;for(int i=0;i<2;i++){var mode=RoadSlicing.Connection.values()[i];method_37063(class_4185.method_46430(class_2561.method_43470((RoadClientConfig.SPLIT_CONNECTION.get()==mode?"✓ ":"")+(i==0?"连续":"路口")),button->{RoadClientConfig.SPLIT_CONNECTION.set(mode);RoadClientConfig.SPEC.save();RoadSplitterClient.clear();method_25419();}).method_46434(x+10+i*104,y+40,96,20).method_46431());}}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);int x=(field_22789-220)/2,y=(field_22790-94)/2;g.method_25294(x,y,x+220,y+94,0xf012212c);g.method_27534(field_22793,field_22785,field_22789/2,y+13,0xffffff);g.method_25300(field_22793,"瞄准道路预览 · 右键分割 · Shift取消",field_22789/2,y+73,0xbad0d9);super.method_25394(g,mx,my,dt);}
  @Override public boolean method_25421(){return false;}
}
