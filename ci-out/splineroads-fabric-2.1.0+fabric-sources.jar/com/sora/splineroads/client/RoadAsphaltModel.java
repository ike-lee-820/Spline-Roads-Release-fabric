package com.sora.splineroads.client;

import java.util.*;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.core.*;
import net.minecraftforge.client.model.BakedModelWrapper;
import net.minecraftforge.client.model.data.*;

/** Road blocks and slabs use the road mesh's four-block world UVs and asphalt tint. */
final class RoadAsphaltModel extends BakedModelWrapper<class_1087> {
  static final ModelProperty<class_2338> POSITION=new ModelProperty<>();
  RoadAsphaltModel(class_1087 original){super(original);}
  @Override public ModelData getModelData(class_1920 level,class_2338 pos,class_2680 state,ModelData input){
    return super.getModelData(level,pos,state,input).derive().with(POSITION,pos.method_10062()).build();
  }
  @Override public List<class_777> getQuads(class_2680 state,class_2350 side,class_5819 random,ModelData data,class_1921 layer){
    var quads=super.getQuads(state,side,random,data,layer);var pos=data.get(POSITION);
    return pos==null?quads:align(quads,pos);
  }
  static List<class_777> align(List<class_777> quads,class_2338 pos){
    if(quads.isEmpty())return quads;
    var result=new ArrayList<class_777>(quads.size());
    for(var q:quads){int[] vertices=q.method_3357().clone();var sprite=q.method_35788();
      for(int i=0;i<4;i++){int at=i*8;double x=Float.intBitsToFloat(vertices[at]),y=Float.intBitsToFloat(vertices[at+1]),z=Float.intBitsToFloat(vertices[at+2]);
        double u,v;switch(q.method_3358().method_10166()){
          case field_11052 -> {u=(Math.floorMod(pos.method_10263(),4)+x)/4;v=(Math.floorMod(pos.method_10260(),4)+z)/4;}
          case field_11048 -> {u=(Math.floorMod(pos.method_10260(),4)+z)/4;v=(Math.floorMod(pos.method_10264(),4)+y)/4;}
          default -> {u=(Math.floorMod(pos.method_10263(),4)+x)/4;v=(Math.floorMod(pos.method_10264(),4)+y)/4;}
        }
        vertices[at+3]=0xffdcdcdc;
        vertices[at+4]=Float.floatToRawIntBits(sprite.method_4580(u*16));vertices[at+5]=Float.floatToRawIntBits(sprite.method_4570(v*16));
      }
      result.add(new class_777(vertices,q.method_3359(),q.method_3358(),sprite,q.method_24874()));
    }return List.copyOf(result);
  }
}
