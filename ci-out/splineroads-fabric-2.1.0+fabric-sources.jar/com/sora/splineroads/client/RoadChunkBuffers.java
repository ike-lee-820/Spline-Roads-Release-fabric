package com.sora.splineroads.client;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_291;

/** Implemented by the narrowly scoped Forge transformer on RenderChunk. */
public interface RoadChunkBuffers {
  Map<class_1921,class_291> splineroads$buffers();
}
