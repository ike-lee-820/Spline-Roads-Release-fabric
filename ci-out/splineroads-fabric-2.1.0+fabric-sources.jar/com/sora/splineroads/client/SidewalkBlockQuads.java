package com.sora.splineroads.client;
import ;
import java.util.*;
import net.minecraft.class_777;
public final class SidewalkBlockQuads {
  /** Lower only the base vertices; the vanilla cube top, UVs and metadata stay unchanged. */
  public static List<class_777> extend(List<class_777> quads,Double bottom){
    if(bottom==null||bottom>=0||quads.isEmpty())return quads;
    var out=new ArrayList<class_777>(quads.size());
    for(var q:quads){int[] packed=null;var original=q.method_3357();
      for(int i=0;i<4;i++)if(Math.abs(Float.intBitsToFloat(original[i*8+1]))<1e-6){
        if(packed==null)packed=original.clone();packed[i*8+1]=Float.floatToRawIntBits(bottom.floatValue());
      }
      out.add(packed==null?q:new class_777(packed,q.method_3359(),q.method_3358(),q.method_35788(),q.method_24874()));
    }
    return List.copyOf(out);
  }
}
