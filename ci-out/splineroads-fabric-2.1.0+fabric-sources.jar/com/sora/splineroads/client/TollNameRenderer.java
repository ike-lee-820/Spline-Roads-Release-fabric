package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.core.TollPlanner.Lengths;
import com.sora.splineroads.core.TollPlaza.Spec;
import com.sora.splineroads.world.RoadIndex;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_5250;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraftforge.client.event.RenderLevelStageEvent;

/** Roof letters use Minecraft's actual language font and normal world depth. */
public final class TollNameRenderer {
  private static long revision=-1;private static int chunkX=Integer.MIN_VALUE,chunkZ=Integer.MIN_VALUE;
  private static List<Spec> nearby=List.of();
  static void clear(){revision=-1;chunkX=chunkZ=Integer.MIN_VALUE;nearby=List.of();}
  static List<Spec> nearby(int cx,int cz){
    var index=ClientRoads.INDEX;if(revision==index.revision()&&cx==chunkX&&cz==chunkZ)return nearby;
    var ids=new HashSet<UUID>();for(int x=cx-12;x<=cx+12;x++)for(int z=cz-12;z<=cz+12;z++)ids.addAll(index.inChunk(net.minecraft.class_1923.method_8331(x,z)));
    var specs=new LinkedHashSet<Spec>();for(UUID id:ids){var road=index.roads.get(id);if(road!=null&&ClientRoads.active(id)&&road.record.toll()!=null&&!road.record.toll().config().name().isEmpty())specs.add(road.record.toll());}
    nearby=List.copyOf(specs);revision=index.revision();chunkX=cx;chunkZ=cz;return nearby;
  }
  public static void render(RenderLevelStageEvent event){
    if(!RoadSignVisibility.enabled())return;
    var mc=class_310.method_1551();if(mc.field_1687==null)return;var eye=event.getCamera().method_19326();
    for(var spec:nearby((int)Math.floor(eye.field_1352)>>4,(int)Math.floor(eye.field_1350)>>4))draw(spec,event);
    if(TollPreview.namedPreview!=null&&ClientRoads.preview!=null)draw(TollPreview.namedPreview.spec(),event);
  }
  private static void draw(Spec spec,RenderLevelStageEvent event){
    String text=spec.config().name();if(text.isEmpty())return;var mc=class_310.method_1551();var camera=event.getCamera().method_19326();
    V axis=spec.b().position().sub(spec.a().position()).horizontalUnit();var lengths=TollPlanner.lengths(spec);V station=spec.a().position().add(axis.mul((lengths.current()+lengths.a()-lengths.b())/2));V center=new V(station.x(),(spec.a().position().y()+spec.b().position().y())/2,station.z());
    if(!spec.path().isEmpty()){double d=lengths.current()/2;center=TollInlineGeometry.equipmentAt(spec,d,0,0);axis=TollInlineGeometry.equipmentAt(spec,d+.05,0,0).sub(TollInlineGeometry.equipmentAt(spec,d-.05,0,0)).horizontalUnit();}
    V eye=new V(camera.field_1352,camera.field_1351,camera.field_1350);if(eye.distance(center)>192)return;
    var styled=class_2561.method_43470(text).method_27692(class_124.field_1067);
    var pose=event.getPoseStack();var buffers=mc.method_22940().method_23000();
    for(int side:TollPlanner.nameSides(spec.config())){double span=TollPlanner.nameWidth(spec.config(),side)-.36,scale=Math.min(.16,span/Math.max(1,mc.field_1772.method_27525(styled)));V front=axis.mul(side),right=front.left().mul(-1);V at=center.add(axis.left().mul(TollPlanner.nameCenter(spec.config(),side))).add(front.mul(5.765)).add(new V(0,spec.config().clearHeight()+2.35+4*scale,0));
      if(eye.sub(at).dot(front)<=0)continue;
      var box=new net.minecraft.class_238(at.x()-span,at.y()-2,at.z()-span,at.x()+span,at.y()+1,at.z()+span);if(!event.getFrustum().method_23093(box))continue;
      for(int layer=0;layer<4;layer++){V point=at.add(front.mul(layer*.035));pose.method_22903();pose.method_22904(point.x()-camera.field_1352,point.y()-camera.field_1351,point.z()-camera.field_1350);
        pose.method_22907(class_7833.field_40716.rotation((float)Math.atan2(-right.z(),right.x())));pose.method_22905((float)scale,(float)-scale,(float)scale);
        mc.field_1772.method_30882(styled,-mc.field_1772.method_27525(styled)/2f,0,layer==3?0xEC4238:0x8D2925,false,pose.method_23760().method_23761(),buffers,class_327.class_6415.field_33993,0,class_765.field_32767);pose.method_22909();
      }
    }
  }
  private TollNameRenderer(){}
}
