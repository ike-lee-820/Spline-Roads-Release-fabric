package com.sora.splineroads.client;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.RailbedCodec;
import com.sora.splineroads.world.RoadRecord;
import com.sora.splineroads.net.RoadNetwork;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;
import java.util.*;

public final class RailbedScreen extends class_437 {
  private static Mesh owned;
  private static final Set<UUID> cancelledTokens=new LinkedHashSet<>();
  private static void cancelled(UUID token){cancelledTokens.add(token);while(cancelledTokens.size()>32)cancelledTokens.remove(cancelledTokens.iterator().next());}
  private static RailbedGeometry.Plan cachedPlan;private static String cachedPlanKey;
  static List<RoadStructures.Part> structures=List.of();
  private static UUID previewToken;private static double previewWidth;private static Structure previewMode;private static String previewSelection="";private static RailbedOptions previewOptions;private static class_2487 lastPreview;
  private class_4185 buildButton,deleteButton;private int previewDelay;private boolean previewReady;private String structureProblem="";
  static List<RailbedPath.Path> highlighted=List.of(),candidates=List.of();
  private final class_2487 payload;private final List<RailbedPath.Path> paths;private Structure mode;private RailbedOptions options;private int page;private double deckWidth;private int x,y;private String status="";private RailbedGeometry.Plan plan;private class_342 widthBox;
  public RailbedScreen(class_2487 tag){super(class_2561.method_43470("SR 铁路路基"));payload=tag.method_10553();paths=tag.method_10554("Paths",class_2520.field_33260).stream().map(t->RailbedCodec.read((class_2487)t)).toList();mode=Structure.valueOf(tag.method_10558("Mode"));deckWidth=tag.method_10574("Width");options=RailbedCodec.options(tag.method_10562("Options"));}
  public static void open(class_2487 tag){if(tag.method_25928("Token")&&cancelledTokens.contains(tag.method_25926("Token")))return;if(tag.method_10558("Kind").equals("railbedStructurePreview")){
      if(!tag.method_25926("Token").equals(previewToken)||tag.method_10574("Width")!=previewWidth||previewMode==null||!tag.method_10558("Mode").equals(previewMode.name())||!tag.method_10558("Selection").equals(previewSelection)||!RailbedCodec.options(tag.method_10562("Options")).equals(previewOptions))return;
      lastPreview=tag.method_10553();
      // A matching request can finish after the user has switched editors.
      // Ordinary overlays (chat/inventory) keep the world preview; other SR editors own theirs.
      var current=class_310.method_1551().field_1755;
      if(owned==null||ClientRoads.preview!=owned||ClientRoads.toolScreen(current))return;
      String problem=tag.method_10558("Problem");structures=List.of();if(tag.method_10545("Road")){var road=RoadRecord.load(tag.method_10562("Road"));structures=road.structures();owned=road.mesh();ClientRoads.preview=owned;}
      if(class_310.method_1551().field_1755 instanceof RailbedScreen screen){screen.previewDelay=0;screen.previewReady=problem.isEmpty()&&tag.method_10545("Road");screen.structureProblem=problem;screen.updateBuild();}
      return;
    }else if(tag.method_10558("Kind").equals("railbedReset")){if(tag.method_25928("Token")&&previewToken!=null&&!previewToken.equals(tag.method_25926("Token")))return;reset();if(class_310.method_1551().field_1755 instanceof RailbedScreen)class_310.method_1551().method_1507(null);}else{lastPreview=tag.method_10545("CachedPreview")?tag.method_10562("CachedPreview").method_10553():null;var screen=new RailbedScreen(tag);highlighted=screen.paths;candidates=tag.method_10554("Candidates",class_2520.field_33260).stream().map(t->RailbedCodec.read((class_2487)t)).toList();if(tag.method_10558("Kind").equals("railbedPreview")){screen.refresh();screen.previewDelay=0;screen.restorePreview();}else class_310.method_1551().method_1507(screen);}}
  private static void clear(){if(ClientRoads.preview==owned)ClientRoads.preview=null;owned=null;structures=List.of();}
  public static void reset(){clear();previewToken=null;previewOptions=null;lastPreview=null;cachedPlan=null;cachedPlanKey=null;highlighted=List.of();candidates=List.of();}
  @Override protected void method_25426(){x=(this.field_22789-340)/2;y=(field_22790-220)/2;
    method_37063(class_4185.method_46430(class_2561.method_43470(new String[]{"基本 1/3","护栏/照明 2/3","接触网 3/3"}[page]),b->{page=(page+1)%3;method_41843();}).method_46434(x+218,y+9,110,20).method_46431());
    if(page==0){
    method_37063(class_4185.method_46430(class_2561.method_43470("路基样式："+label()),b->{mode=mode==Structure.AUTO?Structure.BRIDGE:mode==Structure.BRIDGE?Structure.TUNNEL:Structure.AUTO;b.method_25355(class_2561.method_43470("路基样式："+label()));refresh();}).method_46434(x+12,y+35,316,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("桥梁样式："+bridgeLabel()),b->{var choices=List.of(RoadInfrastructure.Bridge.STANDARD,RoadInfrastructure.Bridge.SUSPENSION,RoadInfrastructure.Bridge.CABLE,RoadInfrastructure.Bridge.ARCH);options=options.styles(choices.get((choices.indexOf(options.bridge())+1)%choices.size()),options.tunnel(),options.fence());method_41843();}).method_46434(x+12,y+62,316,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("隧道样式："+(options.tunnel()==RoadInfrastructure.Tunnel.BOX?"箱型":"圆形")),b->{options=options.styles(options.bridge(),options.tunnel()==RoadInfrastructure.Tunnel.BOX?RoadInfrastructure.Tunnel.ROUND:RoadInfrastructure.Tunnel.BOX,options.fence());method_41843();}).method_46434(x+12,y+88,316,20).method_46431());
    widthBox=new class_342(field_22793,x+132,y+116,80,20,class_2561.method_43470("路基总宽"));widthBox.method_1852(deckWidth==0?"自动":String.valueOf(deckWidth));widthBox.method_1863(value->{try{deckWidth=value.trim().equals("自动")||value.trim().equalsIgnoreCase("auto")?0:Double.parseDouble(value.trim());refresh();}catch(NumberFormatException failure){plan=null;clear();previewReady=false;status="请输入总宽，或输入“自动”";updateBuild();}});method_37063(widthBox);
    method_37063(class_4185.method_46430(class_2561.method_43470("−"),b->change(-.5)).method_46434(x+216,y+116,26,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("+"),b->change(.5)).method_46434(x+246,y+116,26,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("自动"),b->widthBox.method_1852("自动")).method_46434(x+276,y+116,48,20).method_46431());
    }else if(page==1){
      method_37063(class_4185.method_46430(class_2561.method_43470("左侧护栏："+on(options.leftRail())),b->{options=options.flags(!options.leftRail(),options.rightRail(),options.catenary());method_41843();}).method_46434(x+12,y+40,154,20).method_46431());
      method_37063(class_4185.method_46430(class_2561.method_43470("右侧护栏："+on(options.rightRail())),b->{options=options.flags(options.leftRail(),!options.rightRail(),options.catenary());method_41843();}).method_46434(x+174,y+40,154,20).method_46431());
      method_37063(class_4185.method_46430(class_2561.method_43470("地面护栏样式："+options.fence().label),b->{options=options.styles(options.bridge(),options.tunnel(),options.fence()==RailbedOptions.Fence.SOLID?RailbedOptions.Fence.MESH:RailbedOptions.Fence.SOLID);method_41843();}).method_46434(x+12,y+67,316,20).method_46431());
    }else{
      method_37063(class_4185.method_46430(class_2561.method_43470("露天接触网："+on(options.catenary())),b->{options=options.flags(options.leftRail(),options.rightRail(),!options.catenary());method_41843();}).method_46434(x+12,y+35,316,20).method_46431());
      var side=class_4185.method_46430(class_2561.method_43470(paths.size()==1?"单轨支柱："+(options.singleSide()>0?"左侧":"右侧"):"多轨：轨间支柱，双向悬臂"),b->{options=options.wire(options.poleSpacing(),options.wireHeight(),-options.singleSide());method_41843();}).method_46434(x+12,y+62,316,20).method_46431();side.field_22763=paths.size()==1;method_37063(side);
      number("支柱间距（米）",options.poleSpacing(),90,true);
      number("接触网高度（米）",options.wireHeight(),116,false);
    }
    var build=class_4185.method_46430(class_2561.method_43470(payload.method_25928("Id")?"保存":"建造"),b->{if(plan!=null&&previewReady&&RailbedGeometry.unsupported(paths)==null){send("railbedBuild");field_22787.method_1507(null);}}).method_46434(x+12,y+184,74,20).method_46431();buildButton=build;build.field_22763=false;method_37063(build);
    method_37063(class_4185.method_46430(class_2561.method_43470("实景预览"),b->{ManualPlannerClient.worldPreview();method_25419();}).method_46434(x+92,y+184,82,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->{cancelled(payload.method_25926("Token"));previewDelay=0;send("railbedCancel");reset();field_22787.method_1507(null);}).method_46434(x+180,y+184,68,20).method_46431());var delete=class_4185.method_46430(class_2561.method_43470("删除"),b->{send("railbedDelete");field_22787.method_1507(null);}).method_46434(x+254,y+184,74,20).method_46431();deleteButton=delete;method_37063(delete);refresh();restorePreview();
  }
  private static String on(boolean enabled){return enabled?"开":"关";}
  private void number(String title,double value,int row,boolean spacing){
    var box=new class_342(field_22793,x+202,y+row,126,20,class_2561.method_43470(title));box.method_1852(String.valueOf(value));
    box.method_1863(text->{try{
      double n=Double.parseDouble(text.trim());options=options.wire(spacing?n:options.poleSpacing(),spacing?options.wireHeight():n,options.singleSide());refresh();
    }catch(IllegalArgumentException failure){plan=null;clear();previewReady=false;structureProblem="";status=spacing?"间距请输入 8–64 米":"高度请输入 6.1–12 米";updateBuild();}});method_37063(box);
  }
  private String bridgeLabel(){return options.bridge()==RoadInfrastructure.Bridge.STANDARD?"高架":options.bridge()==RoadInfrastructure.Bridge.SUSPENSION?"悬索":options.bridge()==RoadInfrastructure.Bridge.CABLE?"斜拉索":"拱桥";}
  private String label(){return mode==Structure.AUTO?"自动识别":mode==Structure.BRIDGE?"桥梁":"隧道";}
  private void restorePreview(){if(lastPreview!=null)open(lastPreview.method_10553());}
  private void change(double delta){try{double minimum=plan==null?RailbedGeometry.plan(paths,0,mode).minimumWidth():plan.minimumWidth();double base=deckWidth==0||!Double.isFinite(deckWidth)?minimum:deckWidth;widthBox.method_1852(String.valueOf(Math.max(minimum,Math.min(64,base+delta))));}catch(RuntimeException failure){status=failure.getMessage();}}
  private void refresh(){previewReady=false;structureProblem="";previewDelay=8;previewToken=payload.method_25926("Token");previewWidth=deckWidth;previewMode=mode;previewOptions=options;previewSelection=payload.method_10558("Selection");try{String key=payload.method_25926("Token")+":"+payload.method_10558("Selection")+":"+deckWidth+":"+mode;if(!key.equals(cachedPlanKey)){cachedPlan=RailbedGeometry.plan(paths,deckWidth,mode);cachedPlanKey=key;}plan=cachedPlan;clear();owned=plan.mesh();ClientRoads.preview=owned;String unsupported=RailbedGeometry.unsupported(paths);status=unsupported==null?String.format(Locale.ROOT,"已选 %d 轨 · %.1f 格 · 最小总宽 %.1f",paths.size(),paths.get(0).length(),plan.minimumWidth()):unsupported;}catch(RuntimeException failure){plan=null;clear();status=failure.getMessage();}updateBuild();}
  private void updateBuild(){boolean reading=payload.method_10558("SourceStatus").startsWith("正在核验");if(buildButton!=null)buildButton.field_22763=!reading&&plan!=null&&previewReady&&RailbedGeometry.unsupported(paths)==null;if(deleteButton!=null)deleteButton.field_22763=payload.method_25928("Id")&&!reading;}
  @Override public void method_25393(){super.method_25393();if(previewDelay>0&&--previewDelay==0&&plan!=null)send("railbedSettings");}
  private void send(String action){var tag=new class_2487();tag.method_10582("Action",action);tag.method_25927("Token",payload.method_25926("Token"));if(payload.method_25928("PlannerSession"))tag.method_25927("PlannerSession",payload.method_25926("PlannerSession"));tag.method_10549("Width",deckWidth);tag.method_10582("Mode",mode.name());tag.method_10566("Options",RailbedCodec.options(options));RoadNetwork.CHANNEL.sendToServer(new RoadNetwork.Action(tag));}
  @Override public void method_25419(){if(plan!=null&&previewDelay>0){send("railbedSettings");previewDelay=0;}field_22787.method_1507(null);}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);g.method_25294(x,y,x+340,y+220,0xee15232e);g.method_51439(field_22793,field_22785,x+12,y+12,0xffffff,false);if(page==0){g.method_51433(field_22793,"路基总宽度",x+12,y+122,0xffffff,false);}
    else if(page==1){g.method_51440(field_22793,class_2561.method_43470("左右以 A → B 为准。隧道内不另设护栏；关闭一侧即移除该侧墙，预留站台接口。"),x+12,y+94,316,0xcbd9df);g.method_51440(field_22793,class_2561.method_43470("有顶隧道每 16 米设置真实照明。开放隧道不计入。"),x+12,y+121,316,0xcbd9df);}
    else{g.method_51433(field_22793,"支柱间距（8–64 米）",x+12,y+96,0xffffff,false);g.method_51433(field_22793,"高度（6.1–12 米）",x+12,y+122,0xffffff,false);}g.method_51440(field_22793,class_2561.method_43470(structureProblem.isEmpty()?status+(previewReady?"":" · 校验结构中…"):structureProblem),x+12,y+143,316,plan==null||!structureProblem.isEmpty()?0xff8888:0xcbd9df);g.method_51433(field_22793,field_22793.method_27523(payload.method_10558("SourceStatus"),316),x+12,y+171,0xffcc77,false);super.method_25394(g,mx,my,dt);}
}
