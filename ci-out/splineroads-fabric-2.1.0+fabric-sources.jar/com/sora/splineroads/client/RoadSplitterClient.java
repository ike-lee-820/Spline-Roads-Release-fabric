package com.sora.splineroads.client;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.config.RoadClientConfig;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.*;
import com.sora.splineroads.world.RoadSplitGeometry.Range;
import com.sora.splineroads.world.RoadSplitter.Hit;
import java.util.*;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_746;
import net.minecraft.class_761;
import net.minecraft.client.renderer.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT)
public final class RoadSplitterClient {
  private static RoadSplitter.Hit hit;private static UUID token;private static String status="";private static long request,stableSince,sent;private static boolean wanted;private static Object world;
  private static List<RoadSplitGeometry.Range> ranges=List.of(),cachedRanges=List.of();private static RoadRecord rangeRoad;private static Mesh ownPreview;
  private static boolean holding(){var p=class_310.method_1551().field_1724;return p!=null&&(p.method_6047().method_7909() instanceof RoadSplitTool||p.method_6079().method_7909() instanceof RoadSplitTool);}
  public static void clear(){if(ownPreview!=null&&ClientRoads.preview==ownPreview){ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();ClientRoads.conflictPreview=false;ClientRoads.error="";}ownPreview=null;hit=null;token=null;status="";wanted=false;sent=0;request++;ranges=List.of();}
  public static void activate(){var mc=class_310.method_1551();if(mc.field_1724==null)return;
    if(mc.field_1724.method_5715()){clear();var t=new class_2487();t.method_10582("Action","splitCancel");send(t);mc.field_1724.method_7353(class_2561.method_43470("已取消分割"),true);return;}
    if(hit==null){mc.method_1507(new RoadSplitScreen());return;}if(wanted){if(token!=null)commit();return;}ClientRoads.beginWorldEdit();wanted=true;preview();
  }
  private static void send(class_2487 tag){ClientRoads.sendAction(tag);}
  private static void preview(){if(hit==null)return;var t=new class_2487();t.method_10582("Action","splitPreview");t.method_25927("Id",hit.road().record.id());t.method_10569("Signature",hit.road().record.header().hashCode());t.method_10549("Station",hit.station());t.method_10582("Mode",RoadClientConfig.SPLIT_CONNECTION.get().name());t.method_10544("Request",++request);sent=System.nanoTime();status="正在复核分割位置…";send(t);}
  public static void checked(class_2487 reply){var mc=class_310.method_1551();if(reply.method_10537("Request")!=request||mc.field_1687==null||!mc.field_1687.method_27983().method_29177().toString().equals(reply.method_10558("Dimension")))return;
    if(reply.method_10545("Error")){status=reply.method_10558("Error");wanted=false;token=null;return;}token=reply.method_25926("Token");var paths=reply.method_10554("PreviewRoads",net.minecraft.class_2520.field_33260).stream().map(t->RoadRecord.load((class_2487)t).mesh()).toList();if(!paths.isEmpty()){ClientRoads.nodePreviews=paths;ownPreview=paths.get(0);ClientRoads.preview=ownPreview;ClientRoads.conflictPreview=false;ClientRoads.error="";}status="位置已锁定 · 再次右键分割 · Shift＋右键取消";
  }
  private static void commit(){if(token==null)return;var t=new class_2487();t.method_10582("Action","splitCommit");t.method_25927("Token",token);send(t);clear();status="正在提交分割…";}
  @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event){if(event.phase!=TickEvent.Phase.END)return;var mc=class_310.method_1551();if(world!=mc.field_1687){clear();rangeRoad=null;cachedRanges=List.of();world=mc.field_1687;}if(!holding()||mc.field_1755!=null||mc.field_1687==null){if(hit!=null)clear();return;}
    if(wanted)return; // A click owns this station until commit/cancel, independent of the cursor.
    var eye=mc.field_1724.method_33571();var look=mc.field_1724.method_5720();var origin=new V(eye.field_1352,eye.field_1351,eye.field_1350);var direction=new V(look.field_1352,look.field_1351,look.field_1350);var next=RoadSplitter.hit(ClientRoads.INDEX.rayCandidates(origin,direction,64).stream().filter(r->ClientRoads.active(r.record.id())).toList(),origin,direction,64);
    boolean same=next!=null&&hit!=null&&next.road().record==hit.road().record&&Math.abs(next.station()-hit.station())<.005;
    if(!same){clear();hit=next;stableSince=System.nanoTime();if(hit!=null){if(rangeRoad!=hit.road().record){rangeRoad=hit.road().record;cachedRanges=RoadSplitGeometry.protection(rangeRoad);}ranges=cachedRanges;try{RoadSplitGeometry.requireClear(ranges,hit.station(),hit.station());status="右键锁定此位置";}catch(IllegalArgumentException ex){status=ex.getMessage();}}}
    // No expensive world transaction is prepared merely by hovering over a road.
  }
  @SubscribeEvent public static void overlay(RenderGuiOverlayEvent.Post event){var mc=class_310.method_1551();if(!holding()||hit==null||mc.field_1755!=null||!event.getOverlay().id().toString().equals("minecraft:crosshair"))return;var g=event.getGuiGraphics();int x=12,y=mc.method_22683().method_4502()-62;
    String label=RoadClientConfig.SPLIT_CONNECTION.get()==RoadSlicing.Connection.CONTINUOUS?"连续":"路口";g.method_51433(mc.field_1772,String.format(Locale.ROOT,"分割 %s · %s · A–C %.2f / C–B %.2f 格",hit.road().record.id().toString().substring(0,8),label,hit.station(),hit.road().mesh.length()-hit.station()),x,y,0xffffff,true);g.method_51440(mc.field_1772,class_2561.method_43470(status),x,y+15,mc.method_22683().method_4486()-24,token==null?0xffcb81:0x82ffb0);
  }
  @SubscribeEvent public static void render(RenderLevelStageEvent event){if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES||hit==null||!holding())return;var mc=class_310.method_1551();var pose=event.getPoseStack();var camera=event.getCamera().method_19326();pose.method_22903();pose.method_22904(-camera.field_1352,-camera.field_1351,-camera.field_1350);var buffers=mc.method_22940().method_23000();var lines=buffers.getBuffer(class_1921.method_23594());
    var mesh=hit.road().mesh;var at=RoadSlicing.at(mesh,hit.station());line(pose,lines,at.at(-at.halfWidth(),-.08),at.at(at.halfWidth(),-.08),token==null?1:.2f,token==null?.35f:1,.2f);var node=RoadSplitGeometry.node(mesh,hit.station()).position();class_761.method_22980(pose,lines,node.x()-.15,node.y()+.03,node.z()-.15,node.x()+.15,node.y()+.5,node.z()+.15,.2f,1,.3f,1);
    for(var range:ranges)if(range.intersects(hit.station(),hit.station()))for(double d:new double[]{Math.max(0,range.from()),Math.min(mesh.length(),range.to())}){var end=RoadSlicing.at(mesh,d);line(pose,lines,end.at(-end.halfWidth(),-.1),end.at(end.halfWidth(),-.1),1,.1f,.1f);}
    pose.method_22909();buffers.method_22994(class_1921.method_23594());
  }
  private static void line(net.minecraft.class_4587 pose,net.minecraft.class_4588 out,V a,V b,float r,float g,float blue){V normal=b.sub(a).horizontalUnit();for(var p:List.of(a,b))out.method_22918(pose.method_23760().method_23761(),(float)p.x(),(float)p.y(),(float)p.z()).method_22915(r,g,blue,1).method_23763(pose.method_23760().method_23762(),(float)normal.x(),(float)normal.y(),(float)normal.z()).method_1344();}
  private RoadSplitterClient(){}
}
