package com.sora.splineroads.client;

import com.mojang.blaze3d.vertex.*;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.world.NodeEntity;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_746;
import net.minecraft.class_776;
import net.minecraft.class_827;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.blockentity.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(
    modid = SplineRoads.ID,
    value = Dist.CLIENT,
    bus = Mod.EventBusSubscriber.Bus.MOD)
public final class NodeRenderer implements class_827<NodeEntity> {
  public NodeRenderer(class_5614.class_5615 context) {}

  @SubscribeEvent
  public static void register(EntityRenderersEvent.RegisterRenderers e) {
    e.registerBlockEntityRenderer(SplineRoads.NODE_ENTITY.get(), NodeRenderer::new);
    // Infill is static chunk geometry; no BER means no per-frame bbox/collision queries.
  }

  @SubscribeEvent
  public static void colors(
      net.minecraftforge.client.event.RegisterColorHandlersEvent.Block event) {
    event.register(
        (state, level, pos, tint) ->
            level != null
                    && pos != null
                    && state.method_11654(com.sora.splineroads.world.RoadBlocks.Road.FILL)
                        == com.sora.splineroads.world.RoadBlocks.Fill.GRASS_BLOCK
                ? net.minecraft.class_1163.method_4962(level, pos)
                : 0xFFFFFF,
        SplineRoads.COLLIDER.get());
    event.register((state,level,pos,tint)->level!=null&&pos!=null&&level.method_8321(pos) instanceof com.sora.splineroads.world.RoadFillEntity fill?class_310.method_1551().method_1505().method_1697(fill.fill(),level,pos,tint):0xFFFFFF,SplineRoads.FILLED_COLLIDER.get());
  }

  @Override
  public void render(
      NodeEntity n,
      float partial,
      class_4587 pose,
      class_4597 buffer,
      int light,
      int overlay) {
    var p = class_310.method_1551().field_1724;
    if (p == null
        || (!com.sora.splineroads.world.RoadTool.showsNodes(p.method_6047())
            && !com.sora.splineroads.world.RoadTool.showsNodes(p.method_6079()))) return;
    var renderer = class_310.method_1551().method_1541();
    renderer
        .method_3350()
        .method_3367(
            pose.method_23760(),
            buffer.getBuffer(class_1921.method_23577()),
            n.method_11010(),
            RoadTerrainModels.markerModel(renderer.method_3349(n.method_11010())),
            1,
            1,
            1,
            light,
            overlay);
    pose.method_22903();
    pose.method_22904(.5 + n.offsetX, n.offsetY + .05, .5 + n.offsetZ);
    pose.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-((float) n.yaw)));
    class_4588 c = buffer.getBuffer(class_1921.method_23594());
    line(pose, c, 0, 0, -.6f, 0, 0, .8f);
    line(pose, c, 0, 0, .8f, -.3f, 0, .4f);
    line(pose, c, 0, 0, .8f, .3f, 0, .4f);
    line(pose, c, -.3f, 0, -.3f, .3f, 0, -.3f);
    line(pose, c, .3f, 0, -.3f, .3f, 0, .3f);
    line(pose, c, .3f, 0, .3f, -.3f, 0, .3f);
    line(pose, c, -.3f, 0, .3f, -.3f, 0, -.3f);
    pose.method_22909();
  }

  private void line(
      class_4587 p, class_4588 c, float x, float y, float z, float xx, float yy, float zz) {
    float dx = xx - x, dy = yy - y, dz = zz - z, l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
    c.method_22918(p.method_23760().method_23761(), x, y, z)
        .method_1336(70, 255, 223, 255)
        .method_23763(p.method_23760().method_23762(), dx / l, dy / l, dz / l)
        .method_1344();
    c.method_22918(p.method_23760().method_23761(), xx, yy, zz)
        .method_1336(70, 255, 223, 255)
        .method_23763(p.method_23760().method_23762(), dx / l, dy / l, dz / l)
        .method_1344();
  }

  @Override
  public boolean shouldRenderOffScreen(NodeEntity n) {
    return true;
  }
}
