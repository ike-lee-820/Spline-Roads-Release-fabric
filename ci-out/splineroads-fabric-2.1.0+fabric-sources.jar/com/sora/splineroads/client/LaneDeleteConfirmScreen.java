package com.sora.splineroads.client;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.nbt.*;
/** Paged, exact-ID dependency review shared by point, road and junction deletion. */
public final class LaneDeleteConfirmScreen extends class_437 {
 private final class_437 parent;private final class_2499 ids;private final Runnable confirm;private int page;private boolean seenLast;
 public LaneDeleteConfirmScreen(class_437 parent,class_2499 ids,Runnable confirm){super(class_2561.method_43470("确认级联删除"));this.parent=parent;this.ids=ids.method_10612();this.confirm=confirm;}
 @Override protected void method_25426(){int x=(field_22789-340)/2,y=(field_22790-242)/2;seenLast|=(page+1)*8>=ids.size();method_37063(class_4185.method_46430(class_2561.method_43470("上一页"),b->{page=Math.max(0,page-1);method_41843();}).method_46434(x+12,y+176,95,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("下一页"),b->{page=Math.min((ids.size()-1)/8,page+1);method_41843();}).method_46434(x+233,y+176,95,20).method_46431());var yes=method_37063(class_4185.method_46430(class_2561.method_43470("确认删除所列依赖"),b->{field_22787.method_1507(parent);confirm.run();}).method_46434(x+12,y+210,194,20).method_46431());yes.field_22763=seenLast;method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(x+218,y+210,110,20).method_46431());}
 @Override public void method_25419(){field_22787.method_1507(parent);}
 @Override public boolean method_25421(){return false;}
 @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);int x=(field_22789-340)/2,y=(field_22790-242)/2;g.method_25294(x,y,x+340,y+242,0xf0182430);g.method_51433(field_22793,"将连同目标删除以下 "+ids.size()+" 条依赖匝道",x+12,y+12,0xffb39c,false);g.method_51433(field_22793,"仅删除清单内的有效连接及其后续分支",x+12,y+32,0xffffff,false);for(int i=0;i<8&&page*8+i<ids.size();i++)g.method_51433(field_22793,ids.method_10608(page*8+i),x+12,y+55+i*14,0x9acbff,false);g.method_51433(field_22793,(page+1)+" / "+Math.max(1,(ids.size()+7)/8),x+153,y+182,0xffffff,false);super.method_25394(g,mx,my,dt);}
}
