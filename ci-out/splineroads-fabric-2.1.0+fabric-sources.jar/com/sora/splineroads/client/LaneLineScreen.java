package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadLaneLines.Edit;
import com.sora.splineroads.core.RoadLaneLines.Pattern;
import com.sora.splineroads.world.RoadRecord;
import com.sora.splineroads.net.RoadNetwork;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;
public final class LaneLineScreen extends class_437 {
  private final class_2487 payload;private final class_2499 lines;private final RoadGeometry.Settings settings;
  private int selected,x,y,w,h;private RoadLaneLines.Pattern pattern;private double lineWidth;private class_342 widthBox;private class_4185 apply,arrows;private String status="";private boolean pending,playerFacing=true;
  public LaneLineScreen(class_2487 t){super(class_2561.method_43470("车道标线编辑器"));payload=t.method_10553();lines=t.method_10554("Lines",class_2520.field_33260);settings=RoadRecord.readSettings(t.method_10562("Settings"));select(Math.min(lines.size()-1,t.method_10550("Selected")));}
  private void edited(){ClientRoads.editorChanged(this);pending=false;if(apply!=null)apply.field_22763=true;if(arrows!=null)arrows.field_22763=true;}
  private void select(int i){edited();selected=i;var e=RoadLaneLines.get(settings,lines.method_10602(i).method_10558("Key"));pattern=e.pattern();lineWidth=e.width();}
  @Override protected void method_25426(){w=Math.min(420,field_22789-16);x=(field_22789-w)/2;h=Math.min(280,field_22790-8);y=(field_22790-h)/2;
    method_37063(class_4185.method_46430(class_2561.method_43470(playerFacing?"朝向：与玩家一致":"朝向：起点→终点"),b->{playerFacing=!playerFacing;b.method_25355(class_2561.method_43470(playerFacing?"朝向：与玩家一致":"朝向：起点→终点"));}).method_46434(x+12,y+25,w-24,18).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("◀"),b->{select((selected+lines.size()-1)%lines.size());method_41843();}).method_46434(x+12,y+h-132,28,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470(lines.method_10602(selected).method_10558("Label")),b->{select((selected+1)%lines.size());method_41843();}).method_46434(x+44,y+h-132,w-88,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("▶"),b->{select((selected+1)%lines.size());method_41843();}).method_46434(x+w-40,y+h-132,28,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("线型："+pattern.label),b->{edited();pattern=RoadLaneLines.Pattern.values()[(pattern.ordinal()+1)%RoadLaneLines.Pattern.values().length];b.method_25355(class_2561.method_43470("线型："+pattern.label));}).method_46434(x+12,y+h-105,w-126,20).method_46431());
    widthBox=new class_342(field_22793,x+w-106,y+h-105,94,20,class_2561.method_43470("线宽"));widthBox.method_1880(6);widthBox.method_1852(Double.toString(lineWidth));widthBox.method_1863(v->edited());method_37063(widthBox);
    arrows=method_37063(class_4185.method_46430(class_2561.method_43470(settings.options().hideArrows()?"本路段箭头：隐藏 · 点击显示":"本路段箭头：显示 · 点击隐藏"),b->sendArrows()).method_46434(x+12,y+h-51,w-24,20).method_46431());arrows.field_22763=!pending;
    apply=method_37063(class_4185.method_46430(class_2561.method_43470("应用到这根线"),b->send()).method_46434(x+12,y+h-76,(w-30)/2,20).method_46431());apply.field_22763=!pending;
    method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(x+w/2+3,y+h-76,(w-30)/2,20).method_46431());
  }
  public static int facingSign(double roadYaw,double playerYaw){return Math.cos(Math.toRadians(roadYaw-playerYaw))>=0?1:-1;}
  private int lx(int i){return x+26+(int)((.5+(playerFacing?facingSign(payload.method_10574("RoadYaw"),payload.method_10574("PlayerYaw")):1)*lines.method_10602(i).method_10574("Offset")/payload.method_10574("Width"))*(w-52));}
  @Override public boolean method_25402(double mx,double my,int button){if(button==0&&my>=y+57&&my<=y+h-143){int best=selected;double d=12;for(int i=0;i<lines.size();i++)if(Math.abs(mx-lx(i))<d){d=Math.abs(mx-lx(i));best=i;}select(best);method_41843();return true;}return super.method_25402(mx,my,button);}
  private void send(){if(pending)return;try{var edit=new RoadLaneLines.Edit(lines.method_10602(selected).method_10558("Key"),pattern,Double.parseDouble(widthBox.method_1882()));var t=new class_2487();t.method_10582("Action","laneLines");t.method_25927("Id",payload.method_25926("Id"));t.method_10569("Signature",payload.method_10550("Signature"));t.method_10549("Station",payload.method_10574("Station"));t.method_10582("Key",edit.key());t.method_10582("Pattern",pattern.name());t.method_10549("Width",edit.width());pending=true;apply.field_22763=false;arrows.field_22763=false;ClientRoads.sendAction(t);}catch(IllegalArgumentException e){status=e instanceof NumberFormatException?"请输入有效线宽":e.getMessage();}}
  private void sendArrows(){if(pending)return;var t=new class_2487();t.method_10582("Action","laneLines");t.method_25927("Id",payload.method_25926("Id"));t.method_10569("Signature",payload.method_10550("Signature"));t.method_10549("Station",payload.method_10574("Station"));t.method_10556("HideArrows",!settings.options().hideArrows());pending=true;apply.field_22763=false;arrows.field_22763=false;ClientRoads.sendAction(t);}
  public void failed(String s){pending=false;status=s;apply.field_22763=true;arrows.field_22763=true;}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);g.method_25294(x,y,x+w,y+h,0xf015222e);g.method_51433(field_22793,String.format(java.util.Locale.ROOT,"标线区间 %.1f–%.1f 米 · 点击选线",payload.method_10574("RangeStart"),payload.method_10574("RangeEnd")),x+12,y+13,0xffffff,false);g.method_25294(x+20,y+57,x+w-20,y+h-143,0xff43474b);
    for(int i=0;i<lines.size();i++){var p=i==selected?pattern:RoadLaneLines.get(settings,lines.method_10602(i).method_10558("Key")).pattern();int xx=lx(i),color=i==selected?0xff56d8ff:p.yellow()?0xffffd549:0xffeeeeee;for(int yy=y+65;yy<y+h-151;yy+=12)g.method_25294(xx-1,yy,xx+2,Math.min(yy+(p.dashed()?7:12),y+h-151),color);g.method_25300(field_22793,Integer.toString(i+1),xx,y+47,i==selected?0x56d8ff:0xbbbbbb);}
    super.method_25394(g,mx,my,dt);g.method_51440(field_22793,class_2561.method_43470(status.isEmpty()?"线宽 0.06–0.4 格。箭头开关仅作用于本路段。":status),x+12,y+h-26,w-24,status.isEmpty()?0xbbd3dc:0xffb58a);
  }
}
