package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGantry.Edit;
import com.sora.splineroads.core.RoadInfrastructure.Gantry;
import com.sora.splineroads.core.SmartSigns.Mode;
import com.sora.splineroads.core.SmartSigns.State;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;

public final class GantryScreen extends class_437 {
  private final class_2487 payload;private RoadGantry.Edit edit;private class_342 offset,clearance;
  /** 1=A→B, -1=B→A, 2=live player facing, 0=both (speed limit only). */
  private int flow=1;private final Map<Integer,SmartSigns.Mode> styles=new HashMap<>();private class_4185 apply,reset,remove;
  private String status="";private boolean pending,confirmRemove;private int x,y;
  private void edited(){ClientRoads.editorChanged(this);pending=false;if(apply!=null&&reset!=null)active();}
  public GantryScreen(class_2487 tag){
    super(class_2561.method_43470("Spline Roads · 单架龙门架编辑"));payload=tag.method_10553();
    edit=RoadGantry.edit(RoadRecord.readSettings(tag.method_10562("Settings")).options().infrastructure(),tag.method_10550("Slot"));
  }
  private int effective(){return flow==2?(payload.method_10550("PlayerFlow")<0?-1:1):flow==0?1:flow;}
  private SmartSigns.State sign(int direction){return SmartSignCodec.read(payload.method_10562(direction>0?"ForwardSign":"ReverseSign"));}
  private SmartSigns.Mode mode(){return styles.computeIfAbsent(effective(),f->{var m=sign(f).mode();return m==SmartSigns.Mode.NORMAL?SmartSigns.Mode.EMPTY:m==SmartSigns.Mode.EXIT_AUTO?SmartSigns.Mode.EXIT_SIGN:m;});}
  public static List<Integer> directions(SmartSigns.Mode mode,boolean twoWay){return (mode==SmartSigns.Mode.SPEED_LIMIT||mode==SmartSigns.Mode.LANE_INDICATOR)&&twoWay?List.of(1,-1,2,0):List.of(1,-1,2);}
  private String directionLabel(){return flow==0?"双向":flow==2?"当前方向（玩家朝向）":flow>0?"A → B":"B → A";}
  @Override protected void method_25426(){
    x=(field_22789-284)/2;y=Math.max(2,(field_22790-282)/2);
    offset=field("沿路位移",Double.toString(edit.offset()),x+10,y+45);
    clearance=field("横梁基准净高",Double.toString(edit.clearance()),x+148,y+45);
    SmartSigns.Mode mode=mode();
    method_37063(class_4185.method_46430(class_2561.method_43470("样式："+SmartSigns.styleLabel(mode)),b->{if(capture()){
      edited();var next=SmartSigns.STYLES.get((SmartSigns.STYLES.indexOf(mode)+1)%SmartSigns.STYLES.size());styles.put(effective(),next);if(flow==0&&next!=SmartSigns.Mode.SPEED_LIMIT&&next!=SmartSigns.Mode.LANE_INDICATOR)flow=1;confirmRemove=false;method_41843();
    }}).method_46434(x+10,y+73,264,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("行驶方向："+directionLabel()),b->{if(capture()){
      edited();var choices=directions(mode,payload.method_10577("TwoWay"));flow=choices.get((choices.indexOf(flow)+1)%choices.size());
      styles.put(effective(),mode);confirmRemove=false;method_41843();
    }}).method_46434(x+10,y+97,264,20).method_46431());
    var sign=sign(effective());status=payload.method_10577("SignUpdating")?"标牌索引正在更新，稍后重新打开查看结果":sign.diagnostic().isEmpty()?"图形自动识别，文字使用文字编辑器填写":sign.diagnostic();
    apply=method_37063(class_4185.method_46430(class_2561.method_43470("应用到这一架"),b->send(false,false)).method_46434(x+10,y+153,128,20).method_46431());
    reset=method_37063(class_4185.method_46430(class_2561.method_43470("恢复这一架默认"),b->send(true,false)).method_46434(x+146,y+153,128,20).method_46431());
    remove=method_37063(class_4185.method_46430(class_2561.method_43470(confirmRemove?"确认删除这一架":"删除这一架"),b->{if(confirmRemove)send(false,true);else{confirmRemove=true;method_41843();}}).method_46434(x+10,y+177,264,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(x+10,y+201,264,20).method_46431());
    active();
  }
  private void active(){apply.field_22763=reset.field_22763=!pending;if(remove!=null)remove.field_22763=!pending;}
  private class_342 field(String name,String value,int px,int py){var box=new class_342(field_22793,px,py,126,20,class_2561.method_43470(name));box.method_1880(16);box.method_1852(value);box.method_1863(v->edited());method_37063(box);return box;}
  private boolean capture(){
    try{var next=edit.parameters(Double.parseDouble(offset.method_1882()),Double.parseDouble(clearance.method_1882()),edit.kind(),edit.reverse());
      if(Math.abs(next.offset())>payload.method_10574("MaxOffset"))throw new IllegalArgumentException(String.format(Locale.ROOT,"这架最多前后移动 %.1f 格",payload.method_10574("MaxOffset")));
      edit=next;status="";return true;
    }catch(IllegalArgumentException e){status=e instanceof NumberFormatException?"请输入完整数值":e.getMessage();return false;}
  }
  private void send(boolean restore,boolean deleting){
    if(pending||!restore&&!deleting&&!capture())return;
    var t=new class_2487();t.method_10582("Action","gantry");t.method_25927("Id",payload.method_25926("Id"));t.method_10569("Slot",edit.slot());t.method_10569("Signature",payload.method_10550("Signature"));t.method_10556("Reset",restore);t.method_10556("Remove",deleting);
    t.method_10569("Flow",flow);t.method_10582("SignMode",restore?"NORMAL":mode().name());t.method_10544("SignRevision",sign(effective()).revision());t.method_10544("ReverseSignRevision",sign(-1).revision());
    t.method_10549("Offset",edit.offset());t.method_10549("Clearance",edit.clearance());t.method_10582("Style",edit.kind()==Gantry.OFF||edit.kind()==Gantry.AUTO?Gantry.SIGNS.name():edit.kind().name());t.method_10556("Reverse",edit.reverse());
    pending=true;active();status=deleting?"正在删除这一架…":"正在更新这座龙门架…";ClientRoads.sendAction(t);
  }
  public void failed(String message){pending=false;status=message;active();}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    method_25420(g);g.method_25294(x,y,x+284,y+282,0xf012212c);
    g.method_51433(field_22793,edit.independent()?"独立龙门架 · 不受道路龙门架开关影响":"龙门架 "+(edit.slot()+1)+" / "+payload.method_10550("Count")+" · 单独编辑",x+10,y+12,0xffffff,false);
    g.method_51433(field_22793,mode()==SmartSigns.Mode.LANE_INDICATOR?"用文字编辑器右键指示牌设置通行／禁行":"文字用文字编辑器填写；限速和车道指示样式支持双向",x+10,y+128,0xbbd3dc,false);
    g.method_51433(field_22793,"沿路位移 / 格",x+10,y+29,0xbbd3dc,false);g.method_51433(field_22793,"横梁净高 / 格",x+148,y+29,0xbbd3dc,false);
    super.method_25394(g,mx,my,dt);g.method_51440(field_22793,class_2561.method_43470(status),x+10,y+231,264,0xffcaa2);
  }
}
