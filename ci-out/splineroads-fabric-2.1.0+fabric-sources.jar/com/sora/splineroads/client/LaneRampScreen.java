package com.sora.splineroads.client;
import com.sora.splineroads.client.RoadPreviewData.Lane;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Options;
import com.sora.splineroads.core.LanePoints.Path;
import com.sora.splineroads.core.RoadGeometry.Mesh;
import com.sora.splineroads.core.RoadGeometry.Sample;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;
import java.util.*;

/** Uses the shared world preview. Hiding a screen does not discard its checked draft. */
public final class LaneRampScreen extends class_437 {
  private static LaneRampScreen active;
  private static long sequence;
  private final class_2487 payload;private final int rampLanes;
  private LanePoints.Path path;private boolean pending,gradeOverride,allowTunnel;
  private LanePoints.Departure departure;private LanePoints.Arrival arrival;
  private LanePoints.Elevation elevation;private LanePoints.Landing landing;
  private List<RoadGeometry.Mesh> checkedRoads=List.of(),conflictRoads=List.of();
  private String radiusText,transitionText;
  private class_342 radius,transition;private class_4185 build,previewButton,details,back,worldButton,deleteButton;private boolean diagnostic;private UUID token;private RoadGeometry.Mesh checkedMesh;
  private final List<RoadGeometry.Mesh> contextRoads=new ArrayList<>();
  private long request=++sequence,pendingSince;private int x,y,control,panelWidth,panelHeight,widgetHeight=20;private double uiScale=1;
  private String status="设置完成后点击计算预览；实景预览可切换到世界。Shift＋右键清除选点。";
  public LaneRampScreen(class_2487 t){
    super(class_2561.method_43470(t.method_25928("Id")?"编辑匝道":"匝道连接器"));payload=t.method_10553();
    var o=LanePointCodec.options(t.method_10562("Options"));rampLanes=o.lanes();path=o.path();departure=o.departure();arrival=o.arrival();elevation=o.elevation();landing=o.landing();gradeOverride=o.gradeOverride();allowTunnel=o.allowTunnel();radiusText=number(o.radius());transitionText=number(o.transition());
    if(t.method_10577("SourceRamp"))departure=LanePoints.Departure.BRANCH;
    else if(t.method_10577("SourceTunnel")||t.method_10577("SourceHighway"))departure=LanePoints.Departure.EXTRA;
    if(t.method_10577("TargetRamp"))arrival=LanePoints.Arrival.FLOW;
    else if(t.method_10577("TargetTunnel")||t.method_10577("TargetHighway"))arrival=LanePoints.Arrival.EXTRA;
    for(class_2520 value:t.method_10554("ContextRoads",class_2520.field_33260))contextRoads.add(RoadRecord.load((class_2487)value).mesh());
    if(t.method_10545("Road"))checkedMesh=RoadRecord.load(t.method_10562("Road")).mesh();
  }
  private static LanePoints.Arrival nextArrival(LanePoints.Arrival current){
    var choices=List.of(LanePoints.Arrival.MERGE,LanePoints.Arrival.ADD,LanePoints.Arrival.EXTRA,LanePoints.Arrival.FLOW);
    return choices.get((choices.indexOf(current)+1)%choices.size());
  }
  private static String number(double value){return String.format(Locale.ROOT,"%s",value==(int)value?Integer.toString((int)value):Double.toString(value));}
  public static void open(class_2487 t){
    if(active==null||!t.method_25928("Id")||!active.payload.method_25928("Id")||!t.method_25926("Id").equals(active.payload.method_25926("Id"))||t.method_10550("Signature")!=active.payload.method_10550("Signature")){
      clear();active=new LaneRampScreen(t);
    }
    resume();
  }
  public static void resume(){if(active!=null){ClientRoads.beginEditor(active);active.showWorld();class_310.method_1551().method_1507(active);}}
  private void showWorld(){
    // Request ids reject older drafts in this screen. The shared editor owner
    // also prevents a valid hidden result from replacing a different tool's preview.
    if(!ClientRoads.ownsPreview(this))return;
    ClientRoads.conflictPreview=!conflictRoads.isEmpty();ClientRoads.preview=conflictRoads.isEmpty()?checkedMesh:conflictRoads.get(0);ClientRoads.nodePreviews=conflictRoads.isEmpty()?checkedRoads:conflictRoads;
  }
  public static void resume(class_2487 t){if(active==null&&t.method_10545("Fallback"))open(t.method_10562("Fallback"));else resume();}
  public static boolean clear(){
    boolean owned=ClientRoads.endEditor(active);
    if(owned){ClientRoads.conflictPreview=false;ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();}
    active=null;++sequence;return owned;
  }
  public static void checkedReply(class_2487 t){if(active!=null)active.checked(t);}
  public static void checkedReply(class_2487 t,RoadPreviewData prepared){if(active!=null)active.checked(t,prepared);}
  static void deliveryRecovery(){if(active!=null&&active.pending&&active.token==null){active.cancelPreview();active.request=++sequence;active.failed("预览传输繁忙，请重新预览");}}
  public static void failedPending(String message,class_2487 reply){if(active!=null&&active.pending&&active.token!=null)active.failed(message,reply);}
  private int row(int offset){return y+(int)Math.round(offset*uiScale);}
  @Override protected void method_25426(){
    x=12;y=Math.max(6,(field_22790-360)/2);panelWidth=field_22789-24;panelHeight=field_22790-2*y;control=Math.min(330,(panelWidth-36)/2);uiScale=Math.min(1,(field_22790-24)/340.0);widgetHeight=Math.max(14,(int)Math.round(20*uiScale));
    for(var choice:LanePoints.Path.values())method_37063(class_4185.method_46430(class_2561.method_43470((choice==path?"● ":"")+choice.label),b->{path=choice;invalidate();method_41843();}).method_46434(x+12+choice.ordinal()*(control/5),row(51),control/5-2,widgetHeight).method_46431());
    var sourceButton=method_37063(class_4185.method_46430(class_2561.method_43470("汇出："+departure.label+(payload.method_10577("SourceRamp")?"（匝道）":payload.method_10577("SourceHighway")?"（高速）":payload.method_10577("SourceTunnel")?"（隧道）":"")),b->{departure=LanePoints.Departure.values()[(departure.ordinal()+1)%LanePoints.Departure.values().length];invalidate();method_41843();}).method_46434(x+12,row(81),control/2-5,widgetHeight).method_46431());
    var targetButton=method_37063(class_4185.method_46430(class_2561.method_43470("汇入："+arrival.label+(payload.method_10577("TargetRamp")?"（匝道）":payload.method_10577("TargetHighway")?"（高速）":payload.method_10577("TargetTunnel")?"（隧道）":"")),b->{arrival=nextArrival(arrival);invalidate();method_41843();}).method_46434(x+17+control/2,row(81),control/2-5,widgetHeight).method_46431());
    sourceButton.field_22763=!payload.method_10577("SourceHighway")&&!payload.method_10577("SourceTunnel")&&!payload.method_10577("SourceRamp");targetButton.field_22763=!payload.method_10577("TargetHighway")&&!payload.method_10577("TargetTunnel")&&!payload.method_10577("TargetRamp");
    method_37063(class_4185.method_46430(class_2561.method_43470(elevation.label),b->{elevation=LanePoints.Elevation.values()[(elevation.ordinal()+1)%LanePoints.Elevation.values().length];invalidate();method_41843();}).method_46434(x+12,row(108),control/2-5,widgetHeight).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470(landing.label),b->{landing=LanePoints.Landing.values()[(landing.ordinal()+1)%LanePoints.Landing.values().length];invalidate();method_41843();}).method_46434(x+17+control/2,row(108),control/2-5,widgetHeight).method_46431());
    radius=new class_342(field_22793,x+12,row(146),control/2-5,widgetHeight,class_2561.method_43470("参考半径"));radius.method_1880(32);radius.method_1852(radiusText);radius.method_1863(s->{radiusText=s;invalidate();});radius.method_47400(class_7919.method_47407(class_2561.method_43470("规划参考半径：圆弧按此半径布线；直接连接及端口拟合的实际最小半径以已检查预览为准。")));method_37063(radius);
    transition=new class_342(field_22793,x+17+control/2,row(146),control/2-5,widgetHeight,class_2561.method_43470("过渡长度"));transition.method_1880(32);transition.method_1852(transitionText);transition.method_1863(s->{transitionText=s;invalidate();});method_37063(transition);
    method_37063(class_4185.method_46430(class_2561.method_43470(gradeOverride?"坡比超限：开（普通25% / 涉高速20%）":"坡比超限：关（普通20% / 涉高速15%）"),b->{gradeOverride=!gradeOverride;invalidate();method_41843();}).method_46434(x+12,row(173),control,widgetHeight).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("允许隧道："+(allowTunnel?"开":"关")+"（地下接头始终允许）"),b->{allowTunnel=!allowTunnel;invalidate();method_41843();}).method_46434(x+12,row(197),control,widgetHeight).method_46431());
    int third=(control-8)/3;
    previewButton=method_37063(class_4185.method_46430(class_2561.method_43470("计算预览"),b->preview()).method_46434(x+12,row(227),third,widgetHeight).method_46431());previewButton.field_22763=!pending;
    build=method_37063(class_4185.method_46430(class_2561.method_43470(payload.method_25928("Id")?"保存匝道":"建造 A → B"),b->submit()).method_46434(x+20+third*2,row(227),third,widgetHeight).method_46431());build.field_22763=token!=null&&!pending;
    back=method_37063(class_4185.method_46430(class_2561.method_43470(pending&&token==null?"取消计算并返回":"返回实景 / 预览"),b->{if(pending&&token==null){cancelPreview();invalidate();}showWorld();ManualPlannerClient.worldPreview();method_25419();}).method_46434(x+16+third,row(227),third,widgetHeight).method_46431());
    worldButton=back;
    if(ManualPlannerClient.hasMap())method_37063(class_4185.method_46430(class_2561.method_43470("规划地图"),b->{showWorld();ManualPlannerClient.mapPreview(this);}).method_46434(x+12,row(251),third,widgetHeight).method_46431());
    details=method_37063(class_4185.method_46430(class_2561.method_43470("失败详情"),b->class_310.method_1551().method_1507(new FailureDetails(this,status))).method_46434(x+16+third,row(251),third,widgetHeight).method_46431());details.field_22764=diagnostic;details.field_22763=diagnostic;
    if(payload.method_25928("Id")){
      deleteButton=method_37063(class_4185.method_46430(class_2561.method_43470("删除匝道"),b->{
        if(pending)cancelPreview();invalidate();
        var t=new class_2487();t.method_10582("Action","laneRampDeletePreview");t.method_25927("Id",payload.method_25926("Id"));t.method_10569("Signature",payload.method_10550("Signature"));
        t.method_10566("From",payload.method_10562("From").method_10553());t.method_10566("To",payload.method_10562("To").method_10553());ClientRoads.sendAction(t);
      }).method_46434(x+20+third*2,row(251),third,widgetHeight).method_46431());deleteButton.field_22763=!pending;
    }

  }
  private void cancelPreview(){var t=new class_2487();t.method_10582("Action","laneRampCancel");t.method_10544("Request",request);ClientRoads.sendAction(t);}
  private void invalidate(){ClientRoads.editorChanged(this);conflictRoads=List.of();ClientRoads.conflictPreview=false;if(pending)cancelPreview();diagnostic=false;if(details!=null){details.field_22764=false;details.field_22763=false;}token=null;checkedMesh=null;checkedRoads=List.of();pending=false;if(build!=null)build.field_22763=false;if(previewButton!=null)previewButton.field_22763=true;ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();request=++sequence;status=switch(departure){
      case TEMPORARY -> "保留车道分离：直连匝道，主路暂时关闭该车道；净空安全后恢复。地面封闭绿化、高架直角孔区。请预览。";
      case DETACH -> "整车道分离：直连匝道，主路下游取消该车道。请预览。";
      case BRANCH -> "普通分流：原车道继续直行；不是先关闭再恢复。请预览。";
      case EXTRA -> "额外扩出：保持既有车道，另拓出匝道。请预览。";
    };}
  private class_2487 command(String action){var t=new class_2487();t.method_10582("Action",action);t.method_10566("From",payload.method_10562("From").method_10553());t.method_10566("To",payload.method_10562("To").method_10553());if(payload.method_25928("Id")){t.method_25927("Id",payload.method_25926("Id"));t.method_10569("Signature",payload.method_10550("Signature"));}t.method_10566("Options",LanePointCodec.options(new LanePoints.Options(path,departure,arrival,Double.parseDouble(radiusText),Double.parseDouble(transitionText),elevation,landing,gradeOverride,allowTunnel,rampLanes)));t.method_10544("Request",request);return t;}
  private void preview(){try{invalidate();var t=command("laneRampPreview");pending=true;pendingSince=System.nanoTime();previewButton.field_22763=false;if(deleteButton!=null)deleteButton.field_22763=false;ClientRoads.sendAction(t);status="正在后台检查方向、汇入范围与净空，可取消计算…";}catch(IllegalArgumentException e){failed(e.getMessage());}}
  public void checked(class_2487 t){checked(t,null);}
  private void checked(class_2487 t,RoadPreviewData prepared){
    if(t.method_10537("Request")!=request)return;pending=false;
    if(t.method_10545("Error")){if(prepared==null)failed(t.method_10558("Error"),t);else failed(t.method_10558("Error"),prepared.conflicts());return;}
    try{var ready=prepared==null?RoadPreviewData.preparePayload(t).lane():prepared.lane();var r=ready.road();checkedMesh=ready.mesh();checkedRoads=ready.roads();showWorld();token=t.method_25926("Token");build.field_22763=true;previewButton.field_22763=true;worldButton.field_22763=true;if(deleteButton!=null)deleteButton.field_22763=true;
      double offset=t.method_10574("TargetOffset");String landing=payload.method_10562("To").method_25928("Junction")?"":String.format(Locale.ROOT," 汇入口：沿 B 行驶方向 %+.1f 格。",offset);
      String grade=t.method_10545("GradeLimit")?" 坡比上限 "+LaneRampGrade.label(t.method_10574("GradeLimit"))+"。":"";
      if(t.method_10545("GradeAvailable"))grade=String.format(Locale.ROOT," 水平 %.1f / 可布坡 %.1f 格，当前变程需≥%.1f 格；实际最大 %.2f%%，上限 %s。",t.method_10574("GradeHorizontal"),t.method_10574("GradeAvailable"),t.method_10574("GradeMinimum"),t.method_10574("ActualGrade")*100,LaneRampGrade.label(t.method_10574("GradeLimit")));
      String closure=t.method_10577("TemporaryClosure")?(t.method_10577("RectangularClosure")?String.format(Locale.ROOT," 主路从 A 暂时关闭此车道，下游 %.1f 格处恢复；封闭区不收尖。",t.method_10574("RestoredAfter")):String.format(Locale.ROOT," 主路从A暂时关闭此车道，下游 %.1f 格开始恢复、%.1f 格恢复完整。",t.method_10574("ReopenAfter"),t.method_10574("RestoredAfter"))):"";
      String targetClosure=t.method_10577("TargetClosure")?String.format(Locale.ROOT," 目标车道在汇入口前 %.1f 格开始封闭，到匝道完整接入后开放；其他车道保持通行。",t.method_10574("TargetClosedBefore")):"";
      double minimumRadius=ready.minimumRadius();
      String radiusLabel=Double.isFinite(minimumRadius)?String.format(Locale.ROOT,"%.2f 格",minimumRadius):"直线";
      status=String.format(Locale.ROOT,"预览有效：%s，长 %.1f 格，实际最小半径 %s。%s%s%s%s 右键空气返回并建造。",t.method_10545("ResolvedPath")?LanePoints.Path.valueOf(t.method_10558("ResolvedPath")).label:path.label,r.mesh().length(),radiusLabel,landing,closure,targetClosure,grade);
      
    }catch(IllegalArgumentException e){failed(e.getMessage());}
  }
  private void submit(){try{if(token==null||pending)return;var t=command("laneRamp");t.method_25927("Token",token);pending=true;pendingSince=System.nanoTime();status="正在建造：服务端校验接头、生成设施并写入道路，请勿重复提交。";build.field_22763=false;previewButton.field_22763=false;ClientRoads.sendAction(t);}catch(IllegalArgumentException e){failed(e.getMessage());}}
  public void failed(String s){failed(s,new class_2487());}
  void completed(){pending=false;token=null;status="匝道已建成";if(build!=null)build.field_22763=false;if(previewButton!=null)previewButton.field_22763=false;}
  public void failed(String s,class_2487 reply){
    var roads=new ArrayList<RoadGeometry.Mesh>();
    for(class_2520 value:reply.method_10554("ConflictRoads",class_2520.field_33260))try{roads.add(RoadRecord.load((class_2487)value).mesh());}catch(IllegalArgumentException ignored){}
    failed(s,List.copyOf(roads));}
  void failed(String s,List<RoadGeometry.Mesh> roads){
    if(deleteButton!=null)deleteButton.field_22763=true;
    conflictRoads=roads;status=RoadConflictIds.display(s)+(roads.isEmpty()?"":"；冲突道路已标红，返回实景查看，Shift＋右键清除。");diagnostic=true;if(details!=null){details.field_22764=true;details.field_22763=true;}pending=false;if(build!=null)build.field_22763=false;if(previewButton!=null)previewButton.field_22763=true;token=null;checkedMesh=null;checkedRoads=List.of();showWorld();}
  void failureGeometry(String message,List<RoadGeometry.Mesh> roads){
    conflictRoads=roads;status=RoadConflictIds.display(message)+(roads.isEmpty()?"":"；冲突道路已标红，返回实景查看，Shift＋右键清除。");showWorld();
  }
  private static String brief(String message){
    int end=message.indexOf('；');if(end<0)end=message.indexOf('。');
    String first=end>0?message.substring(0,end):message;
    return (first.length()>70?first.substring(0,70)+"…":first)+"。点击“失败详情”查看冲突坐标和完整原因。";
  }
  /** Full diagnostic page instead of overflowing the six-line connector footer. */
  private static final class FailureDetails extends class_437 {
    private final LaneRampScreen parent;private final String message;
    FailureDetails(LaneRampScreen parent,String message){super(class_2561.method_43470("匝道建造失败详情"));this.parent=parent;this.message=message;}
    @Override protected void method_25426(){method_37063(class_4185.method_46430(class_2561.method_43470("返回匝道设置"),b->method_25419()).method_46434((field_22789-160)/2,field_22790-30,160,20).method_46431());}
    @Override public void method_25394(class_332 g,int mx,int my,float dt){
      g.method_25294(12,12,field_22789-12,field_22790-12,0xf015222e);
      g.method_51433(field_22793,"建造未通过：完整诊断",24,24,0xffcf8c,false);
      g.method_51440(field_22793,class_2561.method_43470(message),24,44,Math.max(100,field_22789-48),0xffffff);
      super.method_25394(g,mx,my,dt);
    }
    @Override public void method_25419(){class_310.method_1551().method_1507(parent);}
    @Override public boolean method_25421(){return false;}
  }
  @Override public void method_25419(){super.method_25419();}
  @Override public boolean method_25421(){return false;}
  // Opening, resizing and editing never dispatch expensive planning requests.
  // Only the explicit preview button may start a new checked draft.
  private void map(class_332 g,int left,int top,int w,int h){
    g.method_25294(left,top,left+w,top+h,0xff09161f);
    var roads=new ArrayList<>(contextRoads);roads.addAll(checkedRoads);roads.addAll(conflictRoads);if(checkedMesh!=null)roads.add(checkedMesh);
    if(roads.isEmpty()){g.method_51433(field_22793,"选择 A、B 后计算俯视预览",left+8,top+30,0xafc8d3,false);return;}
    double minX=roads.stream().mapToDouble(m->m.min().x()).min().orElse(0),maxX=roads.stream().mapToDouble(m->m.max().x()).max().orElse(1);
    double minZ=roads.stream().mapToDouble(m->m.min().z()).min().orElse(0),maxZ=roads.stream().mapToDouble(m->m.max().z()).max().orElse(1);
    double scale=Math.min((w-24)/Math.max(1,maxX-minX),(h-42)/Math.max(1,maxZ-minZ));
    double ox=left+(w-(maxX-minX)*scale)/2,oy=top+22+(h-42-(maxZ-minZ)*scale)/2;
    for(var road:roads){int color=conflictRoads.contains(road)?0xffe06060:road==checkedMesh?0xff61cde3:0xff536b7a;
      for(int i=0;i<road.samples().size();i+=2){var p=road.samples().get(i);int px=(int)(ox+(p.center().x()-minX)*scale),py=(int)(oy+(p.center().z()-minZ)*scale),r=Math.max(1,(int)Math.ceil(p.halfWidth()*scale));
        g.method_25294(Math.max(left+2,px-r),Math.max(top+20,py-r),Math.min(left+w-2,px+r+1),Math.min(top+h-2,py+r+1),color);
      }
    }
    if(checkedMesh!=null)for(int i=0;i<2;i++){var p=(i==0?checkedMesh.first():checkedMesh.last()).center();g.method_51433(field_22793,i==0?"A":"B",(int)(ox+(p.x()-minX)*scale),(int)(oy+(p.z()-minZ)*scale),0xffffff,false);}
    // Minecraft north is negative Z. World X/Z are projected directly, never
    // rotated by the player's yaw or the order in which A and B were selected.
    g.method_51433(field_22793,"北 ↑  N",left+w-55,top+6,0xffffff,false);
    g.method_51433(field_22793,pending?"计算中…":checkedMesh==null?"道路位置 · 等待预览":"俯视预览",left+8,top+6,0x9ed7e6,false);
  }
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    if(back!=null)back.method_25355(class_2561.method_43470(pending&&token==null?"取消计算并返回":"返回实景 / 预览"));
    g.method_25294(x,y,x+panelWidth,y+panelHeight,0xea15222e);
    g.method_51433(field_22793,payload.method_25928("Id")?"编辑匝道 · A 汇出 → B 汇入":"匝道连接器 · A 汇出 → B 汇入",x+12,row(12),0x66b5ff,false);
    g.method_51433(field_22793,payload.method_10562("To").method_25928("Junction")?"目标：路口接入口":landing==LanePoints.Landing.EXACT?"目标：锁定 B":"目标：整条连续同车道",x+12,row(32),0xd2e2ed,false);
    g.method_51433(field_22793,"参考半径",x+12,row(134),0xffffff,false);g.method_51433(field_22793,"过渡长度",x+17+control/2,row(134),0xffffff,false);
    map(g,x+control+24,row(32),panelWidth-control-36,(int)Math.round(239*uiScale));
    g.method_44379(x+10,row(283),x+panelWidth-10,y+panelHeight-6);
    g.method_51440(field_22793,class_2561.method_43470(pending?status+String.format(Locale.ROOT," 已等待 %.1f 秒。",(System.nanoTime()-pendingSince)/1e9):diagnostic?brief(status):status),x+12,row(283),panelWidth-24,0xffcf8c);
    g.method_44380();
    previewButton.method_47400(class_7919.method_47407(class_2561.method_43470(status)));
    super.method_25394(g,mx,my,dt);
  }
}
