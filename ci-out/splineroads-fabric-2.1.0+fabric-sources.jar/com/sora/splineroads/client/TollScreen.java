package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.Mesh;
import com.sora.splineroads.core.RoadGeometry.Sample;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.core.RoadStructures.Part;
import com.sora.splineroads.core.RoadSurface.Face;
import com.sora.splineroads.core.TollPlanner.Lengths;
import com.sora.splineroads.core.TollPlaza.*;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import com.mojang.blaze3d.vertex.*;
import ;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_757;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;
import org.joml.Matrix4f;

/** Closing preserves the world preview; every parameter edit invalidates its commit token. */
public final class TollScreen extends class_437 {
  private static class_2487 draft;private static TollScreen waiting;private static long requests;
  private final class_2487 payload;private final List<Runnable> captures=new ArrayList<>();private final List<Label> labels=new ArrayList<>();
  private record Label(String text,int x,int y){}
  private int page,left,top,panel,previewDelay=8;private double uiScale=1;private List<RoadSurface.Face> mapFaces=List.of();private boolean initializing,pending,awaitingPreview,deleteConfirm;private class_4185 build,preview,calculate;private String status="正在准备俯视预览…";private UUID token;private long request;
  private RoadPreviewData.Toll checked;
  private double mapMinX,mapMinZ,mapMaxX,mapMaxZ;
  public TollScreen(class_2487 t){super(class_2561.method_43470("Spline Roads · 收费站"));payload=t.method_10553();payload.method_10551("Token");if(!inline())TollCodec.standaloneMode(payload.method_10562("Spec"),payload.method_10562("Spec").method_10577("TwoWay"));request=++requests;}
  public static void clear(){
    var mc=class_310.method_1551();TollScreen owner=waiting!=null?waiting:mc.field_1755 instanceof TollScreen screen?screen:null;
    if(waiting!=null&&(waiting.token!=null||waiting.pending))waiting.cancelPreview();
    boolean owned=owner!=null&&ClientRoads.endEditor(owner);if(owner!=null){owner.pending=false;owner.awaitingPreview=false;}draft=null;waiting=null;++requests;
    if(owned){clearPublished();if(mc.field_1755==owner)mc.method_1507(null);}
  }
  private static void clearPublished(){TollPreview.clear();JunctionScreen.previewMesh=null;JunctionScreen.previewFaces=List.of();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();}
  private static void resume(TollScreen screen){ClientRoads.beginEditor(screen);screen.showWorld();class_310.method_1551().method_1507(screen);}
  private void showWorld(){if(!ClientRoads.ownsPreview(this))return;ClientRoads.conflictPreview=false;if(checked==null){clearPublished();return;}TollPreview.show(TollCodec.read(payload.method_10562("Spec")),checked.plan());ClientRoads.preview=checked.mesh();ClientRoads.nodePreviews=checked.roads();JunctionScreen.previewMesh=checked.mesh();JunctionScreen.previewFaces=checked.faces();}
  public static void open(class_2487 fresh){open(fresh,null);}
  public static void open(class_2487 fresh,RoadPreviewData prepared){
    String kind=fresh.method_10558("Kind");if(kind.equals("tollReset")){
      var screen=waiting!=null?waiting:class_310.method_1551().field_1755 instanceof TollScreen current?current:null;
      if(fresh.method_10545("Request")&&(screen==null||screen.request!=fresh.method_10537("Request")))return;
      clear();return;
    }
    if(kind.equals("tollCheck")){if(waiting!=null)waiting.checked(fresh,prepared);return;}
    if(kind.equals("tollResume")){if(waiting!=null)resume(waiting);else if(draft!=null)resume(new TollScreen(draft));return;}
    // Keep the exact validated draft/token when returning from a world preview.
    // The server still validates snapshots and token lifetime at commit.
    if(waiting!=null&&!fresh.method_10577("DeleteOnly")&&sameSelection(fresh,waiting.payload)){
      resume(waiting);return;
    }
    if(waiting!=null){waiting.cancelPreview();if(ClientRoads.ownsPreview(waiting))clearPublished();waiting.request=++requests;waiting=null;}
    var t=fresh.method_10553();
    if(draft!=null&&!t.method_10577("DeleteOnly")&&sameSelection(t,draft)){
      var current=TollCodec.read(t.method_10562("Spec"));var previous=TollCodec.read(draft.method_10562("Spec"));t.method_10566("Spec",TollCodec.write(new Spec(current.a(),current.b(),previous.config(),current.portA(),current.portB(),current.path())));t.method_10582("Adjust",draft.method_10558("Adjust"));
    }
    class_310.method_1551().method_1507(new TollScreen(t));
  }
  private static boolean sameSelection(class_2487 a,class_2487 b){
    return Objects.equals(a.method_10580("InlineRoad"),b.method_10580("InlineRoad"))&&a.method_10574("InlineStation")==b.method_10574("InlineStation")&&a.method_10550("InlineSignature")==b.method_10550("InlineSignature")&&Arrays.equals(a.method_10565("Points"),b.method_10565("Points"))&&Objects.equals(a.method_25928("Id")?a.method_25926("Id"):null,b.method_25928("Id")?b.method_25926("Id"):null);
  }
  private void remember(){if(!payload.method_10577("DeleteOnly"))draft=payload.method_10553();}
  private void cancelPreview(){awaitingPreview=false;if(class_310.method_1551().method_1562()!=null){var t=new class_2487();t.method_10582("Action","tollCancelPreview");t.method_10544("Request",request);if(token!=null)t.method_25927("Token",token);ClientRoads.sendAction(t);}}
  private void changed(){if(initializing||pending&&!awaitingPreview)return;ClientRoads.editorChanged(this);if(token!=null||pending)cancelPreview();token=null;checked=null;pending=false;awaitingPreview=false;request=++requests;status="参数已改变，请点击计算更新俯视预览";previewDelay=0;mapFaces=List.of();if(build!=null)build.field_22763=false;if(preview!=null)preview.field_22763=false;if(calculate!=null)calculate.field_22763=true;if(ClientRoads.ownsPreview(this))clearPublished();}
  /** EditBox also reports cursor movement; only text changes invalidate the receipt. */
  private void watch(class_342 box){String[] previous={box.method_1882()};box.method_1863(value->{if(!value.equals(previous[0])){previous[0]=value;changed();}});}
  private boolean capture(){if(pending&&!awaitingPreview)return true;try{captures.forEach(Runnable::run);TollCodec.read(payload.method_10562("Spec"));remember();return true;}catch(IllegalArgumentException e){status=e.getMessage();token=null;return false;}}
  private boolean inline(){return payload.method_25928("InlineRoad")||payload.method_10562("Spec").method_10545("Path");}
  private class_4185 button(String label,int x,int y,int w,Runnable action){return method_37063(class_4185.method_46430(class_2561.method_43470(label),b->action.run()).method_46434(x,y,w,Math.max(14,(int)Math.round(20*uiScale))).method_46431());}
  private void change(Runnable action){if(pending&&!awaitingPreview)return;if(capture()){action.run();changed();remember();method_41843();}}
  private void field(String name,class_2487 t,String key,int col,int row,boolean integer){
    int w=(panel-30)/2,x=left+10+col*(w+10),y=row(56+row*38);labels.add(new Label(name,x,y));var box=new class_342(field_22793,x,y+10,w,Math.max(12,(int)Math.round(18*uiScale)),class_2561.method_43470(name));box.method_1880(8);box.method_1852(integer?Integer.toString(t.method_10550(key)):String.format(Locale.ROOT,"%.2f",t.method_10574(key)));watch(box);method_37063(box);
    if(inline()&&Set.of("A","B","LaneWidth").contains(key))box.method_1888(false);
    captures.add(()->{try{if(integer)t.method_10569(key,Integer.parseInt(box.method_1882()));else t.method_10549(key,Double.parseDouble(box.method_1882()));}catch(NumberFormatException e){throw new IllegalArgumentException(name+"：请输入有效数字");}});
  }
  @Override protected void method_25426(){
    initializing=true;captures.clear();labels.clear();panel=Math.min(330,(field_22789-48)/2);left=12;top=8;uiScale=Math.min(1,(field_22790-20)/340.0);int half=(panel-30)/2,x=left+10;
    String[] tabs={"模式/端点",payload.method_10562("Spec").method_10577("TwoWay")?"A→B 参数":"单向参数",payload.method_10562("Spec").method_10577("TwoWay")?"B→A 参数":"双向预设","尺寸"};for(int i=0;i<4;i++){int next=i;button((page==i?"● ":"")+tabs[i],x+i*(panel-20)/4,row(26),(panel-26)/4,()->{if(capture()){page=next;method_41843();}});}
    var s=payload.method_10562("Spec");
    if(page==0){
      button("模式："+(s.method_10577("TwoWay")?"双向":"单向"),x,row(60),half,()->change(()->TollCodec.standaloneMode(s,!s.method_10577("TwoWay")))).field_22763=!inline();
      var reverse=button("单向："+(s.method_10577("Reverse")?"B→A":"A→B"),x+half+10,row(60),half,()->change(()->s.method_10556("Reverse",!s.method_10577("Reverse"))));reverse.field_22763=!s.method_10577("TwoWay")&&!inline();
      button(s.method_10577("LeftTraffic")?"左侧通行":"右侧通行",x,row(86),panel-20,()->change(()->s.method_10556("LeftTraffic",!s.method_10577("LeftTraffic")))).field_22763=!inline();
      button(inline()?"原路断面接口固定":"调整："+adjustLabel(payload.method_10558("Adjust")),x,row(112),panel-20,()->change(()->{var values=Adjust.values();payload.method_10582("Adjust",values[(Adjust.valueOf(payload.method_10558("Adjust")).ordinal()+1)%values.length].name());})).field_22763=!inline();
      int nx=x;labels.add(new Label("收费站名称（选填）",nx,row(138)));
      var name=new class_342(field_22793,nx,row(150),panel-20,Math.max(14,(int)Math.round(20*uiScale)),class_2561.method_43470("收费站名称（选填，默认空）"));name.method_1880(80);name.method_1852(s.method_10558("Name"));watch(name);method_37063(name);captures.add(()->s.method_10582("Name",name.method_1882()));
    }else if(page==1||page==2){
      var d=s.method_10562(page==1?"Forward":"Backward");field("A 端车道数 1–7",d,"A",0,0,true);field("B 端车道数 1–7",d,"B",1,0,true);field("ETC 通道（合计 1–7）",d,"ETC",0,1,true);field("人工通道（合计 1–7）",d,"Manual",1,1,true);
      labels.add(new Label(page==2&&!s.method_10577("TwoWay")?"单向只用第一组数量；反转保持 A/B 配置归属":"每个单元对应一条收费通道；两向分别保存",x,row(140)));
    }else{
      field("接口车道宽 2–5",s,"LaneWidth",0,0,false);field("收费通道净宽 4–7",s,"PassageWidth",1,0,false);field("最低净高 6–10",s,"ClearHeight",0,1,false);
      button("结构："+s.method_10558("Structure"),x+half+10,row(101),half,()->change(()->s.method_10582("Structure",switch(s.method_10558("Structure")){case "AUTO"->"GROUND";case "GROUND"->"BRIDGE";default->"AUTO";})));
    }
    int foot=field_22790-54,third=(panel-28)/3;
    calculate=button("计算",x,foot,third,()->requestPreview());calculate.field_22763=!pending&&!payload.method_10577("DeleteOnly");
    preview=button("实景预览",x+third+4,foot,third,()->preview());preview.field_22763=token!=null&&checked!=null&&!pending;
    build=button(payload.method_25928("Id")?"更新收费站":"建造收费站",x+2*(third+4),foot,third,()->submit("tollBuild"));build.field_22763=token!=null&&checked!=null&&!pending;
    button("关闭",x,field_22790-30,third,()->method_25419());
    if(payload.method_25928("Id"))button(deleteConfirm?"确认删除收费站":"删除收费站",x+third+4,field_22790-30,2*third+4,()->{if(!deleteConfirm){deleteConfirm=true;method_41843();}else submit("tollDelete");});
    if(payload.method_10577("DeleteOnly")){preview.field_22763=false;build.field_22763=false;}
    initializing=false;
  }
  private static String adjustLabel(String s){return switch(s){case "AB"->"AB 两端等量延长";case "A"->"仅移动 A";case "B"->"仅移动 B";default->"固定 A/B";};}
  private int row(int offset){return top+(int)Math.round(offset*uiScale);}
  @Override public void method_25393(){if(previewDelay>0&&--previewDelay==0&&!payload.method_10577("DeleteOnly"))requestPreview();}
  private void preview(){if(pending||checked==null||token==null)return;showWorld();ManualPlannerClient.worldPreview();class_310.method_1551().method_1507(null);}
  private void requestPreview(){if(pending||!capture())return;previewDelay=0;ClientRoads.editorChanged(this);try{
    token=null;pending=true;awaitingPreview=true;waiting=this;request=++requests;status="正在计算并校验地形、端点与外接道路…";build.field_22763=false;preview.field_22763=false;calculate.field_22763=false;
    var t=TollInputs.command(payload);t.method_10582("Action","tollPreview");t.method_10544("Request",request);ClientRoads.sendAction(t);
  }catch(IllegalArgumentException e){pending=false;awaitingPreview=false;status=e.getMessage();token=null;build.field_22763=false;calculate.field_22763=true;}}
  private static List<RoadSurface.Face> faces(TollPlanner.Plan p){var out=new ArrayList<>(p.paint());for(var part:p.structures())out.addAll(part.faces());return List.copyOf(out);}
  private void checked(class_2487 t,RoadPreviewData prepared){if(t.method_10537("Request")!=request||!awaitingPreview)return;pending=false;awaitingPreview=false;if(calculate!=null)calculate.field_22763=true;
    if(t.method_10545("Error")){if(preview!=null)preview.field_22763=false;status=t.method_10558("Error");token=null;checked=null;if(build!=null)build.field_22763=false;if(ClientRoads.ownsPreview(this)){clearPublished();class_310.method_1551().method_1507(this);}return;}
    var result=t.method_10562("Inputs");token=result.method_25926("Token");checked=prepared==null?RoadPreviewData.preparePayload(t).toll():prepared.toll();prepareMap();showWorld();if(preview!=null)preview.method_25355(class_2561.method_43470("实景预览"));
    status=String.format(Locale.ROOT,"可建造 · A 移动 %.1f / B 移动 %.1f 格 · 联动外接道路 %d 条",result.method_10574("MovedA"),result.method_10574("MovedB"),result.method_10550("Affected"));if(build!=null)build.field_22763=true;if(preview!=null)preview.field_22763=true;remember();if(ClientRoads.ownsPreview(this)&&class_310.method_1551().field_1755==null&&class_310.method_1551().field_1724!=null)class_310.method_1551().field_1724.method_7353(class_2561.method_43470("收费站预览已就绪，可返回设置建造"),true);
  }
  private void submit(String action){if(pending||!capture())return;if(action.equals("tollBuild")&&(token==null||checked==null))return;var t=TollInputs.command(payload);t.method_10582("Action",action);if(token!=null)t.method_25927("Token",token);pending=true;awaitingPreview=false;waiting=this;build.field_22763=false;preview.field_22763=false;calculate.field_22763=false;ClientRoads.sendAction(t);}
  public static void result(TollScreen owner,boolean success,String message){if(waiting!=owner||!owner.pending)return;var screen=waiting;screen.pending=false;screen.awaitingPreview=false;screen.status=message;if(success){ManualPlannerClient.completed(owner);clear();}else{screen.token=null;if(screen.build!=null)screen.build.field_22763=false;if(screen.preview!=null)screen.preview.field_22763=false;if(screen.calculate!=null)screen.calculate.field_22763=true;}}
  static void deliveryRecovery(){if(waiting!=null&&waiting.pending&&waiting.awaitingPreview){var screen=waiting;screen.cancelPreview();screen.pending=false;screen.awaitingPreview=false;screen.checked=null;screen.request=++requests;screen.status="预览传输繁忙，请重新预览";if(screen.preview!=null)screen.preview.field_22763=false;if(screen.calculate!=null)screen.calculate.field_22763=true;if(screen.build!=null)screen.build.field_22763=false;if(ClientRoads.ownsPreview(screen))clearPublished();}}
  @Override public void method_25419(){capture();class_310.method_1551().method_1507(null);}
  @Override public boolean method_25421(){return false;}
  private void prepareMap(){
    mapMinX=mapMinZ=Double.POSITIVE_INFINITY;mapMaxX=mapMaxZ=Double.NEGATIVE_INFINITY;
    for(var sample:checked.mesh().samples())for(double side:new double[]{-1,1}){var p=sample.at(side*sample.halfWidth(),0);mapMinX=Math.min(mapMinX,p.x());mapMinZ=Math.min(mapMinZ,p.z());mapMaxX=Math.max(mapMaxX,p.x());mapMaxZ=Math.max(mapMaxZ,p.z());}
    var faces=new ArrayList<RoadSurface.Face>();var roads=new ArrayList<>(checked.roads());if(!roads.contains(checked.mesh()))roads.add(checked.mesh());
    for(var road:roads)for(int i=1;i<road.samples().size();i++){var a=road.samples().get(i-1);var b=road.samples().get(i);faces.add(new RoadSurface.Face(List.of(a.at(a.halfWidth(),0),a.at(-a.halfWidth(),0),b.at(-b.halfWidth(),0),b.at(b.halfWidth(),0)),0x637885));}
    faces.addAll(checked.faces());faces.sort(Comparator.comparingDouble(f->f.points().stream().mapToDouble(RoadGeometry.V::y).average().orElse(0)));mapFaces=List.copyOf(faces);
  }
  private void map(class_332 g){
    int x=left+panel+12,y=top+26,w=field_22789-x-12,h=field_22790-y-12;g.method_25294(x,y,x+w,y+h,0xff09161f);
    g.method_51433(field_22793,"北 ↑",x+w-36,y+8,0xffffff,false);
    g.method_51433(field_22793,checked!=null?"俯视预览":pending?"计算与校验中…":"等待有效参数",x+8,y+8,0x9ed7e6,false);
    if(checked==null)return;
    var mesh=checked.mesh();double dx=Math.max(1,mapMaxX-mapMinX),dz=Math.max(1,mapMaxZ-mapMinZ);
    double scale=Math.min((w-24)/dx,(h-50)/dz),ox=x+(w-dx*scale)/2,oz=y+28+(h-50-dz*scale)/2;
    g.method_44379(x+2,y+23,x+w-2,y+h-2);g.method_51452();RenderSystem.disableCull();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.setShader(class_757::method_34540);
    var buffer=class_289.method_1348().method_1349();buffer.method_1328(class_293.class_5596.field_27379,class_290.field_1576);var pose=g.method_51448().method_23760().method_23761();
    for(var f:mapFaces){var points=f.points();int c=f.color();for(int i=1;i+1<points.size();i++)for(var v:List.of(points.get(0),points.get(i),points.get(i+1)))buffer.method_22918(pose,(float)(ox+(v.x()-mapMinX)*scale),(float)(oz+(v.z()-mapMinZ)*scale),0).method_1336((c>>16)&255,(c>>8)&255,c&255,255).method_1344();}
    class_286.method_43433(buffer.method_1326());RenderSystem.disableBlend();RenderSystem.enableCull();
    for(int i=0;i<2;i++){var v=(i==0?mesh.first():mesh.last()).center();String label=i==0?"A":"B";int px=(int)(ox+(v.x()-mapMinX)*scale),pz=(int)(oz+(v.z()-mapMinZ)*scale);g.method_51433(field_22793,label,Math.max(x+4,Math.min(x+w-field_22793.method_1727(label)-4,px)),Math.max(y+25,Math.min(y+h-field_22793.field_2000-4,pz)),0xffffff,false);}g.method_44380();
  }
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    method_25420(g);g.method_25294(left,top,field_22789-12,field_22790-8,0xEC172128);g.method_25303(field_22793,"SR · 收费站",left+10,top+9,0xFFFFFF);map(g);super.method_25394(g,mx,my,dt);for(var l:labels)g.method_25303(field_22793,l.text(),l.x(),l.y(),0xDCE5E8);
    try{var spec=TollCodec.read(payload.method_10562("Spec"));var n=TollPlanner.lengths(spec);g.method_25303(field_22793,field_22793.method_27523(String.format(Locale.ROOT,"当前 %.1f / 最低 %.1f / 尚缺 %.1f 格",n.current(),n.minimum(),n.deficit()),panel-20),left+10,row(185),n.deficit()>1e-5?0xFFBB77:0xA7E4B1);g.method_25303(field_22793,field_22793.method_27523("收费单元："+spec.config().forward().units()+(spec.config().twoWay()?" + "+spec.config().backward().units():"")+" · "+adjustLabel(payload.method_10558("Adjust")),panel-20),left+10,row(200),0xC1D2DA);
    }catch(IllegalArgumentException e){token=null;if(build!=null)build.field_22763=false;}
    g.method_44379(left+8,row(222),left+panel-8,field_22790-60);g.method_51440(field_22793,class_2561.method_43470(status),left+10,row(222),panel-20,0xFFE5B1);g.method_44380();
  }
}
