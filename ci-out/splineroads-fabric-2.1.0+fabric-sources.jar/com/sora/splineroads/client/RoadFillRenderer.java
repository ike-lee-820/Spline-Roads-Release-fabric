package com.sora.splineroads.client;

import com.sora.splineroads.world.RoadFillEntity;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import net.minecraft.client.renderer.blockentity.*;

public final class RoadFillRenderer implements class_827<RoadFillEntity> {
  public RoadFillRenderer(class_5614.class_5615 context){}
  @Override public int method_33893(){return 256;}
  @Override public void render(RoadFillEntity entity,float partial,class_4587 pose,class_4597 buffers,int light,int overlay){
    if(entity.fill().method_26215()||entity.cap()<1)return; // Ground caps are baked into ordinary chunk meshes.
    pose.method_22903();pose.method_22904(0,-.002,0);
    class_310.method_1551().method_1541().method_3353(entity.fill(),pose,buffers,light,overlay);
    pose.method_22909();
  }
}
