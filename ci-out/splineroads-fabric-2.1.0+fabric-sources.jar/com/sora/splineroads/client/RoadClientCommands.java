package com.sora.splineroads.client;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.config.RoadClientConfig;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import static net.minecraft.class_2170.*;

/** Local display preferences are available without operator rights on any server. */
@Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT)
public final class RoadClientCommands {
  @SubscribeEvent public static void register(RegisterClientCommandsEvent event){
    var perf=method_9247("perf").executes(c->perf(c.getSource(),!RoadClientConfig.PERF_OVERLAY.get()));
    perf.then(method_9247("on").executes(c->perf(c.getSource(),true)));
    perf.then(method_9247("off").executes(c->perf(c.getSource(),false)));
    event.getDispatcher().register(method_9247("sr").then(perf)
        .then(method_9247("signs").executes(c->signs(c.getSource(),!RoadSignVisibility.enabled()))
          .then(method_9247("on").executes(c->signs(c.getSource(),true)))
          .then(method_9247("off").executes(c->signs(c.getSource(),false))))
        .then(method_9247("sf").executes(c->{
          c.getSource().method_9226(()->class_2561.method_43470("SR 表面模式："+RoadClientConfig.SURFACE_BACKEND.get()+"；/sr sf auto|VBO|terrain"),false);return 1;
        }).then(method_9244("mode",StringArgumentType.word())
            .suggests((c,b)->class_2172.method_9265(List.of("auto","VBO","terrain"),b))
            .executes(c->{
              String name=StringArgumentType.getString(c,"mode").toUpperCase(Locale.ROOT);
              if(name.equals("TERRIAN"))name="TERRAIN";
              RoadClientConfig.SurfaceBackend mode;
              try{mode=RoadClientConfig.SurfaceBackend.valueOf(name);}
              catch(IllegalArgumentException e){throw new SimpleCommandExceptionType(class_2561.method_43470("mode 可选：auto、VBO、terrain")).create();}
              RoadClientConfig.SURFACE_BACKEND.set(mode); // Forge's file config autosaves.
              // The existing frame transition retains valid caches and dirties affected sections.
              RoadTerrainModels.beginFrame();
              c.getSource().method_9226(()->class_2561.method_43470("SR 表面模式已切换为 "+mode),false);return 1;
            }))));
  }
  private static int signs(net.minecraft.class_2168 source,boolean enabled){
    RoadSignVisibility.set(enabled);source.method_9226(()->class_2561.method_43470("SR 全部标牌已"+(enabled?"显示":"隐藏（性能排查）")+"；/sr signs on|off"),false);return 1;
  }
  private static int perf(net.minecraft.class_2168 source,boolean enabled){
    RoadClientConfig.PERF_OVERLAY.set(enabled); // Forge's file config autosaves.
    source.method_9226(()->class_2561.method_43470("SR 性能显示已"+(enabled?"开启":"关闭")),false);return 1;
  }
  private RoadClientCommands(){}
}
