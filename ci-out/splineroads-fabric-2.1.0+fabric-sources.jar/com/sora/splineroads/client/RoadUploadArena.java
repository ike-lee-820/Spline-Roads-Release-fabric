package com.sora.splineroads.client;

import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_293;

/** Render-thread native scratch storage, reused for every material, region and lighting refresh. */
final class RoadUploadArena {
  private class_287 builder;
  private final int initialCapacity;

  RoadUploadArena(){this(4096);}
  RoadUploadArena(int initialCapacity){this.initialCapacity=initialCapacity;}
  boolean allocated(){return builder!=null;}

  class_287 begin(){return begin(class_290.field_1580);}
  class_287 begin(class_293 format) {
    if (builder == null) builder = new class_287(initialCapacity);
    // A failed producer may have left an unfinished batch. It must not pin another batch's bytes.
    if (builder.method_22893()) builder.method_1326().method_43585();
    builder.method_23477();
    builder.method_1328(class_293.class_5596.field_27382, format);
    return builder;
  }
}
