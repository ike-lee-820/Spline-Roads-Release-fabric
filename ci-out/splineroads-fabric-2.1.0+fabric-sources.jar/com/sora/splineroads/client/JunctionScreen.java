package com.sora.splineroads.client;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Piece;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import java.util.function.*;
import net.minecraft.class_1011;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;

public final class JunctionScreen extends class_437 {
  private static class_2487 draft;
  public static Mesh previewMesh;
  public static List<RoadSurface.Face> previewFaces=List.of();
  private final class_2487 payload;
  private class_2487 spec;
  private int page,arm,lane,turn,top;
  private boolean pairSide;
  private String status="";
  private boolean pending,confirmDelete,signalLanes;
  private JunctionPlanner.Plan plan;
  private final class_2487 sourceSpec;
  private class_2487 plannedSpec;
  private AutoJunctions.Draft previewNetwork;
  private net.minecraft.class_2960 mapTexture;
  private int planningPasses,worldFacePasses;
  private JunctionPreview.Image map;
  private class_4185 build;
  private final List<Runnable> captures=new ArrayList<>();
  private final List<Label> labels=new ArrayList<>();
  private record Label(String text,int x,int y) {}
  public JunctionScreen(class_2487 t){super(class_2561.method_43470("Spline Roads · 路口"));payload=t.method_10553();spec=JunctionCodec.write(JunctionCodec.read(payload.method_10562("Spec")));sourceSpec=JunctionCodec.write(JunctionCodec.read(payload.method_10562(payload.method_10545("FreshSpec")?"FreshSpec":"Spec")));if(payload.method_10545("SelectedArm")){arm=Math.max(0,Math.min(spec.method_10554("Arms",class_2520.field_33260).size()-1,payload.method_10550("SelectedArm")));page=1;}}
  public static void clear(){draft=null;previewMesh=null;previewFaces=List.of();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();}
  public static void open(class_2487 fresh) {
    if(fresh.method_10558("Kind").equals("junctionReset")){clear();return;}
    class_2487 t=fresh.method_10553();t.method_10566("FreshSpec",fresh.method_10562("Spec").method_10553());
    if(draft!=null&&!t.method_10577("Paired")&&!t.method_10577("DeleteOnly")&&Arrays.equals(t.method_10565("Points"),draft.method_10565("Points"))&&Objects.equals(t.method_25928("Id")?t.method_25926("Id"):null,draft.method_25928("Id")?draft.method_25926("Id"):null)) {
      class_2487 edited=draft.method_10562("Spec").method_10553();var incoming=t.method_10562("Spec").method_10554("Arms",class_2520.field_33260);var saved=edited.method_10554("Arms",class_2520.field_33260);
      if(incoming.size()==saved.size()){edited.method_10566("Center",t.method_10562("Spec").method_10562("Center").method_10553());for(int i=0;i<saved.size();i++)for(String key:List.of("Node","DX","DZ","External","Attached"))saved.method_10602(i).method_10566(key,incoming.method_10602(i).method_10580(key).method_10707());t.method_10566("Spec",edited);}
    }
    class_310.method_1551().method_1507(new JunctionScreen(t));
  }
  private boolean oneSide(){return spec.method_10545("OneSide");}
  private boolean protectedArm(){return oneSide()&&arm==JunctionCodec.read(spec).oneSide().outgoing();}
  private int allowedTurns(){return oneSide()?OneSidedJunction.allowed(JunctionCodec.read(spec),arm):15;}
  private class_2487 arm(){return spec.method_10554("Arms",class_2520.field_33260).method_10602(arm);}
  private void remember(){payload.method_10566(pairSide?"PairSpec":"Spec",spec);if(!payload.method_10577("DeleteOnly"))draft=payload.method_10553();}
  private boolean capture(){try{captures.forEach(Runnable::run);resizeLanes();remember();return true;}catch(IllegalArgumentException e){status=e.getMessage();return false;}}
  private void resizeLanes(){
    for(class_2520 entry:spec.method_10554("Arms",class_2520.field_33260)){var a=(class_2487)entry;int count=a.method_10550("In");if(count<0||count>7)throw new IllegalArgumentException("进出车道数范围为 0–7");var list=a.method_10554("Lanes",class_2520.field_33260);while(list.size()>count)list.method_10536(list.size()-1);while(list.size()<count){var l=new class_2487();l.method_10569("Mask",-1);l.method_10539("Targets",new int[]{-1,-1,-1,-1});l.method_10539("TargetLanes",new int[]{-1,-1,-1,-1});list.add(l);}a.method_10566("Lanes",list);}
    if(!spec.method_10554("Arms",class_2520.field_33260).isEmpty())lane=Math.max(0,Math.min(lane,arm().method_10550("In")-1));
  }
  private void edited(){ClientRoads.editorChanged(this);pending=false;if(build!=null)build.field_22763=!payload.method_10577("DeleteOnly");}
  private void change(Runnable r){if(capture()){var before=spec.method_10553();r.run();if(!before.equals(spec))edited();remember();method_41843();}}
  private class_4185 button(String text,int x,int y,int w,Runnable r){return method_37063(class_4185.method_46430(class_2561.method_43470(text),b->r.run()).method_46434(x,y,w,20).method_46431());}
  private void field(String label,class_2487 tag,String key,int col,double row,boolean integer){
    int x=16+col*146,y=top+(int)(row*28);labels.add(new Label(label,x,y));
    class_342 box=new class_342(field_22793,x,y+10,136,17,class_2561.method_43470(label));box.method_1880(32);box.method_1852(integer?Integer.toString(tag.method_10550(key)):Double.toString(tag.method_10574(key)));box.method_1863(v->edited());box.method_1888(!(oneSide()&&(key.equals("Thickness")||page==3&&arm<2||protectedArm())));method_37063(box);
    captures.add(()->{try{if(integer)tag.method_10569(key,Integer.parseInt(box.method_1882()));else{double value=Double.parseDouble(box.method_1882());if(!Double.isFinite(value))throw new NumberFormatException();tag.method_10549(key,value);}}catch(NumberFormatException e){throw new IllegalArgumentException(label+"：请输入有效数字");}});
  }
  private void toggle(String title,class_2487 tag,String key,int x,int y,int w){button(title+"："+(tag.method_10577(key)?"开":"关"),x,y,w,()->change(()->tag.method_10556(key,!tag.method_10577(key)))).field_22763=!(oneSide()&&tag!=spec&&arm<2);}
  @Override protected void method_25426(){
    captures.clear();labels.clear();top=57;
    if(payload.method_10577("Paired"))button(pairSide?"编辑 B 端 →":"编辑 A 端 →",field_22789-116,5,108,()->{if(capture()){pairSide=!pairSide;spec=payload.method_10562(pairSide?"PairSpec":"Spec").method_10553();plannedSpec=null;arm=2;lane=0;method_41843();}});
    String[] tabs=spec.method_10554("Arms",class_2520.field_33260).isEmpty()?new String[]{"环岛"}:new String[]{"路口","接入口","车道","斑马线","信号","右转"};for(int i=0;i<tabs.length;i++){int p=i;button((page==i?"● ":"")+tabs[i],12+i*49,29,47,()->change(()->page=p));}
    if(page>0)button("接入口 "+(arm+1)+" / "+spec.method_10554("Arms",class_2520.field_33260).size()+"  →",16,top,282,()->change(()->{arm=(arm+1)%spec.method_10554("Arms",class_2520.field_33260).size();lane=0;}));
    if(page==0){
      button("类型："+(spec.method_10558("Kind").equals("ROUNDABOUT")?"环岛":"普通路口"),16,top,136,()->{}).field_22763=false;
      if(oneSide())button("右侧通行（继承主路）",162,top,136,()->{}).field_22763=false;
      else toggle("左侧通行",spec,"LeftTraffic",162,top,136);
      field("转角半径 / 格",spec,"Corner",0,1,false);field("路面厚度 / 格",spec,"Thickness",1,1,false);
      if(!payload.method_10577("Auto")&&spec.method_10558("Kind").equals("ROUNDABOUT")){
        field("中央岛半径 / 格",spec,"Island",0,2,false);field("环道车道数 1–3",spec,"RingLanes",1,2,true);
        field("环道车道宽 / 格",spec,"RingWidth",0,3,false);
      } else if(!payload.method_10577("Auto")){
      } else if(payload.method_10577("GeneratedRing")) {
        labels.add(new Label("环岛尺寸在生成时设置，八向接点固定",16,top+72));
      } else labels.add(new Label("增删相连道路时自动更新路口方向",16,top+72));
      if(spec.method_10558("Kind").equals("ROUNDABOUT"))toggle("中央岛绿化",spec,"GreenIsland",162,top+95,136);
      toggle("路口导向虚线",spec,"Guides",16,top+121,136);
      if(spec.method_10558("Kind").equals("ROUNDABOUT"))toggle("环岛外侧护栏",spec,"OuterRail",162,top+121,136);
    }else if(page==5){
      var current=JunctionCodec.read(spec);String reason=JunctionSlips.unavailable(current,arm);
      var toggle=button("独立右转匝道："+(arm().method_10577("RightSlip")?"开":"关"),16,top+34,282,()->change(()->arm().method_10556("RightSlip",!arm().method_10577("RightSlip"))));toggle.field_22763=arm().method_10577("RightSlip")||reason.isEmpty();
      labels.add(new Label("三角区："+JunctionSlips.islandLabel(current.arms().get(arm)),16,top+65));
      labels.add(new Label(reason.isEmpty()?"来向额外加一车道，转入道路保留外侧车道接入":reason,16,top+88));
      labels.add(new Label("每个驶入方向独立设置；行人过街优先",16,top+110));
    }else if(page==1){
      if(payload.method_10577("Auto")||oneSide()) {
        labels.add(new Label("驶入 "+arm().method_10550("In")+" 车道 · 驶出 "+arm().method_10550("Out")+" 车道",16,top+34));
        labels.add(new Label("道路总宽："+String.format(Locale.ROOT,"%.1f",arm().method_10574("Width"))+" 格",16,top+57));
        labels.add(new Label("继承各方向道路的宽度与分隔带",16,top+82));
        labels.add(new Label(oneSide()?"中央隔离带与对向主路保持原状":"右键路口外侧路面可修改该道路",16,top+105));
      } else {
        field("进入路口车道数",arm(),"In",0,1,true);field("驶出路口车道数",arm(),"Out",1,1,true);
        field("接入口总宽 / 格",arm(),"Width",0,2,false);field("中央分隔带宽 / 格",arm(),"Median",1,2,false);
        field("两侧非机动车道宽",arm(),"Cycle",0,3,false);field("两侧路缘宽",arm(),"Curb",1,3,false);
        button("分隔带："+(arm().method_10558("MedianKind").equals("GREEN")?"绿化":"护栏"),16,top+121,136,()->change(()->arm().method_10582("MedianKind",arm().method_10558("MedianKind").equals("GREEN")?"RAIL":"GREEN")));
      }
      if(oneSide()){
        boolean choice=arm==JunctionCodec.read(spec).oneSide().incoming()&&(allowedTurns()&JunctionSpec.RIGHT)!=0;
        button("路口预告牌："+(choice&&arm().method_10577("AdvanceSign")?"开":"关"),16,top+147,136,
            ()->change(()->arm().method_10556("AdvanceSign",!arm().method_10577("AdvanceSign")))).field_22763=choice;
      }else toggle("路口预告牌",arm(),"AdvanceSign",16,top+147,136);
      toggle("道路名称牌",arm(),"NameSign",162,top+147,136);
    }else if(page==2){
      var lanes=arm().method_10554("Lanes",class_2520.field_33260);
      if(protectedArm())labels.add(new Label("对向主路保持原状，无需配置",16,top+30));
      else if(lanes.isEmpty())labels.add(new Label("此方向没有驶入车道",16,top+30));
      else {
        var l=lanes.method_10602(lane);int mask=l.method_10550("Mask");
        button("驶入第 "+(lane+1)+" 车道（从左到右）→",16,top+21,282,()->change(()->lane=(lane+1)%lanes.size()));
        String[] names={"直行","左转","右转","掉头"};for(int i=0;i<4;i++){int bit=JunctionSpec.TURNS[i];button(((mask&bit)!=0&&mask>=0?"☑ ":"□ ")+names[i],16+i*72,top+42,66,()->change(()->l.method_10569("Mask",(mask<0?0:mask)^bit))).field_22763=(allowedTurns()&bit)!=0;}
        button("自动分配",16,top+62,136,()->change(()->l.method_10569("Mask",-1)));button("禁行",162,top+62,136,()->change(()->l.method_10569("Mask",0)));
        button("出口映射："+names[turn]+" →",16,top+83,282,()->change(()->{do{turn=(turn+1)%4;}while(oneSide()&&(allowedTurns()&JunctionSpec.TURNS[turn])==0);}));
        int[] targets=l.method_10561("Targets"),targetLanes=l.method_10561("TargetLanes");
        if(oneSide()){
          var current=JunctionCodec.read(spec);int fixed=JunctionSpec.TURNS[turn]==JunctionSpec.STRAIGHT||arm==2?current.oneSide().outgoing():2;
          button((allowedTurns()&JunctionSpec.TURNS[turn])!=0?"出口："+(fixed+1)+"（固定）":"此转向不可用",16,top+104,136,()->{}).field_22763=false;
        }else button("出口："+(targets[turn]<0?"自动":targets[turn]+1),16,top+104,136,()->change(()->{targets[turn]++;if(targets[turn]>=spec.method_10554("Arms",class_2520.field_33260).size())targets[turn]=-1;l.method_10539("Targets",targets);}));
        button("出口车道："+(targetLanes[turn]<0?"自动":targetLanes[turn]+1),162,top+104,136,()->change(()->{targetLanes[turn]++;if(targetLanes[turn]>=RoadLanes.MAX_DIRECTION)targetLanes[turn]=-1;l.method_10539("TargetLanes",targetLanes);})).field_22763=(allowedTurns()&JunctionSpec.TURNS[turn])!=0;
        labels.add(new Label("当前："+JunctionSpec.maskName(mask),16,top+127));
      }
    }else if(page==3){
      if(oneSide()&&arm<2)button("主路保持连续，不生成横跨斑马线",16,top+25,282,()->{}).field_22763=false;
      else if(JunctionCodec.read(spec).arms().get(arm).hasSlowTraffic())toggle("斑马线",arm(),"Crosswalk",16,top+25,282);
      else button("无慢行设施，不生成斑马线",16,top+25,282,()->{}).field_22763=false;
      field("斑马线纵向宽度",arm(),"CrossWidth",0,2,false);field("距路口边缘 / 格",arm(),"Setback",1,2,false);
      field("停止线退后 / 格",arm(),"StopGap",0,3,false);
      labels.add(new Label(oneSide()?"仅支路可设置过街，主路中央分隔带连续":"斑马线前自动收束中央分隔带",16,top+121));
    }else {
      button(signalLanes?"◂ 信号周期（1 / 2）":"车道信号（2 / 2）▸",16,top+22,282,()->change(()->signalLanes=!signalLanes));
      if(!signalLanes){
        String c=spec.method_10558("Control");button("控制："+(c.equals("SIGNALS")?"红绿灯":c.equals("YIELD")?"让行":"无信号灯"),16,top+43,282,()->change(()->spec.method_10582("Control",c.equals("NONE")?"YIELD":c.equals("YIELD")?"SIGNALS":"NONE")));
        field("绿灯 / 秒",spec,"Green",0,2.5,true);field("黄灯 / 秒",spec,"Yellow",1,2.5,true);
        field("全红间隔 / 秒",spec,"AllRed",0,3.5,true);field("入口相位组 0–7",arm(),"Phase",1,3.5,true);
      }else{
        var lanes=arm().method_10554("Lanes",class_2520.field_33260);
        if(protectedArm())labels.add(new Label("对向主路保持原状，无需配置",16,top+55));
        else if(lanes.isEmpty())labels.add(new Label("此方向没有驶入车道",16,top+55));
        else{
          var l=lanes.method_10602(lane);if(!l.method_10545("LeftPhase"))l.method_10569("LeftPhase",-1);
          button("驶入第 "+(lane+1)+" 车道（从左到右）→",16,top+44,282,()->change(()->lane=(lane+1)%lanes.size()));
          button(l.method_10577("SplitLeft")?"左转 / 掉头：独立箭头灯":"左转 / 直行：普通圆灯",16,top+65,282,()->change(()->l.method_10556("SplitLeft",!l.method_10577("SplitLeft")))).field_22763=!oneSide();
          boolean right=lanes.stream().anyMatch(v->((class_2487)v).method_10577("ControlRight"));
          button(right?"入口右转控制灯：开（单独箭头灯）":"入口右转控制灯：关（默认不受控）",16,top+86,282,()->change(()->{for(class_2520 value:lanes)((class_2487)value).method_10556("ControlRight",!right);}));
          labels.add(new Label("只有左转且已设专用灯：不生成普通灯",16,top+121));
        }
      }
    }
    int bottom=Math.max(top+141,field_22790-49);
    build=button(payload.method_25928("Id")?"保存路口":"建造路口",16,bottom,91,()->submit(false));
    button("预览 / 返回世界",111,bottom,112,()->{if(refresh()){publishWorldPreview();remember();ManualPlannerClient.worldPreview();field_22787.method_1507(null);}});
    if(payload.method_25928("Id"))button(confirmDelete?"确认删除":"删除整体",227,bottom,71,()->{if(confirmDelete)submit(true);else{confirmDelete=true;method_41843();}});
    else button("关闭",227,bottom,71,this::method_25419);
    build.field_22763=!pending&&!payload.method_10577("DeleteOnly");refresh();
  }
  private boolean refresh(){
    if(!capture())return false;map=null;
    if(plan!=null&&plannedSpec!=null&&plannedSpec.equals(spec))return true;
    long began=System.nanoTime();
    try{
      var parsed=JunctionCodec.read(spec).supportedCrossings();previewNetwork=null;
      // The received specification already contains the saved ports. Merely opening
      // the editor must not rebuild every logical street at both ends of the graph.
      if(payload.method_10577("Auto")&&!sourceSpec.equals(spec)){
        previewNetwork=AutoJunctions.previewEdit(payload);
        for(var center:previewNetwork.centers())if(center.method_25926("Id").equals(payload.method_25926("Id")))parsed=JunctionCodec.read(center.method_10562("Spec")).supportedCrossings();
      }
      plan=JunctionPlanner.plan(parsed);plannedSpec=spec.method_10553();planningPasses++;
      status=JunctionPlanner.separatedEntrances(parsed)?"分隔式路口预览有效：同侧 B/C 保持独立，A 双向接入":"几何预览有效；建造时校验地形、权限和已有道路";
      return true;
    }catch(IllegalArgumentException e){plan=null;plannedSpec=null;status=e.getMessage();return false;}
    finally{if(Boolean.getBoolean("road.junction.timing"))System.out.println("SR JUNCTION UI plan="+planningPasses+" ms="+(System.nanoTime()-began)/1e6);}
  }
  private void publishWorldPreview(){
    long began=System.nanoTime();var faces=new ArrayList<RoadSurface.Face>();faces.addAll(RoadSidewalks.preview(plan.sidewalks().keySet()));
    for(var piece:plan.pieces()){
      faces.addAll(RoadSurface.custom(new RoadSurface.Geometry(List.of(),List.of()),piece.mesh(),piece.paint()).markings());
      piece.structures().forEach(part->faces.addAll(part.faces()));
    }
    previewMesh=plan.pieces().get(0).mesh();previewFaces=List.copyOf(faces);ClientRoads.preview=previewMesh;
    ClientRoads.nodePreviews=previewNetwork==null?plan.pieces().stream().map(JunctionPlanner.Piece::mesh).toList():previewNetwork.roads().stream().map(RoadRecord::mesh).toList();
    worldFacePasses++;if(Boolean.getBoolean("road.junction.timing"))System.out.println("SR JUNCTION UI world="+worldFacePasses+" ms="+(System.nanoTime()-began)/1e6);
  }
  private void submit(boolean delete){if(pending)return;if(delete&&!payload.method_10554("Dependencies",class_2520.field_33258).isEmpty()&&!payload.method_10545("ConfirmDependencies")){field_22787.method_1507(new LaneDeleteConfirmScreen(this,payload.method_10554("Dependencies",class_2520.field_33258),()->{payload.method_10566("ConfirmDependencies",payload.method_10554("Dependencies",class_2520.field_33258).method_10612());submit(true);}));return;}if(!delete&&!refresh())return;var command=payload.method_10553();command.method_10582("Action",delete?"junctionDelete":"junction");command.method_10566(pairSide?"PairSpec":"Spec",spec.method_10553());pending=true;build.field_22763=false;status="正在校验并建造…";ClientRoads.sendAction(JunctionCodec.editCommand(command));}
  public void failed(String message){pending=false;status=message;if(build!=null)build.field_22763=!payload.method_10577("DeleteOnly");}
  @Override public void method_25419(){capture();previewMesh=null;previewFaces=List.of();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();field_22787.method_1507(null);}
  @Override public void method_25432(){releaseMap();super.method_25432();}
  private void releaseMap(){if(mapTexture!=null){class_310.method_1551().method_1531().method_4615(mapTexture);mapTexture=null;}}
  private void uploadMap(){
    releaseMap();var pixels=new net.minecraft.class_1011(map.width(),map.height(),false);
    for(int y=0;y<map.height();y++)for(int x=0;x<map.width();x++){int c=map.pixels()[y*map.width()+x];pixels.method_4305(x,y,(c&0xff00ff00)|((c>>>16)&255)|((c&255)<<16));}
    mapTexture=field_22787.method_1531().method_4617("sr_junction_map",new net.minecraft.class_1043(pixels));
  }
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    method_25420(g);g.method_25294(6,5,Math.min(field_22789-6,306),field_22790-5,0xe51b2530);g.method_27535(field_22793,field_22785,16,13,0xffffff);super.method_25394(g,mx,my,dt);
    for(Label l:labels)g.method_51433(field_22793,l.text(),l.x(),l.y(),0xd6e2ed,false);
    g.method_51433(field_22793,field_22793.method_27523(status,Math.max(280,field_22789-30)),16,field_22790-19,plan==null?0xffa799:0xb8d6cb,false);
    if(plan!=null&&field_22789>510)drawPlan(g,318,38,field_22789-330,field_22790-76);
  }
  private void drawPlan(class_332 g,int x,int y,int w,int h){
    int imageHeight=Math.max(40,h-28);
    if(map==null||map.width()!=w||map.height()!=imageHeight){map=JunctionPreview.render(plan,w,imageHeight,arm,lane,page==2);uploadMap();}else if(mapTexture==null)uploadMap();
    g.method_25294(x,y,x+w,y+h,0xff202c30);
    g.method_25290(mapTexture,x,y,0,0,map.width(),map.height(),map.width(),map.height());
    for(var label:map.labels()){int xx=x+label.x(),yy=y+label.y();g.method_25294(xx-6,yy-5,xx+7,yy+6,label.arm()==arm?0xff238d98:0xff26363e);g.method_25300(field_22793,Integer.toString(label.arm()+1),xx,yy-4,0xffffff);}
    g.method_51433(field_22793,"北 ↑",x+5,y+4,0xbad0db,false);
    g.method_51433(field_22793,"蓝色：当前接入口",x+5,y+imageHeight+3,0x8ed6dc,false);
    if(page==2)g.method_51433(field_22793,"黄色：选中车道的通行方向",x+5,y+imageHeight+15,0xf4cb77,false);
  }
}
