package com.sora.splineroads.client;

import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadRecord;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class RoadDeleteScreen extends class_437 {
  private final class_2487 payload;
  private class_4185 remove;
  private String status = "删除所选整段道路、护栏和桥墩；保留端点";

  public RoadDeleteScreen(class_2487 t) {
    super(class_2561.method_43470("删除道路"));
    payload = t.method_10553();
    if(t.method_10577("ElevatedDelete"))status="删除这处高架连接并恢复主路车道和辅路；保留原高架尽头及出入点";
    if(t.method_10577("RampDelete"))status="删除所选匝道，并恢复主路车道及附属设施；保留主路";
    var deps=t.method_10554("Dependencies",net.minecraft.class_2520.field_33258);if(!deps.isEmpty())status="级联删除以下依赖匝道："+java.util.stream.IntStream.range(0,deps.size()).mapToObj(i->deps.method_10608(i).substring(0,8)).collect(java.util.stream.Collectors.joining(", "));
    ClientRoads.preview = RoadRecord.load(t.method_10562("Road")).mesh();
    ClientRoads.nodePreviews = java.util.List.of();
  }

  @Override
  protected void method_25426() {
    int x = field_22789 / 2 - 150, y = field_22790 / 2 - 38;
    remove =
        method_37063(
            class_4185.method_46430(
                    class_2561.method_43470(payload.method_10577("ElevatedDelete")?"确认删除高架连接":payload.method_10577("RampDelete")?"确认删除所选匝道":"确认删除所选道路"),
                    b -> {
                      class_2487 t = new class_2487();
                      t.method_10582("Action", payload.method_10577("RampDelete")?"laneRampDelete":"delete");
                      t.method_25927("Id", payload.method_25926("Id"));
                      if(payload.method_10577("RampDelete")){t.method_10569("Signature",payload.method_10550("Signature"));t.method_10566("From",payload.method_10562("From").method_10553());t.method_10566("To",payload.method_10562("To").method_10553());}
                      t.method_10566("ConfirmDependencies",payload.method_10554("Dependencies",net.minecraft.class_2520.field_33258).method_10612());
                      remove.field_22763 = false;
                      if(!payload.method_10554("Dependencies",net.minecraft.class_2520.field_33258).isEmpty()){field_22787.method_1507(new LaneDeleteConfirmScreen(this,payload.method_10554("Dependencies",net.minecraft.class_2520.field_33258),()->ClientRoads.sendAction(t)));remove.field_22763=true;}else ClientRoads.sendAction(t);
                    })
                .method_46434(x + 12, y + 67, 160, 20)
                .method_46431());
    method_37063(
        class_4185.method_46430(class_2561.method_43470("取消"), b -> method_25419())
            .method_46434(x + 180, y + 67, 108, 20)
            .method_46431());
  }

  public void failed(String message) {
    status = message;
    remove.field_22763 = true;
  }

  @Override
  public boolean method_25421() {
    return false;
  }

  @Override
  public void method_25419() {
    ClientRoads.preview = null;
    ClientRoads.draft = null;
    super.method_25419();
  }

  @Override
  public void method_25394(class_332 g, int x, int y, float dt) {
    int l = field_22789 / 2 - 150, t = field_22790 / 2 - 38;
    g.method_25294(l, t, l + 300, t + 100, 0xEE12212C);
    g.method_51433(field_22793, payload.method_10577("ElevatedDelete")?"删除高架连接":payload.method_10577("RampDelete")?"删除匝道 · 主路保留":"删除道路 · 红色高亮为所选路段", l + 12, t + 12, 0xFFFFAC99, false);
    g.method_51440(field_22793, class_2561.method_43470(status), l + 12, t + 32, 276, 0xFFFFFF);
    super.method_25394(g, x, y, dt);
  }
}
