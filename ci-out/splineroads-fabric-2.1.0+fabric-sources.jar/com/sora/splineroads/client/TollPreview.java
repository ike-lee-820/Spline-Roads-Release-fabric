package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.core.TollPlanner.Unit;
import com.sora.splineroads.core.TollPlaza.Spec;
import java.util.*;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_765;
import net.minecraftforge.client.event.RenderLevelStageEvent;

/** Bounded labels on the selected immutable preview only; no world/entity scans. */
public final class TollPreview {
  private record Mark(V at,String text,int color){}
  private static List<Mark> marks=List.of();
  static TollPlanner.Plan namedPreview;
  public static void clear(){marks=List.of();namedPreview=null;}
  public static void show(Spec original,TollPlanner.Plan plan){
    namedPreview=plan;var out=new ArrayList<Mark>();var proposed=plan.spec();
    for(boolean a:new boolean[]{true,false}){String name=a?"A":"B";V old=(a?original.a():original.b()).position(),now=(a?proposed.a():proposed.b()).position();double distance=old.distance(now);
      if(distance>.001)out.add(new Mark(old.add(new V(0,3,0)),name+" 原端点 "+coordinates(old),0xFFD1AE));
      out.add(new Mark(now.add(new V(0,3,0)),name+(distance>.001?" 新端点 ":" ")+coordinates(now)+String.format(Locale.ROOT," · 移动 %.1f 格",distance),0xA8FFD2));
    }
    for(var unit:plan.units())out.add(new Mark(unit.center().add(new V(0,plan.spec().config().clearHeight()+2.2,0)),(unit.direction()>0?"A→B":"B→A")+" "+(unit.etc()?"ETC":"人工")+" "+(unit.index()+1),unit.etc()?0xA8FFD2:0xB2DCFF));
    marks=List.copyOf(out);
  }
  private static String coordinates(V p){return String.format(Locale.ROOT,"(%.1f, %.1f, %.1f)",p.x(),p.y(),p.z());}
  public static void render(RenderLevelStageEvent event){
    if(ClientRoads.preview==null||ClientRoads.preview.settings().style()!=com.sora.splineroads.core.RoadGeometry.Style.TOLL)return;
    var mc=class_310.method_1551();var camera=event.getCamera().method_19326();var pose=event.getPoseStack();var buffers=mc.method_22940().method_23000();
    for(var mark:marks){V p=mark.at();if(p.distance(new V(camera.field_1352,camera.field_1351,camera.field_1350))>192)continue;
      pose.method_22903();pose.method_22904(p.x()-camera.field_1352,p.y()-camera.field_1351,p.z()-camera.field_1350);pose.method_22907(event.getCamera().method_23767());pose.method_22905(-.04f,-.04f,.04f);
      mc.field_1772.method_27521(mark.text(),-mc.field_1772.method_1727(mark.text())/2f,0,mark.color(),false,pose.method_23760().method_23761(),buffers,class_327.class_6415.field_33994,0x60000000,class_765.field_32767);pose.method_22909();
    }
  }
  private TollPreview(){}
}
