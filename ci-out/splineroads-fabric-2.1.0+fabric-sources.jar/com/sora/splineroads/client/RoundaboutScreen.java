package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Piece;
import com.sora.splineroads.core.JunctionPlanner.Plan;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
public final class RoundaboutScreen extends class_437 {
 private final class_2487 payload;private RoadGeometry.Mesh ownedPreview;private List<RoadGeometry.Mesh> ownedPreviews;private List<RoadSurface.Face> ownedFaces;private class_342 radius;private String status="";private boolean pending;private class_4185 build;
 private void edited(){ClientRoads.editorChanged(this);pending=false;}
 public RoundaboutScreen(class_2487 t){super(class_2561.method_43470("Spline Roads · 环岛生成器"));payload=t.method_10553();}
 @Override protected void method_25426(){int x=field_22789/2-140,y=field_22790/2-80;radius=new class_342(field_22793,x+130,y+30,140,20,class_2561.method_43470("中心线半径"));radius.method_1852(Double.toString(payload.method_10574("Radius")));method_37063(radius);
 method_37063(class_4185.method_46430(class_2561.method_43470(payload.method_10550("Lanes")==1?"环道：单车道":"环道：双车道"),b->{capture();payload.method_10569("Lanes",payload.method_10550("Lanes")==1?2:1);edited();method_41843();}).method_46434(x,y+60,130,20).method_46431());
 method_37063(class_4185.method_46430(class_2561.method_43470(payload.method_10577("LeftTraffic")?"左侧通行":"右侧通行"),b->{capture();payload.method_10556("LeftTraffic",!payload.method_10577("LeftTraffic"));edited();method_41843();}).method_46434(x+140,y+60,130,20).method_46431());
 method_37063(class_4185.method_46430(class_2561.method_43470("外侧护栏："+(payload.method_10577("OuterRail")?"开":"关")),b->{capture();payload.method_10556("OuterRail",!payload.method_10577("OuterRail"));edited();method_41843();}).method_46434(x,y+86,270,20).method_46431());
 build=method_37063(class_4185.method_46430(class_2561.method_43470("生成环岛"),b->{if(refresh()&&!pending){var t=payload.method_10553();t.method_10582("Action","roundabout");pending=true;build.field_22763=false;ClientRoads.sendAction(t);}}).method_46434(x,y+115,130,20).method_46431());
 method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(x+140,y+115,130,20).method_46431());radius.method_1863(v->{edited();refresh();});refresh();}
 private boolean capture(){try{payload.method_10549("Radius",Double.parseDouble(radius.method_1882()));return true;}catch(NumberFormatException e){status="请输入半径";return false;}}
 private boolean refresh(){if(!capture()){if(build!=null)build.field_22763=false;clearPreview();return false;}try{var spec=RoundaboutTool.specification(payload);var plan=JunctionPlanner.plan(spec);ownedPreviews=plan.pieces().stream().map(JunctionPlanner.Piece::mesh).toList();ClientRoads.nodePreviews=ownedPreviews;ClientRoads.preview=ClientRoads.nodePreviews.get(0);ownedPreview=ClientRoads.preview;JunctionScreen.previewMesh=ownedPreview;var faces=new ArrayList<RoadSurface.Face>();for(var part:plan.pieces()){faces.addAll(part.paint());part.structures().forEach(s->faces.addAll(s.faces()));}ownedFaces=List.copyOf(faces);JunctionScreen.previewFaces=ownedFaces;status="生成 8 个方向接路点；A 北 B 南 C 西 D 东";if(build!=null)build.field_22763=!pending;return true;}catch(IllegalArgumentException e){status=e.getMessage();if(build!=null)build.field_22763=false;clearPreview();return false;}}
 public void failed(String message){pending=false;status=message;build.field_22763=true;}
 private void clearPreview(){
  if(ownedPreview!=null&&ClientRoads.preview==ownedPreview)ClientRoads.preview=null;
  if(ownedPreviews!=null&&ClientRoads.nodePreviews==ownedPreviews)ClientRoads.nodePreviews=List.of();
  if(ownedPreview!=null&&JunctionScreen.previewMesh==ownedPreview)JunctionScreen.previewMesh=null;
  if(ownedFaces!=null&&JunctionScreen.previewFaces==ownedFaces)JunctionScreen.previewFaces=List.of();
  ownedPreview=null;ownedPreviews=null;ownedFaces=null;
 }
 @Override public void method_25419(){clearPreview();super.method_25419();}
 @Override public void method_25432(){clearPreview();super.method_25432();}
 @Override public boolean method_25421(){return false;}
 @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);int x=field_22789/2-140,y=field_22790/2-80;g.method_25294(x-12,y-12,x+282,y+156,0xee1b2530);g.method_27535(field_22793,field_22785,x,y,0xffffff);g.method_25303(field_22793,"中心线半径 / 格",x,y+36,0xd6e2ed);super.method_25394(g,mx,my,dt);g.method_25303(field_22793,field_22793.method_27523(status,280),x,y+143,0xb8d6cb);}
}
