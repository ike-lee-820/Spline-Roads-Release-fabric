package com.sora.splineroads.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

/**
 * Raster depth bias keeps a flush road legible at distance without moving collision or geometry.
 */
public final class RoadRenderTypes extends class_1921 {
  private RoadRenderTypes() {
    super(
        "splineroads_unused",
        class_290.field_1580,
        class_293.class_5596.field_27382,
        256,
        false,
        false,
        () -> {},
        () -> {});
  }

  public static class_1921 glass(class_2960 texture) {
    return method_24049("splineroads_noise_glass",class_290.field_1580,class_293.class_5596.field_27382,262144,false,true,
        class_4688.method_23598().method_34578(field_29407)
            .method_34577(new class_4683(texture,false,false)).method_23615(field_21370)
            .method_23608(field_21383).method_23611(field_21385).method_23603(field_21344)
            .method_23604(field_21348).method_23616(field_21350).method_23617(false));
  }

  /** Diagnostic overlay must remain locatable below an elevated road. It only
   * writes colour, so it cannot hide or change the real world's depth. */
  public static class_1921 conflict(class_2960 texture) {
    return method_24049("splineroads_conflict",class_290.field_1580,class_293.class_5596.field_27382,262144,false,true,
        class_4688.method_23598().method_34578(field_29407)
            .method_34577(new class_4683(texture,false,false)).method_23615(field_21370)
            .method_23608(field_21383).method_23611(field_21385).method_23603(field_21345)
            .method_23604(field_21346).method_23616(field_21350).method_23617(false));
  }

  public static class_1921 surface(class_2960 texture, boolean marking) {
    return surface(texture,marking,false);
  }

  /** Solid deck walls must not receive the slope bias used for coplanar road paint. */
  public static class_1921 solid(class_2960 texture) {
    return surface(texture,false,true);
  }

  private static class_1921 surface(class_2960 texture, boolean marking, boolean solid) {
    float factor = solid ? 0 : marking ? -2 : -1, units = solid ? 0 : marking ? -16 : -8;
    var offset =
        new class_4675(
            marking ? "road_marking_offset" : "road_surface_offset",
            () -> {
              RenderSystem.polygonOffset(factor, units);
              RenderSystem.enablePolygonOffset();
            },
            () -> {
              RenderSystem.polygonOffset(0, 0);
              RenderSystem.disablePolygonOffset();
            });
    return method_24049(
        marking ? "splineroads_markings" : "splineroads_pavement",
        class_290.field_1580,
        class_293.class_5596.field_27382,
        262144,
        false,
        false,
        class_4688.method_23598()
            .method_34578(new class_5942(() -> RoadShaders.opaque(texture)))
            .method_34577(new class_4683(texture, false, texture.equals(new net.minecraft.class_2960("splineroads","textures/road/asphalt.png"))))
            .method_23608(field_21383)
            .method_23611(field_21385)
            .method_23603(field_21344)
            .method_23604(field_21348)
            .method_23616(field_21349)
            .method_23607(offset)
            .method_23617(false));
  }
}
