package com.sora.splineroads.client;
import com.sora.splineroads.SplineRoads;
import net.minecraft.class_1011;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import net.minecraft.client.renderer.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.io.IOException;
import java.io.InputStream;
/** VBO world solids need fog from the fully camera-relative vertex, not entity-local
 * components. Shader packs still receive the standard intercepted entity program. */
@Mod.EventBusSubscriber(modid=SplineRoads.ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class RoadShaders {
  private static class_5944 worldSolid,worldOpaque,worldAsphalt;
  private static final java.util.Map<class_2960,Boolean> opaqueTextures=new java.util.HashMap<>();
  static void texturesReloaded(){opaqueTextures.clear();}
  private static boolean isOpaque(class_2960 texture){
    return opaqueTextures.computeIfAbsent(texture,key->{
      try(var stream=net.minecraft.class_310.method_1551().method_1478().open(key);var image=net.minecraft.class_1011.method_4309(stream)){
        for(int y=0;y<image.method_4323();y++)for(int x=0;x<image.method_4307();x++)if((image.method_4315(x,y)>>>24)!=255)return false;
        return true;
      }catch(IOException failure){return false;}
    });
  }
  @SubscribeEvent public static void register(RegisterShadersEvent event)throws IOException{
    event.registerShader(new class_5944(event.getResourceProvider(),"road_world_solid",class_290.field_1580),s->worldSolid=s);
    event.registerShader(new class_5944(event.getResourceProvider(),"road_world_opaque",class_290.field_1580),s->worldOpaque=s);
    event.registerShader(new class_5944(event.getResourceProvider(),"road_world_asphalt",class_290.field_1580),s->worldAsphalt=s);
  }
  public static class_5944 solid(){return worldSolid==null||ShaderPackState.current().active()?class_757.method_34504():worldSolid;}
  public static class_5944 opaque(class_2960 texture){if(!isOpaque(texture))return solid();return opaque(texture.method_12832().equals("textures/road/asphalt.png"));}
  public static class_5944 opaque(boolean asphalt){var shader=asphalt?worldAsphalt:worldOpaque;return shader==null||ShaderPackState.current().active()?solid():shader;}
  private RoadShaders(){}
}
