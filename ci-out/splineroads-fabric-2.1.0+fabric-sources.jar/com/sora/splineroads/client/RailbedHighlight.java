package com.sora.splineroads.client;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.world.RailbedTool;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.*;
import java.util.Map.Entry;

@Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT)
public final class RailbedHighlight {
  @SubscribeEvent public static void render(RenderLevelStageEvent event){
    if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES)return;var mc=class_310.method_1551();if(mc.field_1724==null)return;
    if(!(mc.field_1724.method_6047().method_7909() instanceof RailbedTool||mc.field_1724.method_6079().method_7909() instanceof RailbedTool))return;
    var paths=new LinkedHashMap<String,RailbedPath.Path>();RailbedScreen.candidates.forEach(p->paths.put(RailbedCandidates.key(p),p));var selected=new HashSet<String>();RailbedScreen.highlighted.forEach(p->{paths.put(RailbedCandidates.key(p),p);selected.add(RailbedCandidates.key(p));});
    var camera=event.getCamera().method_19326();var pose=event.getPoseStack();pose.method_22903();pose.method_22904(-camera.field_1352,-camera.field_1351,-camera.field_1350);var buffers=mc.method_22940().method_23000();var line=buffers.getBuffer(class_1921.method_23594());
    for(var entry:paths.entrySet()){boolean active=selected.contains(entry.getKey());var points=entry.getValue().positions();for(int i=1;i<points.size();i++){var a=points.get(i-1);var b=points.get(i);if(camera.method_1028(a.x(),a.y(),a.z())>128*128&&camera.method_1028(b.x(),b.y(),b.z())>128*128)continue;var n=b.sub(a).horizontalUnit();
      for(var p:List.of(a,b))line.method_22918(pose.method_23760().method_23761(),(float)p.x(),(float)p.y()+.2f,(float)p.z()).method_22915(active?.15f:1f,active?1f:.7f,active?.3f:.15f,1f).method_23763(pose.method_23760().method_23762(),(float)n.x(),0,(float)n.z()).method_1344();
    }}pose.method_22909();buffers.method_22994(class_1921.method_23594());
  }
  @SubscribeEvent public static void logout(net.minecraftforge.client.event.ClientPlayerNetworkEvent.LoggingOut e){RailbedScreen.reset();}
  private RailbedHighlight(){}
}
