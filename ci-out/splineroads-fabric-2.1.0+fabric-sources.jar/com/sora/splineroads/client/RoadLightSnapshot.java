package com.sora.splineroads.client;
import java.util.Arrays;
import net.minecraft.class_2804;

/** Immutable content stamps also detect light engines that update a DataLayer in place. */
public record RoadLightSnapshot(int sky,int block) {
  public static RoadLightSnapshot capture(class_2804 sky,class_2804 block){return new RoadLightSnapshot(hash(sky),hash(block));}
  private static int hash(class_2804 layer){return layer==null?0:Arrays.hashCode(layer.method_12137());}
}
