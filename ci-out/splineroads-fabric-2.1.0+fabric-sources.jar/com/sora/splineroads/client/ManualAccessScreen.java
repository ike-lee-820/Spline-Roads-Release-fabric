package com.sora.splineroads.client;

import com.sora.splineroads.world.RoadRecord;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;

/** Explicit preview of the complete paired access, before its single world transaction. */
public final class ManualAccessScreen extends class_437 {
  private final class_2487 payload;private class_342 length;private class_4185 build;private String status="先预览两条匝道、接出道路和主路分合流点";private boolean pending;
  ManualAccessScreen(class_2487 t){super(class_2561.method_43470("双向进出匝道"));payload=t.method_10553();}
  @Override protected void method_25426(){int x=field_22789/2-150,y=field_22790/2-85;length=new class_342(field_22793,x+120,y+42,165,20,class_2561.method_43470("接出道路长度"));length.method_1852(Double.toString(payload.method_10574("SpurLength")));length.method_1863(v->{payload.method_10551("Token");if(build!=null)build.field_22763=false;});method_37063(length);method_37063(class_4185.method_46430(class_2561.method_43470("计算完整预览"),b->send("manualAccessPreview")).method_46434(x+12,y+102,128,20).method_46431());build=method_37063(class_4185.method_46430(class_2561.method_43470("统一建造"),b->send("manualAccessBuild")).method_46434(x+150,y+102,138,20).method_46431());build.field_22763=payload.method_25928("Token");method_37063(class_4185.method_46430(class_2561.method_43470("实景预览"),b->{show();ManualPlannerClient.worldPreview();field_22787.method_1507(null);}).method_46434(x+12,y+127,128,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("返回地图"),b->method_25419()).method_46434(x+150,y+127,138,20).method_46431());if(payload.method_25928("Token")){status="完整预览已校验，可以统一建造；按 P 返回设置";show();}}
  private void show(){var roads=payload.method_10554("PlannerPreview",class_2520.field_33260).stream().map(t->RoadRecord.load((class_2487)t).mesh()).toList();ClientRoads.nodePreviews=roads;ClientRoads.preview=roads.isEmpty()?null:roads.get(0);ClientRoads.conflictPreview=false;}
  private void send(String action){if(pending)return;try{double value=Double.parseDouble(length.method_1882());if(!Double.isFinite(value)||value<64||value>160)throw new IllegalArgumentException();payload.method_10549("SpurLength",value);var t=payload.method_10553();t.method_10551("PlannerPreview");t.method_10582("Action",action);pending=true;status="正在校验完整占地与连接…";ClientRoads.sendAction(t);}catch(IllegalArgumentException e){status="长度请输入64–160格";}}
  void failed(String text){pending=false;status=text;}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);int x=field_22789/2-150,y=field_22790/2-85;g.method_25294(x,y,x+300,y+176,0xf015222e);g.method_51439(field_22793,field_22785,x+12,y+13,0xffffffff,false);g.method_51433(field_22793,"接出道路长度",x+12,y+48,0xffc6dbe7,false);g.method_51440(field_22793,class_2561.method_43470(status),x+12,y+72,276,0xffd2e2eb);super.method_25394(g,mx,my,dt);}
}
