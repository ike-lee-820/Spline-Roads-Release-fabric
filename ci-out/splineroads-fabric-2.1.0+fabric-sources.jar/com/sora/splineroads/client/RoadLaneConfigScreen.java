package com.sora.splineroads.client;

import com.sora.splineroads.core.RoadLanes;
import com.sora.splineroads.core.RoadProfile.Type;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Transactional lane editor: cancel never changes the parent draft or live road. */
public final class RoadLaneConfigScreen extends class_437 {
  private final class_437 parent;
  private final java.util.function.BiConsumer<Type,RoadLanes.Counts> apply;
  private final Boolean requiredTwoWay;
  private Type type;
  private int forward,reverse,savedReverse;
  private int x,y;
  RoadLaneConfigScreen(RoadScreen parent,Type type,RoadLanes.Counts counts){
    this(parent,type,counts,(t,c)->parent.applyLaneConfiguration(t,c,false),null);
  }
  RoadLaneConfigScreen(class_437 parent,Type type,RoadLanes.Counts counts,java.util.function.BiConsumer<Type,RoadLanes.Counts> apply,Boolean requiredTwoWay){
    super(class_2561.method_43470("道路车道配置"));this.parent=parent;this.type=type;this.apply=apply;this.requiredTwoWay=requiredTwoWay;
    forward=counts.forward();reverse=counts.reverse();savedReverse=reverse>0?reverse:forward;
    if(requiredTwoWay!=null)reverse=requiredTwoWay?savedReverse:0;
  }
  @Override protected void method_25426(){
    x=Math.max(8,(field_22789-280)/2);y=Math.max(4,(field_22790-194)/2);
    method_37063(class_4185.method_46430(class_2561.method_43470(type==Type.HIGHWAY?"高速道路":"普通道路"),b->{type=type==Type.HIGHWAY?Type.ORDINARY:Type.HIGHWAY;method_41843();}).method_46434(x,y+24,136,20).method_46431());
    var direction=method_37063(class_4185.method_46430(class_2561.method_43470(reverse>0?"双向":"单向"),b->{if(reverse>0){savedReverse=reverse;reverse=0;}else reverse=savedReverse;method_41843();}).method_46434(x+144,y+24,136,20).method_46431());
    direction.field_22763=requiredTwoWay==null;
    method_37063(new CountSlider(x,y+54,forward,true));
    if(reverse>0)method_37063(new CountSlider(x,y+82,reverse,false));
    method_37063(class_4185.method_46430(class_2561.method_43470("应用配置"),b->{apply.accept(type,new RoadLanes.Counts(forward,reverse));field_22787.method_1507(parent);}).method_46434(x,y+162,136,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(x+144,y+162,136,20).method_46431());
  }
  private final class CountSlider extends class_357 {
    final boolean along;
    CountSlider(int x,int y,int count,boolean along){super(x,y,280,20,class_2561.method_43473(),(count-1)/6.0);this.along=along;method_25346();}
    int count(){return Math.max(1,Math.min(RoadLanes.MAX_DIRECTION,1+(int)Math.round(field_22753*6)));}
    @Override protected void method_25346(){method_25355(class_2561.method_43470((along?"A → B":"B → A")+"："+count()+" 车道（1–7）"));}
    @Override protected void method_25344(){
      int snapped=count();field_22753=(snapped-1)/6.0;
      if(along)forward=snapped;else{reverse=snapped;savedReverse=reverse;}
      method_25346();
    }
    @Override public boolean method_25404(int key,int scan,int mods){
      if(key==263||key==262){field_22753=(Math.max(1,Math.min(RoadLanes.MAX_DIRECTION,count()+(key==262?1:-1)))-1)/6.0;method_25344();return true;}
      return super.method_25404(key,scan,mods);
    }
  }
  @Override public void method_25394(class_332 g,int mx,int my,float dt){
    method_25420(g);g.method_25294(x-8,y-6,x+288,y+190,0xEF12212C);
    g.method_51439(field_22793,field_22785,x,y+6,0xFFFFFF,false);
    g.method_51440(field_22793,class_2561.method_43470("数量按 A→B / B→A 分别保存。合并后的续接端口以当前位置实际断面为准；未修改的旧路保留原配置。"),x,y+114,280,0xBDD5DE);
    super.method_25394(g,mx,my,dt);
  }
  @Override public void method_25419(){field_22787.method_1507(parent);}
  @Override public boolean method_25421(){return false;}
}
