package com.sora.splineroads.client;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.world.*;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Point;
import com.sora.splineroads.core.RoadGeometry.V;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_761;
import net.minecraft.client.renderer.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT)
public final class LanePointRenderer {
  static boolean accepts(class_1799 s){return s.method_7909() instanceof LanePointTool||s.method_7909() instanceof LaneRampTool;}
  @SubscribeEvent public static void render(RenderLevelStageEvent e){if(e.getStage()!=RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES)return;var mc=class_310.method_1551();if(mc.field_1724==null||!(accepts(mc.field_1724.method_6047())||accepts(mc.field_1724.method_6079())))return;var camera=e.getCamera().method_19326();var pose=e.getPoseStack();var buffer=mc.method_22940().method_23000();var lines=buffer.getBuffer(class_1921.method_23594());pose.method_22903();pose.method_22904(-camera.field_1352,-camera.field_1351,-camera.field_1350);
    for(var road:ClientToolIndex.near(camera.field_1352,camera.field_1350,true))if(!road.record.railway()&&ClientRoads.active(road.record.id()))for(var p:LaneTopology.visiblePoints(road.record)){var v=p.position();if(camera.method_1028(v.x(),v.y(),v.z())>96*96)continue;class_761.method_22982(pose,lines,new class_238(v.x()-.24,v.y()+.04,v.z()-.24,v.x()+.24,v.y()+.53,v.z()+.24),.12f,.45f,1f,1f);var d=LanePoints.lane(road.mesh,p).direction();var tip=v.add(d.mul(.9));var rear=v.add(d.mul(.45));for(var end:java.util.List.of(v,rear.add(d.left().mul(.22)),rear.sub(d.left().mul(.22)))){var a=tip.add(new com.sora.splineroads.core.RoadGeometry.V(0,.12,0));var b=end.add(new com.sora.splineroads.core.RoadGeometry.V(0,.12,0));var n=b.sub(a).horizontalUnit();lines.method_22918(pose.method_23760().method_23761(),(float)a.x(),(float)a.y(),(float)a.z()).method_22915(.12f,.55f,1f,1f).method_23763(pose.method_23760().method_23762(),(float)n.x(),0,(float)n.z()).method_1344();lines.method_22918(pose.method_23760().method_23761(),(float)b.x(),(float)b.y(),(float)b.z()).method_22915(.12f,.55f,1f,1f).method_23763(pose.method_23760().method_23762(),(float)n.x(),0,(float)n.z()).method_1344();}}
    pose.method_22909();buffer.method_22994(class_1921.method_23594());}
}
