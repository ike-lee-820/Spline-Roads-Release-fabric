package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.SmartSigns.*;
import com.sora.splineroads.world.*;
import com.sora.splineroads.net.RoadNetwork;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import java.util.*;

public final class SmartTextScreen extends class_437 {
  private static SmartTextScreen draft;
  private final State original;private State editing;private final RoadRecord road;private final List<String> fields;private int selected,left,top;private class_342 value;private boolean initializing,pending,invalid;private String rawValue;private String status="所有文字均手填；输入 \\n 指定换行，空白区域不显示文字";
  public SmartTextScreen(class_2487 t){super(class_2561.method_43470("Spline Roads · 文字编辑器"));original=SmartSignCodec.read(t.method_10562("Sign"));editing=original;road=RoadRecord.load(t.method_10562("Road"));fields=indicator()?new ArrayList<>(SmartSigns.layout(road.mesh(),original).boards().stream().filter(b->b.branch().startsWith("lane:")).sorted(Comparator.comparingDouble(Board::x)).map(b->b.branch()+"/status").toList()):new ArrayList<>(SmartSigns.fieldIds(original.mode(),original.branches()));if(fields.isEmpty())throw new IllegalArgumentException("当前标牌没有可编辑区域");selected=Math.max(0,fields.indexOf(t.method_10558("Field")));if(indicator())status="设置当前牌对应车道；确认前不会保存";}
  public static void open(class_2487 t){String kind=t.method_10558("Kind");if(kind.equals("smartTextReset")){clear();return;}if(kind.equals("smartTextResume")){if(draft!=null)class_310.method_1551().method_1507(draft);return;}var incoming=SmartSignCodec.read(t.method_10562("Sign"));if(draft!=null&&draft.original.key().equals(incoming.key())&&draft.original.revision()==incoming.revision()&&(!draft.indicator()||draft.field().equals(t.method_10558("Field"))||draft.dirty())){class_310.method_1551().method_1507(draft);return;}draft=new SmartTextScreen(t);class_310.method_1551().method_1507(draft);}
  public static void clear(){draft=null;SmartSignClient.preview(null,null);}
  private void edited(){ClientRoads.editorChanged(this);pending=false;}
  private boolean indicator(){return original.mode()==Mode.LANE_INDICATOR;}
  private boolean dirty(){return invalid||!editing.text().equals(original.text())||!editing.hiddenHeaders().equals(original.hiddenHeaders())||!editing.hiddenAccessories().equals(original.hiddenAccessories())||!editing.closedLanes().equals(original.closedLanes());}
  private void initIndicator(){
    method_37063(class_4185.method_46430(class_2561.method_43470("上一车道指示牌"),b->select(-1)).method_46434(left+10,top+30,165,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("下一车道指示牌"),b->select(1)).method_46434(left+185,top+30,165,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470(editing.closedLanes().contains(branch())?"状态：禁行（红叉）":"状态：通行（绿箭头）"),b->{edited();editing=editing.indicator(field(),!editing.closedLanes().contains(branch()));status="预览中；确认只保存当前牌对应车道";method_41843();}).method_46434(left+10,top+83,340,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("进入场景预览"),b->{draft=this;class_310.method_1551().method_1507(null);}).method_46434(left+10,top+139,340,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("确认当前指示牌"),b->submit(false)).method_46434(left+10,top+261,165,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(left+185,top+261,165,20).method_46431());
    initializing=false;SmartSignClient.preview(editing,road);
  }
  private String field(){return fields.get(selected);}
  private String branch(){return field().substring(0,field().lastIndexOf('/'));}
  private Text current(){return editing.text().getOrDefault(field(),Text.EMPTY);}
  @Override protected void method_25426(){left=(field_22789-360)/2;top=Math.max(4,(field_22790-302)/2);initializing=true;if(indicator()){initIndicator();return;}var current=current();
    method_37063(class_4185.method_46430(class_2561.method_43470("上一文字区域"),b->select(-1)).method_46434(left+10,top+30,165,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("下一文字区域"),b->select(1)).method_46434(left+185,top+30,165,20).method_46431());
    value=new class_342(field_22793,left+10,top+83,340,20,class_2561.method_43470(SmartSigns.label(field())));value.method_1880(160);value.method_1852(rawValue==null?current.value().replace("\n","\\n"):rawValue);value.method_1863(v->{rawValue=v;if(!initializing)change(v,current().size(),current().wrap());});method_37063(value);
    method_37063(class_4185.method_46430(class_2561.method_43470("字号："+new String[]{"小","中","大"}[current.size()]),b->{if(change(value.method_1882(),(current().size()+1)%3,current().wrap()))method_41843();}).method_46434(left+10,top+110,110,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470(current.wrap()?"允许换行":"单行"),b->{if(change(value.method_1882(),current().size(),!current().wrap()))method_41843();}).method_46434(left+125,top+110,110,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("清空当前字段"),b->{value.method_1852("");change("",current().size(),current().wrap());}).method_46434(left+240,top+110,110,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("进入场景预览"),b->{if(invalid)return;draft=this;class_310.method_1551().method_1507(null);}).method_46434(left+10,top+139,165,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("恢复此目标草稿"),b->submit(true)).method_46434(left+185,top+139,165,20).method_46431());
    if(SmartSigns.headerMode(editing.mode()))method_37063(class_4185.method_46430(class_2561.method_43470("本分支道路编号及名称区："+(editing.headerVisible(branch())?"显示":"隐藏")),b->{try{var next=editing.header(branch(),!editing.headerVisible(branch()));SmartSignClient.validate(road.mesh(),next);edited();editing=next;SmartSignClient.preview(editing,road);status="隐藏保留原文字，再次显示即可恢复";method_41843();}catch(IllegalArgumentException ex){status=ex.getMessage();}}).method_46434(left+10,top+165,340,20).method_46431());
    if(SmartSigns.headerMode(editing.mode()))for(int i=0;i<2;i++){String part=i==0?"exit":"distance",label=i==0?"显示出口编号":"显示距离";
      method_37063(class_4185.method_46430(class_2561.method_43470(label+"："+(editing.accessoryVisible(branch(),part)?"开":"关")),b->{try{var next=editing.accessory(branch(),part,!editing.accessoryVisible(branch(),part));SmartSignClient.validate(road.mesh(),next);edited();editing=next;SmartSignClient.preview(editing,road);status="仅改变附属牌显示，原文字与草稿保留";method_41843();}catch(IllegalArgumentException ex){status=ex.getMessage();}}).method_46434(left+10+i*175,top+191,165,20).method_46431());
    }
    method_37063(class_4185.method_46430(class_2561.method_43470("确认当前字段"),b->submit(false)).method_46434(left+10,top+261,165,20).method_46431());method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(left+185,top+261,165,20).method_46431());initializing=false;SmartSignClient.preview(editing,road);}
  private void select(int delta){ // One explicit field commit; switching never silently sends edits.
    if(dirty()){status="当前字段尚未确认；请先确认或取消，避免丢失修改";return;}edited();selected=Math.floorMod(selected+delta,fields.size());rawValue=null;method_41843();}
  private boolean change(String v,int size,boolean wrap){edited();try{var next=editing.edit(field(),new Text(v.replace("\\n","\n"),size,wrap));SmartSignClient.validate(road.mesh(),next);editing=next;status="预览中；确认前不会保存";invalid=false;SmartSignClient.preview(editing,road);return true;}catch(IllegalArgumentException e){invalid=true;status=e.getMessage();return false;}}
  private class_2487 command(boolean restore){
      if(!restore&&!indicator()){var next=editing.edit(field(),new Text(value.method_1882().replace("\\n","\n"),current().size(),current().wrap()));SmartSignClient.validate(road.mesh(),next);editing=next;}
      var t=SmartSignCodec.key(original.key());t.method_10582("Action","smartText");t.method_10544("Revision",original.revision());
      if(original.target()!=null)t.method_25927("Target",original.target());t.method_10556("Restore",restore);t.method_10582("Field",field());
      if(indicator())t.method_10556("Closed",editing.closedLanes().contains(branch()));else t.method_10566("Value",SmartSignCodec.text(current()));
      if(SmartSigns.headerMode(editing.mode())){t.method_10556("HeaderVisible",editing.headerVisible(branch()));t.method_10556("ExitVisible",editing.accessoryVisible(branch(),"exit"));t.method_10556("DistanceVisible",editing.accessoryVisible(branch(),"distance"));}
      return t;
  }
  private void submit(boolean restore){
    if(pending)return;
    try{var t=command(restore);pending=true;ClientRoads.sendAction(t);}
    catch(IllegalArgumentException e){status=e.getMessage();}
  }
  public static void result(SmartTextScreen owner,boolean success,String message){if(draft!=owner||!owner.pending)return;draft.pending=false;if(success){clear();class_310.method_1551().method_1507(null);}else {draft.status=message;class_310.method_1551().method_1507(draft);}}
  @Override public void method_25419(){clear();class_310.method_1551().method_1507(null);}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);g.method_25294(left,top,left+360,top+297,0xf012212c);g.method_27535(field_22793,field_22785,left+10,top+10,0xffffff);g.method_25303(field_22793,indicator()?"车道指示牌 "+(selected+1)+" / "+fields.size():"区域 "+(selected+1)+" / "+fields.size()+" · "+SmartSigns.label(field()),left+10,top+61,0xd2e4d8);super.method_25394(g,mx,my,dt);g.method_51440(field_22793,class_2561.method_43470(status),left+10,top+221,340,0xffd9a5);}
}
