package com.sora.splineroads.client;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Catalog;
import com.sora.splineroads.core.RoadProfile.Type;
import com.sora.splineroads.core.CorridorPlanner.*;
import com.sora.splineroads.core.InterchangePlanner.Leg;
import com.sora.splineroads.core.InterchangePlanner.Options;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.*;
import java.util.*;
import java.util.concurrent.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;

/** Separate workflow for parallel roads; crossing-interchange controls do not apply. */
public final class CorridorScreen extends class_437 {
  private static final Map<String,class_2487> DRAFTS=new HashMap<>();
  private static final LatestPlanningTask<InterchangePlanner.Plan> WORKER=new LatestPlanningTask<>("SR corridor preview");
  private static long generation;
  private final class_2487 payload;
  private final Map<String,class_342> fields=new LinkedHashMap<>();
  private Config config;
  private InterchangePlanner.Options options;
  private InterchangePlanner.Plan plan;
  private class_4185 save,preview;
  private int x,y,w,h,page,delay,waitTicks,axis=1;
  private long request;
  private boolean initializing,dirty=true,computing,awaitingServer,pending;
  private String status="正在计算同侧出入口…",confirmation="";

  static void deliveryRecovery(){
    if(class_310.method_1551().field_1755 instanceof CorridorScreen screen&&screen.computing&&screen.awaitingServer){
      screen.invalidate(false);screen.delay=1;screen.status="同步已重置，正在重新请求预览…";
    }
  }
  public static void clear(){DRAFTS.clear();generation++;WORKER.cancel();}
  public static void open(class_2487 fresh){
    if(fresh.method_10558("Kind").equals("corridorCheck")){if(class_310.method_1551().field_1755 instanceof CorridorScreen screen)screen.checked(fresh);return;}
    String mode=fresh.method_10545("GeneratorMode")?fresh.method_10558("GeneratorMode"):fresh.method_10562("Corridor").method_10558("Mode");
    String kind=fresh.method_10558("Kind");var old=DRAFTS.get(mode);var mc=class_310.method_1551();
    if(kind.equals("corridorReset")){DRAFTS.remove(mode);generation++;WORKER.cancel();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();return;}
    if(kind.equals("corridorResume")){if(old!=null)mc.method_1507(new CorridorScreen(old));return;}
    class_2487 merged=fresh.method_10553();
    if(old!=null&&Arrays.equals(old.method_10565("Points"),fresh.method_10565("Points"))
        &&old.method_25928("Id")==fresh.method_25928("Id")&&(!old.method_25928("Id")||old.method_25926("Id").equals(fresh.method_25926("Id"))))
      for(String key:List.of("Corridor","Options","Main1","Main2"))merged.method_10566(key,old.method_10562(key).method_10553());
    mc.method_1507(new CorridorScreen(merged));
  }
  public CorridorScreen(class_2487 t){
    super(class_2561.method_43470(t.method_10562("Corridor").method_10558("Mode").equals("FRONTAGE")?"Spline Roads · 主辅路":"Spline Roads · 双层同侧出入口"));
    payload=t.method_10553();HostAxes.normalizeCorridor(payload);config=Corridors.read(payload.method_10562("Corridor"));options=Interchanges.read(t.method_10562("Options"));
    if(t.method_10577("Partial"))status="已有路段被删除；整体更新会补回所选布局";
  }
  private void edited(){ClientRoads.editorChanged(this);pending=false;}
  private void invalidate(){invalidate(true);}
  private void invalidate(boolean edited){if(edited)edited();WORKER.cancel();generation++;computing=false;awaitingServer=false;dirty=true;delay=8;plan=null;if(save!=null)save.field_22763=false;if(preview!=null)preview.field_22763=false;}
  private class_4185 button(String label,int bx,int by,int bw,Runnable action){
    return method_37063(class_4185.method_46430(class_2561.method_43470(label),b->{if(!capture())return;var before=payload.method_10553();var beforeConfig=config;var beforeOptions=options;action.run();boolean changed=!before.equals(payload)||!beforeConfig.equals(config)||!beforeOptions.equals(options);stash();invalidate(changed);method_41843();}).method_46434(bx,by,bw,20).method_46431());
  }
  private void field(String key,String label,double value,int bx,int by,int bw){
    class_342 f=new class_342(field_22793,bx,by+10,bw,18,class_2561.method_43470(label));f.method_1880(32);f.method_1852(Double.toString(value));
    f.method_1863(v->{if(!initializing)invalidate();});fields.put(key,f);method_37063(f);
  }
  private double number(String key,double fallback){return fields.containsKey(key)?Double.parseDouble(fields.get(key).method_1882()):fallback;}
  private Settings settings(int axis){return RoadRecord.readSettings(payload.method_10562("Main"+axis));}
  private void setSettings(Settings s){s.validate();payload.method_10566("Main"+axis,RoadRecord.writeSettings(s));}
  private void changeExtras(RoadProfile.Options options){
    var old=settings(axis);double lane=RoadProfile.layout(old,old.width()).laneWidth();
    setSettings(new Settings(Mode.STRAIGHT,old.style(),RoadProfile.width(old.style(),options,lane),old.thickness(),.4,90).structure(old.structure()).options(options));
  }
  private void changeStyle(Style style){
    var old=settings(axis);double lane=RoadProfile.layout(old,old.width()).laneWidth();
    setSettings(new Settings(Mode.STRAIGHT,style,RoadProfile.width(style,old.options(),lane),old.thickness(),.4,90).structure(old.structure()).options(old.options()));
  }
  @Override protected void method_25426(){
    initializing=true;fields.clear();w=Math.min(680,field_22789-12);h=Math.min(312,field_22790-8);x=(field_22789-w)/2;y=(field_22790-h)/2;
    int bx=x+12,by=y+27,c=w>=540?286:w-24,half=(c-6)/2;
    int tab=(c-12)/3;
    button((page==0?"• ":"")+"出入口",bx,by,tab,()->page=0);
    button((page==1?"• ":"")+"端点调整",bx+tab+6,by,tab,()->page=1);
    button((page==2?"• ":"")+"道路样式",bx+2*(tab+6),by,tab,()->page=2);by+=28;
    if(page==0){
      button(config.sides().label+" ▸",bx,by,half,()->config=new Config(config.kind(),Sides.values()[(config.sides().ordinal()+1)%3],config.access(),config.gap(),config.frontageY(),config.adjustment()));
      if(!HostAxes.fixedFrontage(payload))button(config.access().label+" ▸",bx+half+6,by,half,()->config=new Config(config.kind(),config.sides(),Access.values()[(config.access().ordinal()+1)%4],config.gap(),config.frontageY(),config.adjustment()));
      else button("仅建道路（主路有高差）",bx+half+6,by,half,()->{}).field_22763=false;by+=25;
      button(options.leftTraffic()?"靠左行驶":"靠右行驶",bx,by,half,()->options=changed(!options.leftTraffic(),options.lanes()));
      button("连接匝道："+options.lanes()+" 车道",bx+half+6,by,half,()->options=changed(options.leftTraffic(),3-options.lanes()));by+=26;
      field("gap",config.kind()==Kind.FRONTAGE?"主辅路净间隔":"匝道外绕净间隔",config.gap(),bx,by,half);
      if(config.kind()==Kind.FRONTAGE&&!HostAxes.fixedFrontage(payload))field("height","辅路路面 Y",config.frontageY(),bx+half+6,by,half);
      else if(config.kind()==Kind.FRONTAGE)button("辅路 Y = A："+config.frontageY(),bx+half+6,by+10,half,()->{}).field_22763=false;by+=39;
      field("transition","两端过渡长度",options.transition(),bx,by,half);field("radius","最小半径",options.radius(),bx+half+6,by,half);by+=39;
    }else if(page==1){
      button("调整端点："+(options.adjustEndpoints()?"允许":"关闭"),bx,by,c,()->options=options.adjust(!options.adjustEndpoints()));by+=26;
      button("端点范围："+config.adjustment().label+" ▸",bx,by,c,()->config=config.adjustment(Adjustment.values()[(config.adjustment().ordinal()+1)%Adjustment.values().length]));by+=30;
      field("clearance","交叠道路净高",options.clearance(),bx,by,c);
    }else{
      button((axis==1?"• ":"")+"AB 主路",bx,by,half,()->axis=1);
      button((axis==2?"• ":"")+(config.kind()==Kind.FRONTAGE?"同向辅路":"CD 第二层"),bx+half+6,by,half,()->axis=2);
      var road=settings(axis);var catalog=RoadProfile.catalog(road);boolean frontage=config.kind()==Kind.FRONTAGE&&axis==2;
      button(catalog.type()==RoadProfile.Type.HIGHWAY?"高速道路 ▸":"普通道路 ▸",bx,by+24,half,()->{
        var type=catalog.type()==RoadProfile.Type.HIGHWAY?RoadProfile.Type.ORDINARY:RoadProfile.Type.HIGHWAY;
        setSettings(RoadLanes.configure(road,type,RoadLanes.counts(road),RoadProfile.layout(road,road.width()).laneWidth()));
      });
      button(RoadLanes.counts(road).label()+"…",bx+half+6,by+24,half,()->{
        final int edited=axis;
        field_22787.method_1507(new RoadLaneConfigScreen(this,catalog.type(),RoadLanes.counts(road),(type,counts)->{
          axis=edited;
          if(frontage&&counts.reverse()>0){status="同向辅路请选择单向车道";return;}
          setSettings(RoadLanes.configure(settings(axis),type,counts,RoadProfile.layout(road,road.width()).laneWidth()));stash();invalidate();
        },!frontage));
      });
      var medianButton=button(RoadProfile.medianName(catalog.median())+" ▸",bx,by+48,c,()->{
        var medians=catalog.type()==RoadProfile.Type.HIGHWAY?List.of(RoadProfile.Median.RAIL,RoadProfile.Median.GREEN):List.of(RoadProfile.Median.DOUBLE_YELLOW,RoadProfile.Median.RAIL,RoadProfile.Median.GREEN);
        changeStyle(RoadLanes.carrier(catalog.type(),RoadLanes.counts(road),medians.get((medians.indexOf(catalog.median())+1)%medians.size())));
      });medianButton.field_22763=catalog.twoWay();
      field("width"+axis,"道路总宽 / 格",road.width(),bx,by+72,half);
      field("thickness"+axis,"路板厚度 / 格",road.thickness(),bx+half+6,by+72,half);
      button("外侧护栏："+road.options().outerRail().label+" ▸",bx,by+106,half,()->setSettings(settings(axis).options(settings(axis).options().outerRail(RoadProfile.OuterRail.values()[(road.options().outerRail().ordinal()+1)%RoadProfile.OuterRail.values().length]))));
      button("龙门架："+(road.options().infrastructure().gantry()==RoadInfrastructure.Gantry.OFF?"关闭":"开启"),bx+half+6,by+106,half,()->{
        var current=settings(axis);var infra=current.options().infrastructure();setSettings(current.options(current.options().infrastructure(infra.gantry(infra.gantry()==RoadInfrastructure.Gantry.OFF?RoadInfrastructure.Gantry.FRAME:RoadInfrastructure.Gantry.OFF))));
      });
      if(catalog.type()==RoadProfile.Type.ORDINARY&&h>=280){
        button("非机动车道："+(road.options().cycle()?"开":"关"),bx,by+130,half,()->{var o=settings(axis).options();changeExtras(o.extras(!o.cycle(),o.cycleRail(),o.curb()));});
        button("路缘石："+(road.options().curb()?"开":"关"),bx+half+6,by+130,half,()->{var o=settings(axis).options();changeExtras(o.extras(o.cycle(),o.cycleRail(),!o.curb()));});
      }

    }
    int n=payload.method_25928("Id")?5:3,bw=(w-24-6*(n-1))/n,footer=y+h-26;
    save=method_37063(class_4185.method_46430(class_2561.method_43470(payload.method_25928("Id")?"整体更新":"整体建造"),b->submit("interchange")).method_46434(bx,footer,bw,20).method_46431());
    preview=method_37063(class_4185.method_46430(class_2561.method_43470("实景预览"),b->{if(capture()){stash();ManualPlannerClient.worldPreview();field_22787.method_1507(null);}}).method_46434(bx+bw+6,footer,bw,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("关闭"),b->method_25419()).method_46434(bx+2*(bw+6),footer,bw,20).method_46431());
    if(n==5)for(int i=0;i<2;i++){
      String action=i==0?"interchangeDeleteRamps":"interchangeDelete";boolean ramps=i==0;
      method_37063(class_4185.method_46430(class_2561.method_43470(ramps?"仅删匝道":"删除组合"),b->{
        if(!action.equals(confirmation)){confirmation=action;b.method_25355(class_2561.method_43470("再次点击确认"));status=ramps?"保留主路与辅路/第二层道路，解除组合关系":"删除此组合的所有道路，保留端点";}else submit(action);
      }).method_46434(bx+(3+i)*(bw+6),footer,bw,20).method_46431());
    }
    save.field_22763=preview.field_22763=plan!=null&&!dirty&&!computing&&!pending;
    initializing=false;delay=1;
  }
  private InterchangePlanner.Options changed(boolean left,int lanes){return new InterchangePlanner.Options(options.preset(),left,lanes,options.transition(),options.radius(),options.clearance(),1,0,options.adjustEndpoints());}
  private boolean capture(){
    try{
      config=new Config(config.kind(),config.sides(),config.access(),number("gap",config.gap()),number("height",config.frontageY()),config.adjustment());
      options=new InterchangePlanner.Options(options.preset(),options.leftTraffic(),options.lanes(),number("transition",options.transition()),number("radius",options.radius()),number("clearance",options.clearance()),1,options.rampWidth(),options.adjustEndpoints());
      for(int i=1;i<=2;i++){var old=settings(i);var next=new Settings(Mode.STRAIGHT,old.style(),number("width"+i,old.width()),number("thickness"+i,old.thickness()),.4,90).structure(old.structure()).options(old.options());next.validate();payload.method_10566("Main"+i,RoadRecord.writeSettings(next));}
      payload.method_10566("Corridor",Corridors.write(config));HostAxes.normalizeCorridor(payload);config=Corridors.read(payload.method_10562("Corridor"));
      return true;
    }catch(IllegalArgumentException e){status=e instanceof NumberFormatException?"请输入有效数字":e.getMessage();return false;}
  }
  private void stash(){payload.method_10566("Corridor",Corridors.write(config));payload.method_10566("Options",Interchanges.write(options));DRAFTS.put(config.kind().name(),payload.method_10553());}
  @Override public void method_25393(){super.method_25393();if(delay>0)delay--;if(computing&&++waitTicks>400){WORKER.cancel();computing=false;request=++generation;status="预览检查超时，请调整参数或重新打开后重试";}if(delay==0&&dirty&&!computing)calculate();}
  private void calculate(){
    dirty=false;if(!capture())return;stash();ClientRoads.editorChanged(this);computing=true;awaitingServer=true;waitTicks=0;request=++generation;
    class_2487 command=new class_2487();for(String key:List.of("Id","Points","Main1","Main2","Options","Corridor"))if(payload.method_10545(key))command.method_10566(key,payload.method_10580(key).method_10707());
    command.method_10582("Action","interchangePreview");command.method_10544("Request",request);status="正在核对既有道路、端点占用与可调整方向…";
    ClientRoads.sendAction(command);
  }
  private void checked(class_2487 reply){
    if(reply.method_10537("Request")!=request||!computing||field_22787.field_1687==null||!field_22787.field_1687.method_27983().method_29177().toString().equals(reply.method_10558("Dimension")))return;
    awaitingServer=false;
    if(dirty){computing=false;delay=1;return;}
    if(reply.method_10545("Error")){computing=false;status=reply.method_10558("Error");ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();return;}
    var inputs=reply.method_10562("Inputs").method_10553();payload.method_10566("Nodes",inputs.method_10554("Nodes",class_2520.field_33260).method_10612());payload.method_10582("ResolvedFit",inputs.method_10558("ResolvedFit"));payload.method_10566("HostAxes",inputs.method_10554("HostAxes",class_2520.field_33260).method_10612());payload.method_10566("Corridor",inputs.method_10562("Corridor").method_10553());config=Corridors.read(payload.method_10562("Corridor"));
    long token=request;waitTicks=0;status="检查通过，正在生成道路预览…";
    WORKER.submit(()->Interchanges.plan(inputs),(result,error)->class_310.method_1551().execute(()->{
      if(token!=generation)return;computing=false;if(dirty){delay=1;return;}
      if(error!=null){Throwable cause=error.getCause()==null?error:error.getCause();status=cause.getMessage();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();return;}
      plan=result;ClientRoads.nodePreviews=result.legs().stream().map(l->RoadRenderMesh.simplify(l.mesh())).toList();ClientRoads.preview=ClientRoads.nodePreviews.get(0);
      status=(options.adjustEndpoints()?"端点："+Adjustment.valueOf(inputs.method_10558("ResolvedFit")).label+"；":"")+result.movements()+" 条同侧出入口；最大纵坡 "+String.format(Locale.ROOT,"%.1f%%",result.legs().stream().mapToDouble(l->RoadGrades.maximum(l.mesh())).max().orElse(0)*100)+"。左右以 A→B 为准。";
      int moved=0;double distance=0;var source=payload.method_10554("Nodes",class_2520.field_33260);
      for(int i=0;i<result.anchors().size();i++){double d=result.anchors().get(i).position().distance(RoadRecord.readNode(source.method_10602(i)).position());if(d>1e-6){moved++;distance=Math.max(distance,d);}}
      if(HostAxes.fixedFrontage(payload))status="主路有高差：仅建辅路，不设出入口；辅路固定在 A 端高度 "+config.frontageY()+"。";
      if(moved>0)status+=" 自动调整 "+moved+" 个端点，最大移动 "+String.format(Locale.ROOT,"%.1f",distance)+" 格（实景预览可查看）。";
      if(payload.method_10577("Partial"))status+=" 整体更新会补回已删除路段。";
      save.field_22763=preview.field_22763=!pending;
    }));
  }
  private void submit(String action){
    if(pending||action.equals("interchange")&&(plan==null||dirty||computing))return;
    if(!capture())return;stash();class_2487 command=new class_2487();
    for(String key:List.of("Id","Points","Main1","Main2","Options","Corridor"))if(payload.method_10545(key))command.method_10566(key,payload.method_10580(key).method_10707());
    command.method_10569("SourceAxesHash",com.sora.splineroads.world.HostAxes.signature(payload));
    command.method_10566("SourceNodes",payload.method_10554("Nodes",class_2520.field_33260).method_10612());
    if(plan!=null){class_2499 fitted=new class_2499();plan.anchors().forEach(n->fitted.add(RoadRecord.writeNode(n)));command.method_10566("FittedNodes",fitted);}
    command.method_10582("Action",action);pending=true;save.field_22763=false;preview.field_22763=false;status="正在检查并提交道路组合…";
    ClientRoads.sendAction(command);
  }
  /** A child settings screen can remain open while this submission completes. */
  void completed(){pending=false;}

  public void failed(String reason){pending=false;status=reason;save.field_22763=plan!=null&&!dirty;preview.field_22763=save.field_22763;}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25432(){WORKER.cancel();generation++;if(computing)dirty=true;computing=false;super.method_25432();}
  @Override public void method_25419(){WORKER.cancel();generation++;if(capture())stash();ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();super.method_25419();}
  @Override public void method_25394(class_332 g,int mx,int my,float partial){
    method_25420(g);g.method_25294(x,y,x+w,y+h,0xEF182530);g.method_51439(field_22793,field_22785,x+12,y+10,0xFFFFFF,false);super.method_25394(g,mx,my,partial);
    for(var f:fields.values())g.method_51439(field_22793,f.method_25369(),f.method_46426(),f.method_46427()-9,0xC8DAE5,false);
    if(w>=540){int px=x+312,py=y+55,pw=w-324,ph=h-123;g.method_25294(px,py,px+pw,py+ph,0xFF09161F);
      if(plan!=null){
        V origin=plan.anchors().get(0).position(),axis=plan.anchors().get(1).position().sub(origin).horizontalUnit();
        double length=plan.anchors().get(1).position().distance(origin),extent=plan.legs().stream().flatMap(l->l.mesh().samples().stream()).mapToDouble(s->Math.abs(s.center().sub(origin).dot(axis.left()))+s.halfWidth()).max().orElse(20);
        double scale=Math.min((pw-16)/length,(ph-30)/(extent*2));
        for(var leg:plan.legs())for(int i=0;i<leg.mesh().samples().size();i+=2){Sample s=leg.mesh().samples().get(i);V d=s.center().sub(origin);int xx=px+8+(int)(d.dot(axis)*scale),zz=py+ph/2+(int)(d.dot(axis.left())*scale),r=Math.max(1,(int)(s.halfWidth()*scale));g.method_25294(xx-r,zz-r,xx+r+1,zz+r+1,leg.mesh().settings().style().ramp()?0xFFFFCD6D:leg.name().contains("辅路")?0xFF71C7A5:0xFF579CC9);}
        g.method_51433(field_22793,"A → B 俯视 · 黄色为连接匝道",px+6,py+6,0xFFFFFF,false);
      }
    }
    var lines=field_22793.method_1728(class_2561.method_43470(status==null?"":status),w-24);for(int i=0;i<Math.min(2,lines.size());i++)g.method_51430(field_22793,lines.get(i),x+12,y+h-51+i*10,plan==null?0xFFFFB6A3:0xFFC8E9DA,false);
    if(lines.size()>2&&my>=y+h-52&&my<y+h-29)g.method_51438(field_22793,class_2561.method_43470(status),mx,my);
  }
}
