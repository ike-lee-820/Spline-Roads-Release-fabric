package com.sora.splineroads.client;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Link;
import com.sora.splineroads.core.RoadGeometry.Mesh;
import com.sora.splineroads.core.TollPlanner.Plan;
import com.sora.splineroads.core.TollPlaza.Spec;
import com.sora.splineroads.world.*;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Pure immutable preview preparation on the existing bounded network decoder.
 * No level, renderer, texture or GUI state is read here. */
public record RoadPreviewData(Toll toll,Lane lane,List<Mesh> conflicts,Set<UUID> dependencies) {
  public record Toll(Mesh mesh,TollPlanner.Plan plan,List<Mesh> roads,List<RoadSurface.Face> faces) {}
  public record Lane(RoadRecord road,Mesh mesh,List<Mesh> roads,double minimumRadius) {}

  public static boolean queued(class_2487 envelope) {
    String type=envelope.method_10558("Type");
    var payload=type.equals("open")?envelope.method_10562("Payload"):envelope;
    if(!payload.method_10554("ConflictRoads",class_2520.field_33260).isEmpty())return type.equals("open")||type.equals("resultPreview");
    if(!type.equals("open")||payload.method_10545("Error"))return false;
    return Set.of("tollCheck","laneRampCheck","corridorCheck").contains(payload.method_10558("Kind"));
  }

  public static RoadPreviewData prepare(class_2487 envelope) {
    return preparePayload(envelope.method_10558("Type").equals("open")?envelope.method_10562("Payload"):envelope);
  }

  public static RoadPreviewData preparePayload(class_2487 payload) {
    var dependencies=new LinkedHashSet<UUID>();var conflicts=new ArrayList<Mesh>();
    for(class_2520 tag:payload.method_10554("ConflictRoads",class_2520.field_33260)) {
      try {var road=RoadRecord.load((class_2487)tag);conflicts.add(road.mesh());depend(dependencies,road);}
      catch(IllegalArgumentException ignored) {}
    }
    Toll toll=null;Lane lane=null;
    if(!payload.method_10545("Error")&&payload.method_10558("Kind").equals("tollCheck")) {
      var input=payload.method_10562("Inputs");var spec=TollCodec.read(input.method_10562("Spec"));
      var roads=new ArrayList<RoadIndex.Built>();
      for(class_2520 tag:input.method_10554("Roads",class_2520.field_33260)){var road=RoadRecord.load((class_2487)tag);depend(dependencies,road);roads.add(new RoadIndex.Built(road));}
      var station=roads.stream().filter(r->spec.equals(r.record.toll())).findFirst().orElseThrow(()->new IllegalArgumentException("收费站预览缺少站区"));
      var plan=station.record.tollPlan();var faces=new ArrayList<RoadSurface.Face>(plan.paint());
      for(var road:roads){
        road.record.structures().forEach(part->faces.addAll(part.faces()));
        if(road!=station)faces.addAll(RoadSurface.build(road.mesh,List.of(),roads.stream().filter(r->r!=road).map(r->r.mesh).toList()).markings());
      }
      toll=new Toll(station.mesh,plan,roads.stream().map(r->r.mesh).toList(),List.copyOf(faces));
    } else if(!payload.method_10545("Error")&&payload.method_10558("Kind").equals("laneRampCheck")) {
      var road=RoadRecord.load(payload.method_10562("Road"));var mesh=road.mesh();depend(dependencies,road);
      var views=new ArrayList<Mesh>();for(class_2520 tag:payload.method_10554("ChangedRoads",class_2520.field_33260)) {
        var changed=RoadRecord.load((class_2487)tag);depend(dependencies,changed);views.add(changed.mesh());
      }
      lane=new Lane(road,mesh,views.isEmpty()?List.of(mesh):List.copyOf(views),RoadRibbon.minRadius(mesh));
    }
    return new RoadPreviewData(toll,lane,List.copyOf(conflicts),Set.copyOf(dependencies));
  }

  private static void depend(Set<UUID> ids,RoadRecord road) {
    ids.add(road.id());var link=LaneTopology.metadata(road).link();
    if(link!=null){if(link.from().road()!=null)ids.add(link.from().road());if(link.to().road()!=null)ids.add(link.to().road());}
  }

  /** Keep the original request envelope so the affected editor can offer retry. */
  public static class_2487 failed(class_2487 envelope,String message) {
    var out=envelope.method_10553();var payload=out.method_10558("Type").equals("open")?out.method_10562("Payload"):out;
    for(String key:List.of("Inputs","Road","ChangedRoads","ConflictRoads"))payload.method_10551(key);
    if(out.method_10558("Type").equals("open"))payload.method_10582("Error",message);
    else {out.method_10556("Success",false);out.method_10582("Message",message);}
    return out;
  }
}
