package com.sora.splineroads.client;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.client.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT)
public final class ManualPlannerClient {
  static ManualPlannerScreen map;private static class_437 resume,lastChild;private static boolean world;private static net.minecraft.class_5321<net.minecraft.class_1937> dimension;
  private static long openingAt;private static UUID openingRequest;
  private static class_437 mapPreviewEditor;
  private static ManualPlannerScreen.SurfaceCache retainedSurface;
  private static net.minecraft.class_638 surfaceLevel;
  private static long surfaceDeadline;
  private static double openedX,openedZ;
  private static int surfaceRadius;
  private static boolean openedRangeExpired;
  private static void expireOpenSurface(){var mc=class_310.method_1551();if(map!=null&&!openedRangeExpired&&mc.field_1724!=null&&Math.hypot(mc.field_1724.method_23317()-openedX,mc.field_1724.method_23321()-openedZ)>map.cacheRadius()){openedRangeExpired=true;map.invalidateSurface();}}
  private static void releaseSurface(){if(retainedSurface!=null)retainedSurface.release();retainedSurface=null;surfaceLevel=null;surfaceDeadline=0;}
  private static void expireSurface(long now){var mc=class_310.method_1551();if(retainedSurface!=null&&(surfaceLevel!=mc.field_1687||mc.field_1724==null||now>=surfaceDeadline||Math.hypot(mc.field_1724.method_23317()-openedX,mc.field_1724.method_23321()-openedZ)>surfaceRadius))releaseSurface();}

  static boolean hasMap(){return map!=null;}
  static boolean previewing(Object owner){return map!=null&&class_310.method_1551().field_1755==map&&mapPreviewEditor==owner;}
  static boolean hasMapPreview(){return mapPreviewEditor!=null;}
  static void mapPreview(class_437 editor){if(map==null)return;mapPreviewEditor=editor;resume=null;world=false;lastChild=null;class_310.method_1551().method_1507(map);map.refresh();}
  static void resumeMapPreview(){if(mapPreviewEditor==null)return;var editor=mapPreviewEditor;mapPreviewEditor=null;ClientRoads.beginEditor(editor);class_310.method_1551().method_1507(editor);}
  static void abandonMapPreview(){if(mapPreviewEditor==null)return;mapPreviewEditor=null;ClientRoads.preview=null;ClientRoads.nodePreviews=List.of();ClientRoads.conflictPreview=false;}
  private static final Set<class_437> children=Collections.newSetFromMap(new WeakHashMap<>());
  static final class_304 KEY=new class_304("key.splineroads.manual_planner",GLFW.GLFW_KEY_P,"key.categories.splineroads");
  @Mod.EventBusSubscriber(modid=SplineRoads.ID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.MOD)
  public static final class Setup {@SubscribeEvent public static void keys(RegisterKeyMappingsEvent e){e.register(KEY);}}
  @SubscribeEvent public static void input(InputEvent.Key e){var mc=class_310.method_1551();if(e.getAction()==GLFW.GLFW_PRESS&&mc.field_1755==null&&KEY.method_1417(e.getKey(),e.getScanCode()))while(mc.field_1690.field_26845.method_1436()){} }
  @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){
    if(e.phase!=TickEvent.Phase.END)return;var mc=class_310.method_1551();
    if(mc.field_1687==null){clear();dimension=null;return;}
    if(dimension!=null&&!dimension.equals(mc.field_1687.method_27983())){clear();if(mc.field_1755 instanceof ManualPlannerScreen)mc.method_1507(null);}
    dimension=mc.field_1687.method_27983();long now=net.minecraft.class_156.method_658();expireSurface(now);expireOpenSurface();
    if(openingAt!=0&&now-openingAt>30000||map!=null&&map.snapshotExpired(now))deliveryFailure("等待服务器超时，请关闭地图后重试");
    if(mc.field_1755!=null){lastChild=children.contains(mc.field_1755)?mc.field_1755:null;}
    else if(lastChild!=null){lastChild=null;if(world)world=false;else if(map!=null){mc.method_1507(map);ClientRoads.beginEditor(map);map.refresh();}}
    while(KEY.method_1436())if(mc.field_1755==null){
      if(resume!=null){var next=resume;resume=null;ClientRoads.beginEditor(next);mc.method_1507(next);}
      else if(openingRequest==null){var t=new class_2487();t.method_10582("Action","manualOpen");openingRequest=UUID.randomUUID();t.method_25927("OpenRequest",openingRequest);openingAt=now;RoadNetwork.CHANNEL.sendToServer(new RoadNetwork.Action(t));}
    }
  }
  @SubscribeEvent public static void opening(ScreenEvent.Opening e){if(e.getNewScreen()!=null)cancelOpening();if(map==null)return;var old=class_310.method_1551().field_1755;if(e.getNewScreen()==null&&children.contains(old)){if(world){world=false;return;}e.setNewScreen(map);ClientRoads.beginEditor(map);map.refresh();}else if(e.getNewScreen()!=null&&e.getNewScreen()!=map&&children.contains(old))children.add(e.getNewScreen());}
  static void child(class_437 screen){children.add(screen);lastChild=screen;}
  static void completed(class_437 screen){
    if(resume==screen)resume=null;
    if(mapPreviewEditor==screen)mapPreviewEditor=null;
    // A visible child still needs the normal close-to-map transition. Hidden
    // completed editors must not be resurrected by either P or the tick fallback.
    if(class_310.method_1551().field_1755!=screen){if(lastChild==screen)lastChild=null;children.remove(screen);}
  }
  private static void cancelOpening(){if(openingRequest!=null&&class_310.method_1551().method_1562()!=null){var t=new class_2487();t.method_10582("Action","manualCancelOpen");t.method_25927("OpenRequest",openingRequest);RoadNetwork.CHANNEL.sendToServer(new RoadNetwork.Action(t));}openingRequest=null;openingAt=0;}
  static void clear(){releaseSurface();clearEditors();}
  private static void clearEditors(){cancelOpening();abandonMapPreview();if(map!=null)map.release();map=null;resume=null;lastChild=null;world=false;children.clear();}
  static void deliveryFailure(String message){if(openingRequest==null&&(map==null||!map.loading()))return;cancelOpening();if(map!=null)map.failSnapshot(message);var mc=class_310.method_1551();if(mc.field_1724!=null)mc.field_1724.method_7353(net.minecraft.class_2561.method_43470("规划地图读取失败："+message),false);com.mojang.logging.LogUtils.getLogger().warn("Manual planner delivery failed: {}",message);}
  static boolean openResult(class_2487 t){if(!t.method_25928("OpenRequest"))return false;if(t.method_25926("OpenRequest").equals(openingRequest)&&!t.method_10577("Success"))cancelOpening();return true;}
  static void opened(class_2487 t){if(map!=null&&t.method_25928("PlannerSession")&&map.session.equals(t.method_25926("PlannerSession"))){var screen=class_310.method_1551().field_1755;if(screen!=null&&screen!=map)child(screen);}}
  static void worldPreview(){var screen=class_310.method_1551().field_1755;if(map!=null&&children.contains(screen)){resume=screen;world=true;}else if(screen instanceof ElevatedAccessScreen)resume=screen;}
  static void decorate(class_2487 t){var screen=class_310.method_1551().field_1755;if(map!=null&&(screen==map||children.contains(screen)||t.method_25928("PlannerSession")))t.method_25927("PlannerSession",map.session);}
  static boolean receive(class_2487 t){
    String kind=t.method_10558("Kind");
    if(kind.equals("manualTerrain")){if(map!=null&&t.method_25928("PlannerSession")&&map.session.equals(t.method_25926("PlannerSession")))map.terrain(t);return true;}
    if(kind.equals("manualMapPage")){if(map!=null&&t.method_25928("PlannerSession")&&map.session.equals(t.method_25926("PlannerSession")))map.page(t);return true;}
    if(!kind.equals("manualPlanner")&&!kind.equals("manualState"))return false;
    if(kind.equals("manualPlanner")){
      if(openingRequest==null||!t.method_25928("OpenRequest")||!openingRequest.equals(t.method_25926("OpenRequest")))return true;
      var mc=class_310.method_1551();if(mc.field_1687==null||mc.field_1755!=null){cancelOpening();return true;}
      openingRequest=null;openingAt=0;
      expireSurface(net.minecraft.class_156.method_658());
      if(map==null||!map.session.equals(t.method_25926("PlannerSession"))){clearEditors();map=new ManualPlannerScreen(t);if(retainedSurface!=null){map.restoreSurface(retainedSurface);releaseSurface();}}
      openedX=mc.field_1724.method_23317();openedZ=mc.field_1724.method_23321();openedRangeExpired=false;
      map.state(t);if(t.method_25928("MapSnapshot"))map.beginSnapshot(t);mc.method_1507(map);ClientRoads.beginEditor(map);
    }else if(map!=null&&map.session.equals(t.method_25926("PlannerSession"))){map.state(t);if(t.method_25928("MapSnapshot"))map.beginSnapshot(t);}
    return true;
  }
  static void close(){
    if(map==null)return;var mc=class_310.method_1551();var t=new class_2487();t.method_10582("Action","manualClose");t.method_25927("PlannerSession",map.session);RoadNetwork.CHANNEL.sendToServer(new RoadNetwork.Action(t));
    releaseSurface();int seconds=map.cacheSeconds();surfaceRadius=map.cacheRadius();
    if(seconds>0&&!openedRangeExpired&&mc.field_1724!=null&&Math.hypot(mc.field_1724.method_23317()-openedX,mc.field_1724.method_23321()-openedZ)<=surfaceRadius){retainedSurface=map.detachSurface();surfaceLevel=mc.field_1687;surfaceDeadline=net.minecraft.class_156.method_658()+seconds*1000L;}
    clearEditors();mc.method_1507(null);
  }
  private ManualPlannerClient(){}
}
