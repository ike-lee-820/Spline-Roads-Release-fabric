package com.sora.splineroads.client;

import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1087;
import net.minecraft.class_1723;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.core.*;
import net.minecraftforge.client.ChunkRenderTypeSet;
import net.minecraftforge.client.model.BakedModelWrapper;
import net.minecraftforge.client.model.data.ModelData;

/** Optional Fabric renderer bridge. No Fabric types link on a Forge-only client. */
final class RoadFabricModels {
  private static final Api API=Api.find();
  static class_1087 wrap(class_1087 base,class_1087 terrain,Function<ModelData,List<class_777>> roads,
      BiFunction<List<class_777>,ModelData,List<class_777>> clip,Predicate<ModelData> covered){
    if(API==null||!API.model.isInstance(base))return terrain;
    var handler=new Model(base,terrain,roads,clip,covered);
    return (class_1087)Proxy.newProxyInstance(RoadFabricModels.class.getClassLoader(),new Class<?>[]{class_1087.class,API.model},handler);
  }
  static class_1087 unwrap(class_1087 model){
    if(Proxy.isProxyClass(model.getClass())&&Proxy.getInvocationHandler(model) instanceof Model handler)return handler.base;
    return model;
  }
  private record Clipped(class_777 quad,Object material,class_2350 cull,int tag){}
  private record Model(class_1087 base,class_1087 terrain,Function<ModelData,List<class_777>> roads,
      BiFunction<List<class_777>,ModelData,List<class_777>> clip,Predicate<ModelData> covered) implements InvocationHandler {
    public Object invoke(Object proxy,Method method,Object[] args)throws Throwable{
      if(method.getDeclaringClass()==Object.class)return switch(method.getName()){
        case "equals" -> proxy==args[0];case "hashCode" -> System.identityHashCode(proxy);case "toString" -> "SR Fabric terrain bridge["+base+"]";default -> call(method,terrain,args);
      };
      return switch(method.getName()){
        case "isVanillaAdapter" -> false;
        case "emitBlockQuads" -> {emit(args);yield null;}
        case "emitItemQuads" -> call(method,base,args);
        default -> call(method,terrain,args);
      };
    }
    @SuppressWarnings("unchecked") private void emit(Object[] args)throws Throwable{
      Object context=args[4];var state=(class_2680)args[1];
      var data=net.minecraftforge.client.model.ForgeBakedModels.of(terrain).getModelData((class_1920)args[0],(class_2338)args[2],state,(ModelData)call(API.modelData,context));
      var clipped=new ArrayList<Clipped>();
      Object transform=null;
      if(covered.test(data)){
        Object finder=call(API.spriteFinder,null,class_310.method_1551().method_1554().method_24153(class_1723.field_21668));
        transform=Proxy.newProxyInstance(RoadFabricModels.class.getClassLoader(),new Class<?>[]{API.transform},(p,m,a)->{
          if(!m.getName().equals("transform"))return m.getName().equals("hashCode")?System.identityHashCode(p):m.getName().equals("equals")?p==a[0]:"SR road coverage";
          Object quad=a[0]; // Contact extrusion also transforms side and bottom faces.
          var sprite=(class_1058)call(API.findSprite,finder,quad);
          var original=(class_777)call(API.bakedQuad,quad,sprite);var pieces=clip.apply(List.of(original),data);
          if(pieces.size()==1&&pieces.get(0)==original)return true;
          Object material=call(API.material,quad);var cull=(class_2350)call(API.cullFace,quad);int tag=(int)call(API.tag,quad);
          for(var piece:pieces)clipped.add(new Clipped(piece,material,cull,tag));return false;
        });
        call(API.push,context,transform);
      }
      try{call(API.emitBlock,base,args);}finally{if(transform!=null)call(API.pop,context);}
      Object emitter=call(API.emitter,context);
      for(var piece:clipped){call(API.fromVanilla,emitter,piece.quad(),piece.material(),piece.cull());call(API.setTag,emitter,piece.tag());call(API.emit,emitter);}
      var layer=(class_1921)call(API.layer,context);var quads=roads.apply(data);
      if(quads==null||quads.isEmpty()||layer!=null&&layer!=class_1921.method_23577())return;
      // Pass an ordinary Forge carrier through the renderer's encoder. It is
      // roads-only, so CTM base quads are never emitted a second time.
      var overlay=new BakedModelWrapper<class_1087>(terrain){
        @Override public List<class_777> method_4707(class_2680 s,class_2350 face,class_5819 random){return face==null?quads:List.of();}
        @Override public List<class_777> getQuads(class_2680 s,class_2350 face,class_5819 random,ModelData d,class_1921 type){return face==null&&(type==null||type==class_1921.method_23577())?quads:List.of();}
        @Override public ChunkRenderTypeSet getRenderTypes(class_2680 s,class_5819 random,ModelData d){return ChunkRenderTypeSet.of(class_1921.method_23577());}
        @Override public boolean method_4708(){return false;}
      };
      ((Consumer<class_1087>)call(API.fallback,context)).accept(overlay);
    }
  }
  private static Object call(Method m,Object target,Object... args)throws Throwable{try{return m.invoke(target,args);}catch(InvocationTargetException e){throw e.getCause();}}
  private static final class Api {
    final Class<?> model,transform;
    final Method emitBlock,modelData,layer,push,pop,emitter,fallback,spriteFinder,findSprite,bakedQuad,lightFace,material,cullFace,tag,fromVanilla,setTag,emit;
    Api()throws ReflectiveOperationException{
      var loader=RoadFabricModels.class.getClassLoader();model=Class.forName("net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel",false,loader);
      var context=Class.forName("net.fabricmc.fabric.api.renderer.v1.render.RenderContext",false,loader);
      transform=Class.forName("net.fabricmc.fabric.api.renderer.v1.render.RenderContext$QuadTransform",false,loader);
      var quad=Class.forName("net.fabricmc.fabric.api.renderer.v1.mesh.QuadView",false,loader);var out=Class.forName("net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter",false,loader);
      var mat=Class.forName("net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial",false,loader);var finder=Class.forName("net.fabricmc.fabric.api.renderer.v1.model.SpriteFinder",false,loader);
      emitBlock=model.getMethod("emitBlockQuads",class_1920.class,class_2680.class,class_2338.class,Supplier.class,context);
      modelData=context.getMethod("getModelData");layer=context.getMethod("getRenderLayer");push=context.getMethod("pushTransform",transform);pop=context.getMethod("popTransform");emitter=context.getMethod("getEmitter");fallback=context.getMethod("fallbackConsumer");
      spriteFinder=finder.getMethod("get",class_1059.class);findSprite=finder.getMethod("find",quad);bakedQuad=quad.getMethod("toBakedQuad",class_1058.class);lightFace=quad.getMethod("lightFace");material=quad.getMethod("material");cullFace=quad.getMethod("cullFace");tag=quad.getMethod("tag");
      fromVanilla=out.getMethod("fromVanilla",class_777.class,mat,class_2350.class);setTag=out.getMethod("tag",int.class);emit=out.getMethod("emit");
    }
    static Api find(){try{return new Api();}catch(Throwable absent){return null;}}
  }
}
