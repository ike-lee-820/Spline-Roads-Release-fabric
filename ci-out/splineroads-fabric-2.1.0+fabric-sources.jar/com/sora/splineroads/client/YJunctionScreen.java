package com.sora.splineroads.client;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.RoadRecord;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.gui.components.*;
import net.minecraft.nbt.*;
public final class YJunctionScreen extends class_437 {
  private final class_2487 payload;private class_342 tension;private String status="";private int x,y,w,h;private boolean pending;private class_4185 apply;private YJunctionPlanner.Plan plan;
  private void edited(){ClientRoads.editorChanged(this);pending=false;}
  public YJunctionScreen(class_2487 t){super(class_2561.method_43470("Y 字路口编辑器"));payload=t.method_10553();}
  @Override protected void method_25426(){w=Math.min(430,field_22789-12);h=Math.min(330,field_22790-8);x=(field_22789-w)/2;y=(field_22790-h)/2;
    for(int i=0;i<3;i++){final int slot=i;var settings=RoadRecord.readSettings(payload.method_10562("Profile"+i));
      var button=method_37063(class_4185.method_46430(class_2561.method_43470((char)('A'+i)+" "+RoadLanes.counts(settings).label()),b->{
        payload.method_10549("Tension",parseTension());
        field_22787.method_1507(new RoadLaneConfigScreen(this,RoadProfile.catalog(settings).type(),RoadLanes.counts(settings),(type,counts)->{
          var changed=RoadLanes.configure(settings,type,counts,RoadProfile.layout(settings,settings.width()).laneWidth());
          payload.method_10566("Profile"+slot,RoadRecord.writeSettings(changed));edited();
        },slot==0));
      }).method_46434(x+12+i*(w-24)/3,y+31,(w-30)/3,20).method_46431());button.field_22763=!payload.method_10577("LockedProfile"+i)&&!pending;
    }
    tension=new class_342(field_22793,x+w-100,y+h-89,86,20,class_2561.method_43470("曲线强度"));tension.method_1880(5);tension.method_1852(Double.toString(payload.method_10574("Tension")));method_37063(tension);tension.method_1863(v->{edited();preview();});
    apply=method_37063(class_4185.method_46430(class_2561.method_43470(payload.method_25928("Id")?"保存修改":"建造 Y 字路口"),b->send(false)).method_46434(x+12,y+h-62,(w-32)/2,20).method_46431());
    method_37063(class_4185.method_46430(class_2561.method_43470("取消"),b->method_25419()).method_46434(x+w/2+4,y+h-62,(w-32)/2,20).method_46431());
    if(payload.method_25928("Id"))method_37063(class_4185.method_46430(class_2561.method_43470("删除此 Y 字路口"),b->send(true)).method_46434(x+12,y+h-37,w-24,20).method_46431());preview();
  }
  private double parseTension(){try{return Double.parseDouble(tension.method_1882());}catch(RuntimeException e){return payload.method_10574("Tension");}}
  private void preview(){try{var n=payload.method_10554("Nodes",class_2520.field_33260);plan=YJunctionPlanner.plan(RoadRecord.readNode(n.method_10602(0)),RoadRecord.readNode(n.method_10602(1)),RoadRecord.readNode(n.method_10602(2)),RoadRecord.readSettings(payload.method_10562("Profile0")),RoadRecord.readSettings(payload.method_10562("Profile1")),RoadRecord.readSettings(payload.method_10562("Profile2")),Double.parseDouble(tension.method_1882()));status="";}catch(IllegalArgumentException e){plan=null;status=e instanceof NumberFormatException?"请输入曲线强度":e.getMessage();}if(apply!=null)apply.field_22763=plan!=null&&!pending;}
  private void send(boolean delete){if(pending||!delete&&plan==null)return;var t=payload.method_10553();t.method_10582("Action","yJunction");if(!delete)t.method_10549("Tension",Double.parseDouble(tension.method_1882()));t.method_10556("Delete",delete);pending=true;apply.field_22763=false;ClientRoads.sendAction(t);}
  /** A child settings screen can remain open while this submission completes. */
  void completed(){pending=false;}

  public void failed(String s){pending=false;status=s;apply.field_22763=plan!=null;}
  @Override public boolean method_25421(){return false;}
  @Override public void method_25394(class_332 g,int mx,int my,float dt){method_25420(g);g.method_25294(x,y,x+w,y+h,0xf015222e);g.method_51433(field_22793,"Y 字路口 · A 双向 / B 出向 / C 入向",x+12,y+12,0xffffff,false);
    g.method_25294(x+12,y+55,x+w-12,y+h-123,0xff252f36);
    if(plan!=null){var ms=List.of(plan.stem(),plan.outbound(),plan.inbound());double minX=ms.stream().mapToDouble(m->m.min().x()).min().orElse(0),maxX=ms.stream().mapToDouble(m->m.max().x()).max().orElse(1),minZ=ms.stream().mapToDouble(m->m.min().z()).min().orElse(0),maxZ=ms.stream().mapToDouble(m->m.max().z()).max().orElse(1);double scale=Math.min((w-70)/Math.max(1,maxX-minX),(h-198)/Math.max(1,maxZ-minZ));double cx=(minX+maxX)/2,cz=(minZ+maxZ)/2;
      for(int i=0;i<ms.size();i++)for(var s:ms.get(i).samples()){int px=x+w/2+(int)((s.center().x()-cx)*scale),py=y+65+(h-188)/2+(int)((s.center().z()-cz)*scale);int r=Math.max(1,(int)(s.halfWidth()*scale));g.method_25294(px-r,py-r,px+r+1,py+r+1,i==0?0xff9eabb2:i==1?0xff4bd7a5:0xffeeb268);}
      var n=payload.method_10554("Nodes",class_2520.field_33260);for(int i=0;i<3;i++){var p=RoadRecord.readNode(n.method_10602(i)).position();g.method_25300(field_22793,""+(char)('A'+i),x+w/2+(int)((p.x()-cx)*scale),y+65+(h-188)/2+(int)((p.z()-cz)*scale),0xffffff);}
    }
    g.method_51440(field_22793,class_2561.method_43470(status.isEmpty()?"绿色 A→B 按 B 车道过渡，橙色 C→A 按 A 接收方向车道过渡；B、C 须为单向道路，可使用不同车道数。":status),x+14,y+h-116,w-28,status.isEmpty()?0xbdd9d5:0xffaf91);g.method_51433(field_22793,"曲线强度（0.2–0.8）",x+14,y+h-82,0xd7e8ef,false);super.method_25394(g,mx,my,dt);
  }
}
