package com.sora.splineroads;

import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.*;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.*;

@Mod(SplineRoads.ID)
public final class SplineRoads {
  public static final String ID = "splineroads";
  public static final DeferredRegister<class_2248> BLOCKS =
      DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
  public static final DeferredRegister<class_1792> ITEMS =
      DeferredRegister.create(ForgeRegistries.ITEMS, ID);
  public static final DeferredRegister<class_2591<?>> ENTITIES =
      DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ID);
  public static final DeferredRegister<class_1761> TABS =
      DeferredRegister.create(class_7924.field_44688, ID);
  public static final RegistryObject<class_2248> NODE =
      BLOCKS.register("road_node", RoadBlocks.Node::new);
  public static final RegistryObject<class_2248> ROAD_BLOCK = BLOCKS.register("road_block",()->new class_2248(net.minecraft.class_4970.class_2251.method_9630(net.minecraft.class_2246.field_10340).method_9629(1.8f,6f)));
  public static final RegistryObject<class_2248> ROAD_SLAB = BLOCKS.register("road_slab",()->new net.minecraft.class_2482(net.minecraft.class_4970.class_2251.method_9630(net.minecraft.class_2246.field_10340).method_9629(1.8f,6f)));
  public static final RegistryObject<class_2248> TUNNEL_AIR = BLOCKS.register("tunnel_air",TunnelAir::new);
  public static final RegistryObject<class_2248> COLLIDER =
      BLOCKS.register("road_collision", RoadBlocks.Road::new);
  public static final RegistryObject<class_2248> FILLED_COLLIDER =
      BLOCKS.register("road_infill", RoadBlocks.FilledRoad::new);
  public static final RegistryObject<class_2591<RoadFillEntity>> FILL_ENTITY =
      ENTITIES.register("road_infill",()->class_2591.class_2592.method_20528(RoadFillEntity::new,FILLED_COLLIDER.get()).method_11034(null));
  public static final RegistryObject<class_2591<NodeEntity>> NODE_ENTITY =
      ENTITIES.register(
          "road_node", () -> class_2591.class_2592.method_20528(NodeEntity::new, NODE.get()).method_11034(null));
  public static final RegistryObject<class_1792> NODE_ITEM =
      ITEMS.register("road_node", () -> new class_1747(NODE.get(), new class_1792.class_1793()));
  public static final RegistryObject<class_1792> ROAD_BLOCK_ITEM = ITEMS.register("road_block",()->new class_1747(ROAD_BLOCK.get(),new class_1792.class_1793()));
  public static final RegistryObject<class_1792> ROAD_SLAB_ITEM = ITEMS.register("road_slab",()->new class_1747(ROAD_SLAB.get(),new class_1792.class_1793()));
  public static final RegistryObject<class_1792> CONNECTOR =
      ITEMS.register("road_connector", RoadTool::new);
  public static final RegistryObject<class_1792> RAILBED_CONNECTOR = ITEMS.register("railbed_connector", RailbedTool::new);
  public static final RegistryObject<class_1792> RAMP_CONNECTOR =
      ITEMS.register("ramp_connector", LaneRampTool::new);
  public static final RegistryObject<class_1792> JUNCTION = ITEMS.register("junction_connector", JunctionTool::new);
  public static final RegistryObject<class_1792> ROUNDABOUT = ITEMS.register("roundabout_generator", RoundaboutTool::new);
  public static final RegistryObject<class_1792> INTERCHANGE =
      ITEMS.register("interchange_connector", InterchangeTool::new);
  public static final RegistryObject<class_1792> INTERCHANGE_3 =
      ITEMS.register("interchange_connector_3", () -> new InterchangeTool(3));
  public static final RegistryObject<class_1792> INTERCHANGE_5 =
      ITEMS.register("interchange_connector_5", () -> new InterchangeTool(5));
  public static final RegistryObject<class_1792> INTERCHANGE_6 =
      ITEMS.register("interchange_connector_6", () -> new InterchangeTool(6));
  public static final RegistryObject<class_1792> FRONTAGE = ITEMS.register("frontage_generator",
      () -> new InterchangeTool(2,com.sora.splineroads.core.CorridorPlanner.Kind.FRONTAGE));
  public static final RegistryObject<class_1792> LAYERED = ITEMS.register("layered_connector",
      () -> new InterchangeTool(4,com.sora.splineroads.core.CorridorPlanner.Kind.LAYERED));
  public static final RegistryObject<class_1792> TOLL = ITEMS.register("toll_plaza_generator",TollTool::new);
  public static final RegistryObject<class_1792> TEXT_EDITOR = ITEMS.register("text_editor", SmartTextTool::new);
  public static final RegistryObject<class_1792> GANTRY_CREATOR = ITEMS.register("gantry_creator", GantryCreatorTool::new);
  public static final RegistryObject<class_1792> GANTRY_EDITOR = ITEMS.register("gantry_editor", GantryTool::new);
  public static final RegistryObject<class_1792> SPLITTER=ITEMS.register("road_splitter",RoadSplitTool::new);
  public static final RegistryObject<class_1792> ELEVATED_POINT=ITEMS.register("elevated_access_creator",ElevatedPointTool::new);
  public static final RegistryObject<class_1792> JUNCTION_POINT=ITEMS.register("junction_point_creator",JunctionPointTool::new);
  public static final RegistryObject<class_1792> ATTACHED_POINT=ITEMS.register("endpoint_creator",AttachedPointTool::new);
  public static final RegistryObject<class_1792> LANE_POINT=ITEMS.register("lane_point_tool",LanePointTool::new);
  public static final RegistryObject<class_1792> LANE_LINES=ITEMS.register("lane_line_editor",LaneLineTool::new);
  public static final RegistryObject<class_1792> Y_JUNCTION=ITEMS.register("y_junction_editor",YJunctionTool::new);
  public static final RegistryObject<class_1792> REMOVER =
      ITEMS.register("road_remover", RoadRemover::new);
  public static final RegistryObject<class_1761> TAB =
      TABS.register(
          "roads",
          () ->
              class_1761.method_47307(class_1761.class_7915.field_41049, 0)
                  .method_47321(class_2561.method_43471("itemGroup.splineroads"))
                  .method_47320(() -> new class_1799(CONNECTOR.get()))
                  .method_47317(
                      (p, o) -> {
                        o.method_45421(NODE_ITEM.get());o.method_45421(ROAD_BLOCK_ITEM.get());o.method_45421(ROAD_SLAB_ITEM.get());o.method_45421(JUNCTION_POINT.get());o.method_45421(ATTACHED_POINT.get());o.method_45421(ELEVATED_POINT.get());o.method_45421(SPLITTER.get());o.method_45421(LANE_POINT.get());
                        o.method_45421(CONNECTOR.get());
                        o.method_45421(RAILBED_CONNECTOR.get());
                        o.method_45421(RAMP_CONNECTOR.get());
                        o.method_45421(JUNCTION.get());
                        o.method_45421(ROUNDABOUT.get());
                        o.method_45421(INTERCHANGE_3.get());
                        o.method_45421(INTERCHANGE.get());
                        o.method_45421(INTERCHANGE_5.get());
                        o.method_45421(INTERCHANGE_6.get());
                        o.method_45421(FRONTAGE.get());o.method_45421(TOLL.get());
                        o.method_45421(LAYERED.get());
                        o.method_45421(GANTRY_CREATOR.get());o.method_45421(GANTRY_EDITOR.get());o.method_45421(TEXT_EDITOR.get());o.method_45421(LANE_LINES.get());o.method_45421(Y_JUNCTION.get());
                        o.method_45421(REMOVER.get());
                      })
                  .method_47324());

  public SplineRoads() {
    IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
    BLOCKS.register(bus);
    ITEMS.register(bus);
    ENTITIES.register(bus);
    TABS.register(bus);
    net.minecraftforge.fml.ModLoadingContext.get().registerConfig(
        net.minecraftforge.fml.config.ModConfig.Type.CLIENT, com.sora.splineroads.config.RoadClientConfig.SPEC);
    RoadNetwork.register();
  }
}
