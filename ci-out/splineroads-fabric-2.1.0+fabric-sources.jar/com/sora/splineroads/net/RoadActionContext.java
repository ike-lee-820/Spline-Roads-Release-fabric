package com.sora.splineroads.net;

import com.sora.splineroads.core.RoadEditRequests;
import net.minecraft.class_2487;

/** Correlation fields are transport metadata, never authority for a world edit. */
public final class RoadActionContext {
  public static String target(class_2487 command) {
    if (command.method_25928("Id")) return "road:" + command.method_25926("Id");
    if (command.method_25928("Token")) return "token:" + command.method_25926("Token");
    if (command.method_10545("Pos")) return "node:" + command.method_10537("Pos");
    if (command.method_10545("A") || command.method_10545("B"))
      return "ends:" + command.method_10537("A") + ":" + command.method_10537("B");
    return "";
  }

  public static void attach(class_2487 command, RoadEditRequests.Request request) {
    command.method_25927("ReplyId", request.id());
    command.method_10544("ReplyGeneration", request.generation());
  }

  public static void echo(class_2487 command, class_2487 reply) {
    if (!command.method_25928("ReplyId")) return;
    reply.method_25927("ReplyId", command.method_25926("ReplyId"));
    reply.method_10544("ReplyGeneration", command.method_10537("ReplyGeneration"));
    reply.method_10582("ReplyAction", command.method_10558("Action"));
    reply.method_10582("ReplyTarget", target(command));
  }

  private RoadActionContext() {}
}
