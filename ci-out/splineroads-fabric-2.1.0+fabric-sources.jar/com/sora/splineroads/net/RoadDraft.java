package com.sora.splineroads.net;

import java.util.List;
import java.util.LinkedHashSet;
import java.util.Objects;
import net.minecraft.class_2487;
import net.minecraft.class_2520;

/** Preserve user edits when the server reopens the same target after world preview. */
public final class RoadDraft {
  public static class_2487 merge(class_2487 fresh, class_2487 saved) {
    class_2487 out = baseline(fresh);
    if (saved == null
        || fresh.method_10577("DeleteOnly")
        || saved.method_10577("DeleteOnly")
        || !fresh.method_10558("Kind").equals(saved.method_10558("Kind"))) return out;
    boolean same =
        fresh.method_10558("Kind").equals("node")
            ? fresh.method_10537("Pos") == saved.method_10537("Pos")
            : fresh.method_25928("Id")
                ? saved.method_25928("Id") && fresh.method_25926("Id").equals(saved.method_25926("Id"))
                : !saved.method_25928("Id")
                    && fresh.method_10537("A") == saved.method_10537("A")
                    && fresh.method_10537("B") == saved.method_10537("B");
    if(fresh.method_10558("Kind").equals("armRoad"))same &= fresh.method_10550("Arm")==saved.method_10550("Arm")&&fresh.method_10550("Signature")==saved.method_10550("Signature");
    if(fresh.method_10558("Kind").equals("sideRoad"))same &= fresh.method_10550("Signature")==saved.method_10550("Signature")
        &&Objects.equals(fresh.method_10580("Main"),saved.method_10580("Main"))&&Objects.equals(fresh.method_10580("AttachedPoint"),saved.method_10580("AttachedPoint"))
        &&Objects.equals(fresh.method_10580("Branch"),saved.method_10580("Branch"))&&Objects.equals(fresh.method_10580("MainB"),saved.method_10580("MainB"))
        &&Objects.equals(fresh.method_10580("AttachedPointB"),saved.method_10580("AttachedPointB"))&&fresh.method_10577("MainFirst")==saved.method_10577("MainFirst");
    if (same) {
      for (String key :
          List.of(
              "Settings", "Node", "Advanced", "ExtraPage", "LiftPage", "OptionsPage", "LevelEnds", "ForceJunction", "ForceJunctionA", "ForceJunctionB"))
        if (saved.method_10545(key)) out.method_10566(key, saved.method_10580(key).method_10707());
      if (fresh.method_10558("Kind").equals("road") && fresh.method_10545("Settings")) {
        var base=saved.method_10545("BaseSettings")?saved.method_10562("BaseSettings"):saved.method_10562("Settings");
        var current=fresh.method_10562("Settings");
        try {
          out.method_10566("Settings",reconcileSettings(base,saved.method_10562("Settings"),current));
          out.method_10566("BaseSettings",editableSettings(current));out.method_10551("DraftConflict");
        } catch(IllegalArgumentException conflict) {
          // Keep the unsaved choice and its old baseline. The server will reject
          // conflicting changes until the user resolves them or clears the draft.
          out.method_10566("Settings",mergeSettings(base,saved.method_10562("Settings"),current,"",false));
          out.method_10566("BaseSettings",base.method_10553());out.method_10582("DraftConflict",conflict.getMessage());
        }
      }
    }
    return out;
  }

  /** The baseline is captured before any widget writes; Esc keeps it with the draft. */
  public static class_2487 baseline(class_2487 value) {
    var out=value.method_10553();
    if(out.method_10558("Kind").equals("road")&&out.method_10545("Settings")&&!out.method_10545("BaseSettings"))
      out.method_10566("BaseSettings",editableSettings(out.method_10562("Settings")));
    return out;
  }

  private static class_2487 editableSettings(class_2487 settings) {
    var out=settings.method_10553();
    for(String key:List.of("AttachedRoadPoints","LanePointsV2","LaneLines","HideArrows"))out.method_10551(key);
    var infra=out.method_10562("Infrastructure");for(String key:List.of("GantryEdits","FixedStations","Signs"))infra.method_10551(key);
    return out;
  }

  /** Three-way dirty-field merge, repeated against authoritative settings at save time. */
  public static class_2487 reconcileSettings(class_2487 base,class_2487 edited,class_2487 current) {
    return mergeSettings(base,edited,current,"",true);
  }

  private static boolean toolOwned(String path) {
    return path.equals("Infrastructure.GantryEdits")||path.equals("Infrastructure.FixedStations")
        ||path.equals("AttachedRoadPoints")||path.equals("LanePointsV2")||path.equals("LaneLines")
        ||path.equals("HideArrows")||path.equals("Infrastructure.Signs");
  }

  private static class_2487 mergeSettings(class_2487 base,class_2487 edited,class_2487 current,String parent,boolean strict) {
    var out=new class_2487();var keys=new LinkedHashSet<String>();
    keys.addAll(base.method_10541());keys.addAll(edited.method_10541());keys.addAll(current.method_10541());
    for(String key:keys) {
      String path=parent.isEmpty()?key:parent+"."+key;
      class_2520 before=base.method_10580(key),wanted=edited.method_10580(key),latest=current.method_10580(key),chosen;
      if(toolOwned(path)||Objects.equals(wanted,before))chosen=latest;
      else if(wanted instanceof class_2487 a&&latest instanceof class_2487 b&&(before==null||before instanceof class_2487))
        chosen=mergeSettings(before instanceof class_2487 c?c:new class_2487(),a,b,path,strict);
      else if(Objects.equals(latest,before)||Objects.equals(latest,wanted))chosen=wanted;
      else {
        if(strict)throw new IllegalArgumentException("道路设置已更新（"+path+"）；请重新打开核对，或 Shift＋右键清除旧草稿");
        chosen=wanted;
      }
      if(chosen!=null)out.method_10566(key,chosen.method_10707());
    }
    return out;
  }

  /** Commands never echo road meshes, neighboring structures or preview context. */
  public static class_2487 action(class_2487 draft, boolean node) {
    class_2487 out = new class_2487();
    for (String key :
        node ? List.of("Pos", "Node") : List.of("A", "B", "Id", "Settings", "BaseSettings", "LevelEnds", "ForceJunction", "ForceJunctionA", "ForceJunctionB"))
      if (draft.method_10545(key)) out.method_10566(key, draft.method_10580(key).method_10707());
    out.method_10582("Action", node ? "node" : "connect");
    return out;
  }

  private RoadDraft() {}
}
