package com.sora.splineroads.net;

import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Map snapshots are application pages as well as transport fragments. Fragmenting
 * a single huge NBT does not reduce its decoded allocation budget. */
public final class ManualPlannerPackets {
  private static final int PAGE_WEIGHT=1024*1024, PAGE_ITEMS=32;

  public static List<class_2487> pages(UUID session,UUID snapshot,class_2499 roads,class_2499 nodes) {
    var result=new ArrayList<class_2487>();
    var roadPage=new class_2499();var nodePage=new class_2499();long weight=0;
    for(boolean road:new boolean[]{true,false})for(class_2520 entry:road?roads:nodes) {
      long next=Math.max(0,entry.method_47988())+128L;
      if(!roadPage.isEmpty()||!nodePage.isEmpty()) {
        if(weight+next>PAGE_WEIGHT||roadPage.size()+nodePage.size()>=PAGE_ITEMS) {
          result.add(page(session,snapshot,roadPage,nodePage));roadPage=new class_2499();nodePage=new class_2499();weight=0;
        }
      }
      (road?roadPage:nodePage).add(entry);weight+=next;
    }
    if(!roadPage.isEmpty()||!nodePage.isEmpty()||result.isEmpty())result.add(page(session,snapshot,roadPage,nodePage));
    for(int i=0;i<result.size();i++){result.get(i).method_10569("Page",i);result.get(i).method_10569("Pages",result.size());}
    return result;
  }

  private static class_2487 page(UUID session,UUID snapshot,class_2499 roads,class_2499 nodes) {
    var tag=new class_2487();tag.method_10582("Kind","manualMapPage");tag.method_25927("PlannerSession",session);tag.method_25927("MapSnapshot",snapshot);
    tag.method_10566("MapRoads",roads);tag.method_10566("Nodes",nodes);return tag;
  }
  private ManualPlannerPackets(){}
}
