package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.world.RoadSplitter.Plan;
import java.util.*;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

/** A persistent reversible marker at an exact continuous split, with ordinary-junction semantics. */
public final class JunctionPointTool extends class_1792 {
  public JunctionPointTool(){super(new class_1793().method_7889(1));}
  static UUID source(RoadRecord r){return r.fragment()==null?r.id():r.fragment().source();}
  static void requireDifferent(class_3218 level,class_2338 a,class_2338 b){
    if(level.method_8321(a) instanceof NodeEntity x&&level.method_8321(b) instanceof NodeEntity y&&x.junctionSource!=null&&x.junctionSource.equals(y.junctionSource))throw new IllegalArgumentException("请选择不同道路上的路口点");
  }
  static void requireDifferent(class_3218 level,class_2338 node,RoadRecord host){
    if(level.method_8321(node) instanceof NodeEntity n&&n.junctionSource!=null&&n.junctionSource.equals(source(host)))throw new IllegalArgumentException("路口点和附属点必须位于不同道路");
  }
  static class_2338 create(class_3218 level,class_3222 player,RoadIndex.Built road,V hit){
    if(player!=null&&(!player.method_7294()||player.method_7325()))throw new IllegalArgumentException("没有建设权限");
    if(road==null||!AutoJunctions.ordinary(road.record)||road.record.railway()||road.record.toll()!=null||road.record.settings().style().ramp())throw new IllegalArgumentException("路口点只能创建在独立普通道路上");
    if(player!=null)RoadData.requireOwner(player,road.record.owner());
    var q=RoadQueries.horizontal(road.mesh,hit);if(q.horizontalDistance()>q.sample().halfWidth()+.05)throw new IllegalArgumentException("请选择普通道路路面");
    var plan=RoadSplitter.plan(level,player,road.record,q.sample().distance(),RoadSlicing.Connection.CONTINUOUS,source(road.record));
    RoadSplitter.commit(level,player,plan);return plan.pair().pos();
  }
  @Override public class_1269 method_7884(class_1838 c){
    if(c.method_8045().field_9236)return class_1269.field_5812;
    if(c.method_8036() instanceof class_3222 p)try(var work=RoadWorkChunks.open(p.method_51469())){
      var hit=c.method_17698();create(p.method_51469(),p,RoadTool.pick(p),new V(hit.field_1352,hit.field_1351,hit.field_1350));p.method_7353(class_2561.method_43470("路口点已创建；使用道路连接器连接端点或另一道路的路口点"),false);
    }catch(IllegalArgumentException failure){p.method_7353(class_2561.method_43470(failure.getMessage()),false);}
    return class_1269.field_21466;
  }
}
