package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.nbt.*;

/** Part of the same SavedData as the render/collision records and transaction journal. */
public final class RailbedStore {
  public static final class Entry {
    public final RoadRecord road;public final List<RailbedPath.Path> paths;public final double width;public final Structure mode;public final RailbedOptions options;
    public final Long2ObjectOpenHashMap<class_2680> original=new Long2ObjectOpenHashMap<>(),written=new Long2ObjectOpenHashMap<>();
    public Entry(RoadRecord road,List<RailbedPath.Path> paths,double width,Structure mode){this(road,paths,width,mode,RailbedOptions.DEFAULT);}
    public Entry(RoadRecord road,List<RailbedPath.Path> paths,double width,Structure mode,RailbedOptions options){this.road=road;this.paths=List.copyOf(paths);this.width=width;this.mode=mode;this.options=options;}
    public String identity(){return identity(paths);}
    public static String identity(List<RailbedPath.Path> paths){return paths.stream().map(p->p.segments().stream().map(RailbedPath.Segment::id).sorted().toList().toString()).sorted().toList().toString();}
    class_2487 save(){var t=new class_2487();t.method_10566("Road",road.save());var rails=new class_2499();paths.forEach(p->rails.add(RailbedCodec.write(p)));t.method_10566("Paths",rails);t.method_10549("Width",width);t.method_10582("Mode",mode.name());t.method_10566("Options",RailbedCodec.options(options));t.method_10566("Original",RoadBlockStorage.write(original));t.method_10566("Written",RoadBlockStorage.write(written));return t;}
    static Entry load(class_2487 t){var e=new Entry(RoadRecord.load(t.method_10562("Road")),t.method_10554("Paths",class_2520.field_33260).stream().map(v->RailbedCodec.read((class_2487)v)).toList(),t.method_10574("Width"),Structure.valueOf(t.method_10558("Mode")),RailbedCodec.options(t.method_10562("Options")));RoadBlockStorage.read(t.method_10554("Original",class_2520.field_33260),e.original);RoadBlockStorage.read(t.method_10554("Written",class_2520.field_33260),e.written);if(!e.original.keySet().equals(e.written.keySet()))throw new IllegalStateException("铁路恢复清单不完整");return e;}
  }
  public static final class Pending {
    final UUID id;final Entry old,next;final Long2ObjectOpenHashMap<class_2680> before,after;
    Pending(UUID id,Entry old,Entry next,Long2ObjectOpenHashMap<class_2680> before,Long2ObjectOpenHashMap<class_2680> after){this.id=id;this.old=old;this.next=next;this.before=before;this.after=after;}
    class_2487 save(){var t=new class_2487();t.method_25927("Id",id);if(old!=null)t.method_10566("Old",old.save());if(next!=null)t.method_10566("Next",next.save());t.method_10566("Before",RoadBlockStorage.write(before));t.method_10566("After",RoadBlockStorage.write(after));return t;}
    static Pending load(class_2487 t){var before=new Long2ObjectOpenHashMap<class_2680>();var after=new Long2ObjectOpenHashMap<class_2680>();RoadBlockStorage.read(t.method_10554("Before",class_2520.field_33260),before);RoadBlockStorage.read(t.method_10554("After",class_2520.field_33260),after);if(!before.keySet().equals(after.keySet()))throw new IllegalStateException("铁路事务日志不完整");return new Pending(t.method_25926("Id"),t.method_10545("Old")?Entry.load(t.method_10562("Old")):null,t.method_10545("Next")?Entry.load(t.method_10562("Next")):null,before,after);}
  }
  public final Map<UUID,Entry> entries=new LinkedHashMap<>();
  final Map<UUID,Pending> pending=new LinkedHashMap<>();
  class_2487 save(){var out=new class_2487();out.method_10569("Version",2);var values=new class_2499();entries.values().forEach(e->values.add(e.save()));out.method_10566("Entries",values);var journal=new class_2499();pending.values().forEach(p->journal.add(p.save()));out.method_10566("Pending",journal);return out;}
  void load(class_2487 tag){if(tag.method_10550("Version")>2)throw new IllegalStateException("铁路存档版本过新");for(class_2520 raw:tag.method_10554("Entries",class_2520.field_33260)){var e=Entry.load((class_2487)raw);entries.put(e.road.id(),e);}for(class_2520 raw:tag.method_10554("Pending",class_2520.field_33260)){var p=Pending.load((class_2487)raw);pending.put(p.id,p);}}
}
