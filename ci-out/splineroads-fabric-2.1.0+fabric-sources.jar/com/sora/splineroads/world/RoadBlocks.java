package com.sora.splineroads.world;

import com.sora.splineroads.core.RoadRaster.Box;
import com.sora.splineroads.core.RoadRaster.Cell;
import com.sora.splineroads.core.RoadStructures.Part;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.world.RoadIndex.Built.Column;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3619;
import net.minecraft.class_3726;
import net.minecraft.class_3727;
import net.minecraft.world.level.block.*;
import net.minecraft.world.phys.shapes.*;

public final class RoadBlocks {
  public static boolean isCollider(class_2680 state){return state.method_26204() instanceof Road;}
  public static boolean canInfill(class_1937 level,class_2338 p,class_2680 fill) {
    class_2680 existing=level.method_8320(p);RoadIndex i=index(level);
    if(!isCollider(existing)||existing.method_27852(com.sora.splineroads.SplineRoads.FILLED_COLLIDER.get())
        ||existing.method_11654(Road.FILL)!=Fill.NONE||i==null||fill.method_31709()||TunnelAir.isAirSpace(fill)
        ||!class_2248.method_9614(fill.method_26220(level,p)))return false;
    if(gantryCell(i,p))return class_259.method_1074(class_259.method_1077(),i.shape(p),class_247.field_16886);
    var nearby=i.inChunk(new net.minecraft.class_1923(p).method_8324()).stream().map(i.roads::get).filter(java.util.Objects::nonNull).toList();
    if(GroundTerrainJoin.usable(GroundTerrainJoin.cap(p,fill,nearby)))return true;
    if(TunnelTerrainSpace.safe(p,nearby)||TunnelTerrainSpace.exteriorInfill(p,nearby))return class_259.method_1074(class_259.method_1077(),i.shape(p),class_247.field_16886);
    boolean deck=false;
    for(var id:i.at(p.method_10063())){
      var road=i.roads.get(id);var c=road.column(p);
      if(c!=null){deck=true;if(p.method_10264()+1>c.minTop()+1e-7)return false;}
      else if(level.field_9236){
        // Client indices rasterize lazily and do not maintain server column maps.
        var boxes=new com.sora.splineroads.core.RoadRaster.Local(road.mesh,java.util.List.of()).boxes(new com.sora.splineroads.core.RoadRaster.Cell(p.method_10263(),p.method_10264(),p.method_10260()));
        for(var box:boxes){deck=true;if(1>box.y0()+road.record.settings().thickness()+1e-7)return false;}
      }
    }
    boolean walkway=false;
    if(!deck)for(var id:i.at(p.method_10063())){
      var road=i.roads.get(id);
      for(var part:road.record.structures())if(part.material().name().startsWith("WALK_")){
        var boxes=com.sora.splineroads.core.RoadRaster.structures(java.util.List.of(part),new com.sora.splineroads.core.RoadRaster.Cell(p.method_10263(),p.method_10264(),p.method_10260()));
        if(!boxes.isEmpty()&&boxes.values().stream().flatMap(java.util.List::stream).anyMatch(b->b.y1()>=1-1e-7))walkway=true;
      }
    }
    return (deck||walkway)&&class_259.method_1074(class_259.method_1077(),i.shape(p),class_247.field_16886);
  }
  static boolean gantryCell(RoadIndex index,class_2338 p){
    var cell=new com.sora.splineroads.core.RoadRaster.Cell(p.method_10263(),p.method_10264(),p.method_10260());
    for(var id:index.at(p.method_10063()))if(gantryCell(index.roads.get(id),cell))return true;
    return false;
  }
  static boolean gantryCell(RoadIndex.Built road,com.sora.splineroads.core.RoadRaster.Cell cell){
    var parts=road.record.structures().stream().filter(part->part.material()==com.sora.splineroads.core.RoadStructures.Material.GANTRY_FRAME).toList();
    return !parts.isEmpty()&&!com.sora.splineroads.core.RoadRaster.structures(parts,cell).isEmpty();
  }
  public static Function<class_1937, RoadIndex> clientIndex = l -> null;

  public static RoadIndex index(class_1922 world) {
    if (world instanceof net.minecraft.class_3218 server)
      return RoadData.get(server).index;
    return world instanceof class_1937 level ? clientIndex.apply(level) : null;
  }

  public enum Fill implements net.minecraft.class_3542 {
    NONE,
    GRASS_BLOCK,
    DIRT,
    STONE,
    SAND,
    GRAVEL,
    DEEPSLATE,
    COARSE_DIRT,
    PODZOL,
    ANDESITE,
    DIORITE,
    GRANITE,
    STONE_SLAB,
    SMOOTH_STONE_SLAB,
    STONE_BRICK_SLAB,
    COBBLESTONE_SLAB,
    BRICK_SLAB,
    QUARTZ_SLAB,
    OAK_SLAB,
    SPRUCE_SLAB,
    STONE_BRICKS,
    BRICKS;

    public double top() {
      return name().endsWith("_SLAB") ? .5 : 1;
    }

    public String method_15434() {
      return name().toLowerCase(java.util.Locale.ROOT);
    }

    public class_2680 state() {
      return this == NONE
          ? class_2246.field_10124.method_9564()
          : net.minecraft.class_7923.field_41175
              .method_10223(
                  new net.minecraft.class_2960(
                      "minecraft", method_15434()))
              .method_9564();
    }

    public static Fill of(class_2680 state) {
      for (var f : values()) if (f != NONE && state.equals(f.state())) return f;
      return NONE;
    }
  }

  public static class Road extends class_2248 implements net.minecraft.class_2402 {
    public static final net.minecraft.class_2746 WATERLOGGED =
        net.minecraft.class_2741.field_12508;
    public static final net.minecraft.class_2746 PERMEABLE =
        net.minecraft.class_2746.method_11825("water_permeable");
    @Override public boolean method_10310(class_1922 w,class_2338 p,class_2680 s,net.minecraft.class_3611 f){
      // PERMEABLE is set only for exterior/open structure cells. SEALED controls
      // shell light blocking; using it as a blanket water ban drained the exterior.
      return s.method_11654(PERMEABLE)&&!s.method_11654(WATERLOGGED)&&f==net.minecraft.class_3612.field_15910;
    }
    @Override public boolean method_10311(net.minecraft.class_1936 w,class_2338 p,class_2680 s,net.minecraft.class_3610 f){
      if(!method_10310(w,p,s,f.method_15772()))return false;
      if(!w.method_8608()){w.method_8652(p,s.method_11657(WATERLOGGED,true),3);w.method_39281(p,net.minecraft.class_3612.field_15910,net.minecraft.class_3612.field_15910.method_15789(w));}
      return true;
    }
    @Override public net.minecraft.class_3610 method_9545(class_2680 s){
      return s.method_11654(WATERLOGGED)?net.minecraft.class_3612.field_15910.method_15729(false):super.method_9545(s);
    }
    @Override public class_2680 method_9559(class_2680 s,net.minecraft.class_2350 direction,class_2680 neighbour,net.minecraft.class_1936 w,class_2338 p,class_2338 other){
      if(s.method_11654(WATERLOGGED))w.method_39281(p,net.minecraft.class_3612.field_15910,net.minecraft.class_3612.field_15910.method_15789(w));
      return super.method_9559(s,direction,neighbour,w,p,other);
    }
    public static final net.minecraft.class_2746 SEALED =
        net.minecraft.class_2746.method_11825("sealed");
    public static final net.minecraft.class_2746 LIT =
        net.minecraft.class_2746.method_11825("lit");
    public static final net.minecraft.class_2754<Fill> FILL =
        net.minecraft.class_2754.method_11850("fill", Fill.class);

    public Road() {
      super(
          class_2251.method_9637()
              .method_9629(-1, 3600000)
              .method_9624()
              .method_51369() // Dynamic shapes have no cached solid flag; rain heightmaps still need one.
              .method_22488()
              .method_9631(state -> state.method_11654(LIT) ? 15 : 0)
              .method_26245((s, w, p) -> false)
              .method_26243((s, w, p) -> false)
              .method_50012(class_3619.field_15972));
      method_9590(field_10647.method_11664().method_11657(FILL, Fill.NONE).method_11657(LIT, false).method_11657(SEALED,false).method_11657(WATERLOGGED,false).method_11657(PERMEABLE,false));
    }

    @Override
    protected void method_9515(
        net.minecraft.class_2689.class_2690<class_2248, class_2680> b) {
      b.method_11667(FILL, LIT, SEALED, WATERLOGGED, PERMEABLE);
    }

    @Override
    public float method_9594(class_2680 s, class_1657 player, class_1922 w, class_2338 p) {
      return s.method_11654(FILL) == Fill.NONE
          ? 0
          : s.method_11654(FILL).state().method_26165(player, w, p);
    }

    @Override
    public class_2464 method_9604(class_2680 s) {
      return class_2464.field_11458; // Empty unless the client terrain model supplies this cell.
    }

    @Override
    public class_265 method_9549(
        class_2680 s, class_1922 w, class_2338 p, class_3726 c) {
      // Preserved full terrain already determines the complete collision cell.
      if (s.method_11654(FILL) != Fill.NONE) {
        class_265 fill = s.method_11654(FILL).state().method_26194(w,p,c);
        if (class_2248.method_9614(fill)) return class_259.method_1077();
      }
      RoadIndex i = index(w);
      class_265 road = i == null ? class_259.method_1077() : SidewalkBlockContact.collision(w,p,i,i.shape(p));
      // A retained proxy with no current geometry is empty, not an invisible cube.
      if (s.method_11654(FILL) == Fill.NONE) return road;
      class_265 fill = s.method_11654(FILL).state().method_26194(w, p, c);
      return class_2248.method_9614(fill) ? class_259.method_1077() : class_259.method_1082(fill, road,class_247.field_1366);
    }

    @Override
    public class_265 method_9530(class_2680 s, class_1922 w, class_2338 p, class_3726 c) {
      return method_9549(s, w, p, c);
    }

    @Override
    public class_265 method_9571(class_2680 s, class_1922 w, class_2338 p) {
      return class_259.method_1073();
    }

    @Override
    public class_265 method_26159(class_2680 s, class_1922 w, class_2338 p, class_3726 c) {
      return class_259.method_1073();
    }

    @Override
    public boolean method_9579(class_2680 s, class_1922 w, class_2338 p) {
      return !s.method_11654(SEALED);
    }

    @Override public int method_9505(class_2680 s,class_1922 w,class_2338 p){return s.method_11654(SEALED)?15:0;}
  }

  public static class FilledRoad extends Road implements class_2343 {
    @Override public class_2586 method_10123(class_2338 p,class_2680 s){return new RoadFillEntity(p,s);}
    @Override public class_2464 method_9604(class_2680 s){return class_2464.field_11458;}
    @Override public class_265 method_9549(class_2680 s,class_1922 w,class_2338 p,class_3726 c){
      class_265 road=super.method_9549(s,w,p,c);
      return w.method_8321(p) instanceof RoadFillEntity entity?entity.collision(w,p,c,road):road;
    }
    @Override public float method_9594(class_2680 s,class_1657 player,class_1922 w,class_2338 p){
      return w.method_8321(p) instanceof RoadFillEntity fill?fill.fill().method_26165(player,w,p):0;
    }
  }

  public static class Node extends class_2237 {
    private static final class_265 MARKER = class_2248.method_9541(3, 0, 3, 13, 2, 13);

    public Node() {
      super(
          class_2251.method_9637()
              .method_9632(1.5f)
              .method_9624()
              .method_22488()
              .method_26243((s, w, p) -> false)
              .method_50012(class_3619.field_15972));
    }

    @Override
    public class_2586 method_10123(class_2338 p, class_2680 s) {
      return new NodeEntity(p, s);
    }

    @Override
    public class_2464 method_9604(class_2680 s) {
      return class_2464.field_11458; // Marker visibility remains controlled by NodeRenderer.
    }

    @Override
    public class_265 method_9530(class_2680 s, class_1922 w, class_2338 p, class_3726 c) {
      boolean holding =
          c instanceof class_3727 entity
              && entity.method_32480() instanceof class_1309 who
              && (RoadTool.showsNodes(who.method_6047())
                  || RoadTool.showsNodes(who.method_6079()));
      return holding ? class_259.method_1084(MARKER, method_9549(s, w, p, c)) : class_259.method_1073();
    }

    @Override
    public class_265 method_9549(
        class_2680 s, class_1922 w, class_2338 p, class_3726 c) {
      RoadIndex i = index(w);
      return i == null ? class_259.method_1073() : i.shape(p);
    }

    @Override
    public void method_9567(class_1937 w, class_2338 p, class_2680 s, class_1309 who, class_1799 stack) {
      if (w.method_8321(p) instanceof NodeEntity n) {
        n.owner = who == null ? null : who.method_5667();
        n.yaw = who == null ? 0 : who.method_36454();
        n.method_5431();
        w.method_8413(p, s, s, 3);
      }
    }

    @Override
    public float method_9594(class_2680 s, class_1657 player, class_1922 w, class_2338 p) {
      RoadIndex i = index(w);
      if (i != null
          && i.roads.values().stream()
              .anyMatch(r -> r.record.a().equals(p) || r.record.b().equals(p))) return 0;
      return super.method_9594(s, player, w, p);
    }
  }

  private RoadBlocks() {}
}
