package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.StreetPlan.*;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Strict bounded wire/save format. Client geometry is never accepted as construction input. */
public final class StreetPlanCodec {
  public static class_2487 write(Input input){
    var t=new class_2487();t.method_10569("Version",StreetPlan.VERSION);t.method_10564("Area",input.selection().stream().mapToLong(Cell::key).toArray());t.method_10564("Protect",input.protection().stream().mapToLong(Cell::key).toArray());
    t.method_10564("Corridor",input.corridor().stream().mapToLong(Cell::key).toArray());t.method_10556("CorridorConfirmed",input.corridorConfirmed());
    var centers=new class_2499();input.centers().forEach(p->centers.add(point(p)));t.method_10566("Centers",centers);
    var entries=new class_2499();for(var e:input.entries()){var tag=point(e.point());tag.method_10549("Y",e.height());tag.method_10549("Yaw",e.yaw());tag.method_10556("Left",e.left());tag.method_10556("Existing",e.existing());tag.method_10582("Reference",e.reference());entries.add(tag);}t.method_10566("Entries",entries);
    var o=input.options();var v=new class_2487();v.method_10582("Style",o.style().name());v.method_10549("Density",o.density());v.method_10549("BlockSize",o.blockSize());v.method_10549("Direction",o.direction());v.method_10544("Seed",o.seed());
    v.method_10549("PrimaryWidth",o.primaryWidth());v.method_10549("SecondaryWidth",o.secondaryWidth());v.method_10549("LocalWidth",o.localWidth());v.method_10582("PrimarySection",o.primarySection().name());v.method_10582("SecondarySection",o.secondarySection().name());v.method_10582("LocalSection",o.localSection().name());v.method_10556("Left",o.left());v.method_10556("Sidewalks",o.sidewalks());v.method_10556("Lighting",o.lighting());v.method_10549("Earthwork",o.earthwork());t.method_10566("Options",v);return t;
  }
  public static Input read(class_2487 t){
    if(t.method_10550("Version")!=StreetPlan.VERSION)throw new IllegalArgumentException("路网草案版本不同，请重新规划");
    long[] area=t.method_10565("Area"),protect=t.method_10565("Protect");var centers=t.method_10554("Centers",class_2520.field_33260);var entries=t.method_10554("Entries",class_2520.field_33260);
    if(area.length>StreetPlan.MAX_CHUNKS||protect.length>StreetPlan.MAX_CHUNKS||centers.size()>StreetPlan.MAX_CENTERS||entries.size()>StreetPlan.MAX_ENTRIES)throw new IllegalArgumentException("路网参数数量超限");
    var selection=new HashSet<Cell>();for(long p:area)selection.add(Cell.from(p));var protection=new HashSet<Cell>();for(long p:protect)protection.add(Cell.from(p));
    var locations=new ArrayList<Point>();for(class_2520 tag:centers)locations.add(point((class_2487)tag));var interfaces=new ArrayList<Entry>();for(class_2520 tag:entries){var e=(class_2487)tag;interfaces.add(new Entry(point(e),e.method_10574("Y"),e.method_10574("Yaw"),e.method_10577("Left"),e.method_10577("Existing"),e.method_10558("Reference")));}
    var v=t.method_10562("Options");var options=new Options(Style.valueOf(v.method_10558("Style")),v.method_10574("Density"),v.method_10574("BlockSize"),v.method_10574("Direction"),v.method_10537("Seed"),v.method_10574("PrimaryWidth"),v.method_10574("SecondaryWidth"),v.method_10574("LocalWidth"),RoadGeometry.Style.valueOf(v.method_10558("PrimarySection")),RoadGeometry.Style.valueOf(v.method_10558("SecondarySection")),RoadGeometry.Style.valueOf(v.method_10558("LocalSection")),v.method_10577("Left"),v.method_10577("Sidewalks"),v.method_10577("Lighting"),v.method_10574("Earthwork"));
    var corridor=new HashSet<Cell>();long[] extra=t.method_10565("Corridor");if(extra.length>StreetPlan.MAX_CHUNKS)throw new IllegalArgumentException("走廊数量超限");for(long key:extra)corridor.add(Cell.from(key));
    return new Input(selection,protection,locations,interfaces,options,corridor,t.method_10577("CorridorConfirmed"));
  }
  public static class_2487 write(StreetTerrain terrain){
    var result=new class_2487();var chunks=new class_2499();for(var e:terrain.chunks().entrySet()){var t=new class_2487();t.method_10544("Cell",e.getKey().key());t.method_10539("Height",e.getValue().heights());t.method_10570("Ground",e.getValue().ground());t.method_10564("Fingerprint",e.getValue().fingerprints());chunks.add(t);}result.method_10566("Chunks",chunks);return result;
  }
  public static StreetTerrain terrain(class_2487 tag){
    var source=tag.method_10554("Chunks",class_2520.field_33260);if(source.size()>StreetPlan.MAX_CHUNKS)throw new IllegalArgumentException("地形快照过大");var chunks=new HashMap<Cell,StreetTerrain.Chunk>();
    for(class_2520 item:source){var t=(class_2487)item;var key=Cell.from(t.method_10537("Cell"));if(chunks.put(key,new StreetTerrain.Chunk(t.method_10561("Height"),t.method_10547("Ground"),t.method_10565("Fingerprint")))!=null)throw new IllegalArgumentException("地形快照区块重复");}return new StreetTerrain(chunks);
  }
  private static class_2487 point(Point p){var t=new class_2487();t.method_10549("X",p.x());t.method_10549("Z",p.z());return t;}
  private static Point point(class_2487 t){return new Point(t.method_10574("X"),t.method_10574("Z"));}
  private StreetPlanCodec(){}
}
