package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LaneSections.Live;
import com.sora.splineroads.core.RoadGantry.Station;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.world.item.*;

public class GantryTool extends class_1792 {
  public GantryTool(){super(new class_1793().method_7889(1));}
  public static int signature(RoadRecord r){return Objects.hash(r.start(),r.end(),r.settings(),r.structures());}
  @Override public class_1269 method_7884(class_1838 context){
    if(context.method_8045().field_9236)return class_1269.field_5812;
    if(!(context.method_8036() instanceof class_3222 player))return class_1269.field_5811;
    try{
      var data=RoadData.get(player.method_51469());var hit=context.method_17698();
      V point=new V(hit.field_1352,hit.field_1351,hit.field_1350);RoadIndex.Built chosen=null;int slot=-1;double best=Double.POSITIVE_INFINITY;
      for(var id:data.index.at(context.method_8037().method_10063())){
        var built=data.index.roads.get(id);if(built.record.junction()!=null||built.record.toll()!=null)continue;
        for(int i:RoadGantry.slots(built.mesh)){
          var station=RoadGantry.station(built.mesh,i);var sample=station.sample();
          V forward=sample.left().left().mul(-1);
          double score=Math.abs(point.sub(sample.center()).dot(forward))+Math.abs(point.y()-sample.center().y())*.01;
          if(score<best){best=score;chosen=built;slot=i;}
        }
      }
      if(chosen==null)throw new IllegalArgumentException("请右键龙门架，或右键其下方道路选择最近的一架");
      RoadData.requireOwner(player,chosen.record.owner());
      if(!player.method_7294()||player.method_7325())throw new IllegalArgumentException("没有建设权限");
      var t=new class_2487();t.method_10582("Kind","gantry");t.method_25927("Id",chosen.record.id());t.method_10569("Slot",slot);
      t.method_10569("Count",RoadGantry.slots(chosen.mesh).size());t.method_10569("Signature",signature(chosen.record));
      t.method_10549("MaxOffset",RoadGantry.maxOffset(chosen.mesh,slot));
      var at=RoadGantry.station(chosen.mesh,slot);var look=player.method_5720();
      t.method_10569("PlayerFlow",RoadGantry.playerFlow(at.sample(),new V(look.field_1352,look.field_1351,look.field_1350)));
      var lanes=LaneSections.live(chosen.mesh,at.distance());t.method_10556("TwoWay",lanes.count(1)>0&&lanes.count(-1)>0);
      t.method_10566("Settings",RoadRecord.writeSettings(chosen.record.settings()));
      t.method_10556("SignUpdating",data.smartSigns.pending());
      t.method_10566("ForwardSign",SmartSignCodec.write(data.smartSigns.peek(new SmartSigns.Key(chosen.record.id(),slot,1))));
      t.method_10566("ReverseSign",SmartSignCodec.write(data.smartSigns.peek(new SmartSigns.Key(chosen.record.id(),slot,-1))));RoadNetwork.open(player,t);
    }catch(IllegalArgumentException e){player.method_7353(class_2561.method_43470(e.getMessage()),false);}
    return class_1269.field_21466;
  }
  @Override public void method_7851(class_1799 s,class_1937 level,List<class_2561> lines,class_1836 flag){
    lines.add(class_2561.method_43471("tooltip.splineroads.gantry_editor"));
  }
}
