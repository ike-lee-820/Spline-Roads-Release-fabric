package com.sora.splineroads.world;

import ;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

public final class JunctionTool extends class_1792 {
  public JunctionTool(){super(new class_1793().method_7889(1));}
  @Override public class_1269 method_7884(class_1838 context) {
    if(context.method_8045().field_9236)return class_1269.field_5812;
    if(!(context.method_8036() instanceof class_3222 player))return class_1269.field_5811;
    try {
      class_2338 p=RoadTool.endpointAtHit(context);
      if(player.method_51469().method_8321(p) instanceof NodeEntity) {
        RoadData.requireNode(player.method_51469(),p,player);var tag=context.method_8041().method_7948();
        if(tag.method_10565("Points").length==0){
          var data=RoadData.get(player.method_51469());
          for(var entry:data.junctions.entrySet()){var saved=entry.getValue();var points=saved.method_10565("Points");
            if(saved.method_10545("CenterPos")&&saved.method_10537("CenterPos")==p.method_10063()||points.length>0&&points[0]==p.method_10063()){
              RoadNetwork.open(player,Junctions.payload(player.method_51469(),player,new long[0],entry.getKey()));return class_1269.field_21466;
            }
          }
        }
        String dim=player.method_37908().method_27983().method_29177().toString();long[] old=dim.equals(tag.method_10558("Dimension"))?tag.method_10565("Points"):new long[0];
        if(old.length>=7)throw new IllegalArgumentException("已选中心和 6 个接入口；右键空气打开设置，Shift＋右键空气重新选点");
        for(long point:old)if(point==p.method_10063())throw new IllegalArgumentException("此点已选；右键空气打开设置");
        long[] next=Arrays.copyOf(old,old.length+1);next[old.length]=p.method_10063();tag.method_10564("Points",next);tag.method_10582("Dimension",dim);
        player.method_7353(class_2561.method_43470(old.length==0?"中心已选；继续选择 3–6 个道路接入口":("已选 "+old.length+" 个接入口；"+(old.length>=3?"右键空气打开设置，或继续选点":"至少需要 3 个接入口"))),true);
      } else open(player,context.method_8041());
    } catch(IllegalArgumentException e){player.method_7353(class_2561.method_43470(e.getMessage()),false);}
    return class_1269.field_21466;
  }
  private void open(class_3222 p,class_1799 stack) {
    var hit=RoadTool.pick(p);
    if(hit!=null&&hit.record.junction()!=null){RoadNetwork.open(p,Junctions.selectedPayload(p.method_51469(),p,hit.record));return;}
    if(hit!=null&&hit.record.assembly()!=null){var saved=RoadData.get(p.method_51469()).interchanges.get(hit.record.assembly());if(saved!=null&&saved.method_10577("YJunction")){RoadNetwork.open(p,YJunctionTool.payload(p.method_51469(),p,saved.method_10565("Points"),hit.record.assembly()));return;}}
    var t=stack.method_7948();if(!p.method_37908().method_27983().method_29177().toString().equals(t.method_10558("Dimension")))throw new IllegalArgumentException("先选中心，再选 3–6 个接入口");
    RoadNetwork.open(p,Junctions.payload(p.method_51469(),p,t.method_10565("Points"),null));
  }
  @Override public class_1271<class_1799> method_7836(class_1937 level,class_1657 who,class_1268 hand) {
    class_1799 stack=who.method_5998(hand);
    if(!level.field_9236&&who instanceof class_3222 p)try {
      if(who.method_5715()){stack.method_7948().method_10551("Points");var t=new class_2487();t.method_10582("Kind","junctionReset");RoadNetwork.open(p,t);}
      else open(p,stack);
    }catch(IllegalArgumentException e){who.method_7353(class_2561.method_43470(e.getMessage()),false);}
    return class_1271.method_29237(stack,level.field_9236);
  }
  @Override public void method_7851(class_1799 s,class_1937 l,List<class_2561> lines,class_1836 f){lines.add(class_2561.method_43470("中心端点 → 3–6 个接入口 → 右键空气设置"));lines.add(class_2561.method_43470("右键编辑普通路口、环岛或 Y 字路口；Shift＋右键空气清除选点"));}
}
