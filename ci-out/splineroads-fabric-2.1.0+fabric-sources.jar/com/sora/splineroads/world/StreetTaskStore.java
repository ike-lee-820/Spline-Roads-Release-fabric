package com.sora.splineroads.world;

import ;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.StreetPlan.*;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.nbt.*;

/** Plans and undo obligations belong to their dimension, not to a transient screen. */
public final class StreetTaskStore extends class_18 {
  enum State { READING,READY,BUILDING,PAUSED,CANCELLED,COMPLETE,UNDOING,UNDONE,CONFLICT,FAILED }
  static final class Task {
    final UUID id,owner;Input input;StreetTerrain terrain=new StreetTerrain(Map.of());
    State state=State.READING;String message="正在读取地形";int progress,readChunks,undoCursor=-1,conflicts;
    long peakUnitMicros,totalUnitMicros;final long created;long updated;
    long verifiedRevision=Long.MIN_VALUE;boolean undoIntent;
    List<RoadRecord> roads=List.of();List<class_2487> centers=List.of();final List<StreetJournal> journals=new ArrayList<>();
    final Map<Long,Long> fingerprints=new it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap();final Map<UUID,class_2487> dependencies=new HashMap<>();
    Task(UUID id,UUID owner,Input input){this(id,owner,input,System.currentTimeMillis());}
    Task(UUID id,UUID owner,Input input,long created){this.id=id;this.owner=owner;this.input=input;this.created=created;updated=created;}
    int cells(){return journals.stream().mapToInt(j->j.before.blocks.size()).sum();}
    class_2487 save(){
      var t=new class_2487();t.method_25927("Id",id);t.method_25927("Owner",owner);t.method_10566("Input",StreetPlanCodec.write(input));t.method_10566("Terrain",StreetPlanCodec.write(terrain));t.method_10582("State",state.name());t.method_10582("Message",message);t.method_10569("Progress",progress);t.method_10569("ReadChunks",readChunks);t.method_10569("UndoCursor",undoCursor);t.method_10556("UndoIntent",undoIntent);t.method_10569("Conflicts",conflicts);t.method_10544("Created",created);t.method_10544("Updated",updated);t.method_10544("PeakUnitMicros",peakUnitMicros);t.method_10544("TotalUnitMicros",totalUnitMicros);
      var r=new class_2499();roads.forEach(v->r.add(v.save()));t.method_10566("Roads",r);var c=new class_2499();centers.forEach(v->c.add(v.method_10553()));t.method_10566("Centers",c);var j=new class_2499();journals.forEach(v->j.add(v.save()));t.method_10566("Journals",j);
      var keys=new long[fingerprints.size()*2];int i=0;for(var e:fingerprints.entrySet()){keys[i++]=e.getKey();keys[i++]=e.getValue();}t.method_10564("Fingerprints",keys);
      var deps=new class_2499();dependencies.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e->{var v=new class_2487();v.method_25927("Id",e.getKey());v.method_10566("Road",e.getValue().method_10553());deps.add(v);});t.method_10566("Dependencies",deps);return t;
    }
    static Task load(class_2487 t){
      var task=new Task(t.method_25926("Id"),t.method_25926("Owner"),StreetPlanCodec.read(t.method_10562("Input")),t.method_10537("Created"));task.terrain=StreetPlanCodec.terrain(t.method_10562("Terrain"));task.state=State.valueOf(t.method_10558("State"));task.message=t.method_10558("Message");task.progress=t.method_10550("Progress");task.readChunks=t.method_10550("ReadChunks");task.undoCursor=t.method_10550("UndoCursor");task.undoIntent=t.method_10577("UndoIntent")||task.state==State.UNDOING;task.conflicts=t.method_10550("Conflicts");task.updated=t.method_10537("Updated");task.peakUnitMicros=t.method_10537("PeakUnitMicros");task.totalUnitMicros=t.method_10537("TotalUnitMicros");
      task.roads=t.method_10554("Roads",class_2520.field_33260).stream().map(v->RoadRecord.load((class_2487)v)).toList();task.centers=t.method_10554("Centers",class_2520.field_33260).stream().map(v->((class_2487)v).method_10553()).toList();
      for(class_2520 v:t.method_10554("Journals",class_2520.field_33260))task.journals.add(StreetJournal.load((class_2487)v));var keys=t.method_10565("Fingerprints");if(keys.length%2!=0)throw new IllegalStateException("路网地形校验记录损坏");for(int i=0;i<keys.length;i+=2)task.fingerprints.put(keys[i],keys[i+1]);for(class_2520 v:t.method_10554("Dependencies",class_2520.field_33260)){var d=(class_2487)v;task.dependencies.put(d.method_25926("Id"),d.method_10562("Road").method_10553());}
      if(task.roads.size()>StreetPlan.MAX_EDGES||task.progress<0||task.progress>task.roads.size()||task.journals.size()>StreetPlan.MAX_EDGES)throw new IllegalStateException("路网任务进度损坏，已停止恢复");
      if(task.state==State.BUILDING||task.state==State.READING||task.state==State.UNDOING){task.state=State.PAUSED;task.message="服务器已重载；任务暂停，已完成部分保留，可继续或撤销";}
      return task;
    }
  }
  final Map<UUID,Task> tasks=new LinkedHashMap<>();
  public static StreetTaskStore get(class_3218 level){return level.method_17983().method_17924(StreetTaskStore::load,StreetTaskStore::new,"splineroads_street_tasks");}
  public static StreetTaskStore load(class_2487 t){if(t.method_10550("Version")!=1)throw new IllegalStateException("路网任务存档版本不受支持");var store=new StreetTaskStore();for(class_2520 v:t.method_10554("Tasks",class_2520.field_33260)){var task=Task.load((class_2487)v);store.tasks.put(task.id,task);}store.method_80();return store;}
  @Override public class_2487 method_75(class_2487 t){t.method_10569("Version",1);var tasksTag=new class_2499();tasks.values().forEach(task->tasksTag.add(task.save()));t.method_10566("Tasks",tasksTag);return t;}
  void changed(Task t){t.updated=System.currentTimeMillis();method_80();}
}
