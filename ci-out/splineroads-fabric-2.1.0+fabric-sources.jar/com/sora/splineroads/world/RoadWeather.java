package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import java.util.EnumSet;
import net.minecraft.class_2791;
import net.minecraft.class_2826;
import net.minecraft.class_2902;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Refresh old saved precipitation heights after dynamic road blocks became solid. */
@Mod.EventBusSubscriber(modid=SplineRoads.ID)
public final class RoadWeather {
  @SubscribeEvent public static void loaded(ChunkEvent.Load event){refresh(event.getChunk());}
  public static boolean refresh(class_2791 chunk){
    boolean road=false;
    for(var section:chunk.method_12006())if(section.method_19523(RoadBlocks::isCollider)){road=true;break;}
    if(!road)return false;
    class_2902.method_16684(chunk,EnumSet.of(class_2902.class_2903.field_13197,class_2902.class_2903.field_13203,
        class_2902.class_2903.field_13200));
    return true;
  }
  private RoadWeather(){}
}
