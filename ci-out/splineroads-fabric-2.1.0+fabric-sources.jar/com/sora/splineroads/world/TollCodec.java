package com.sora.splineroads.world;
import com.sora.splineroads.core.TollPlaza.*;
import com.sora.splineroads.core.RoadGeometry.*;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import java.util.*;

/** Strict versioned authored parameters; generated collision geometry is owned by RoadRecord. */
public final class TollCodec {
  /** Standalone mode charges all selected directions; inline stations retain their explicit mask. */
  public static void standaloneMode(class_2487 t,boolean twoWay){t.method_10556("TwoWay",twoWay);t.method_10569("ChargedDirections",twoWay?3:1);}
  public static class_2487 write(Spec spec){var t=config(spec.config());t.method_10569("Version",spec.config().twoWay()&&spec.config().chargedDirections()!=3?7:spec.path().isEmpty()?3:spec.curvedDeck()?6:spec.rigidCore()?5:4);if(spec.portA()!=null)t.method_10566("PortA",RoadRecord.writeSettings(spec.portA()));if(spec.portB()!=null)t.method_10566("PortB",RoadRecord.writeSettings(spec.portB()));t.method_10566("A",RoadRecord.writeNode(spec.a()));t.method_10566("B",RoadRecord.writeNode(spec.b()));if(!spec.path().isEmpty()){var path=new class_2499();for(var s:spec.path()){var p=new class_2499();for(double v:new double[]{s.center().x(),s.center().y(),s.center().z(),s.left().x(),s.left().z(),s.distance(),s.halfWidth()})p.add(class_2489.method_23241(v));path.add(p);}t.method_10566("Path",path);}return t;}
  public static Spec read(class_2487 t){if(t.method_10550("Version")<1||t.method_10550("Version")>7)throw new IllegalArgumentException("收费站数据版本无效");var path=new ArrayList<Sample>();var list=t.method_10554("Path",class_2520.field_33259);if(list.size()>com.sora.splineroads.core.RoadLimits.MAX_SAMPLES)throw new IllegalArgumentException("收费站路径过大");for(var v:list){var p=(class_2499)v;if(p.size()!=7)throw new IllegalArgumentException("收费站路径数据无效");path.add(new Sample(new V(p.method_10611(0),p.method_10611(1),p.method_10611(2)),new V(p.method_10611(3),0,p.method_10611(4)),p.method_10611(5),p.method_10611(6)));}return new Spec(RoadRecord.readNode(t.method_10562("A")),RoadRecord.readNode(t.method_10562("B")),config(t),t.method_10545("PortA")?RoadRecord.readSettings(t.method_10562("PortA")):null,t.method_10545("PortB")?RoadRecord.readSettings(t.method_10562("PortB")):null,path,path.isEmpty()||t.method_10550("Version")>=5,path.isEmpty()||t.method_10550("Version")>=6);}
  public static class_2487 config(Config c){var t=new class_2487();t.method_10556("TwoWay",c.twoWay());t.method_10556("Reverse",c.reverse());t.method_10556("LeftTraffic",c.leftTraffic());t.method_10556("Highway",c.highway());t.method_10566("Forward",direction(c.forward()));t.method_10566("Backward",direction(c.backward()));t.method_10549("LaneWidth",c.laneWidth());t.method_10549("PassageWidth",c.passageWidth());t.method_10549("ClearHeight",c.clearHeight());t.method_10582("Structure",c.structure().name());t.method_10582("Name",c.name());t.method_10569("ChargedDirections",c.chargedDirections());return t;}
  public static Config config(class_2487 t){return new Config(t.method_10577("TwoWay"),t.method_10577("Reverse"),t.method_10577("LeftTraffic"),t.method_10577("Highway"),direction(t.method_10562("Forward")),direction(t.method_10562("Backward")),t.method_10574("LaneWidth"),t.method_10574("PassageWidth"),t.method_10574("ClearHeight"),Structure.valueOf(t.method_10558("Structure")),t.method_10558("Name"),t.method_10545("ChargedDirections")?t.method_10550("ChargedDirections"):t.method_10577("TwoWay")?3:1);}
  private static class_2487 direction(Direction d){var t=new class_2487();t.method_10569("A",d.aLanes());t.method_10569("B",d.bLanes());t.method_10569("ETC",d.etc());t.method_10569("Manual",d.manual());return t;}
  private static Direction direction(class_2487 t){return new Direction(t.method_10550("A"),t.method_10550("B"),t.method_10550("ETC"),t.method_10550("Manual"));}
  private TollCodec(){}
}
