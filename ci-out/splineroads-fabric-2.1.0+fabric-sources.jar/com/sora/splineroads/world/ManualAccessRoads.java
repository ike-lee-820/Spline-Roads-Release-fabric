package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Lane;
import com.sora.splineroads.core.LanePoints.Link;
import com.sora.splineroads.core.LanePoints.Options;
import com.sora.splineroads.core.LanePoints.Point;
import com.sora.splineroads.core.LanePoints.Ref;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Paired access ramps, their four real lane points and the exit road share one prepared edit. */
public final class ManualAccessRoads {
  private record Approval(UUID owner,RoadRecord source,class_2487 key,long created){}
  private static final Map<RoadData,Map<UUID,Approval>> APPROVALS=new WeakHashMap<>();
  private static boolean supported(RoadRecord r){return r.assembly()==null&&r.toll()==null&&r.junction()==null&&LaneTopology.metadata(r).link()==null&&!r.mesh().closed()&&LanePoints.supported(r.settings())&&!r.settings().style().ramp();}
  static class_2487 payload(class_3222 player,V hit,class_2487 selection){
    var data=RoadData.get(player.method_51469());RoadRecord host=null;
    if(selection.method_10545("LaneFrom")){var ref=LanePointCodec.ref(selection.method_10562("LaneFrom"));var built=data.index.roads.get(ref.road());if(built!=null)host=built.record;}
    if(host==null)host=data.index.roads.values().stream().map(b->b.record).filter(ManualAccessRoads::supported).min(Comparator.comparingDouble(r->RoadQueries.horizontal(r.mesh(),hit).horizontalDistance())).orElseThrow(()->new IllegalArgumentException("附近没有可接入的独立普通道路或高速道路"));
    if(!supported(host))throw new IllegalArgumentException("请选择独立普通道路或高速道路作为主路");RoadData.requireOwner(player,host.owner());
    var t=new class_2487();t.method_10582("Kind","manualAccess");t.method_10582("Dimension",player.method_37908().method_27983().method_29177().toString());t.method_25927("Road",host.id());t.method_10569("Signature",host.header().hashCode());t.method_10549("X",hit.x());t.method_10549("Y",hit.y());t.method_10549("Z",hit.z());t.method_10549("SpurLength",80);return t;
  }
  private static class_2487 key(class_2487 t){var out=new class_2487();for(String name:List.of("Road","Signature","X","Y","Z","SpurLength","Dimension"))if(t.method_10545(name))out.method_10566(name,t.method_10580(name).method_10707());return out;}
  static class_2487 preview(class_3222 player,class_2487 command){return preview(player.method_51469(),player,command);}
  static class_2487 preview(class_3218 level,class_3222 player,class_2487 command){try(var chunks=RoadWorkChunks.open(level)){
    var data=RoadData.get(level);var built=data.index.roads.get(command.method_25926("Road"));if(built==null||!supported(built.record)||built.record.header().hashCode()!=command.method_10550("Signature"))throw new IllegalArgumentException("主路已变化，请重新放置接入点");var host=built.record;if(player!=null)RoadData.requireOwner(player,host.owner());if(!level.method_27983().method_29177().toString().equals(command.method_10558("Dimension")))throw new IllegalArgumentException("地图维度已变化");
    V target=new V(command.method_10574("X"),command.method_10574("Y"),command.method_10574("Z"));double length=command.method_10574("SpurLength");if(!RoadGeometry.finite(target.x(),target.y(),target.z(),length)||length<64||length>160)throw new IllegalArgumentException("接出道路长度应为64–160格");
    var q=RoadQueries.horizontal(built.mesh,target);double distance=q.horizontalDistance();if(distance<length+48||distance>384)throw new IllegalArgumentException("接入点与主路需保留至少道路长度加48格、最多384格的横向空间");
    V outward=target.sub(q.sample().center()).horizontalUnit();double station=q.sample().distance(),spread=Math.max(64,Math.min(120,distance*.6));if(station-spread<40||station+spread>built.mesh.length()-40)throw new IllegalArgumentException("主路两侧需有足够分合流长度，请在更长路段中部放置");
    var lanes=LaneAdditions.slots(built.mesh,station).stream().filter(i->LaneSections.active(built.mesh,station,i)).map(i->LanePoints.lane(built.mesh,station,i)).toList();
    var outgoing=lanes.stream().min(Comparator.comparingDouble(l->l.position().sub(target).horizontalLength())).orElseThrow(()->new IllegalArgumentException("所选主路没有可用车道"));
    var incoming=lanes.stream().filter(l->l.sign()==outgoing.sign()).max(Comparator.comparingDouble(l->l.position().sub(q.sample().center()).dot(outward))).orElseThrow();
    var departure=LanePoints.point(UUID.randomUUID(),LanePoints.Origin.MANUAL,built.mesh,station-spread*outgoing.sign(),outgoing.index());
    var arrival=LanePoints.point(UUID.randomUUID(),LanePoints.Origin.MANUAL,built.mesh,station+spread*outgoing.sign(),incoming.index());
    var points=new ArrayList<>(LaneTopology.metadata(host).points());points.add(departure);points.add(arrival);var changedHost=host.withLanePoints(LaneTopology.metadata(host).points(points));
    V start=target.sub(outward.mul(length));var na=new Node(start,RoadPlanner.yaw(outward),0);var nb=new Node(target,RoadPlanner.yaw(outward),0);class_2338 a=class_2338.method_49637(start.x(),start.y(),start.z()),b=class_2338.method_49637(target.x(),target.y(),target.z());
    var settings=RoadLanes.configure(Settings.defaults(),RoadProfile.Type.ORDINARY,new RoadLanes.Counts(1,1),RoadProfile.layout(built.mesh,q.sample()).laneWidth()).structure(Structure.AUTO);settings=RoadPlanner.mode(settings,Mode.STRAIGHT,90).options(settings.options().traffic(host.settings().options().leftTraffic()).route(RoadProfile.Routing.DEFAULT.fit(false)).infrastructure(settings.options().infrastructure().gantry(RoadInfrastructure.Gantry.OFF)));
    var spur=new RoadRecord(UUID.randomUUID(),host.owner(),a,b,na,nb,settings,false,4);var spurMesh=spur.mesh();var spurLanes=LaneAdditions.slots(spurMesh,length/2).stream().map(i->LanePoints.lane(spurMesh,length/2,i)).toList();
    var entry=LanePoints.point(UUID.randomUUID(),LanePoints.Origin.MANUAL,spurMesh,length/2,spurLanes.stream().filter(l->l.sign()>0).findFirst().orElseThrow().index());
    var exit=LanePoints.point(UUID.randomUUID(),LanePoints.Origin.MANUAL,spurMesh,length/2,spurLanes.stream().filter(l->l.sign()<0).findFirst().orElseThrow().index());spur=spur.withLanePoints(LanePoints.Data.EMPTY.points(List.of(entry,exit)));
    var all=new LinkedHashMap<>(LaneTopology.records(data));all.put(host.id(),changedHost);all.put(spur.id(),spur);
    var options=new LanePoints.Options(LanePoints.Path.AUTO,LanePoints.Departure.BRANCH,LanePoints.Arrival.FLOW,24,24,LanePoints.Elevation.AUTO,LanePoints.Landing.EXACT);
    var firstLink=new LanePoints.Link(LanePoints.Ref.lane(host.id(),departure.id()),LanePoints.Ref.lane(spur.id(),entry.id()),options,null);
    var first=LaneRamps.generate(data,all,UUID.randomUUID(),host.owner(),firstLink);all.put(first.id(),first);
    var secondLink=new LanePoints.Link(LanePoints.Ref.lane(spur.id(),exit.id()),LanePoints.Ref.lane(host.id(),arrival.id()),options,null);
    var second=LaneRamps.generate(data,all,UUID.randomUUID(),host.owner(),secondLink);all.put(second.id(),second);
    var selected=new HashSet<class_2338>();selected.addAll(LaneRamps.contactEndpoints(all,first));selected.addAll(LaneRamps.contactEndpoints(all,second));selected.add(a);selected.add(b);
    UUID token=UUID.randomUUID();var requested=List.of(changedHost,spur,first,second);var prepared=data.prepareAssembly(level,player,requested.stream().map(RoadIndex.Built::new).toList(),Set.of(host.id()),selected,List.of(node(a,na,host.owner()),node(b,nb,host.owner())),token,Set.of(spur.id(),first.id(),second.id()),true);
    var table=APPROVALS.computeIfAbsent(data,d->new LinkedHashMap<>());table.entrySet().removeIf(e->System.nanoTime()-e.getValue().created()>600_000_000_000L||Objects.equals(e.getValue().owner(),player==null?null:player.method_5667()));table.put(token,new Approval(player==null?null:player.method_5667(),host,key(command),System.nanoTime()));while(table.size()>4)table.remove(table.keySet().iterator().next());
    var reply=command.method_10553();reply.method_10551("Action");reply.method_10582("Kind","manualAccess");reply.method_25927("Token",token);var roads=new class_2499();prepared.forEach(r->roads.add(r.record.save()));reply.method_10566("PlannerPreview",roads);com.sora.splineroads.net.RoadActionContext.echo(command,reply);return reply;
  }}
  private static RoadData.NodeMove node(class_2338 p,Node n,UUID owner){var t=new class_2487();t.method_25927("Owner",owner);t.method_10566("Node",RoadRecord.writeNode(n));t.method_10556("HeadingLocked",true);t.method_10556("HeightExplicit",true);return new RoadData.NodeMove(null,p,n,t);}
  static String build(class_3222 player,class_2487 t){return build(player.method_51469(),player,t);}
  static String build(class_3218 level,class_3222 player,class_2487 t){var data=RoadData.get(level);var table=APPROVALS.get(data);var approval=table==null||!t.method_25928("Token")?null:table.remove(t.method_25926("Token"));if(approval==null||System.nanoTime()-approval.created()>600_000_000_000L||!Objects.equals(approval.owner(),player==null?null:player.method_5667())||!approval.key().equals(key(t))||data.index.roads.get(approval.source().id())==null||data.index.roads.get(approval.source().id()).record!=approval.source())throw new IllegalArgumentException("接入匝道预览已失效，请重新预览");data.buildPrepared(level,player,t.method_25926("Token"));return "双向进出匝道、接出道路及分合流点已统一建造";}
  private ManualAccessRoads(){}
}
