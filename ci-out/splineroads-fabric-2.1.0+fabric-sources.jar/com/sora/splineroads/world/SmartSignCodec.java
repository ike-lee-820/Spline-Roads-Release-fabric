package com.sora.splineroads.world;
import com.sora.splineroads.core.SmartSigns;
import com.sora.splineroads.core.SmartSigns.*;
import com.sora.splineroads.core.RoadGeometry.V;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import java.util.*;

public final class SmartSignCodec {
  public static class_2487 key(Key k){var t=new class_2487();t.method_25927("Road",k.road());t.method_10569("Slot",k.slot());t.method_10569("Flow",k.flow());return t;}
  public static Key key(class_2487 t){return new Key(t.method_25926("Road"),t.method_10550("Slot"),t.method_10550("Flow"));}
  public static class_2487 text(Text v){var t=new class_2487();t.method_10582("Value",v.value());t.method_10569("Size",v.size());t.method_10556("Wrap",v.wrap());return t;}
  public static Text text(class_2487 t){return new Text(t.method_10558("Value"),t.method_10550("Size"),t.method_10577("Wrap"));}
  private static class_2487 words(Map<String,Text> map){var t=new class_2487();map.forEach((k,v)->t.method_10566(k,text(v)));return t;}
  private static Map<String,Text> words(class_2487 t){if(t.method_10541().size()>SmartSigns.MAX_FIELDS)throw new IllegalArgumentException("文字区域过多");var out=new HashMap<String,Text>();for(String k:t.method_10541())out.put(k,text(t.method_10562(k)));return out;}
  public static class_2487 write(State s){var t=key(s.key());t.method_10569("Version",SmartSigns.VERSION);t.method_10569("LayoutVersion",2);t.method_25927("GantryId",s.key().id());t.method_10582("Mode",s.mode().name());t.method_10582("Entry",s.entry());if(s.target()!=null)t.method_25927("Target",s.target());t.method_10582("Diagnostic",s.diagnostic());t.method_10544("Revision",s.revision());t.method_10566("Text",words(s.text()));var hidden=new class_2499();s.hiddenHeaders().stream().sorted().forEach(v->hidden.add(class_2519.method_23256(v)));t.method_10566("HiddenHeaders",hidden);var accessories=new class_2499();s.hiddenAccessories().stream().sorted().forEach(v->accessories.add(class_2519.method_23256(v)));t.method_10566("HiddenAccessories",accessories);var closed=new class_2499();s.closedLanes().stream().sorted().forEach(v->closed.add(class_2519.method_23256(v)));t.method_10566("ClosedLanes",closed);var history=new class_2499();s.drafts().forEach((k,v)->{var h=new class_2487();h.method_10582("Target",k);h.method_10566("Text",words(v));history.add(h);});t.method_10566("Drafts",history);
    var bs=new class_2499();for(var b:s.branches()){var n=new class_2487();n.method_10582("Id",b.id());n.method_10539("Lanes",b.lanes().stream().mapToInt(Integer::intValue).toArray());n.method_10569("Side",b.side());n.method_10556("Dedicated",b.dedicated());var path=new class_2499();for(V p:b.path()){var v=new class_2487();v.method_10549("X",p.x());v.method_10549("Y",p.y());v.method_10549("Z",p.z());path.add(v);}n.method_10566("Path",path);bs.add(n);}t.method_10566("Branches",bs);if(s.support()!=null){var a=new class_2487();a.method_10566("Foot",vector(s.support().foot()));a.method_10566("Right",vector(s.support().right()));a.method_10566("Front",vector(s.support().front()));a.method_10556("Paired",s.support().paired());a.method_10569("CantileverSide",s.support().cantileverSide());if(s.support().gantrySpan()!=0)a.method_10549("GantrySpan",s.support().gantrySpan());if(s.support().boardCenter()!=null)a.method_10549("BoardCenter",s.support().boardCenter());t.method_10566("Support",a);}return t;
  }
  public static State read(class_2487 t){if(t.method_10550("Version")>SmartSigns.VERSION)throw new IllegalArgumentException("智能标牌数据版本过新");var bs=new ArrayList<Branch>();var list=t.method_10554("Branches",class_2520.field_33260);if(list.size()>12)throw new IllegalArgumentException("分支过多");for(class_2520 v:list){var b=(class_2487)v;var path=new ArrayList<V>();var ps=b.method_10554("Path",class_2520.field_33260);if(ps.size()>128)throw new IllegalArgumentException("结构示意过大");for(class_2520 p:ps){var n=(class_2487)p;path.add(new V(n.method_10574("X"),n.method_10574("Y"),n.method_10574("Z")));}bs.add(new Branch(b.method_10558("Id"),Arrays.stream(b.method_10561("Lanes")).boxed().toList(),b.method_10550("Side"),b.method_10577("Dedicated"),path));}
    var drafts=new LinkedHashMap<String,Map<String,Text>>();var ds=t.method_10554("Drafts",class_2520.field_33260);if(ds.size()>8)throw new IllegalArgumentException("草稿过多");for(class_2520 v:ds){var d=(class_2487)v;drafts.put(d.method_10558("Target"),words(d.method_10562("Text")));}
    var state=new State(key(t),Mode.valueOf(t.method_10558("Mode")),t.method_25928("Target")?t.method_25926("Target"):null,t.method_10558("Diagnostic"),t.method_10537("Revision"),bs,words(t.method_10562("Text")),drafts,t.method_10545("Entry")?t.method_10558("Entry"):Integer.toString(t.method_10550("Flow")),t.method_10545("Support")?support(t.method_10562("Support")):null,hidden(t,"HiddenHeaders"),hidden(t,"HiddenAccessories"),hidden(t,"ClosedLanes"));
    return t.method_10550("LayoutVersion")<2?SmartSigns.unifiedHeader(state):state;
  }
  private static Set<String> hidden(class_2487 t,String key){var list=t.method_10554(key,class_2520.field_33258);if(list.size()>SmartSigns.MAX_FIELDS)throw new IllegalArgumentException("道路标识区状态过多");var out=new HashSet<String>();for(int i=0;i<list.size();i++)out.add(list.method_10608(i));return out;}
  private static class_2487 vector(V p){var t=new class_2487();t.method_10549("X",p.x());t.method_10549("Y",p.y());t.method_10549("Z",p.z());return t;}
  private static V vector(class_2487 t){return new V(t.method_10574("X"),t.method_10574("Y"),t.method_10574("Z"));}
  private static Support support(class_2487 t){return new Support(vector(t.method_10562("Foot")),vector(t.method_10562("Right")),vector(t.method_10562("Front")),t.method_10577("Paired"),t.method_10550("CantileverSide"),t.method_10574("GantrySpan"),t.method_10545("BoardCenter")?t.method_10574("BoardCenter"):null);}
  private SmartSignCodec(){}
}
