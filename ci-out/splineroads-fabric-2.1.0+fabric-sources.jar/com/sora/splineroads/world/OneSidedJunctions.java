package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Piece;
import com.sora.splineroads.core.JunctionPlanner.Plan;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Options;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.core.JunctionSpec.*;
import com.sora.splineroads.core.OneSidedJunction.Source;
import com.sora.splineroads.core.RoadAttachments.Point;
import java.util.*;
import java.nio.charset.StandardCharsets;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Attached-point/endpoint connection with separate road and junction editors. */
public final class OneSidedJunctions {
  static Settings preference(class_2487 tool){
    var s=tool.method_10545("Settings")?RoadRecord.readSettings(tool.method_10562("Settings")):new Settings(Mode.STRAIGHT,Style.O2_YELLOW,9,1,.35,90);
    return s.options(s.options().lanePoints(LanePoints.Data.EMPTY).attachments(RoadAttachments.Data.EMPTY).ends(RoadTransitions.Ends.NONE));
  }
  static boolean selectedEndpoint(class_3222 player,class_2487 tool,class_2338 endpoint){
    if(!tool.method_25928("SideMain"))return false;
    if(!tool.method_10558("Dimension").equals(player.method_51469().method_27983().method_29177().toString())){tool.method_10551("ElevatedSelection");tool.method_10551("SideSelection");tool.method_10551("SideMain");tool.method_10551("SidePoint");return false;}
    var host=RoadData.get(player.method_51469()).index.roads.get(tool.method_25926("SideMain"));
    if(host!=null&&host.record.settings().options().attachments().points().stream().anyMatch(p->p.id().equals(tool.method_25926("SidePoint"))&&p.elevated())){
      ElevatedAccessRoads.open(player,tool,ElevatedAccessRoads.payload(player.method_51469(),player,host.record.id(),tool.method_25926("SidePoint"),endpoint,true,null));return true;
    }
    openSelection(player,tool,create(player.method_51469(),player,tool.method_25926("SideMain"),tool.method_25926("SidePoint"),endpoint,true,preference(tool)));return true;
  }
  static void selectedAttached(class_3222 player,class_2487 tool,RoadIndex.Built road,RoadAttachments.Point point){
    if(point.elevated()){ElevatedAccessRoads.select(player,tool,road,point);return;}
    RoadData.requireOwner(player,road.record.owner());String dimension=player.method_51469().method_27983().method_29177().toString();
    if(tool.method_25928("SideMain")){var selected=RoadData.get(player.method_51469()).index.roads.get(tool.method_25926("SideMain"));if(selected!=null&&selected.record.settings().options().attachments().points().stream().anyMatch(p->p.id().equals(tool.method_25926("SidePoint"))&&p.elevated()))throw new IllegalArgumentException("高架出入点须连接已有高架的尽头端点");}
    if(tool.method_25928("SideMain")&&dimension.equals(tool.method_10558("Dimension"))){openSelection(player,tool,PairedSideJunctions.create(player.method_51469(),player,tool.method_25926("SideMain"),tool.method_25926("SidePoint"),road.record.id(),point.id(),preference(tool)));return;}
    if(tool.method_10545("Start")&&dimension.equals(tool.method_10558("Dimension"))){
      openSelection(player,tool,create(player.method_51469(),player,road.record.id(),point.id(),class_2338.method_10092(tool.method_10537("Start")),false,preference(tool)));return;
    }
    tool.method_10551("ElevatedSelection");tool.method_10551("SideSelection");tool.method_10551("Start");tool.method_10551(CurveControlNodes.KEY);tool.method_25927("SideMain",road.record.id());tool.method_25927("SidePoint",point.id());tool.method_10582("Dimension",dimension);
    player.method_7353(net.minecraft.class_2561.method_43470("已选附属点 A，请右键端点或另一主路附属点 B；单行连接按 A→B"),true);
  }
  private static class_2487 selection(class_2487 command){var t=new class_2487();for(String key:List.of("Main","AttachedPoint","Branch","MainFirst","Paired","MainB","AttachedPointB","MixedMarker","Marker","MixedLink"))if(command.method_10545(key))t.method_10566(key,command.method_10580(key).method_10707());return t;}
  private static void openSelection(class_3222 player,class_2487 tool,class_2487 command){tool.method_10566("SideSelection",selection(command));com.sora.splineroads.net.RoadNetwork.open(player,SideRoads.payload(command));}
  public static String buildRoadSelected(class_3218 level,class_3222 player,class_2487 command,net.minecraft.class_1799 stack){
    var tool=stack.method_7948();
    if(!command.method_25928("Id")&&(!level.method_27983().method_29177().toString().equals(tool.method_10558("Dimension"))||!tool.method_10545("SideSelection")||!tool.method_10562("SideSelection").equals(selection(command))))throw new IllegalArgumentException("连接选点已失效，请重新选择附属点和道路端点");
    String result=build(level,player,command,RoadRecord.readSettings(command.method_10562("Settings")));
    for(String key:List.of("SideSelection","SideMain","SidePoint","Start"))tool.method_10551(key);
    return result;
  }
  public static String buildSelected(class_3218 level,class_3222 player,class_2487 command,net.minecraft.class_1799 stack){
    var tool=stack.method_7948();
    if(!command.method_25928("Id")&&(!level.method_27983().method_29177().toString().equals(tool.method_10558("Dimension"))||!tool.method_10545("SideSelection")||!tool.method_10562("SideSelection").equals(selection(command))))throw new IllegalArgumentException("单边路口选点已失效，请重新选择附属点和支路端点");
    String result=build(level,player,command);
    for(String key:List.of("SideSelection","SideMain","SidePoint","Start"))tool.method_10551(key);
    return result;
  }
  static boolean saved(RoadData data,UUID group){return group!=null&&data.junctions.getOrDefault(group,new class_2487()).method_10577("OneSided");}
  public static class_2487 create(class_3218 level,class_3222 player,UUID mainId,UUID pointId,class_2338 branch,boolean mainFirst,Settings fallback){
    var main=RoadData.get(level).index.roads.get(mainId);if(main==null)throw new IllegalArgumentException("主路已变化，请重新选择附属点");
    JunctionPointTool.requireDifferent(level,branch,main.record);
    if(!SideHosts.attachable(main.record))throw new IllegalArgumentException("请选择普通主路路段的附属点；不能直接占用路口铺装或立交组成段");
    if(level.method_8321(branch) instanceof NodeEntity node&&node.junctionSource!=null)return JunctionPointConnections.create(level,player,main.record,pointId,branch,mainFirst,fallback);
    var t=new class_2487();t.method_10556("OneSided",true);t.method_25927("Main",mainId);t.method_25927("AttachedPoint",pointId);t.method_10544("Branch",branch.method_10063());t.method_10556("MainFirst",mainFirst);t.method_10566("Fallback",RoadRecord.writeSettings(fallback));
    var original=SideHosts.original(RoadData.get(level),main.record);t.method_10566("OriginalMain",original.save());return fresh(level,player,t,original);
  }
  public static class_2487 payload(class_3218 level,class_3222 player,UUID group){
    if(JunctionPointConnections.saved(RoadData.get(level),group))return JunctionPointConnections.payload(level,player,group);
    if(PairedSideJunctions.saved(RoadData.get(level),group))return PairedSideJunctions.payload(level,player,group);
    var saved=RoadData.get(level).junctions.get(group);if(saved==null||!saved.method_10577("OneSided"))throw new IllegalArgumentException("单边路口已经不存在");
    if(player!=null)RoadData.requireOwner(player,saved.method_25926("Owner"));
    return fresh(level,player,saved.method_10553(),RoadRecord.load(saved.method_10562("OriginalMain")));
  }
  static class_2487 fresh(class_3218 level,class_3222 player,class_2487 t,RoadRecord original){return fresh(level,player,t,original,null);}
  static class_2487 fresh(class_3218 level,class_3222 player,class_2487 t,RoadRecord original,Node virtual){
    if(player!=null)RoadData.requireOwner(player,original.owner());
    var mesh=original.mesh();var options=original.settings().options();
    if(!RoadProfile.catalog(original.settings().style()).twoWay()||options.leftTraffic())throw new IllegalArgumentException("单边路口主路须为右侧通行的双向普通道路");
    if(original.settings().mode()==Mode.RING||!options.lanePoints().points(List.of()).equals(LanePoints.Data.EMPTY)||options.lanePoints().points().stream().anyMatch(p->!p.automatic()||!LaneTopology.references(RoadData.get(level),LanePoints.Ref.lane(original.id(),p.id())).isEmpty())||!options.routing().controls().isEmpty()||options.attachments().points().stream().anyMatch(RoadAttachments.Point::controlled))throw new IllegalArgumentException("主路含匝道、车道改造或曲线控制点，请在独立普通路段建立单边路口");
    var point=options.attachments().points().stream().filter(p->p.id().equals(t.method_25926("AttachedPoint"))).findFirst().orElseThrow(()->new IllegalArgumentException("主路附属点已改变，请重新选择"));
    var at=RoadQueries.horizontal(mesh,point.position()).sample();class_2338 branch=class_2338.method_10092(t.method_10537("Branch"));
    if(branch.equals(original.a())||branch.equals(original.b()))throw new IllegalArgumentException("支路端点不能是主路自身端点");
    if(virtual==null)JunctionPointTool.requireDifferent(level,branch,original);
    Node node=virtual==null?RoadData.requireNode(level,branch,player).constructionNode():virtual;V inward=at.center().sub(node.position()).horizontalUnit();
    int side=node.position().sub(at.center()).dot(at.left())>0?1:-1;
    var data=RoadData.get(level);UUID group=t.method_25928("Id")?t.method_25926("Id"):null;
    var links=(virtual==null?data.index.atNode(branch):Set.<UUID>of()).stream().map(data.index.roads::get).filter(r->!Objects.equals(group,r.record.assembly())||group==null).toList();
    if(links.size()>1)throw new IllegalArgumentException("支路端点连接多条道路，请选只有一条外接路的端点");
    Settings profile=RoadRecord.readSettings(t.method_10562("Fallback"));boolean incoming=!t.method_10577("MainFirst");
    if(!links.isEmpty()){
      var link=links.get(0);if(!AutoJunctions.ordinary(link.record))throw new IllegalArgumentException("支路须为普通道路端点");if(player!=null)RoadData.requireOwner(player,link.record.owner());
      boolean first=branch.equals(link.record.a());var sample=first?link.mesh.first():link.mesh.last();inward=sample.left().left().mul(first?1:-1);
      profile=RoadEndpointSections.orient(link.record.settings().taper(sample.halfWidth()*2,sample.halfWidth()*2),first);
      if(!RoadProfile.catalog(profile.style()).twoWay()&&incoming==first)throw new IllegalArgumentException("所选 A→B 与现有单行支路方向冲突，请按行驶方向重新选择");
      incoming=!first;node=new Node(sample.center(),RoadPlanner.yaw(inward),(first?-1:1)*(first?link.record.start():link.record.end()).grade());
      t.method_25927("BranchRoad",link.record.id());t.method_10569("BranchSignature",link.record.header().hashCode());
    }else node=new Node(node.position(),RoadPlanner.yaw(inward),node.grade());
    if(RoadProfile.catalog(profile.style()).type()!=RoadProfile.Type.ORDINARY||profile.options().leftTraffic())throw new IllegalArgumentException("支路须为右侧通行的普通道路");
    profile=section(profile);
    if(t.method_10545("ConnectionSettings")){
      profile=SideRoads.settings(RoadRecord.readSettings(t.method_10562("ConnectionSettings")),profile,!links.isEmpty());
      incoming=!t.method_10577("MainFirst");
    }
    JunctionSpec previous=t.method_10545("Spec")?JunctionCodec.read(t.method_10562("Spec")):null;
    double corner=previous==null?6:previous.cornerRadius();double span=Math.max(48,mesh.settings().width()+profile.width()+corner+16);
    double from=previous==null?at.distance()-span:previous.oneSide().from(),to=previous==null?at.distance()+span:previous.oneSide().to();
    if(from<2||to>mesh.length()-2)throw new IllegalArgumentException("附属点两侧主路至少各预留 "+(int)Math.ceil(span+2)+" 格，请移动附属点或延长主路");
    var protectedRanges=RoadSplitGeometry.protection(original);RoadSplitGeometry.requireClear(protectedRanges,from,from);RoadSplitGeometry.requireClear(protectedRanges,to,to);
    var arms=new ArrayList<Arm>();
    for(int i=0;i<2;i++){
      var port=RoadSlicing.at(mesh,i==0?from:to);V f=port.left().left().mul(i==0?-1:1);
      var section=section(RoadEndpointSections.orient(original.settings().taper(port.halfWidth()*2,port.halfWidth()*2),i==1));
      double d=.1;var before=RoadSlicing.at(mesh,Math.max(0,port.distance()-d));var after=RoadSlicing.at(mesh,Math.min(mesh.length(),port.distance()+d));double grade=(after.center().y()-before.center().y())/Math.max(1e-7,after.center().sub(before.center()).horizontalLength())*(i==0?1:-1);
      arms.add(JunctionSpec.arm(new Node(port.center(),RoadPlanner.yaw(f),grade),f,section,true,i).attached(true).crossing(false).signs(i==(side>0?0:1),false));
    }
    arms.add(JunctionSpec.arm(node,inward,profile,incoming,2).attached(!links.isEmpty()).signs(false,true));
    if(previous!=null)for(int i=0;i<3;i++){
      var old=previous.arms().get(i);var a=arms.get(i);
      if((i!=2||!t.method_10545("ConnectionSettings"))&&(a.incoming()!=old.incoming()||a.outgoing()!=old.outgoing()||a.width()!=old.width()))throw new IllegalArgumentException("接入道路断面已变化，请重新建立单边路口");
      var lanes=new ArrayList<Lane>();for(int lane=0;lane<a.incoming();lane++)lanes.add(lane<old.lanes().size()?old.lanes().get(lane):Lane.AUTO);
      arms.set(i,new Arm(a.endpoint(),a.inward(),a.external(),a.incoming(),a.outgoing(),a.width(),a.median(),a.medianKind(),a.cycleWidth(),a.curbWidth(),i==2&&old.crosswalk(),old.crossingWidth(),old.crossingSetback(),old.stopGap(),old.phase(),lanes,a.attached(),old.advanceSign(),old.nameSign(),false));
    }
    var source=new OneSidedJunction.Source(mesh,original.structures(),from,to,side);
    var spec=previous==null?new JunctionSpec(at.center(),Kind.INTERSECTION,false,corner,12,1,4,original.settings().thickness(),Control.NONE,20,3,1,0,true,true,arms):new JunctionSpec(at.center(),Kind.INTERSECTION,false,corner,12,1,4,original.settings().thickness(),previous.control(),previous.greenSeconds(),previous.yellowSeconds(),previous.allRedSeconds(),previous.timeOffset(),previous.guides(),true,arms);
    spec=spec.oneSide(source).supportedCrossings();OneSidedJunction.prepare(spec);
    SideHosts.available(data,original,point.id(),spec,group);
    t.method_10582("Kind","junction");t.method_10566("Spec",JunctionCodec.write(spec));t.method_10569("MainSignature",original.save().hashCode());
    t.method_10564("Points",new long[]{original.a().method_10063(),original.b().method_10063(),branch.method_10063()});t.method_10569("SelectedArm",2);return t;
  }
  public static String build(class_3218 level,class_3222 player,class_2487 command){
    return build(level,player,command,null);
  }
  private static String build(class_3218 level,class_3222 player,class_2487 command,Settings roadSettings){
    if(command.method_10577("MixedMarker")||command.method_25928("Id")&&JunctionPointConnections.saved(RoadData.get(level),command.method_25926("Id")))return JunctionPointConnections.build(level,player,command,roadSettings);
    if(!command.method_25928("Id")&&!command.method_10577("MixedMarker")&&level.method_8321(class_2338.method_10092(command.method_10537("Branch"))) instanceof NodeEntity marker&&marker.junctionSource!=null)throw new IllegalArgumentException("请重新选择路口点与附属点");
    if(command.method_10577("Paired")||command.method_25928("Id")&&PairedSideJunctions.saved(RoadData.get(level),command.method_25926("Id")))return PairedSideJunctions.build(level,player,command,roadSettings);
    try(var work=RoadWorkChunks.open(level)){
      var data=RoadData.get(level);UUID group=command.method_25928("Id")?command.method_25926("Id"):UUID.randomUUID();boolean editing=command.method_25928("Id");
      var fresh=editing?payload(level,player,group):create(level,player,command.method_25926("Main"),command.method_25926("AttachedPoint"),class_2338.method_10092(command.method_10537("Branch")),command.method_10577("MainFirst"),RoadRecord.readSettings(command.method_10562("Fallback")));
      if(fresh.method_10550("MainSignature")!=command.method_10550("MainSignature")||fresh.method_10550("BranchSignature")!=command.method_10550("BranchSignature"))throw new IllegalArgumentException("道路在预览后发生变化，请重新打开单边路口");
      if(roadSettings!=null){
        if(SideRoads.signature(fresh)!=command.method_10550("Signature"))throw new IllegalArgumentException("连接道路或路口已变化，请重新打开道路编辑器");
        fresh.method_10566("ConnectionSettings",RoadRecord.writeSettings(roadSettings));
        fresh=fresh(level,player,fresh,RoadRecord.load(fresh.method_10562("OriginalMain")));
      }
      var requested=roadSettings==null?validated(fresh,command):JunctionCodec.read(fresh.method_10562("Spec"));
      // Rebuild from the authoritative original while retaining the previewed ports.
      fresh.method_10566("Spec",JunctionCodec.write(requested));var original=RoadRecord.load(fresh.method_10562("OriginalMain"));fresh=fresh(level,player,fresh,original);requested=JunctionCodec.read(fresh.method_10562("Spec"));
      var plan=JunctionPlanner.plan(requested);var removed=new HashSet<UUID>();removed.add(original.id());
      if(editing)data.index.roads.values().stream().filter(r->group.equals(r.record.assembly())).forEach(r->removed.add(r.record.id()));
      var built=new ArrayList<RoadIndex.Built>();var center=class_2338.method_49637(requested.center().x(),requested.center().y(),requested.center().z());
      for(int i=0;i<plan.pieces().size();i++){
        var p=plan.pieces().get(i);boolean retained=p.arm()==-3;var mesh=p.mesh();UUID id=retained?original.id():UUID.nameUUIDFromBytes((group+":one-side:"+i).getBytes(StandardCharsets.UTF_8));
        if(retained){built.add(new RoadIndex.Built(SideHosts.retained(data,original,group,requested)));continue;}
        var a=retained?original.start():new Node(mesh.first().center(),RoadPlanner.yaw(mesh.first().left().left().mul(-1)),0);var b=retained?original.end():new Node(mesh.last().center(),RoadPlanner.yaw(mesh.last().left().left().mul(-1)),0);
        class_2338 posA=retained?original.a():p.arm()==2?class_2338.method_10092(fresh.method_10537("Branch")):center,posB=retained?original.b():center;
        built.add(new RoadIndex.Built(new RoadRecord(id,original.owner(),posA,posB,a,b,retained?original.settings():mesh.settings(),false,4).junction(group,new JunctionPlanner.Ref(requested,i))));
      }
      for(var proposed:built)for(var old:data.index.roads.values())if(!removed.contains(old.record.id())&&RoadIndex.overlapXZ(proposed.mesh,old.mesh,1))Interchanges.checkExternal(proposed.mesh,old.mesh,null);
      var nodes=new HashSet<class_2338>(List.of(original.a(),original.b(),class_2338.method_10092(fresh.method_10537("Branch"))));data.replaceAssembly(level,player,built,removed,nodes);
      fresh.method_25927("Id",group);fresh.method_25927("Owner",original.owner());data.junctions.put(group,fresh);data.method_80();return "单边路口已保存；中央隔离带和对向道路保持原状";
    }
  }
  public static void remove(class_3218 level,class_3222 player,UUID group){
    SideHosts.remove(level,player,group);
  }
  static JunctionSpec validated(class_2487 fresh,class_2487 command){
    var source=JunctionCodec.read(fresh.method_10562("Spec"));var request=command.method_10562("Spec").method_10553();if(!request.method_10545("OneSide"))request.method_10566("OneSide",fresh.method_10562("Spec").method_10562("OneSide").method_10553());var requested=JunctionCodec.read(request);
      if(!source.center().equals(requested.center())||requested.arms().size()!=3||!source.oneSide().equals(requested.oneSide())||requested.leftTraffic()||requested.thickness()!=source.thickness())throw new IllegalArgumentException("主路及保护区参数已变化，请重新预览");
      for(int i=0;i<3;i++){var a=source.arms().get(i);var b=requested.arms().get(i);if(!a.endpoint().equals(b.endpoint())||!a.inward().equals(b.inward())||!a.external().equals(b.external())||a.width()!=b.width()||a.incoming()!=b.incoming()||a.outgoing()!=b.outgoing()||a.median()!=b.median()||a.medianKind()!=b.medianKind()||a.cycleWidth()!=b.cycleWidth()||a.curbWidth()!=b.curbWidth()||a.attached()!=b.attached())throw new IllegalArgumentException("单边路口继承接入道路断面，不能修改主路或支路宽度");}
    return requested;
  }
  private static Settings section(Settings s){return s.options(s.options().lanePoints(LanePoints.Data.EMPTY).attachments(RoadAttachments.Data.EMPTY));}
  private OneSidedJunctions(){}
}
