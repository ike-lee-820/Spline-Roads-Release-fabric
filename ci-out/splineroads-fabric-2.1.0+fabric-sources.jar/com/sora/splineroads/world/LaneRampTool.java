package com.sora.splineroads.world;
import com.sora.splineroads.core.JunctionSpec;
import com.sora.splineroads.core.LanePoints;
import com.sora.splineroads.core.LanePoints.Options;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.LanePointTool.Pick;
import com.sora.splineroads.world.RoadIndex.Built;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import java.util.*;
import java.util.Map.Entry;

public final class LaneRampTool extends class_1792 {
  private static LanePoints.Options freshOptions(){return new LanePoints.Options(LanePoints.Path.AUTO,LanePoints.Departure.TEMPORARY,LanePoints.Arrival.MERGE,24,32,LanePoints.Elevation.AUTO,LanePoints.Landing.FLEXIBLE);}
  public LaneRampTool(){super(new class_1793().method_7889(1));}
  private void select(class_3222 p,class_1799 stack){try{if(p.method_5715()){clearSelection(p,stack);var reset=new class_2487();reset.method_10582("Kind","laneRampReset");RoadNetwork.open(p,reset);p.method_7353(class_2561.method_43470("已清除匝道选点与预览"),true);return;}if(!p.method_7294()||p.method_7325())throw new IllegalArgumentException("没有建设权限");var state=stack.method_7948();String dimension=p.method_37908().method_27983().method_29177().toString();if(!dimension.equals(state.method_10558("LaneDimension"))){clearSelection(p,stack);state.method_10582("LaneDimension",dimension);}var data=RoadData.get(p.method_51469());var picked=LanePointTool.pick(p);LanePoints.Ref ref=null;
    if(picked!=null){ref=LanePoints.Ref.lane(picked.road().id(),picked.point().id());LaneRamps.host(LaneTopology.records(data),ref);RoadData.requireOwner(p,picked.road().owner());}else{var hit=p.method_5745(96,0,false);var at=net.minecraft.class_2338.method_49638(hit.method_17784());double best=1.1;for(var e:data.junctions.entrySet()){var spec=RampJunctions.spec(data,e.getKey());var v=spec.center();double d=hit.method_17784().method_1022(new net.minecraft.class_243(v.x(),v.y(),v.z()));if(d<best){ref=LanePoints.Ref.junction(e.getKey());best=d;}}}
    if(ref==null){var selected=RoadTool.pick(p);if(selected!=null&&LaneTopology.metadata(selected.record).link()!=null&&selected.record.assembly()==null){RoadData.requireOwner(p,selected.record.owner());if(!state.method_25928("LaneEdit")||!state.method_25926("LaneEdit").equals(selected.record.id()))clearSelection(p,stack);state.method_10582("LaneDimension",dimension);state.method_25927("LaneEdit",selected.record.id());RoadNetwork.open(p,LaneRamps.tunnelChoices(LaneRamps.payload(selected.record,false),LaneTopology.records(data)));return;}
      if(state.method_10545("LaneTo")||state.method_25928("LaneEdit")){var resume=new class_2487();resume.method_10582("Kind","laneRampResume");
        var fallback=new class_2487();if(state.method_25928("LaneEdit")){var existing=data.index.roads.get(state.method_25926("LaneEdit"));if(existing!=null&&LaneTopology.metadata(existing.record).link()!=null)fallback=LaneRamps.payload(existing.record,false);}
        else {fallback.method_10582("Kind","laneRamp");fallback.method_10566("From",state.method_10562("LaneFrom").method_10553());fallback.method_10566("To",state.method_10562("LaneTo").method_10553());var preview=state.method_10562("LanePreview");var options=preview.method_10545("Road")?LaneTopology.metadata(RoadRecord.load(preview.method_10562("Road"))).link().options():freshOptions();fallback.method_10566("Options",LanePointCodec.options(options));}
        if(!fallback.method_33133())resume.method_10566("Fallback",LaneRamps.tunnelChoices(fallback,LaneTopology.records(data)));RoadNetwork.open(p,resume);return;}}
    if(ref==null)throw new IllegalArgumentException("只能选择蓝色车道点，汇入还可选择路口中心；普通端点、红色附属点和路面不能替代");
    if(!state.method_10545("LaneFrom")){if(ref.junction()!=null)throw new IllegalArgumentException("先选择汇出车道点 A，路口中心只能作为汇入点 B");clearSelection(p,stack);state.method_10582("LaneDimension",dimension);state.method_10566("LaneFrom",LanePointCodec.ref(ref));p.method_7353(class_2561.method_43470("已选汇出 A；请右键汇入车道点或路口中心 B"),false);return;}
    if(state.method_10562("LaneFrom").equals(LanePointCodec.ref(ref)))throw new IllegalArgumentException("请另选汇入点 B；Shift＋右键清除选点");
    cancelPlanning(p,stack);state.method_10566("LaneTo",LanePointCodec.ref(ref));var t=new class_2487();t.method_10582("Kind","laneRamp");t.method_10566("From",state.method_10562("LaneFrom").method_10553());t.method_10566("To",state.method_10562("LaneTo").method_10553());t.method_10566("Options",LanePointCodec.options(freshOptions()));RoadNetwork.open(p,LaneRamps.tunnelChoices(t,LaneTopology.records(data)));
    }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}}
  @Override public class_1269 method_7884(class_1838 c){if(c.method_8036() instanceof class_3222 p)select(p,c.method_8041());return class_1269.method_29236(c.method_8045().field_9236);}
  @Override public class_1271<class_1799> method_7836(class_1937 l,class_1657 p,class_1268 hand){if(p instanceof class_3222 sp)select(sp,p.method_5998(hand));return class_1271.method_29237(p.method_5998(hand),l.field_9236);}
  static void cancelPlanning(class_3222 player,class_1799 stack){
    com.sora.splineroads.net.RoadPlanningJobs.cancel(player.method_5667());
    var state=stack.method_7948();var preview=state.method_10562("LanePreview");
    if(preview.method_25928("Token"))RoadData.forgetPreview(player.method_5667(),preview.method_25926("Token"));
    state.method_10551("LanePreview");
  }
  static void clearSelection(class_3222 player,class_1799 stack){cancelPlanning(player,stack);clearSelection(stack);}
  static void clearSelection(class_1799 stack){var t=stack.method_7948();for(String key:List.of("LaneFrom","LaneTo","LanePreview","LaneDimension","LaneEdit"))t.method_10551(key);}
  /** The editor shares the normal dependency review and restoration transaction. */
  public static String deletion(class_3222 player,class_1799 tool,class_2487 command,boolean commit){
    if(!command.method_25928("Id"))throw new IllegalArgumentException("请先选择已建匝道");
    LaneRamps.selection(player,tool,command);
    var data=RoadData.get(player.method_51469());var road=data.index.roads.get(command.method_25926("Id")).record;
    cancelPlanning(player,tool);
    if(commit){LaneDeletes.remove(player.method_51469(),player,command);clearSelection(tool);return "匝道已删除，主路车道与附属设施已恢复";}
    var payload=new class_2487();payload.method_10582("Kind","road");payload.method_10556("DeleteOnly",true);payload.method_10556("RampDelete",true);
    payload.method_25927("Id",road.id());payload.method_10569("Signature",road.header().hashCode());payload.method_10566("Road",road.header());
    payload.method_10566("From",command.method_10562("From").method_10553());payload.method_10566("To",command.method_10562("To").method_10553());
    LaneDeletes.payload(data,road.id(),payload);com.sora.splineroads.net.RoadActionContext.echo(command,payload);RoadNetwork.open(player,payload);return "";
  }
  @Override public void method_7851(class_1799 s,class_1937 l,List<class_2561> lines,class_1836 f){lines.add(class_2561.method_43470("先选蓝色汇出 A，再选蓝色汇入 B 或路口中心；右键已建匝道编辑"));lines.add(class_2561.method_43470("Shift＋右键清除选点与预览（空气、方块、点均可）"));}
}
