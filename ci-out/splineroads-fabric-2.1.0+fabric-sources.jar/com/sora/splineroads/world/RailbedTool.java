package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.compat.mtr.MtrRailAccess;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RailbedPath.Path;
import com.sora.splineroads.core.RoadGeometry.Structure;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RailbedStore.Entry;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=SplineRoads.ID)
public final class RailbedTool extends class_1792 {
  static final class Draft {
    final UUID token=UUID.randomUUID();final String dimension;final class_2338 a;class_2338 b;
    final java.util.concurrent.atomic.AtomicBoolean cancelled=new java.util.concurrent.atomic.AtomicBoolean();
    volatile List<? extends CompletableFuture<?>> reads=List.of();
    void cancel(){cancelled.set(true);reads.forEach(f->f.cancel(false));}
    void reads(List<? extends CompletableFuture<?>> tasks){reads=List.copyOf(tasks);if(cancelled.get())reads.forEach(f->f.cancel(false));}
    RailbedBuildQueue.Preview previewTask;String previewKey="";class_2487 previewResponse;long previewComputations;
    final List<RailbedPath.Path> paths=new ArrayList<>();List<RailbedPath.Path> candidates=List.of();CompletableFuture<?> pending,preview;String sourceStatus="";List<RailbedPath.Path> surrounding=List.of();double width;Structure mode=Structure.AUTO;RailbedOptions options=RailbedOptions.DEFAULT;UUID saved,plannerSession;
    Draft(class_3222 player,class_2338 a){dimension=dimension(player);this.a=a.method_10062();}
  }
  private static final Map<UUID,Draft> drafts=new java.util.concurrent.ConcurrentHashMap<>();
  /** Network thread may touch only the authenticated owner's atomic flag. */
  public static void cancelSignal(UUID owner,UUID token){var d=drafts.get(owner);if(d!=null&&d.token.equals(token))d.cancel();}
  public RailbedTool(){super(new class_1793().method_7889(1));}
  private static String dimension(class_3222 player){var id=player.method_37908().method_27983().method_29177();return id.method_12836()+"/"+id.method_12832();}
  private static boolean held(class_3222 player){return player.method_6047().method_7909() instanceof RailbedTool||player.method_6079().method_7909() instanceof RailbedTool;}
  static Draft draft(class_3222 player){var d=drafts.get(player.method_5667());if(d==null||!d.dimension.equals(dimension(player)))throw new IllegalArgumentException("铁路选择已失效，请重新选点");return d;}
  private static void require(class_3222 player,class_2487 tag){if(tag.method_25928("PlannerSession")){if(!(ManualPlanner.tool(player,tag).method_7909() instanceof RailbedTool))throw new IllegalArgumentException("请从规划地图重新打开铁路路基");}else require(player);}
  private static void publish(class_3222 player,Draft d,class_2487 tag){if(d.plannerSession!=null)tag.method_25927("PlannerSession",d.plannerSession);RoadNetwork.open(player,tag);}
  private static void require(class_3222 player){if(!held(player)||!player.method_7294()||player.method_7325())throw new IllegalArgumentException("请手持铁路路基连接器并确保拥有建设权限");}
  @Override public class_1269 method_7884(class_1838 context){
    if(context.method_8045().field_9236)return class_1269.field_5812;if(!(context.method_8036() instanceof class_3222 player))return class_1269.field_5811;
    try{require(player);if(player.method_5715()){clear(player);return class_1269.field_21466;}
      String problem=MtrRailAccess.unavailable();if(problem!=null)throw new IllegalArgumentException(problem);
      class_2338 pos=context.method_8037();if(!player.method_51469().method_8505(player,pos))throw new IllegalArgumentException("铁路节点位于受保护区域");
      if(!MtrRailAccess.trainNode(context.method_8045().method_8320(pos).method_26204())){if(!drafts.containsKey(player.method_5667())&&edit(player))return class_1269.field_21466;var existing=draft(player);if(!toggle(player,existing))resume(player);return class_1269.field_21466;}
      var d=drafts.get(player.method_5667());if(d==null||!d.dimension.equals(dimension(player))){d=new Draft(player,pos);drafts.put(player.method_5667(),d);message(player,"已选铁路节点 A，请右键同一路径的节点 B");}
      else if(d.paths.isEmpty()){if(d.pending!=null&&!d.pending.isDone())throw new IllegalArgumentException("正在读取轨道，请稍候");d.b=pos.method_10062();read(player,d);}
      else if(!toggle(player,d))resume(player);
    }catch(RuntimeException failure){message(player,failure.getMessage());}return class_1269.field_21466;
  }
  @Override public class_1271<class_1799> method_7836(class_1937 level,class_1657 actor,class_1268 hand){if(actor instanceof class_3222 player)try{require(player);if(player.method_5715())clear(player);else if(!drafts.containsKey(player.method_5667())&&edit(player)){}else{var d=draft(player);if(!toggle(player,d))resume(player);}}catch(RuntimeException failure){message(player,failure.getMessage());}return class_1271.method_29237(actor.method_5998(hand),level.field_9236);}
  private static void read(class_3222 player,Draft d){message(player,"正在读取 MTR 实际轨迹…");
    var future=MtrRailAccess.read(d.dimension,RailbedCodec.node(d.a),RailbedCodec.node(d.b));d.pending=future;d.reads(List.of(future));
    future.whenComplete((path,error)->player.field_13995.execute(()->{
      if(!valid(player,d))return;d.pending=null;
      if(error!=null){d.b=null;message(player,reason(error));return;}d.paths.clear();d.paths.add(path);neighbors(player,d,true);
    }));
  }
  private static String reason(Throwable e){while(e.getCause()!=null)e=e.getCause();return e.getMessage()==null?"铁路读取失败："+e.getClass().getSimpleName():e.getMessage();}
  private static void resume(class_3222 player){open(player,draft(player));}
  private static void neighbors(class_3222 player,Draft d,boolean show){var future=MtrRailAccess.nearby(d.dimension,d.paths.get(0));d.pending=future;d.reads(List.of(future));future.whenComplete((near,error)->player.field_13995.execute(()->{if(!valid(player,d))return;d.pending=null;if(error!=null)message(player,reason(error));else{d.surrounding=near;d.candidates=RailbedCandidates.find(d.paths.get(0),near);if(d.saved==null&&d.paths.size()==1&&d.previewKey.isEmpty()){var selected=RailbedCandidates.automatic(d.paths.get(0),d.candidates);d.paths.clear();d.paths.addAll(selected);}}open(player,d,show);}));}
  static void open(class_3222 player,Draft d){open(player,d,true);}
  static void open(class_3222 player,Draft d,boolean show){if(d.paths.isEmpty()){message(player,"请继续选择铁路节点 B");return;}preview(player,d);var t=new class_2487();t.method_10582("Kind",show?"railbed":"railbedPreview");t.method_25927("Token",d.token);t.method_10582("Dimension",d.dimension);t.method_10582("SourceStatus",d.sourceStatus);t.method_10549("Width",d.width);t.method_10582("Mode",d.mode.name());t.method_10566("Options",RailbedCodec.options(d.options));
    var paths=new class_2499();d.paths.forEach(path->paths.add(RailbedCodec.write(path)));t.method_10566("Paths",paths);var candidates=new class_2499();d.candidates.forEach(path->candidates.add(RailbedCodec.write(path)));t.method_10566("Candidates",candidates);t.method_10582("Selection",selection(d));if(d.previewResponse!=null)t.method_10566("CachedPreview",d.previewResponse.method_10553());if(d.saved!=null)t.method_25927("Id",d.saved);publish(player,d,t);}
  private static boolean valid(class_3222 player,Draft d){return !d.cancelled.get()&&drafts.get(player.method_5667())==d&&!player.method_31481()&&d.dimension.equals(dimension(player))&&(d.plannerSession==null||ManualPlanner.active(player,d.plannerSession));}
  private static String selection(Draft d){return d.paths.stream().map(RailbedPath.Path::fingerprint).toList().toString();}
  private static void preview(class_3222 player,Draft d){
    if(d.cancelled.get()||d.sourceStatus.startsWith("正在核验"))return;
    String key=selection(d)+":"+d.width+":"+d.mode+":"+d.options+":"+d.saved+":"+d.surrounding.stream().map(RailbedPath.Path::fingerprint).sorted().toList();
    if(d.previewTask!=null&&key.equals(d.previewKey)&&(!d.previewTask.future().isDone()||d.previewTask.valid()))return;
    if(d.preview!=null)d.preview.cancel(false);double width=d.width;var mode=d.mode;var options=d.options;String selection=selection(d);
    d.previewResponse=null;d.previewKey=key;
    try{d.previewTask=RailbedBuildQueue.previewTask(player.method_51469(),player,d.saved==null?d.token:d.saved,List.copyOf(d.paths),width,mode,d.surrounding,options,d.cancelled::get);var future=d.previewTask.future();d.preview=future;d.previewComputations++;
      future.whenComplete((entry,error)->player.field_13995.execute(()->{if(!valid(player,d)||d.preview!=future||future.isCancelled())return;
        var tag=new class_2487();tag.method_10582("Kind","railbedStructurePreview");tag.method_25927("Token",d.token);tag.method_10549("Width",width);tag.method_10582("Mode",mode.name());tag.method_10566("Options",RailbedCodec.options(options));tag.method_10582("Selection",selection);
        if(error==null)tag.method_10566("Road",entry.road.save());else tag.method_10582("Problem",reason(error));d.previewResponse=tag;publish(player,d,tag);
      }));
    }catch(RuntimeException e){d.previewTask=null;var tag=new class_2487();tag.method_10582("Kind","railbedStructurePreview");tag.method_25927("Token",d.token);tag.method_10549("Width",width);tag.method_10582("Mode",mode.name());tag.method_10566("Options",RailbedCodec.options(options));tag.method_10582("Selection",selection);tag.method_10582("Problem",reason(e));d.previewResponse=tag;publish(player,d,tag);}
  }
  private static void sourceStatus(class_3222 player,Draft d){
    String unavailable=MtrRailAccess.unavailable();if(unavailable!=null){d.sourceStatus="源不可用；仍可删除旧路基";open(player,d);return;}
    var reads=d.paths.stream().map(p->MtrRailAccess.read(d.dimension,p.segments().get(0).from(),p.segments().get(p.segments().size()-1).to())).toList();
    var all=CompletableFuture.allOf(reads.toArray(CompletableFuture[]::new));d.pending=all;d.reads(reads);
    all.whenComplete((v,error)->player.field_13995.execute(()->{if(!valid(player,d))return;d.pending=null;
      if(error!=null){d.sourceStatus="源失效："+reason(error)+"；旧路基已保留";open(player,d);return;}
      try{var fresh=new ArrayList<RailbedPath.Path>();fresh.add(reads.get(0).join());for(int i=1;i<reads.size();i++)fresh.add(RailbedCandidates.clip(fresh.get(0),reads.get(i).join().segments()));
        boolean changed=false;for(int i=0;i<fresh.size();i++)changed|=!fresh.get(i).fingerprint().equals(d.paths.get(i).fingerprint());
        d.sourceStatus=changed?"待更新：轨道已改变，保存时需确认新预览":"源轨道有效";neighbors(player,d,true);
      }catch(RuntimeException e){d.sourceStatus="源失效："+reason(e);open(player,d);}
    }));
  }
  private static boolean edit(class_3222 player){var picked=RoadTool.pick(player);if(picked==null||!picked.record.railway())return false;openExisting(player,picked.record.id(),null);return true;}
  static void openExisting(class_3222 player,UUID id,UUID session){var entry=RoadData.get(player.method_51469()).railbeds.entries.get(id);if(entry==null)throw new IllegalArgumentException("铁路结构正在恢复，请稍候");RoadData.requireOwner(player,entry.road.owner());var d=new Draft(player,entry.road.a());d.b=entry.road.b();d.paths.addAll(entry.paths);d.saved=entry.road.id();d.width=entry.width;d.mode=entry.mode;d.options=entry.options;d.plannerSession=session;var previous=drafts.put(player.method_5667(),d);if(previous!=null){previous.cancel();if(previous.preview!=null)previous.preview.cancel(false);}d.sourceStatus="正在核验绑定轨道…";open(player,d);sourceStatus(player,d);}
  private static boolean toggle(class_3222 player,Draft d){if(d.paths.isEmpty())return false;var eye=player.method_33571();var look=player.method_5720();var origin=new com.sora.splineroads.core.RoadGeometry.V(eye.field_1352,eye.field_1351,eye.field_1350);var direction=new com.sora.splineroads.core.RoadGeometry.V(look.field_1352,look.field_1351,look.field_1350);RailbedPath.Path selected=null;double nearest=97;
    for(var candidate:d.candidates){var points=candidate.positions();double hit=Double.POSITIVE_INFINITY;for(int i=1;i<points.size();i++){
      var a=points.get(i-1).add(new com.sora.splineroads.core.RoadGeometry.V(0,.2,0));var delta=points.get(i).sub(points.get(i-1));var w=a.sub(origin);double dd=delta.dot(delta),vd=direction.dot(delta),den=dd-vd*vd;double t=den<1e-9?0:Math.max(0,Math.min(1,(vd*w.dot(direction)-w.dot(delta))/den));var p=a.add(delta.mul(t));double distance=p.sub(origin).dot(direction);if(distance>0&&distance<96&&p.distance(origin.add(direction.mul(distance)))<.65)hit=Math.min(hit,distance);
    }if(hit<nearest){if(selected!=null&&Math.abs(hit-nearest)<.75)throw new IllegalArgumentException("候选轨道重叠，请靠近后选择");selected=candidate;nearest=hit;}}
    if(selected==null)return false;String key=RailbedCandidates.key(selected);boolean removed=d.paths.removeIf(p->p!=d.paths.get(0)&&RailbedCandidates.key(p).equals(key));if(!removed){if(d.paths.size()>=8)throw new IllegalArgumentException("最多选择 8 股轨道");var proposed=new ArrayList<>(d.paths);proposed.add(selected);RailbedGeometry.plan(proposed,0,d.mode);d.paths.add(selected);}open(player,d,false);message(player,"已选 "+d.paths.size()+" 股轨道；右键空处返回设置");return true;
  }
  public static void action(class_3222 player,class_2487 tag){try{var d=draft(player);if(tag.method_10558("Action").equals("railbedCancel")&&tag.method_25928("Token")&&d.token.equals(tag.method_25926("Token"))){clear(player);return;}require(player,tag);if(d.cancelled.get())return;if(!Objects.equals(d.plannerSession,tag.method_25928("PlannerSession")?tag.method_25926("PlannerSession"):null))throw new IllegalArgumentException("铁路规划会话已变化，请重新打开");if(!d.token.equals(tag.method_25926("Token")))throw new IllegalArgumentException("铁路草稿已变化，请重新打开");
    String action=tag.method_10558("Action");if(action.equals("railbedCancel")){clear(player);return;}
    if(d.pending!=null&&!d.pending.isDone())throw new IllegalArgumentException("正在读取或施工，请稍候");
    if(action.equals("railbedDelete")){if(d.saved==null)throw new IllegalArgumentException("当前尚未建造");d.pending=RailbedRoads.submit(player.method_51469(),player,d.saved,null,0,d.mode,d.options,List.of(),planner(d));d.pending.whenComplete((v,e)->player.field_13995.execute(()->{if(e==null&&drafts.get(player.method_5667())==d)clear(player);}));return;}
    double width=tag.method_10574("Width");if(!Double.isFinite(width)||width<0||width>64)throw new IllegalArgumentException("路基总宽无效");var mode=Structure.valueOf(tag.method_10558("Mode"));if(mode==Structure.GROUND)throw new IllegalArgumentException("铁路模式无效");
    RailbedGeometry.plan(d.paths,width,mode);d.width=width;d.mode=mode;d.options=RailbedCodec.options(tag.method_10562("Options"));
    if(action.equals("railbedSettings")){preview(player,d);if(d.previewResponse!=null)publish(player,d,d.previewResponse.method_10553());return;}
    if(!action.equals("railbedBuild"))throw new IllegalArgumentException("未知铁路操作");build(player,d);
  }catch(RuntimeException failure){message(player,failure.getMessage());}}
  private static class_2487 planner(Draft d){if(d.plannerSession==null)return null;var t=new class_2487();t.method_25927("PlannerSession",d.plannerSession);return t;}
  private static void build(class_3222 player,Draft d){String unsupported=RailbedGeometry.unsupported(d.paths);if(unsupported!=null)throw new IllegalArgumentException(unsupported);message(player,"正在重新校验 MTR 源轨道…");
    long sourceRevision=MtrRailAccess.revision(d.dimension);
    var reads=d.paths.stream().map(p->{var s=p.segments();return MtrRailAccess.read(d.dimension,s.get(0).from(),s.get(s.size()-1).to());}).toList();var all=CompletableFuture.allOf(reads.toArray(CompletableFuture[]::new));d.pending=all;d.reads(reads);
    all.whenComplete((ignored,error)->player.field_13995.execute(()->{if(!valid(player,d))return;if(error!=null){message(player,reason(error));return;}
      try{var fresh=new ArrayList<RailbedPath.Path>();fresh.add(reads.get(0).join());for(int i=1;i<reads.size();i++)fresh.add(RailbedCandidates.clip(fresh.get(0),reads.get(i).join().segments()));
        for(int i=0;i<fresh.size();i++)if(!fresh.get(i).fingerprint().equals(d.paths.get(i).fingerprint())){d.paths.clear();d.paths.addAll(fresh);message(player,"轨道已变化，请重新确认建造");neighbors(player,d,true);return;}
        var nearby=MtrRailAccess.nearby(d.dimension,fresh.get(0));d.pending=nearby;d.reads(List.of(nearby));nearby.whenComplete((surrounding,failure)->player.field_13995.execute(()->{if(!valid(player,d))return;if(failure!=null){message(player,reason(failure));return;}try{
          if(sourceRevision!=MtrRailAccess.revision(d.dimension))throw new IllegalArgumentException("MTR 轨道在校验期间发生变化，请重新预览");
          UUID id=d.saved==null?UUID.randomUUID():d.saved;var future=RailbedRoads.submit(player.method_51469(),player,id,fresh,d.width,d.mode,d.options,surrounding,planner(d));d.pending=future;message(player,"已加入铁路施工队列");future.whenComplete((entry,e)->player.field_13995.execute(()->{if(e==null&&drafts.get(player.method_5667())==d)clear(player);}));
        }catch(RuntimeException e){message(player,e.getMessage());}}));
      }catch(RuntimeException e){message(player,reason(e));}
    }));
  }
  private static void clear(class_3222 player){var d=drafts.remove(player.method_5667());if(d!=null){d.cancel();if(d.pending!=null)d.pending.cancel(false);if(d.preview!=null)d.preview.cancel(false);}var tag=new class_2487();tag.method_10582("Kind","railbedReset");if(d!=null)tag.method_25927("Token",d.token);if(d!=null)publish(player,d,tag);else RoadNetwork.open(player,tag);message(player,"铁路草稿已清除");}
  private static void message(class_3222 player,String text){player.method_7353(class_2561.method_43470(text==null?"铁路操作失败":text),true);}
  @SubscribeEvent public static void logout(PlayerEvent.PlayerLoggedOutEvent event){var d=drafts.remove(event.getEntity().method_5667());if(d!=null){d.cancel();if(d.pending!=null)d.pending.cancel(false);if(d.preview!=null)d.preview.cancel(false);}}
  @SubscribeEvent public static void dimensionChanged(PlayerEvent.PlayerChangedDimensionEvent event){if(event.getEntity() instanceof class_3222 player)clear(player);}
  @SubscribeEvent public static void stopped(ServerStoppedEvent event){for(var d:drafts.values()){d.cancel();if(d.pending!=null)d.pending.cancel(false);if(d.preview!=null)d.preview.cancel(false);}drafts.clear();}
}
