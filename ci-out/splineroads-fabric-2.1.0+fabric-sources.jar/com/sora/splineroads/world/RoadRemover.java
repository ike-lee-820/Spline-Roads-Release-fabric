package com.sora.splineroads.world;

import com.sora.splineroads.world.RoadIndex.Built;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

public final class RoadRemover extends class_1792 {
  public RoadRemover() {
    super(new class_1793().method_7889(1));
  }

  private void select(class_1657 player) {
    if (!(player instanceof class_3222 p)) return;
    try {
      var road = RoadTool.pick(p);
      if (road == null) p.method_7353(class_2561.method_43470("请指向 256 格内已加载的道路，再右键选择删除"), true);
      else RoadTool.openRoad(p, road.record, true);
    } catch (IllegalArgumentException e) {
      p.method_7353(class_2561.method_43470(e.getMessage()), false);
    }
  }

  @Override
  public class_1269 method_7884(class_1838 context) {
    select(context.method_8036());
    return class_1269.method_29236(context.method_8045().field_9236);
  }

  @Override
  public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
    select(player);
    return class_1271.method_29237(player.method_5998(hand), level.field_9236);
  }

  @Override
  public void method_7851(class_1799 s, class_1937 l, List<class_2561> lines, class_1836 flag) {
    lines.add(class_2561.method_43471("tooltip.splineroads.remover"));
  }
}
