package com.sora.splineroads.world;

import com.sora.splineroads.core.TollPlaza.Spec;
import java.io.*;
import java.security.*;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Client commands carry authored settings, never the potentially large preview context. */
public final class TollInputs {
  public static class_2487 command(class_2487 payload){
    var out=new class_2487();
    for(String key:List.of("Id","Points","Dimension","InlineRoad","InlineStation","InlineSignature","Adjust","SelectionStamp"))
      if(payload.method_10545(key))out.method_10566(key,payload.method_10580(key).method_10707());
    out.method_10556("CompactToll",true);
    out.method_10566("Spec",TollCodec.config(TollCodec.config(payload.method_10562("Spec"))));
    return out;
  }
  static String stamp(class_2487 payload){
    var context=new class_2487();
    for(String key:List.of("Points","Spec","SnapshotA","SnapshotB","Connections","Revision","Id","Dimension"))
      if(payload.method_10545(key))context.method_10566(key,payload.method_10580(key));
    try{
      var digest=MessageDigest.getInstance("SHA-256");
      try(var out=new DataOutputStream(new DigestOutputStream(OutputStream.nullOutputStream(),digest))){canonical(context,out);}
      return HexFormat.of().formatHex(digest.digest());
    }catch(IOException|NoSuchAlgorithmException e){throw new IllegalStateException("收费站选择校验失败",e);}
  }
  private static void canonical(class_2520 tag,DataOutput out)throws IOException{
    out.writeByte(tag.method_10711());
    if(tag instanceof class_2487 compound){out.writeInt(compound.method_10546());for(String key:new TreeSet<>(compound.method_10541())){out.writeUTF(key);canonical(compound.method_10580(key),out);}}
    else if(tag instanceof class_2499 list){out.writeInt(list.size());for(class_2520 value:list)canonical(value,out);}
    else tag.method_10713(out);
  }
  static class_2487 expand(class_3218 level,class_3222 player,class_2487 command){
    if(!command.method_10577("CompactToll"))return command;
    var authoritative=TollRoads.payload(level,player,command.method_10565("Points"),command.method_25928("Id")?command.method_25926("Id"):null);
    if(!authoritative.method_10558("SelectionStamp").equals(command.method_10558("SelectionStamp"))
        ||!authoritative.method_10558("Dimension").equals(command.method_10558("Dimension")))
      throw new IllegalArgumentException("端点或连接道路已变化，请重新打开收费站");
    var original=TollCodec.read(authoritative.method_10562("Spec"));
    authoritative.method_10566("Spec",TollCodec.write(new Spec(original.a(),original.b(),TollCodec.config(command.method_10562("Spec")),original.portA(),original.portB(),original.path())));
    authoritative.method_10582("Adjust",command.method_10558("Adjust"));
    for(String key:List.of("Token","Request"))if(command.method_10545(key))authoritative.method_10566(key,command.method_10580(key).method_10707());
    return authoritative;
  }
  private TollInputs(){}
}
