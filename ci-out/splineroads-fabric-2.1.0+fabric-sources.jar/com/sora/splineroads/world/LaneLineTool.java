package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadAttachments.Paint;
import com.sora.splineroads.core.RoadAttachments.Range;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadLaneLines.Line;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
public final class LaneLineTool extends class_1792 {
  public LaneLineTool(){super(new class_1793().method_7889(1));}
  @Override public class_1269 method_7884(class_1838 c){
    if(c.method_8045().field_9236)return class_1269.field_5812;
    if(c.method_8036() instanceof class_3222 p)try{
      var built=RoadTool.pick(p);if(built==null)throw new IllegalArgumentException("请右键要编辑的道路");
      if(built.record.junction()!=null||built.record.toll()!=null)throw new IllegalArgumentException("请选中路口外的独立路段");
      RoadData.requireOwner(p,built.record.owner());
      if(!RoadProfile.modern(built.record.settings().style()))throw new IllegalArgumentException("请先把旧式道路更新为普通道路或高速公路");
      var t=new class_2487();t.method_10582("Kind","laneLines");t.method_25927("Id",built.record.id());t.method_10569("Signature",GantryTool.signature(built.record));t.method_10566("Settings",RoadRecord.writeSettings(built.record.settings()));
      var lines=new class_2499();int selected=0,n=0;double best=Double.POSITIVE_INFINITY;
      var hit=c.method_17698();double lateral=RoadQueries.horizontal(built.mesh,new V(hit.field_1352,hit.field_1351,hit.field_1350)).lateral();
      for(var line:RoadLaneLines.lines(built.mesh)){var e=new class_2487();e.method_10582("Key",line.key());e.method_10582("Label",line.label());e.method_10549("Offset",line.offset());lines.add(e);double d=Math.abs(line.offset()-lateral);if(d<best){best=d;selected=n;}n++;}
      var at=RoadQueries.horizontal(built.mesh,new V(hit.field_1352,hit.field_1351,hit.field_1350)).sample();
      double station=Math.min(built.mesh.length()-1e-6,Math.max(0,at.distance()));var range=RoadAttachments.range(built.mesh,station);var paint=RoadAttachments.paint(built.mesh,station);t.method_10549("Station",station);t.method_10549("RangeStart",range.start());t.method_10549("RangeEnd",range.end());t.method_10566("Settings",RoadRecord.writeSettings(built.record.settings().options(built.record.settings().options().laneLines(paint.lines()).hideArrows(paint.hideArrows()))));t.method_10549("RoadYaw",RoadPlanner.yaw(at.left().left().mul(-1)));t.method_10549("PlayerYaw",p.method_36454());t.method_10566("Lines",lines);t.method_10569("Selected",selected);t.method_10549("Width",built.record.settings().width());RoadNetwork.open(p,t);
    }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}
    return class_1269.field_21466;
  }
}
