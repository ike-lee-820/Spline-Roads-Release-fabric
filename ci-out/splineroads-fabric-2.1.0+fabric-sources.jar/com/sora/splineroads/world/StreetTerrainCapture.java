package com.sora.splineroads.world;

import com.sora.splineroads.config.StreetServerConfig;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.StreetPlan.*;
import java.util.*;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.world.level.block.*;

/** Bounded server-thread capture. At most one new chunk is acquired per step. */
public final class StreetTerrainCapture {
  private final class_3218 level;private final Iterator<Cell> remaining;private final Map<Cell,StreetTerrain.Chunk> result=new TreeMap<>();
  private Cell cell;private int column=256;private int[] heights;private byte[] ground;private long[] fingerprints;
  private int completed;private final int count;private boolean done;
  public StreetTerrainCapture(class_3218 level,Set<Cell> cells){
    if(cells.size()>StreetServerConfig.MAX_CHUNKS.get())throw new IllegalArgumentException("选区超过服务器路网区块上限");
    this.level=level;count=cells.size();remaining=new TreeSet<>(cells).iterator();
  }
  public boolean step(){
    if(!level.method_8503().method_18854())throw new IllegalStateException("地形必须在服务端线程读取");if(done)return true;
    if(column==256){if(!remaining.hasNext()){done=true;return true;}cell=remaining.next();column=0;heights=new int[256];ground=new byte[256];fingerprints=new long[256];}
    long until=System.nanoTime()+StreetServerConfig.WORK_MICROS.get()*1000L;int budget=StreetServerConfig.CAPTURE_COLUMNS.get();
    try(var lease=RoadWorkChunks.open(level)){
      lease.load(Set.of(class_1923.method_8331(cell.x(),cell.z())));
      do{int x=cell.x()*16+column%16,z=cell.z()*16+column/16;var value=column(level,x,z);heights[column]=value.height;ground[column]=(byte)value.ground.ordinal();fingerprints[column]=value.fingerprint;column++;budget--;}while(column<256&&budget>0&&System.nanoTime()<until);
    }
    if(column==256){result.put(cell,new StreetTerrain.Chunk(heights,ground,fingerprints));completed++;}
    return false;
  }
  public int completed(){return completed;}public int count(){return count;}public StreetTerrain snapshot(){return new StreetTerrain(result);}
  record Column(int height,Ground ground,long fingerprint){}
  static Column column(class_3218 level,int x,int z){
    int height=level.method_8624(class_2902.class_2903.field_13202,x,z);Ground ground=Ground.LAND;
    while(height>level.method_31607()&&plant(level.method_8320(new class_2338(x,height-1,z))))height--;
    if(height<=level.method_31607()||height+10>=level.method_31600())ground=Ground.OBSTACLE;
    long hash=0xcbf29ce484222325L;
    // Hash the natural deck/earthwork band and all potential overhead fixtures.
    // A building's roof is an obstacle even when its interior is hollow.
    for(int y=Math.max(level.method_31607(),height-5);y<Math.min(level.method_31600(),height+11);y++){
      var p=new class_2338(x,y,z);var state=level.method_8320(p);var entity=state.method_31709()?level.method_8321(p):null;
      // Grass can spread to dirt below transparent road colliders between ticks.
      // Treat only this natural surface-cover change as equivalent; height,
      // every other block, fluid and block-entity payload stay fingerprinted.
      var fingerprintState=state.method_27852(class_2246.field_10219)?class_2246.field_10566.method_9564():state;
      hash=(hash^class_2248.method_9507(fingerprintState))*0x100000001b3L;hash=(hash^(entity==null?0:entity.method_38242().hashCode()))*0x100000001b3L;
      if(!state.method_26227().method_15769())ground=Ground.WATER;
      else if(RoadBlocks.isCollider(state)||entity instanceof NodeEntity){if(ground==Ground.LAND)ground=Ground.ROAD;}
      else if(entity!=null||!natural(state))ground=Ground.OBSTACLE;
    }
    hash=(hash^height)*0x100000001b3L;return new Column(height,ground,hash);
  }
  static boolean natural(class_2680 state){
    var block=state.method_26204();return state.method_26215()||block==class_2246.field_10219||state.method_26164(class_3481.field_29822)||state.method_26164(class_3481.field_25806)
        ||state.method_26164(class_3481.field_15466)||block==class_2246.field_10255||block==class_2246.field_10460||block==class_2246.field_10477||block==class_2246.field_10491||block==class_2246.field_9987
        ||block==class_2246.field_10479||block==class_2246.field_10214||block==class_2246.field_10112||block==class_2246.field_10313||state.method_26164(class_3481.field_20339);
  }
  private static boolean plant(class_2680 state){var b=state.method_26204();return b==class_2246.field_10479||b==class_2246.field_10214||b==class_2246.field_10112||b==class_2246.field_10313||state.method_26164(class_3481.field_20339);}
}
