package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.ElevatedAccess.Plan;
import com.sora.splineroads.core.ElevatedAccess.Reservation;
import com.sora.splineroads.core.LanePoints.Data;
import com.sora.splineroads.core.LanePoints.Opening;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadLanes.Counts;
import com.sora.splineroads.core.RoadProfile.Layout;
import com.sora.splineroads.core.RoadSidewalks.Config;
import com.sora.splineroads.core.RoadTransitions.Ends;
import com.sora.splineroads.core.RoadTransitions.Section;
import com.sora.splineroads.net.*;
import com.sora.splineroads.world.ElevatedAccessChain.Result;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Authoritative preview, atomic installation and restoration of elevated terminals. */
public final class ElevatedAccessRoads {
  private record Approval(UUID owner,class_2487 key,class_2487 receipt,long created){}
  private static final Map<RoadData,Map<UUID,Approval>> APPROVALS=new WeakHashMap<>();
  public static boolean saved(RoadData data,UUID id){return id!=null&&data.interchanges.getOrDefault(id,new class_2487()).method_10577("ElevatedAccess");}
  static LanePoints.Data logicalLanes(RoadRecord street,RoadRecord live){
    var lanes=LaneTopology.metadata(live);
    if(lanes.access().isEmpty()||street==live)return lanes;
    double shift=street.fragment()!=null&&live.fragment()!=null&&street.fragment().source().equals(live.fragment().source())
        ? live.fragment().origin()-street.fragment().origin()
        : RoadQueries.horizontal(street.rawMesh(),live.rawMesh().first().center()).sample().distance();
    if(Math.abs(shift)<1e-8)return lanes;
    var ids=new HashSet<UUID>();lanes.access().forEach(a->ids.add(a.connection()));
    var access=lanes.access().stream().map(a->ElevatedAccess.shifted(a,shift)).toList();
    var cuts=new ArrayList<>(lanes.cuts().stream().filter(c->!ids.contains(c.connection())).toList());
    var adds=new ArrayList<>(lanes.additions().stream().filter(a->!ids.contains(a.connection())).toList());
    for(var reservation:access){cuts.addAll(reservation.cuts());adds.addAll(reservation.additions());}
    return lanes.cuts(cuts).additions(adds).access(access);
  }
  static void protect(RoadData data,List<RoadIndex.Built> proposed,Set<UUID> removed){
    var all=LaneTopology.records(data);removed.forEach(all::remove);for(var b:proposed)all.put(b.record.id(),b.record);
    for(var entry:data.interchanges.entrySet())if(entry.getValue().method_10577("ElevatedAccess")&&all.containsKey(entry.getKey())){
      var t=entry.getValue();var old=data.index.roads.get(t.method_25926("Main"));var next=all.get(t.method_25926("Main"));
      if(old==null||next==null)throw new IllegalArgumentException("主路仍连接高架，请同时删除依赖的高架连接");
      if(!sameGeometry(old.record,next)||next.settings().options().attachments().points().stream().noneMatch(p->p.id().equals(t.method_25926("Point"))&&p.elevated()))
        throw new IllegalArgumentException("主路已有高架出入口；改变主路线形或断面前，请先删除该连接");
      for(UUID member:members(t))if(!member.equals(next.id())){
        var prior=data.index.roads.get(member);var proposedRoad=all.get(member);
        if(prior==null||proposedRoad==null||!sameGeometry(prior.record,proposedRoad))throw new IllegalArgumentException("此段承载相邻高架出入口的辅路，请先删除连接");
      }
      var end=class_2338.method_10092(t.method_10537("Endpoint"));var neighbors=all.values().stream().filter(r->!r.id().equals(entry.getKey())&&(r.a().equals(end)||r.b().equals(end))).toList();
      if(neighbors.size()>1||neighbors.isEmpty()&&!data.index.atNode(end).stream().allMatch(entry.getKey()::equals))throw new IllegalArgumentException("高架出入口只能连接道路尽头，不能把此端点改成多路交汇");
      for(var r:neighbors){var before=data.index.roads.get(r.id());if(before==null||!sameGeometry(before.record,r))throw new IllegalArgumentException("该道路尽头连接高架出入口，请先删除连接再改变其线形或断面");}
    }
  }
  private static boolean sameGeometry(RoadRecord a,RoadRecord b){return sameNode(a.start(),b.start())&&sameNode(a.end(),b.end())
      &&sameSamples(a.rawMesh().samples(),b.rawMesh().samples())&&a.settings().thickness()==b.settings().thickness()
      &&a.settings().style()==b.settings().style()&&RoadLanes.counts(a.settings()).equals(RoadLanes.counts(b.settings()))
      &&a.settings().options().leftTraffic()==b.settings().options().leftTraffic()&&sameEnds(a.settings(),b.settings());}
  private static boolean sameMeasure(double a,double b){return Math.abs(a-b)<=1e-9;}
  private static boolean sameNode(Node a,Node b){return a.position().distance(b.position())<=1e-9&&sameMeasure(a.yaw(),b.yaw())&&sameMeasure(a.grade(),b.grade());}
  private static boolean sameSamples(List<Sample> a,List<Sample> b){
    if(a.size()!=b.size())return false;for(int i=0;i<a.size();i++){var x=a.get(i);var y=b.get(i);
      if(x.center().distance(y.center())>1e-9||x.left().distance(y.left())>1e-9||!sameMeasure(x.distance(),y.distance())||!sameMeasure(x.halfWidth(),y.halfWidth()))return false;
    }return true;
  }
  // Adding an identical continuation materializes a formerly implicit end section.
  // Accept that representation change only; changed physical sections stay protected.
  private static boolean sameEnds(Settings a,Settings b){
    var x=a.options().ends();var y=b.options().ends();if(x.equals(y))return true;
    return x.persistent()==y.persistent()&&sameMeasure(x.trimmedStart(),y.trimmedStart())&&sameMeasure(x.trimmedEnd(),y.trimmedEnd())
        &&Objects.equals(x.port(),y.port())&&sameMeasure(x.paintPhase(),y.paintPhase())&&sameMeasure(x.startHold(),y.startHold())&&sameMeasure(x.endHold(),y.endHold())
        &&sameTerminal(x.start(),y.start(),a,b)&&sameTerminal(x.end(),y.end(),a,b);
  }
  private static boolean sameTerminal(RoadTransitions.Section a,RoadTransitions.Section b,Settings ownA,Settings ownB){
    if(Objects.equals(a,b))return true;if(a!=null&&b!=null)return false;
    var x=a==null?RoadTransitions.Section.of(ownA):a;var y=b==null?RoadTransitions.Section.of(ownB):b;
    var wx=x.sidewalk()==null?RoadSidewalks.Config.DEFAULT:x.sidewalk();var wy=y.sidewalk()==null?RoadSidewalks.Config.DEFAULT:y.sidewalk();
    if(wx.enabled()!=wy.enabled()||wx.enabled()&&!wx.equals(wy)||x.cycle()!=y.cycle()||x.curb()!=y.curb()||x.cycleRail()!=y.cycleRail()||x.outerRail()!=y.outerRail()||x.cycleAsphalt()!=y.cycleAsphalt()||!Objects.equals(x.streetscape(),y.streetscape()))return false;
    var lx=x.layout(ownA.options().leftTraffic());var ly=y.layout(ownB.options().leftTraffic());
    if(!lx.catalog().equals(ly.catalog())||lx.outside()!=ly.outside())return false;
    double[] ax={x.width(),lx.laneWidth(),lx.median(),lx.motorMin(),lx.motorMax(),lx.cycleWidth(),lx.curbWidth(),lx.shoulderWidth(),lx.medianCenter(),x.port()==null?lx.curbWidth():x.port().curbLeft(),x.port()==null?lx.curbWidth():x.port().curbRight()};
    double[] ay={y.width(),ly.laneWidth(),ly.median(),ly.motorMin(),ly.motorMax(),ly.cycleWidth(),ly.curbWidth(),ly.shoulderWidth(),ly.medianCenter(),y.port()==null?ly.curbWidth():y.port().curbLeft(),y.port()==null?ly.curbWidth():y.port().curbRight()};
    for(int i=0;i<ax.length;i++)if(Math.abs(ax[i]-ay[i])>1e-9)return false;
    var dx=lx.dividers().stream().sorted().toList();var dy=ly.dividers().stream().sorted().toList();if(dx.size()!=dy.size())return false;
    for(int i=0;i<dx.size();i++)if(Math.abs(dx.get(i)-dy.get(i))>1e-9)return false;return true;
  }
  static void prune(RoadData data){data.interchanges.entrySet().removeIf(e->e.getValue().method_10577("ElevatedAccess")&&!data.index.roads.containsKey(e.getKey()));}
  private static RoadIndex.Built host(RoadData data,UUID id){var b=data.index.roads.get(id);
    if(b==null||b.record.assembly()!=null||b.record.junction()!=null||b.record.toll()!=null||b.record.railway()||LaneTopology.metadata(b.record).link()!=null)
      throw new IllegalArgumentException("高架出入点的主路已变化，请重新选择普通道路或高速道路");return b;}
  private static RoadAttachments.Point point(RoadRecord road,UUID id){return road.settings().options().attachments().points().stream().filter(p->p.id().equals(id)&&p.elevated()).findFirst().orElseThrow(()->new IllegalArgumentException("高架出入点已不存在"));}
  private static List<RoadIndex.Built> endpoint(RoadData data,class_2338 endpoint,UUID edited){
    var roads=data.index.atNode(endpoint).stream().filter(id->!id.equals(edited)).map(data.index.roads::get).toList();
    if(roads.size()!=1||!ElevatedPointTool.supported(roads.get(0).record))
      throw new IllegalArgumentException("高架出入口须连接已有高架的尽头端点");
    var road=roads.get(0);
    double station=road.record.a().equals(endpoint)?Math.min(.25,road.mesh.length()/2):Math.max(0,road.mesh.length()-.25);
    if(!RoadStreetscape.raised(road.mesh,RoadStructures.sample(road.mesh,station)))
      throw new IllegalArgumentException("所选道路尽头须为高架路段");
    return roads;
  }
  public static class_2487 payload(class_3218 level,class_3222 player,UUID main,UUID marker,class_2338 end,boolean first,UUID edited){
    var data=RoadData.get(level);var host=host(data,main);var point=point(host.record,marker);
    if(edited==null&&LaneTopology.metadata(host.record).access().stream().anyMatch(a->a.point().equals(marker)))throw new IllegalArgumentException("该高架出入点已连接道路，请编辑已有连接");
    if(edited!=null){
      var receipt=data.interchanges.get(edited);
      if(!saved(data,edited)||!data.index.roads.containsKey(edited)||!main.equals(receipt.method_25926("Main"))
          ||!marker.equals(receipt.method_25926("Point"))||end.method_10063()!=receipt.method_10537("Endpoint")||first!=receipt.method_10577("MainFirst"))
        throw new IllegalArgumentException("已建高架连接已改变，请重新选择");
    }
    var node=RoadData.requireNode(level,end,player);var connected=endpoint(data,end,edited);
    if(player!=null){RoadData.requireOwner(player,host.record.owner());for(var b:connected)RoadData.requireOwner(player,b.record.owner());}
    var station=RoadQueries.horizontal(host.mesh,point.position()).sample();var counts=RoadLanes.counts(host.record.settings());
    if(!RoadLanes.counts(connected.get(0).record.settings()).twoWay())first=connected.get(0).record.a().equals(end);
    int axis=!counts.twoWay()?(first?1:-1):node.node().position().sub(station.center()).dot(station.left().left().mul(-1))<0?-1:1;
    boolean positive=(first?axis:-axis)>0;int maxForward=positive?counts.forward():counts.reverse(),maxReverse=positive?counts.reverse():counts.forward();
    var upper=connected.get(0).record;
    boolean atFirst=upper.a().equals(end);
    Settings settings=RoadEndpointSections.section(upper.caps(0).mesh(),atFirst,atFirst!=first);
    var t=new class_2487();t.method_10582("Kind","elevatedAccess");t.method_10582("Dimension",level.method_27983().method_29177().toString());t.method_25927("Main",main);t.method_25927("Point",marker);t.method_10544("Endpoint",end.method_10063());t.method_10556("MainFirst",first);t.method_10569("Signature",host.record.header().hashCode());t.method_10569("TargetSignature",Objects.hash(node.node(),connected.stream().map(b->b.record.header()).toList()));
    t.method_10569("MaxForward",maxForward);t.method_10569("MaxReverse",maxReverse);t.method_10556("Locked",true);t.method_10566("Settings",RoadRecord.writeSettings(settings));if(edited!=null)t.method_25927("Id",edited);return t;
  }
  static void select(class_3222 player,class_2487 tool,RoadIndex.Built road,RoadAttachments.Point marker){
    if(tool.method_25928("SideMain"))throw new IllegalArgumentException("高架出入点须连接已有高架的尽头端点");
    String dimension=player.method_37908().method_27983().method_29177().toString();
    if(tool.method_10545("Start")&&dimension.equals(tool.method_10558("Dimension"))){open(player,tool,payload(player.method_51469(),player,road.record.id(),marker.id(),class_2338.method_10092(tool.method_10537("Start")),false,null));return;}
    tool.method_10551("ElevatedSelection");tool.method_10551("SideSelection");tool.method_10551("Start");tool.method_10551(CurveControlNodes.KEY);tool.method_25927("SideMain",road.record.id());tool.method_25927("SidePoint",marker.id());tool.method_10582("Dimension",dimension);
    player.method_7353(net.minecraft.class_2561.method_43470("已选高架出入点，请右键已有高架的尽头端点"),true);
  }
  static void open(class_3222 player,class_2487 tool,class_2487 payload){tool.method_10566("ElevatedSelection",selection(payload));RoadNetwork.open(player,payload);}
  public static void open(class_3222 player,UUID id){var data=RoadData.get(player.method_51469());var saved=data.interchanges.get(id);if(saved==null)throw new IllegalArgumentException("高架连接已删除");var t=payload(player.method_51469(),player,saved.method_25926("Main"),saved.method_25926("Point"),class_2338.method_10092(saved.method_10537("Endpoint")),saved.method_10577("MainFirst"),id);
    previewConnector(t,data.index.roads.get(id).record);
    RoadNetwork.open(player,t);
  }
  private static void previewConnector(class_2487 t,RoadRecord connector){
    var records=new class_2499();records.add(connector.save());t.method_10566("PlannerPreview",records);
  }
  private static class_2487 selection(class_2487 t){var key=new class_2487();for(String field:List.of("Main","Point","Endpoint","MainFirst","Dimension"))if(t.method_10545(field))key.method_10566(field,t.method_10580(field).method_10707());return key;}
  private static class_2487 key(class_2487 t){var key=selection(t);for(String field:List.of("Id","Settings","Signature","TargetSignature"))if(t.method_10545(field))key.method_10566(field,t.method_10580(field).method_10707());return key;}
  public static void requireSelection(class_3222 player,net.minecraft.class_1799 tool,class_2487 t){if(!t.method_25928("Id")&&!tool.method_7948().method_10562("ElevatedSelection").equals(selection(t)))throw new IllegalArgumentException("高架选点已改变，请重新选择");}

  public static class_2487 preview(class_3218 level,class_3222 player,class_2487 command){try(var chunks=RoadWorkChunks.open(level)){
    var data=RoadData.get(level);UUID edited=command.method_25928("Id")?command.method_25926("Id"):null;
    var fresh=payload(level,player,command.method_25926("Main"),command.method_25926("Point"),class_2338.method_10092(command.method_10537("Endpoint")),command.method_10577("MainFirst"),edited);
    if(!fresh.method_10558("Dimension").equals(command.method_10558("Dimension"))||fresh.method_10550("Signature")!=command.method_10550("Signature")||fresh.method_10550("TargetSignature")!=command.method_10550("TargetSignature"))throw new IllegalArgumentException("道路或端点已改变，请重新打开高架连接设置");
    var host=host(data,command.method_25926("Main"));var marker=point(host.record,command.method_25926("Point"));
    if(LaneTopology.metadata(host.record).access().stream().anyMatch(a->a.point().equals(marker.id())&&!a.connection().equals(edited)))throw new IllegalArgumentException("该高架出入点已连接道路，请编辑已有连接");
    var requested=RoadRecord.readSettings(command.method_10562("Settings"));var inherited=RoadRecord.readSettings(fresh.method_10562("Settings"));
    var selected=RoadLanes.counts(requested);
    if(!selected.equals(RoadLanes.counts(inherited)))throw new IllegalArgumentException("已有高架尽头须保持其实际各方向车道数");
    if(selected.forward()>fresh.method_10550("MaxForward")||selected.reverse()>fresh.method_10550("MaxReverse"))throw new IllegalArgumentException("高架车道数不能超过下方道路对应方向");
    var clean=inherited;
    clean=clean.options(clean.options().attachments(RoadAttachments.Data.EMPTY).lanePoints(LanePoints.Data.EMPTY).route(RoadProfile.Routing.DEFAULT.fit(false)));
    var end=class_2338.method_10092(command.method_10537("Endpoint"));var node=RoadData.requireNode(level,end,player).node();var links=endpoint(data,end,edited);
    {var road=links.get(0);boolean first=road.record.a().equals(end);var geometry=road.record.caps(0).mesh();var s=first?geometry.first():geometry.last();V direction=s.left().left().mul(first?-1:1);var n=first?road.record.start():road.record.end();node=new Node(s.center(),RoadPlanner.yaw(direction),n.grade()*(first?1:-1));}
    UUID id=edited==null?UUID.randomUUID():edited;
    var original=without(host.record,id);
    var result=ElevatedAccessChain.plan(data,original,marker,id,node,clean,fresh.method_10577("MainFirst"));
    var plan=result.plan();
    var affected=new LinkedHashSet<>(result.reservations().keySet());
    if(edited!=null)affected.addAll(members(data.interchanges.get(edited)));
    var changes=new ArrayList<RoadIndex.Built>();
    var opening=new LanePoints.Opening(id,plan.road().samples().stream().map(Sample::center).toList(),plan.road().samples().stream().mapToDouble(Sample::halfWidth).max().orElseThrow());
    for(var member:affected){
      var road=without(host(data,member).record,id);
      if(player!=null)RoadData.requireOwner(player,road.owner());
      var reservation=result.reservations().get(member);
      if(reservation!=null){
        var md=LaneTopology.metadata(road);
        var access=new ArrayList<>(md.access());access.add(reservation);
        var cuts=new ArrayList<>(md.cuts());cuts.addAll(reservation.cuts());
        var additions=new ArrayList<>(md.additions());additions.addAll(reservation.additions());
        var openings=new ArrayList<>(md.openings());openings.add(opening);
        road=road.withLanePoints(md.access(access).cuts(cuts).additions(additions).openings(openings));
      }
      changes.add(new RoadIndex.Built(road.structures(List.of())));
    }
    var path=plan.road();var a=RoadRibbon.start(path);var b=RoadRibbon.end(path);var pa=class_2338.method_49637(a.position().x(),a.position().y(),a.position().z());var pb=class_2338.method_49637(b.position().x(),b.position().y(),b.position().z());
    // Finite sampled secants are not the authored endpoint derivative. Keep
    // the upper road's exact grade, including a flat terminal at a crest.
    if(fresh.method_10577("MainFirst"))b=new Node(b.position(),b.yaw(),node.grade()*(b.direction().dot(node.direction())<0?-1:1));
    else a=new Node(a.position(),a.yaw(),node.grade()*(a.direction().dot(node.direction())<0?-1:1));
    var connector=new RoadRecord(id,host.record.owner(),fresh.method_10577("MainFirst")?pa:end,fresh.method_10577("MainFirst")?end:pb,a,b,path.settings(),false,4).alignment(id,path);
    // Check the complete physical lane deck. Reserved holes permit only the
    // selected access; the other lanes remain ordinary protected road space.
    var nodes=new HashSet<class_2338>();nodes.add(end);
    for(var changed:changes){
      Interchanges.checkExternal(connector.mesh(),changed.mesh,null);
      nodes.add(changed.record.a());nodes.add(changed.record.b());
    }
    var removed=new HashSet<>(affected);if(edited!=null)removed.add(edited);
    UUID token=UUID.randomUUID();changes.add(new RoadIndex.Built(connector));
    var prepared=data.prepareAssembly(level,player,changes,removed,nodes,List.of(),token,Set.of(connector.id()),true);
    var receipt=selection(fresh);receipt.method_25927("Id",id);receipt.method_10556("ElevatedAccess",true);receipt.method_25927("Owner",host.record.owner());receipt.method_10566("Settings",RoadRecord.writeSettings(clean));
    var hosts=new class_2499();for(UUID member:result.reservations().keySet())hosts.add(net.minecraft.class_2512.method_25929(member));receipt.method_10566("Hosts",hosts);
    var table=APPROVALS.computeIfAbsent(data,d->new LinkedHashMap<>());table.entrySet().removeIf(e->System.nanoTime()-e.getValue().created()>600_000_000_000L||Objects.equals(e.getValue().owner(),player==null?null:player.method_5667()));table.put(token,new Approval(player==null?null:player.method_5667(),key(command),receipt,System.nanoTime()));
    while(table.size()>4)table.remove(table.keySet().iterator().next());var reply=command.method_10553();reply.method_10551("Action");reply.method_10582("Kind","elevatedAccess");reply.method_25927("Token",token);previewConnector(reply,prepared.stream().filter(p->p.record.id().equals(id)).findFirst().orElseThrow().record);RoadActionContext.echo(command,reply);return reply;
  }}
  public static String build(class_3218 level,class_3222 player,class_2487 t){var data=RoadData.get(level);var table=APPROVALS.get(data);var approval=table==null||!t.method_25928("Token")?null:table.remove(t.method_25926("Token"));
    if(approval==null||!Objects.equals(approval.owner(),player==null?null:player.method_5667())||System.nanoTime()-approval.created()>600_000_000_000L||!approval.key().equals(key(t)))throw new IllegalArgumentException("高架连接预览已失效，请重新计算预览");
    data.buildPrepared(level,player,t.method_25926("Token"),()->data.interchanges.put(approval.receipt().method_25926("Id"),approval.receipt().method_10553()));return "高架上下坡连接已建造，地面车道和直行辅路已同步更新";
  }
  static void remove(class_3218 level,class_3222 player,UUID id){var data=RoadData.get(level);var saved=data.interchanges.get(id);if(saved==null)return;
    var replacements=new ArrayList<RoadIndex.Built>();var removed=new HashSet<UUID>();removed.add(id);var nodes=new HashSet<class_2338>();
    for(var member:members(saved)){
      var main=data.index.roads.get(member);if(main==null)continue;
      replacements.add(new RoadIndex.Built(without(main.record,id).structures(List.of())));
      removed.add(member);nodes.add(main.record.a());nodes.add(main.record.b());
    }
    nodes.add(class_2338.method_10092(saved.method_10537("Endpoint")));data.replaceAssembly(level,player,replacements,removed,nodes);data.interchanges.remove(id);data.method_80();
  }
  private static Set<UUID> members(class_2487 saved){
    var ids=new LinkedHashSet<UUID>();ids.add(saved.method_25926("Main"));
    for(var t:saved.method_10554("Hosts",class_2520.field_33261))ids.add(class_2512.method_25930(t));
    return ids;
  }
  private static RoadRecord without(RoadRecord road,UUID id){
    var md=LaneTopology.metadata(road);
    return road.withLanePoints(md.access(md.access().stream().filter(a->!a.connection().equals(id)).toList())
        .cuts(md.cuts().stream().filter(c->!c.connection().equals(id)).toList())
        .additions(md.additions().stream().filter(a->!a.connection().equals(id)).toList())
        .openings(md.openings().stream().filter(o->!o.connection().equals(id)).toList()));
  }
  private ElevatedAccessRoads(){}
}
