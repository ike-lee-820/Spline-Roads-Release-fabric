package com.sora.splineroads.world;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Ref;
import com.sora.splineroads.core.RoadAprons.Cell;
import com.sora.splineroads.core.RoadAprons.JunctionCell;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.core.RoadStructures.Ground;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.world.RoadIndex.Built.Column;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2482;
import net.minecraft.class_2680;
import net.minecraft.class_2771;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.world.level.block.*;
import java.util.*;
import java.util.Map.Entry;

/** Real apron blocks share the sidewalk transaction's original-state/rollback ledger. */
final class SmartRoadAprons {
 static boolean material(class_2680 state){return state.method_27852(SplineRoads.ROAD_BLOCK.get())||state.method_27852(SplineRoads.ROAD_SLAB.get());}
 static Set<Long> plan(Map<Long,class_2680> paving,Collection<RoadIndex.Built> roads,class_3218 level,Map<Long,class_2680> originals,Map<Long,class_2680> previous,Set<Long> previousAprons,Collection<RoadIndex.Built> dirty){
  var aprons=new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
  var affected=new HashSet<Long>();for(var r:dirty)affected.addAll(RoadCoverage.chunks(r.mesh,3));
  // Keep untouched roads without re-reading their terrain or re-rasterizing the city.
  for(var e:previous.entrySet())if(previousAprons.contains(e.getKey())&&!affected.contains(new class_1923(class_2338.method_10092(e.getKey())).method_8324()))put(paving,aprons,e.getKey(),e.getValue());
  var local=new ArrayList<RoadIndex.Built>();var byChunk=new HashMap<Long,List<RoadIndex.Built>>();
  for(var r:roads){if(!Collections.disjoint(RoadCoverage.chunks(r.mesh,3),affected))local.add(r);for(long c:r.chunks)if(affected.contains(c))byChunk.computeIfAbsent(c,k->new ArrayList<>()).add(r);}
  record Candidate(double top,RoadIndex.Built road){}
  var candidates=new TreeMap<Long,Candidate>();
  var ground=RoadTerrain.read(level,Map.of(),originals,new RoadTerrain.Cache(Map.of(),originals));
  for(var r:local){if(r.record.junction()!=null&&r.record.junction().get().arm()<0){
    var ref=r.record.junction();if(ref.piece()!=ref.spec().arms().size())continue;
    for(var jc:RoadAprons.junctionCells(ref,s->grounded(s,ground,1))){var c=jc.cell();long chunk=class_1923.method_8331(c.x()>>4,c.z()>>4);if(!affected.contains(chunk))continue;
      var owner=local.stream().filter(v->Objects.equals(v.record.assembly(),r.record.assembly())&&v.record.junction()!=null&&v.record.junction().get().arm()==jc.arm()).findFirst().orElse(r);
      candidates.merge(class_2338.method_10064(c.x(),0,c.z()),new Candidate(c.top(),owner),(a,b)->a.top()<=b.top()?a:b);
    }continue;
   }
   for(var c:RoadAprons.cells(r.mesh,(sample,side)->grounded(sample,ground,side))){long chunk=class_1923.method_8331(c.x()>>4,c.z()>>4);if(affected.contains(chunk))candidates.merge(class_2338.method_10064(c.x(),0,c.z()),new Candidate(c.top(),r),(a,b)->a.top()<=b.top()?a:b);}
  }
  for(var entry:candidates.entrySet()){
   RoadPlanningBudget.check();var column=class_2338.method_10092(entry.getKey());double roadTop=entry.getValue().top();var owner=entry.getValue().road();
   boolean terrainMode=owner.record.railway()||owner.record.settings().options().streetscape().apron()==RoadStreetscape.Apron.TERRAIN;
   // Half-block steps follow slopes without raising pavement or changing its width.
   double top=Math.floor(roadTop*2+1e-6)/2;int y=(int)Math.ceil(top)-1;var p=new class_2338(column.method_10263(),y,column.method_10260());
   if(level.method_31606(p)||!level.method_8621().method_11952(p)||!RoadWorkChunks.terrainAvailable(level,p))continue;
   class_2680 desired=top-y<.75?SplineRoads.ROAD_SLAB.get().method_9564().method_11657(class_2482.field_11501,class_2771.field_12681):SplineRoads.ROAD_BLOCK.get().method_9564();
   var near=byChunk.getOrDefault(new class_1923(p).method_8324(),List.of());boolean blocked=false;
   for(var r:near){if(r.tunnelAt(p)||r.cycleBodyAt(p)){blocked=true;break;}var c=r.column(p);if(c!=null&&y+1>=c.minTop()-1e-7&&y<c.maxTop()+4.25){
     // Partial edge cells use a capped full texture through RoadFillEntity; never
     // substitute a slab model whose top lies above the cap or into another road.
     if(GroundTerrainJoin.usable(GroundTerrainJoin.cap(p,SplineRoads.ROAD_BLOCK.get().method_9564(),near)))desired=SplineRoads.ROAD_BLOCK.get().method_9564();else {blocked=true;break;}
    }else if(r.clearanceAt(p)){blocked=true;break;}}
   if(blocked)continue;
   class_2680 chosen=terrainMode?adjacent(level,owner.mesh,p,originals,previous):SplineRoads.ROAD_BLOCK.get().method_9564();
   if(chosen==null)continue;if(terrainMode)desired=chosen;
   var current=RoadPlanInputs.state(level,p);var base=terrain(current,p,originals,previous);
   if(previous.containsKey(p.method_10063())&&!RoadBlocks.isCollider(current)&&!current.equals(previous.get(p.method_10063())))continue;
   if(!replaceable(base))continue;
   // Only a ground-supported apron: do not fill across water, voids, bridge spans
   // or erase furniture. A single lower course closes a one-block terrain dip.
   var below=p.method_10074();if(!RoadWorkChunks.terrainAvailable(level,below))continue;var lower=RoadPlanInputs.state(level,below);var support=terrain(lower,below,originals,previous);
   if(!base.method_26225()&&!support.method_26225()){
    if(!replaceable(support)||!support.method_26227().method_15769()||support.method_31709())continue;
    var beneath=below.method_10074();if(!RoadWorkChunks.terrainAvailable(level,beneath))continue;var foundation=RoadPlanInputs.state(level,beneath);
    if(!foundation.method_26225()||foundation.method_31709()||!foundation.method_26227().method_15769())continue;
    if(near.stream().anyMatch(r->r.clearanceAt(below)&&r.boxes(below).isEmpty()||r.tunnelAt(below)||r.cycleBodyAt(below)))continue;
    put(paving,aprons,below.method_10063(),chosen);
   }
   put(paving,aprons,p.method_10063(),desired);
   // At a noninteger deck level the edge voxel is above the outer slab's course.
   int edgeY=(int)Math.floor(roadTop);var edge=new class_2338(p.method_10263(),edgeY,p.method_10260());
   if(edgeY!=y&&GroundTerrainJoin.usable(GroundTerrainJoin.cap(edge,SplineRoads.ROAD_BLOCK.get().method_9564(),near))){var at=RoadPlanInputs.state(level,edge);if(replaceable(terrain(at,edge,originals,previous))&&!at.method_31709())put(paving,aprons,edge.method_10063(),chosen);}
  }return aprons;
 }
 private static class_2680 adjacent(class_3218 level,Mesh mesh,class_2338 p,Map<Long,class_2680> originals,Map<Long,class_2680> previous){
  var q=RoadQueries.horizontal(mesh,new V(p.method_10263()+.5,p.method_10264(),p.method_10260()+.5));int side=q.lateral()<0?-1:1;
  for(double reach:new double[]{1.5,2.5,3.5})for(int down=0;down<=2;down++){
   V edge=q.sample().at(side*(q.sample().halfWidth()+reach),0);var at=class_2338.method_49637(edge.x(),p.method_10264()-down,edge.z());
   if(!RoadWorkChunks.terrainAvailable(level,at))continue;
   var state=terrain(RoadPlanInputs.state(level,at),at,originals,previous);
   if(state.method_26225()&&!state.method_31709()&&state.method_26227().method_15769()&&!RoadBlocks.isCollider(state)&&!material(state))return state;
  }
  return null;
 }
 private static void put(Map<Long,class_2680> paving,Set<Long> aprons,long key,class_2680 state){if(paving.putIfAbsent(key,state)==null)aprons.add(key);}
 private static boolean grounded(Sample sample,RoadStructures.Ground ground,int side){
  int contact=0;for(double f:new double[]{.35,.65,.9}){var p=sample.at(side*sample.halfWidth()*f,0);double y=ground.top(p.x(),p.z(),p.y());if(Double.isFinite(y)&&p.y()-y<=RoadStructures.GROUND_CONTACT)contact++;}return contact>=2;
 }
 private static class_2680 terrain(class_2680 current,class_2338 p,Map<Long,class_2680> originals,Map<Long,class_2680> previous){return RoadBlocks.isCollider(current)||previous.containsKey(p.method_10063())?originals.getOrDefault(p.method_10063(),current):current;}
 private static boolean replaceable(class_2680 s){return !s.method_31709()&&s.method_26227().method_15769()&&(s.method_26215()||s.method_45474()||s.method_26164(class_3481.field_29822)||s.method_26164(class_3481.field_15466)||s.method_26164(class_3481.field_25806)||s.method_27852(class_2246.field_10255)||s.method_27852(class_2246.field_10491)||s.method_27852(class_2246.field_10477)||material(s));}
 private SmartRoadAprons(){}
}
