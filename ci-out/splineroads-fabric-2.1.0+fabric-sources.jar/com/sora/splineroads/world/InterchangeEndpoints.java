package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.RoadGeometry.Node;
import com.sora.splineroads.core.RoadGeometry.V;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Existing descriptors are authoritative; merely opening an editor never writes a marker. */
final class InterchangeEndpoints {
  record Endpoint(Node node, NodeEntity marker, class_2487 snapshot) {}

  static Endpoint read(class_3218 level, class_3222 player, class_2487 saved, int i) {
    long[] points = saved.method_10565("Points");
    class_2338 pos = class_2338.method_10092(points[i]);
    try (var chunks = RoadWorkChunks.open(level)) {
      chunks.node(pos);
      if (level.method_8321(pos) instanceof NodeEntity) {
        var marker = RoadData.requireNode(level, pos, player);
        return new Endpoint(marker.constructionNode(), marker, marker.method_38244());
      }
      var nodes = saved.method_10554("Nodes", class_2520.field_33260);
      var data = RoadData.get(level);
      if (!saved.method_25928("Id") || !saved.method_25928("Owner") || nodes.size() != points.length
          || data.index.roads.values().stream().noneMatch(r -> saved.method_25926("Id").equals(r.record.assembly())))
        throw new IllegalArgumentException("端点 " + (char)('A' + i) + " 缺失，且没有完整的立交端点记录");
      if (player != null) {
        RoadData.requireOwner(player, saved.method_25926("Owner"));
        if (!player.method_7294() || !level.method_8505(player, pos))
          throw new IllegalArgumentException("此处没有建设权限");
      }
      var state = level.method_8320(pos);
      boolean ownRoad = RoadBlocks.isCollider(state) && !data.index.at(pos.method_10063()).isEmpty()
          && data.index.at(pos.method_10063()).stream().allMatch(id -> saved.method_25926("Id").equals(data.index.roads.get(id).record.assembly()));
      if (level.method_8321(pos) != null || !(TunnelAir.isAirSpace(state) || state.method_27852(SplineRoads.NODE.get()) || ownRoad))
        throw new IllegalArgumentException("立交端点 " + (char)('A' + i) + " 缺失，原位置被占用：" + pos.method_23854());
      Node node = RoadRecord.readNode(nodes.method_10602(i));
      var p = node.position();
      if (!Double.isFinite(p.x()) || !Double.isFinite(p.y()) || !Double.isFinite(p.z())
          || !Double.isFinite(node.yaw()) || !Double.isFinite(node.grade()))
        throw new IllegalArgumentException("立交端点记录无效，请恢复存档备份");
      class_2487 snapshot = new class_2487();
      snapshot.method_25927("Owner", saved.method_25926("Owner"));
      snapshot.method_10566("Node", RoadRecord.writeNode(node));
      snapshot.method_10556("HeightExplicit", true);
      return new Endpoint(node, null, snapshot);
    }
  }

  /** Keep the confirmed node when a newly created range marker was derived from a sliced mesh.
   * Existing markers never use this path. Matching a block address alone is insufficient: another
   * real endpoint in that block must retain its own position and orientation. */
  static Node generated(long[] points, java.util.List<Node> anchors, class_2338 pos, Node fallback) {
    for (int i = 0; i < points.length && i < anchors.size(); i++) {
      if (points[i] != pos.method_10063()) continue;
      Node anchor = anchors.get(i);
      var a = anchor.position(); var b = fallback.position();
      if (sameCoordinate(a.x(), b.x()) && sameCoordinate(a.y(), b.y())
          && sameCoordinate(a.z(), b.z())
          && Math.abs(Math.IEEEremainder(anchor.yaw() - fallback.yaw(), 360)) <= 1e-8
          && Math.abs(anchor.grade() - fallback.grade()) <= 1e-8) return anchor;
    }
    return fallback;
  }

  private static boolean sameCoordinate(double a, double b) {
    return Double.isFinite(a) && Double.isFinite(b)
        && Math.abs(a - b) <= Math.max(1e-12, 8 * Math.max(Math.ulp(a), Math.ulp(b)));
  }

  private InterchangeEndpoints() {}
}
