package com.sora.splineroads.world;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import net.minecraft.nbt.*;

/** Lossless restoration palette. One NBT state per type, eight bytes per position. */
final class RoadBlockStorage {
  private static final class Group {
    int count, cursor;
    long[] positions;
  }

  static class_2499 write(Long2ObjectOpenHashMap<class_2680> blocks) {
    Map<class_2680, Group> groups = new IdentityHashMap<>();
    var entries = blocks.long2ObjectEntrySet().fastIterator();
    while (entries.hasNext()) groups.computeIfAbsent(entries.next().getValue(), s -> new Group()).count++;
    for (var group : groups.values()) group.positions = new long[group.count];
    entries = blocks.long2ObjectEntrySet().fastIterator();
    while (entries.hasNext()) {
      var entry = entries.next();
      var group = groups.get(entry.getValue());
      group.positions[group.cursor++] = entry.getLongKey();
    }
    class_2499 result = new class_2499();
    // Stable palette order also makes unchanged saves comparable without sorting millions of positions.
    groups.entrySet().stream().sorted(java.util.Comparator.comparing(e -> e.getKey().toString())).forEach(e -> {
      class_2487 tag = new class_2487();
      tag.method_10566("State", class_2512.method_10686(e.getKey()));
      tag.method_10564("Positions", e.getValue().positions);
      result.add(tag);
    });
    return result;
  }

  static void read(class_2499 palette, Long2ObjectOpenHashMap<class_2680> blocks) {
    long count = 0;
    for (class_2520 value : palette) count += ((class_2487)value).method_10565("Positions").length;
    if (count > Integer.MAX_VALUE - 8) throw new IllegalStateException("Too many road restoration blocks");
    for (class_2520 value : palette) {
      class_2487 tag = (class_2487)value;
      if (!tag.method_10573("State", class_2520.field_33260) || !tag.method_10573("Positions", class_2520.field_33262))
        throw new IllegalStateException("Incomplete road restoration palette");
      class_2680 state = class_2512.method_10681(class_7923.field_41175.method_46771(), tag.method_10562("State"));
      for (long pos : tag.method_10565("Positions"))
        if (blocks.put(pos, state) != null) throw new IllegalStateException("Duplicate road restoration position");
    }
  }

  private RoadBlockStorage() {}
}
