package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Piece;
import com.sora.splineroads.core.JunctionPlanner.Plan;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.AutoJunctions.CommitInput;
import com.sora.splineroads.world.AutoJunctions.StreetChange;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.nio.charset.StandardCharsets;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** A marker junction and an attached-point junction share one reversible connection transaction. */
public final class JunctionPointConnections {
  static boolean saved(RoadData data,UUID id){return id!=null&&data.junctions.getOrDefault(id,new class_2487()).method_10577("MixedMarker");}
  static UUID group(RoadData data,UUID link){return data.junctions.entrySet().stream().filter(e->e.getValue().method_10577("MixedMarker")&&e.getValue().method_25926("MixedLink").equals(link)).map(Map.Entry::getKey).findFirst().orElse(null);}
  public static class_2487 create(class_3218 level,class_3222 player,RoadRecord main,UUID point,class_2338 marker,boolean mainFirst,Settings fallback){
    if(!SideHosts.attachable(main))throw new IllegalArgumentException("请选择独立普通主路附属点");
    var t=new class_2487();t.method_10556("OneSided",true);t.method_10556("MixedMarker",true);t.method_25927("Main",main.id());t.method_25927("AttachedPoint",point);t.method_10544("Marker",marker.method_10063());t.method_10556("MainFirst",mainFirst);
    t.method_25927("MixedLink",UUID.nameUUIDFromBytes(("junction-marker:"+marker.method_10063()+":"+main.id()+":"+point).getBytes(StandardCharsets.UTF_8)));
    t.method_10566("OriginalMain",SideHosts.original(RoadData.get(level),main).save());t.method_10566("Fallback",RoadRecord.writeSettings(fallback));return fresh(level,player,t);
  }
  public static class_2487 payload(class_3218 level,class_3222 player,UUID group){
    var t=RoadData.get(level).junctions.get(group);if(t==null||!t.method_10577("MixedMarker"))throw new IllegalArgumentException("路口点连接已不存在");
    if(player!=null)RoadData.requireOwner(player,t.method_25926("Owner"));return fresh(level,player,t.method_10553());
  }
  private static class_2487 fresh(class_3218 level,class_3222 player,class_2487 t){
    var data=RoadData.get(level);var original=RoadRecord.load(t.method_10562("OriginalMain"));var marker=class_2338.method_10092(t.method_10537("Marker"));var node=RoadData.requireNode(level,marker,player);
    if(node.junctionSource==null)throw new IllegalArgumentException("所选路口点已经改变");JunctionPointTool.requireDifferent(level,marker,original);
    var pointId=t.method_25926("AttachedPoint");
    var point=original.settings().options().attachments().points().stream().filter(p->p.id().equals(pointId)&&!p.elevated()).findFirst().orElseThrow(()->new IllegalArgumentException("附属点已经改变"));
    V end=node.constructionNode().position(),at=RoadQueries.horizontal(original.mesh(),point.position()).sample().center(),mid=at.add(end).mul(.5);
    if(at.sub(end).horizontalLength()<4)throw new IllegalArgumentException("两连接点没有足够的道路空间");
    var seam=class_2338.method_49637(mid.x(),mid.y(),mid.z());if(level.method_8321(seam) instanceof NodeEntity)throw new IllegalArgumentException("连接中点已有端点，请调整连接位置");
    t.method_10544("Branch",seam.method_10063());t.method_10566("MarkerNode",RoadRecord.writeNode(node.constructionNode()));t.method_10566("BranchNode",RoadRecord.writeNode(new Node(mid,RoadPlanner.yaw(at.sub(end)),0)));
    t=OneSidedJunctions.fresh(level,player,t,original,RoadRecord.readNode(t.method_10562("BranchNode")));
    var graph=AutoJunctions.context(data,Set.of(marker,seam));t.method_10566("MarkerGraph",graph);t.method_10569("MarkerSignature",graph.hashCode());
    // Both previews use the same logical link and the same endpoint sections as commit.
    var settings=t.method_10545("ConnectionSettings")?RoadRecord.readSettings(t.method_10562("ConnectionSettings")):RoadRecord.readSettings(t.method_10562("Fallback"));
    AutoJunctions.previewComposite(graph,link(t,settings));return t;
  }
  private static RoadRecord link(class_2487 t,Settings wanted){
    var spec=JunctionCodec.read(t.method_10562("Spec"));var settings=SideRoads.settings(wanted,spec.arms().get(2).external(),false);
    var marker=RoadRecord.readNode(t.method_10562("MarkerNode")).position();var seam=RoadRecord.readNode(t.method_10562("BranchNode")).position();boolean first=t.method_10577("MainFirst");
    V a=first?seam:marker,b=first?marker:seam;double yaw=RoadPlanner.yaw(b.sub(a));double grade=(b.y()-a.y())/Math.max(1e-7,b.sub(a).horizontalLength());
    settings=new Settings(Mode.STRAIGHT,settings.style(),settings.width(),settings.thickness(),settings.tension(),settings.arcDegrees()).structure(settings.structure()).options(settings.options().route(spec.arms().get(2).external().options().routing().fit(false)).ends(RoadTransitions.Ends.NONE));
    return new RoadRecord(t.method_25926("MixedLink"),RoadRecord.load(t.method_10562("OriginalMain")).owner(),class_2338.method_10092(t.method_10537(first?"Branch":"Marker")),class_2338.method_10092(t.method_10537(first?"Marker":"Branch")),new Node(a,yaw,grade),new Node(b,yaw,grade),settings,false,4);
  }
  public static List<RoadRecord> preview(class_2487 t,Settings settings){var next=link(t,settings);return AutoJunctions.previewComposite(t.method_10562("MarkerGraph"),next).roads();}
  static String build(class_3218 level,class_3222 player,class_2487 command,Settings roadSettings){
    try(var work=RoadWorkChunks.open(level)){
      var data=RoadData.get(level);boolean editing=command.method_25928("Id");UUID group=editing?command.method_25926("Id"):UUID.randomUUID();
      var host=data.index.roads.get(command.method_25926("Main"));if(host==null)throw new IllegalArgumentException("附属点主路已经改变");
      var t=editing?payload(level,player,group):create(level,player,host.record,command.method_25926("AttachedPoint"),class_2338.method_10092(command.method_10537("Marker")),command.method_10577("MainFirst"),RoadRecord.readSettings(command.method_10562("Fallback")));
      if(t.method_10550("MainSignature")!=command.method_10550("MainSignature")||t.method_10550("MarkerSignature")!=command.method_10550("MarkerSignature"))throw new IllegalArgumentException("连接道路在预览后已经改变，请重新打开");
      if(roadSettings!=null){if(SideRoads.signature(t)!=command.method_10550("Signature"))throw new IllegalArgumentException("连接设置已经改变，请重新打开");t.method_10566("ConnectionSettings",RoadRecord.writeSettings(roadSettings));t=fresh(level,player,t);}
      var spec=roadSettings==null?OneSidedJunctions.validated(t,command):JunctionCodec.read(t.method_10562("Spec"));t.method_10566("Spec",JunctionCodec.write(spec));OneSidedJunction.prepare(spec);
      var settings=t.method_10545("ConnectionSettings")?RoadRecord.readSettings(t.method_10562("ConnectionSettings")):RoadRecord.readSettings(t.method_10562("Fallback"));
      var next=link(t,settings);var change=AutoJunctions.compositeStreet(level,player,next);var original=RoadRecord.load(t.method_10562("OriginalMain"));
      var removed=new HashSet<UUID>();removed.add(original.id());if(editing)data.index.roads.values().stream().filter(r->group.equals(r.record.assembly())).forEach(r->removed.add(r.record.id()));
      var input=AutoJunctions.compositeInput(level,player,change,removed);removed.addAll(input.removed());var built=new ArrayList<>(input.built());
      var plan=JunctionPlanner.plan(spec);var center=class_2338.method_49637(spec.center().x(),spec.center().y(),spec.center().z());var seam=class_2338.method_10092(t.method_10537("Branch"));
      for(int i=0;i<plan.pieces().size();i++){
        var p=plan.pieces().get(i);if(p.arm()==-3){built.add(new RoadIndex.Built(SideHosts.retained(data,original,group,spec)));continue;}
        var m=p.mesh();UUID id=UUID.nameUUIDFromBytes((group+":marker-side:"+i).getBytes(StandardCharsets.UTF_8));
        built.add(new RoadIndex.Built(new RoadRecord(id,original.owner(),p.arm()==2?seam:center,center,new Node(m.first().center(),RoadPlanner.yaw(m.first().left().left().mul(-1)),0),new Node(m.last().center(),RoadPlanner.yaw(m.last().left().left().mul(-1)),0),m.settings(),false,4).junction(group,new JunctionPlanner.Ref(spec,i))));
      }
      var nodes=new HashSet<>(input.selected());nodes.addAll(List.of(original.a(),original.b(),seam,class_2338.method_10092(t.method_10537("Marker"))));check(level,built,removed);
      var direct=new HashSet<>(AutoJunctions.directlyEditedRoads(change.draft(),Set.of(next.id()),Set.of()));built.stream().filter(r->group.equals(r.record.assembly())||r.record.id().equals(original.id())).forEach(r->direct.add(r.record.id()));
      data.replaceAssembly(level,player,built,removed,nodes,List.of(),input.editing(direct));AutoJunctions.compositeMetadata(data,change,input);
      t.method_25927("Id",group);t.method_25927("Owner",original.owner());data.junctions.put(group,t);data.method_80();return "路口点连接已保存：完整路口与单边路口已同时更新";
    }
  }
  static void remove(class_3218 level,class_3222 player,UUID group){
    try(var work=RoadWorkChunks.open(level)){
      var data=RoadData.get(level);var t=data.junctions.get(group);if(t==null||!t.method_10577("MixedMarker"))throw new IllegalArgumentException("连接已经不存在");if(player!=null)RoadData.requireOwner(player,t.method_25926("Owner"));
      var saved=RoadRecord.load(t.method_10562("OriginalMain"));var live=data.index.roads.get(saved.id());if(live==null||!SideHosts.host(live.record))throw new IllegalArgumentException("附属点主路已改变，不能覆盖恢复");var original=SideHosts.original(data,live.record);
      var removed=new HashSet<UUID>();removed.add(original.id());data.index.roads.values().stream().filter(r->group.equals(r.record.assembly())).forEach(r->removed.add(r.record.id()));
      var change=AutoJunctions.withoutStreet(level,player,t.method_25926("MixedLink"));var input=AutoJunctions.compositeInput(level,player,change,removed);removed.addAll(input.removed());var built=new ArrayList<>(input.built());built.add(new RoadIndex.Built(SideHosts.retained(data,original,group,null)));
      var nodes=new HashSet<>(input.selected());nodes.addAll(List.of(original.a(),original.b(),class_2338.method_10092(t.method_10537("Marker")),class_2338.method_10092(t.method_10537("Branch"))));check(level,built,removed);
      data.replaceAssembly(level,player,built,removed,nodes,List.of(),input.editing(Set.of(original.id(),t.method_25926("MixedLink"))));AutoJunctions.compositeMetadata(data,change,input);data.junctions.remove(group);data.method_80();
    }
  }
  private static void check(class_3218 level,List<RoadIndex.Built> built,Set<UUID> removed){var data=RoadData.get(level);for(var next:built)for(var old:data.index.roads.values())if(!removed.contains(old.record.id())&&RoadIndex.overlapXZ(next.mesh,old.mesh,1))Interchanges.checkExternal(next.mesh,old.mesh,data.index.roads.containsKey(next.record.id())?data.index.roads.get(next.record.id()).mesh:null);}
  private JunctionPointConnections(){}
}
