package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.CorridorPlanner.*;
import com.sora.splineroads.core.InterchangePlanner.Leg;
import com.sora.splineroads.core.InterchangePlanner.Plan;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.InterchangeEndpoints.Endpoint;
import com.sora.splineroads.world.RoadIndex.Built;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import java.util.*;

/** Saved main/frontage relationship and shared client/server configuration. */
public final class Corridors {
  public static class_2487 write(Config c){
    class_2487 t=new class_2487();t.method_10582("Mode",c.kind().name());t.method_10582("Sides",c.sides().name());
    t.method_10582("Access",c.access().name());t.method_10549("Gap",c.gap());t.method_10549("FrontageY",c.frontageY());t.method_10582("Adjustment",c.adjustment().name());return t;
  }
  public static Config read(class_2487 t){
    return new Config(Kind.valueOf(t.method_10558("Mode")),Sides.valueOf(t.method_10558("Sides")),
        Access.valueOf(t.method_10558("Access")),t.method_10574("Gap"),t.method_10574("FrontageY"),t.method_10545("Adjustment")?Adjustment.valueOf(t.method_10558("Adjustment")):Adjustment.AUTO);
  }
  public static class_2487 initialize(class_2487 t,Kind kind){
    t.method_10582("Kind","corridor");
    if(!t.method_10545("Corridor")){
      var a=RoadRecord.readNode(t.method_10554("Nodes",class_2520.field_33260).method_10602(0));
      t.method_10566("Corridor",write(new Config(kind,Sides.BOTH,Access.BOTH,kind==Kind.LAYERED?0:12,a.position().y(),Adjustment.AUTO)));
      t.method_10566("Options",Interchanges.write(new InterchangePlanner.Options(
          InterchangePlanner.Preset.CLOVERLEAF,false,1,48,20,5,1).adjust(true)));
      if(kind==Kind.FRONTAGE)t.method_10566("Main2",RoadRecord.writeSettings(new Settings(
          Mode.STRAIGHT,Style.O2_ONE,Style.O2_ONE.defaultWidth(),1,.4,90)));
    }
    HostAxes.normalizeCorridor(t);return t;
  }
  public static Config effective(class_2487 t){
    Config c=read(t.method_10562("Corridor"));
    return c.adjustment()==Adjustment.AUTO&&t.method_10545("ResolvedFit")?c.adjustment(Adjustment.valueOf(t.method_10558("ResolvedFit"))):c;
  }

  /** Read-only authoritative preview; final construction repeats this against the live world. */
  public static class_2487 preview(class_3218 level,class_3222 player,class_2487 command){
    class_2487 t=Interchanges.payload(level,player,command.method_10565("Points"),command.method_25928("Id")?command.method_25926("Id"):null);
    for(String key:List.of("Main1","Main2","Options","Corridor"))t.method_10566(key,command.method_10562(key).method_10553());
    if(!t.method_10545("Corridor"))throw new IllegalArgumentException("缺少道路组合参数");
    resolve(level,player,t);return t;
  }

  public static InterchangePlanner.Plan resolve(class_3218 level,class_3222 player,class_2487 t){
    try(var chunks=RoadWorkChunks.open(level)){
      RoadData data=RoadData.get(level);UUID group=t.method_25928("Id")?t.method_25926("Id"):null;
      Interchanges.requireNoEndpointJunction(data,group);
      long[] points=t.method_10565("Points");Set<UUID> replaced=new HashSet<>();
      if(group!=null){for(var road:data.index.roads.values())if(group.equals(road.record.assembly()))replaced.add(road.record.id());}
      else for(int i=0;i+1<points.length;i+=2)for(var road:Interchanges.mainChain(data,class_2338.method_10092(points[i]),class_2338.method_10092(points[i+1])))replaced.add(road.id());
      HostAxes.normalizeCorridor(t);Config c=read(t.method_10562("Corridor"));boolean adjust=Interchanges.read(t.method_10562("Options")).adjustEndpoints();
      Adjustment[] candidates=adjust&&c.adjustment()==Adjustment.AUTO?new Adjustment[]{Adjustment.BOTH,Adjustment.END,Adjustment.START}:new Adjustment[]{c.adjustment()==Adjustment.AUTO?Adjustment.BOTH:c.adjustment()};
      List<String> reasons=new ArrayList<>();
      for(Adjustment mode:candidates){
        t.method_10582("ResolvedFit",mode.name());
        try{
          var plan=Interchanges.plan(t);
          for(var leg:plan.legs()){UUID source=ContinuousRoads.sourceId(leg.name());if(source!=null)replaced.add(source);}
          Set<class_2338> sources=new HashSet<>();for(long p:points)sources.add(class_2338.method_10092(p));
          for(int i=0;i<points.length;i++){
            class_2338 from=class_2338.method_10092(points[i]);var endpoint=InterchangeEndpoints.read(level,player,t,i);Node target=plan.anchors().get(i);
            if(endpoint.node().equals(target)||ContinuousRoads.virtual(t,i,target))continue;
            if(data.index.atNode(from).stream().anyMatch(id->!replaced.contains(id)))SharedRoadEndpoints.validate(data,from,target);
            V pos=target.position();class_2338 to=class_2338.method_49637(pos.x(),pos.y(),pos.z());chunks.node(to);
            if(level.method_31606(to)||!level.method_8621().method_11952(to))throw new IllegalArgumentException("调整后的端点超出世界高度或边界");
            if(player!=null&&!level.method_8505(player,to))throw new IllegalArgumentException("调整后的端点位于受保护区域");
            var state=level.method_8320(to);var entity=level.method_8321(to);
            boolean source=sources.contains(to)&&entity instanceof NodeEntity;
            if(!source&&(entity!=null||state.method_26214(level,to)<0||RoadBlocks.isCollider(state)&&data.index.at(to.method_10063()).stream().anyMatch(id->!replaced.contains(id))))
              throw new IllegalArgumentException("端点目标被占用："+to.method_23854()+"（"+net.minecraft.class_7923.field_41175.method_10221(state.method_26204())+"）");
          }
          for(var leg:plan.legs())for(var old:data.index.roads.values())if(!replaced.contains(old.record.id())&&RoadIndex.overlapXZ(leg.mesh(),old.mesh,1))Interchanges.checkExternal(leg.mesh(),old.mesh);
          return plan;
        }catch(IllegalArgumentException error){reasons.add(mode.label+"："+error.getMessage());}
      }
      t.method_10551("ResolvedFit");throw new IllegalArgumentException(String.join("；",reasons));
    }
  }
  private Corridors(){}
}
