package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadAttachments.Data;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Layout;
import com.sora.splineroads.core.RoadProfile.Type;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.level.*;

/** A distinct central access marker. It never converts an ordinary side junction. */
public final class ElevatedPointTool extends class_1792 {
  public ElevatedPointTool(){super(new class_1793().method_7889(1));}
  public static boolean supported(RoadRecord r){var type=RoadProfile.catalog(r.settings()).type();return r.assembly()==null&&r.junction()==null&&r.toll()==null&&!r.railway()&&r.settings().mode()!=Mode.RING&&LaneTopology.metadata(r).link()==null&&(type==RoadProfile.Type.ORDINARY||type==RoadProfile.Type.HIGHWAY);}
  public static RoadAttachments.Point create(class_3218 level,class_3222 player,RoadIndex.Built road,V hit){
    if(road==null||!supported(road.record))
      throw new IllegalArgumentException("高架出入点只能创建在道路上，不能位于路口或自动生成的分支");
    if(player!=null){if(!player.method_7294()||player.method_7325())throw new IllegalArgumentException("没有建设权限");RoadData.requireOwner(player,road.record.owner());}
    var q=RoadQueries.horizontal(road.mesh,hit);
    if(q.horizontalDistance()>q.sample().halfWidth()+.05||Math.abs(hit.y()-q.sample().center().y())>2.5)
      throw new IllegalArgumentException("请在道路路面创建高架出入点");
    var layout=RoadProfile.layout(road.mesh,q.sample());
    V at=q.sample().at(layout.catalog().twoWay()?layout.medianCenter():0,0);
    var metadata=road.record.settings().options().attachments();
    for(var point:metadata.points())if(point.elevated()&&point.position().distance(at)<1.1)return point;
    var point=new RoadAttachments.Point(UUID.randomUUID(),at,q.sample().center(),false,at,true);
    var points=new ArrayList<>(metadata.points());points.add(point);
    RoadData.get(level).updatePointMetadata(level,player,road.record,metadata.points(points));return point;
  }
  @Override public class_1269 method_7884(class_1838 context){
    if(context.method_8045().field_9236)return class_1269.field_5812;
    if(context.method_8036() instanceof class_3222 player)try{
      var hit=context.method_17698();var road=RoadTool.pick(player);
      var point=create(player.method_51469(),player,road,new V(hit.field_1352,hit.field_1351,hit.field_1350));
      var updated=RoadData.get(player.method_51469()).index.roads.get(road.record.id());
      RoadNetwork.open(player,AttachedPointTool.payload(updated.record,point));
    }catch(IllegalArgumentException failure){player.method_7353(class_2561.method_43470(failure.getMessage()),false);}
    return class_1269.field_21466;
  }
}
