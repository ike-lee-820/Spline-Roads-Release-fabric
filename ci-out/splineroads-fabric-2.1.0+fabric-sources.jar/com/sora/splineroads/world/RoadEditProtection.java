package com.sora.splineroads.world;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.core.*;
import net.minecraft.server.level.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.level.BlockEvent;

/** Shared preflight for construction tools; no blocks are changed by these probes. */
final class RoadEditProtection {
  static boolean probing;
  static void check(class_3218 level,class_3222 player,class_2338 pos,class_2680 current,class_2680 target){
    if(player==null||current.equals(target))return;
    if(!level.method_8505(player,pos)||!player.method_7343(pos,class_2350.field_11036,player.method_6047()))throw new IllegalArgumentException("道路施工范围受保护："+pos.method_23854());
    boolean prior=probing;probing=true;
    try{
      if(!current.method_26215()&&MinecraftForge.EVENT_BUS.post(new BlockEvent.BreakEvent(level,pos,current,player)))throw denied(pos);
      var snapshot=BlockSnapshot.create(level.method_27983(),level,pos);
      var event=new BlockEvent.EntityPlaceEvent(snapshot,current,player){@Override public class_2680 getPlacedBlock(){return target;}@Override public class_2680 getState(){return target;}};
      if(MinecraftForge.EVENT_BUS.post(event))throw denied(pos);
    }finally{probing=prior;}
  }
  private static IllegalArgumentException denied(class_2338 pos){return new IllegalArgumentException("道路施工被区域保护拒绝："+pos.method_23854());}
  private RoadEditProtection(){}
}
