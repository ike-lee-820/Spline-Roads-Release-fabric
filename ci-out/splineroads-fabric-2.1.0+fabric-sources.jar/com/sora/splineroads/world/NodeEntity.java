package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.RoadGeometry.*;
import java.util.UUID;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2622;
import net.minecraft.class_2680;

public final class NodeEntity extends class_2586 {
  public double yaw, grade, offsetX, offsetY, offsetZ;
  public boolean headingLocked, gradeLocked, heightExplicit, plannerHeading;
  public UUID owner;
  public UUID junctionSource;

  public NodeEntity(class_2338 pos, class_2680 state) {
    super(SplineRoads.NODE_ENTITY.get(), pos, state);
  }

  public Node node() {
    return new Node(
        new V(
            field_11867.method_10263() + .5 + offsetX,
            field_11867.method_10264() + offsetY,
            field_11867.method_10260() + .5 + offsetZ),
        yaw,
        grade);
  }

  /** 0.1 default markers used +0.25; normalize that default when a road is rebuilt. */
  public Node constructionNode() {
    Node n = node();
    return !heightExplicit && Math.abs(offsetY - .25) < 1e-8
        ? new Node(
            new V(n.position().x(), field_11867.method_10264(), n.position().z()), n.yaw(), n.grade())
        : n;
  }

  public void apply(Node node) {
    offsetX = node.position().x() - field_11867.method_10263() - .5;
    offsetY = node.position().y() - field_11867.method_10264();
    offsetZ = node.position().z() - field_11867.method_10260() - .5;
    yaw = node.yaw();
    grade = node.grade();
    method_5431();
    if (field_11863 != null) field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
  }

  @Override
  protected void method_11007(class_2487 t) {
    super.method_11007(t);
    t.method_10566("Node", RoadRecord.writeNode(node()));
    t.method_10556("HeightExplicit", heightExplicit);
    t.method_10556("PlannerHeading",plannerHeading);
    t.method_10556("HeadingLocked", headingLocked);
    t.method_10556("GradeLocked", gradeLocked);
    if (owner != null) t.method_25927("Owner", owner);
    if(junctionSource!=null)t.method_25927("JunctionSource",junctionSource);
  }

  @Override
  public void method_11014(class_2487 t) {
    super.method_11014(t);
    if (t.method_10545("Node")) {
      Node n = RoadRecord.readNode(t.method_10562("Node"));
      offsetX = n.position().x() - field_11867.method_10263() - .5;
      offsetY = n.position().y() - field_11867.method_10264();
      offsetZ = n.position().z() - field_11867.method_10260() - .5;
      yaw = n.yaw();
      grade = n.grade();
    }
    if (t.method_25928("Owner")) owner = t.method_25926("Owner");
    junctionSource=t.method_25928("JunctionSource")?t.method_25926("JunctionSource"):null;
    heightExplicit =
        t.method_10545("HeightExplicit")
            ? t.method_10577("HeightExplicit")
            : (Math.abs(offsetY) > 1e-8 && Math.abs(offsetY - .25) > 1e-8);
    plannerHeading=t.method_10577("PlannerHeading");
    headingLocked = t.method_10577("HeadingLocked");
    gradeLocked = t.method_10577("GradeLocked");
  }

  @Override
  public class_2487 method_16887() {
    return method_38244();
  }

  @Override
  public class_2622 method_38235() {
    return class_2622.method_38585(this);
  }
}
