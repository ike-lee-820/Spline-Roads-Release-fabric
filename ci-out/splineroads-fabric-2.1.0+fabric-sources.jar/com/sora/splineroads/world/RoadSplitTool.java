package com.sora.splineroads.world;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
/** All mutation goes through the server's preview-token transaction. */
public final class RoadSplitTool extends class_1792 {
  public static Runnable activateClient=()->{};
  public RoadSplitTool(){super(new class_1793().method_7889(1));}
  @Override public class_1269 method_7884(class_1838 context){if(context.method_8045().field_9236)activateClient.run();return class_1269.method_29236(context.method_8045().field_9236);}
  @Override public class_1271<class_1799> method_7836(class_1937 level,class_1657 player,class_1268 hand){if(level.field_9236)activateClient.run();return class_1271.method_29237(player.method_5998(hand),level.field_9236);}
}
