package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LaneDeck.Strip;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Control;
import com.sora.splineroads.core.RoadSlicing.Patch;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import java.util.*;

final class RoadSliceCodec {
  static class_2487 write(RoadSlicing.Fragment s){
    var t=new class_2487();t.method_10569("Version",2);t.method_25927("Source",s.source());t.method_10549("Origin",s.origin());t.method_10549("Total",s.total());t.method_10582("Connection",s.connection().name());t.method_10566("Applied",AttachedPointCodec.write(s.applied()));t.method_10570("Supports",RoadRecord.packStructures(s.supports()));
    var anchors=new class_2499();for(var c:s.curveAnchors()){var a=new class_2487();a.method_25927("Id",c.id());a.method_10566("Position",LanePointCodec.position(c.position()));anchors.add(a);}t.method_10566("CurveAnchors",anchors);
    var patches=new class_2499();for(var p:s.geometry().patches()){
      var q=new class_2487();q.method_10549("From",p.from());q.method_10549("To",p.to());var strips=new class_2499();
      for(var strip:p.strips()){var v=new class_2487();v.method_10566("AL",LanePointCodec.position(strip.al()));v.method_10566("AR",LanePointCodec.position(strip.ar()));v.method_10566("BL",LanePointCodec.position(strip.bl()));v.method_10566("BR",LanePointCodec.position(strip.br()));v.method_10556("Low",strip.lowWall());v.method_10556("High",strip.highWall());strips.add(v);}
      q.method_10566("Strips",strips);patches.add(q);
    }t.method_10566("Patches",patches);return t;
  }
  static RoadSlicing.Fragment read(class_2487 t){
    if(t.method_10550("Version")!=1&&t.method_10550("Version")!=2)throw new IllegalArgumentException("道路分割数据版本无效");
    var patches=new ArrayList<RoadSlicing.Patch>();var list=t.method_10554("Patches",class_2520.field_33260);if(list.size()>4)throw new IllegalArgumentException("道路分割切面数量无效");
    for(class_2520 tag:list){var p=(class_2487)tag;var strips=new ArrayList<LaneDeck.Strip>();var values=p.method_10554("Strips",class_2520.field_33260);if(values.size()>16)throw new IllegalArgumentException("道路分割切面过大");
      for(class_2520 value:values){var v=(class_2487)value;strips.add(new LaneDeck.Strip(LanePointCodec.position(v.method_10562("AL")),LanePointCodec.position(v.method_10562("AR")),LanePointCodec.position(v.method_10562("BL")),LanePointCodec.position(v.method_10562("BR")),v.method_10577("Low"),v.method_10577("High")));}
      patches.add(new RoadSlicing.Patch(p.method_10574("From"),p.method_10574("To"),strips));
    }
    var anchors=new ArrayList<RoadProfile.Control>();var saved=t.method_10554("CurveAnchors",class_2520.field_33260);if(saved.size()>32)throw new IllegalArgumentException("分割曲线点数量无效");for(var value:saved){var a=(class_2487)value;anchors.add(new RoadProfile.Control(a.method_25926("Id"),LanePointCodec.position(a.method_10562("Position"))));}
    return new RoadSlicing.Fragment(t.method_25926("Source"),t.method_10574("Origin"),t.method_10574("Total"),RoadSlicing.Connection.valueOf(t.method_10558("Connection")),AttachedPointCodec.read(t.method_10562("Applied")),new RoadSlicing.Geometry(patches),t.method_10545("Supports")?RoadRecord.unpackStructures(t.method_10547("Supports")):List.of(),anchors);
  }
  private RoadSliceCodec(){}
}
