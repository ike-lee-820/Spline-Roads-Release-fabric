package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.DoubleTrumpetToll.Config;
import com.sora.splineroads.core.InterchangePlanner.Leg;
import com.sora.splineroads.core.InterchangePlanner.Options;
import com.sora.splineroads.core.InterchangePlanner.Plan;
import com.sora.splineroads.core.LanePoints.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadInfrastructure.Bridge;
import com.sora.splineroads.core.RoadStructures.Ground;
import com.sora.splineroads.core.SmartSigns.State;
import com.sora.splineroads.world.ContinuousRoads.Source;
import com.sora.splineroads.world.InterchangeEndpoints.Endpoint;
import com.sora.splineroads.world.RoadData.NodeMove;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/**
 * Three or four anchors, compact editable specification, and a single validated world transaction.
 */
public final class Interchanges {
  public static class_2487 descriptor(RoadData data,UUID id){
    var saved=data.interchanges.get(InterchangeJunctions.parent(data,id));
    if(saved==null)throw new IllegalArgumentException("道路组合已不存在");
    return saved.method_10553();
  }
  // Geometry is independent of terrain and permissions. Reuse an identical preview in single
  // player.
  private static final Map<class_2487, InterchangePlanner.Plan> PLANS =
      new LinkedHashMap<>(16, .75f, true) {
        protected boolean removeEldestEntry(Map.Entry<class_2487, InterchangePlanner.Plan> e) {
          return size() > 3;
        }
      };

  public static class_2487 write(InterchangePlanner.Options o) {
    class_2487 t = new class_2487();
    t.method_10582("Preset", o.preset().name());
    t.method_10556("Left", o.leftTraffic());
    t.method_10569("Lanes", o.lanes());
    t.method_10549("Transition", o.transition());
    t.method_10549("Radius", o.radius());
    t.method_10549("Clearance", o.clearance());
    t.method_10569("Upper", o.upper());
    t.method_10569("JunctionAxis",o.junctionAxis());
    t.method_10569("LoopMask",o.loopMask());
    t.method_10556("AllowAbove",o.allowAbove());t.method_10556("FlatConnector",o.flatConnector());t.method_10549("ConnectorHeight",o.connectorHeight());
    t.method_10549("RampWidth", o.rampWidth());
    t.method_10556("AdjustEndpoints", o.adjustEndpoints());
    t.method_10556("AllowShrink", o.allowShrink());
    t.method_10549("MaxLowering", o.maxLowering());
    var config=o.toll();var toll=new class_2487();toll.method_10556("Enabled",config.enabled());toll.method_10556("TwoWay",config.twoWay());toll.method_10556("Reverse",config.reverse());toll.method_10582("Near",config.near().name());toll.method_10569("ForwardETC",config.forwardEtc());toll.method_10569("ReverseETC",config.reverseEtc());toll.method_10582("Name",config.name());t.method_10566("Toll",toll);
    return t;
  }

  public static InterchangePlanner.Options read(class_2487 t) {
    return new InterchangePlanner.Options(
        InterchangePlanner.Preset.valueOf(t.method_10558("Preset")),
        t.method_10577("Left"),
        t.method_10550("Lanes"),
        t.method_10574("Transition"),
        t.method_10574("Radius"),
        t.method_10574("Clearance"),
        t.method_10550("Upper"),
        t.method_10574("RampWidth"),
        t.method_10577("AdjustEndpoints"),
        t.method_10577("AllowShrink"),
        t.method_10545("MaxLowering") ? t.method_10574("MaxLowering") : 8,
        t.method_10545("JunctionAxis") ? t.method_10550("JunctionAxis") : 1,
        t.method_10545("LoopMask") ? t.method_10550("LoopMask") : 5,
        t.method_10577("AllowAbove"),t.method_10577("FlatConnector"),t.method_10574("ConnectorHeight"),readToll(t));
  }

  private static DoubleTrumpetToll.Config readToll(class_2487 options){
    if(!options.method_10545("Toll"))return DoubleTrumpetToll.Config.OFF;var t=options.method_10562("Toll");
    return new DoubleTrumpetToll.Config(t.method_10577("Enabled"),t.method_10577("TwoWay"),t.method_10577("Reverse"),DoubleTrumpetToll.Near.valueOf(t.method_10558("Near")),t.method_10550("ForwardETC"),t.method_10550("ReverseETC"),t.method_10558("Name"));
  }

  static void clearRemovedDesign(class_2487 t){
    t.method_10566("Options",write(read(t.method_10562("Options"))));
    for(String key:List.of("DesignInputNodes","DesignInputAxes","DesignFittedNodes","DesignShape","DesignFixed","ParallelDesignScale","ParallelDesignOptions"))t.method_10551(key);
  }

  public static InterchangePlanner.Plan plan(class_2487 t) {
    if(ParallelSpui.present(t))return ParallelSpui.plan(t);
    validateMainStyles(t);
    return InterchangeJunctions.applyEdits(InterchangeJunctions.elevationDefaults(ContinuousRoads.plan(t,Interchanges::planBase),t),t);
  }
  static InterchangePlanner.Plan confirmedPlan(class_2487 t,class_2487 command){
    validateMainStyles(t);var fixed=ConfirmedInterchangeFit.candidate(t,command);
    // Validate the exact submitted endpoints without repeating optional fitting.
    var plan=ContinuousRoads.confirmed(t,planBase(fixed));
    return InterchangeJunctions.applyEdits(InterchangeJunctions.elevationDefaults(plan,t),t);
  }
  private static void validateMainStyles(class_2487 t) {
    for(String key:List.of("Main1","Main2","Main3"))if(t.method_10545(key)){
      var bridge=RoadRecord.readSettings(t.method_10562(key)).options().infrastructure().bridge();
      if(bridge==RoadInfrastructure.Bridge.ARCH||bridge==RoadInfrastructure.Bridge.CABLE||bridge==RoadInfrastructure.Bridge.SUSPENSION)
        throw new IllegalArgumentException("立交主路不支持大河拱桥、斜拉桥或悬索桥，请选择普通高架、梁桥、跨线桥或连续梁");
    }
  }
  private static InterchangePlanner.Plan planBase(class_2487 t) {
    if(HostAxes.retiredInterchange(t))throw new IllegalArgumentException(HostAxes.RETIRED_MESSAGE);
    class_2487 key = new class_2487();
    for (String field : List.of("Nodes", "Main1", "Main2", "Main3", "Options", "MultiBaseY", "Corridor", "ResolvedFit", "HostAxes"))
      if (t.method_10545(field)) key.method_10566(field, t.method_10580(field).method_10707());
    synchronized (PLANS) {
      var cached = PLANS.get(key);
      if (cached != null) return cached;
    }
    var tags = t.method_10554("Nodes", class_2520.field_33260);
    if (tags.size() < 2 || tags.size() > 6) throw new IllegalArgumentException("道路组合端点数据不完整");
    Node[] nodes = new Node[tags.size()];
    for (int i = 0; i < nodes.length; i++) nodes[i] = RoadRecord.readNode(tags.method_10602(i));
    var result = t.method_10545("Corridor") ? CurvedRoadPlans.corridor(nodes,RoadRecord.readSettings(t.method_10562("Main1")),RoadRecord.readSettings(t.method_10562("Main2")),read(t.method_10562("Options")),Corridors.effective(t),HostAxes.read(t)) : nodes.length>=5 ? MultiInterchange.plan(nodes,new Settings[]{RoadRecord.readSettings(t.method_10562("Main1")),RoadRecord.readSettings(t.method_10562("Main2")),RoadRecord.readSettings(t.method_10562("Main3"))},read(t.method_10562("Options")),t.method_10574("MultiBaseY")) :
        CurvedRoadPlans.interchange(
            nodes,
            RoadRecord.readSettings(t.method_10562("Main1")),
            RoadRecord.readSettings(t.method_10562("Main2")),
            read(t.method_10562("Options")),HostAxes.read(t));
    synchronized (PLANS) {
      PLANS.put(key, result);
    }
    return result;
  }

  public static class_2487 payload(
      class_3218 level, class_3222 player, long[] points, UUID id) {
    try (var workChunks = RoadWorkChunks.open(level)) {
      if ((points.length < 2 || points.length > 6)
          || Arrays.stream(points).distinct().count() != points.length)
        throw new IllegalArgumentException("请选择对应数量的不同端点");
      RoadData data = RoadData.get(level);
      class_2487 t = new class_2487();
      if (id != null) {
        var saved = data.interchanges.get(id);
        if (saved == null) throw new IllegalArgumentException("立交已不存在");
        if (!Arrays.equals(points, saved.method_10565("Points")))
          throw new IllegalArgumentException("立交端点已变化，请重新打开立交");
        if (player != null) RoadData.requireOwner(player, saved.method_25926("Owner"));
        t = saved.method_10553();
      } else
        for (var entry : data.interchanges.entrySet())
          if (Arrays.equals(entry.getValue().method_10565("Points"), points)) {
            return payload(level, player, points, entry.getKey());
          }
      t.method_10582("Kind", t.method_10545("Corridor") ? "corridor" : "interchange");
      t.method_10564("Points", points);
      class_2499 nodes = new class_2499();
      for (int i = 0; i < points.length; i++)
        nodes.add(
            RoadRecord.writeNode(
                id!=null&&t.method_10577("VirtualRange")?RoadRecord.readNode(t.method_10554("PlanningNodes",class_2520.field_33260).method_10602(i)):InterchangeEndpoints.read(level, player, t, i).node()));
      t.method_10566("Nodes", nodes);
      if(points.length>=5&&!t.method_10545("MultiBaseY")){double base=Double.POSITIVE_INFINITY;for(int i=0;i<nodes.size();i++)base=Math.min(base,RoadRecord.readNode(nodes.method_10602(i)).position().y());t.method_10549("MultiBaseY",base);}
      if (!t.method_10545("Options")) {
        var d = InterchangePlanner.Options.DEFAULT;
        t.method_10566(
            "Options",
            write(
                points.length == 3
                    ? new InterchangePlanner.Options(
                        InterchangePlanner.Preset.TRUMPET,
                        d.leftTraffic(),
                        d.lanes(),
                        d.transition(),
                        d.radius(),
                        d.clearance(),
                        d.upper())
                    : d));
      }
      if(points.length>=5&&!t.method_10562("Options").method_10558("Preset").startsWith("DIRECTIONAL_"))
        t.method_10566("Options",write(new InterchangePlanner.Options(points.length==5?InterchangePlanner.Preset.DIRECTIONAL_FIVE:InterchangePlanner.Preset.DIRECTIONAL_SIX,false,1,96,20,5,2,0,true,true,0)));
      if(ParallelSpui.capture(data,t,player))return t;
      var hostAxes=new ArrayList<RoadAxis>();
      for (int axis = 0; axis < (points.length>=5?3:2); axis++) {
        String key = "Main" + (axis + 1);
        if (id!=null && t.method_10545(key)) continue;
        Settings settings =
            new Settings(Mode.STRAIGHT, Style.H4_RAIL, Style.H4_RAIL.defaultWidth(), 1, .4, 90);
        var chain =
            axis * 2 + 1 < points.length
                ? mainChain(data, class_2338.method_10092(points[axis * 2]), class_2338.method_10092(points[axis * 2 + 1]))
                : points.length==2 ? List.<RoadRecord>of() : points.length==3 ? thirdArmChain(data, t, points) : branchProfile(data,class_2338.method_10092(points[axis*2]));
        var profiles=chain;
        if (profiles.isEmpty() && axis == 1 && points.length == 3)
          profiles = branchProfile(data, class_2338.method_10092(points[2]));
        if (!profiles.isEmpty()) {
          var r = profiles.get(0);
          if (player != null) RoadData.requireOwner(player, r.owner());
          settings = r.settings();
        }
        if(!t.method_10545(key))t.method_10566(key, RoadRecord.writeSettings(settings));
        if(points.length>=5&&!chain.isEmpty()){var path=HostAxes.chain(chain,class_2338.method_10092(points[axis*2]));if(path.curved()||!path.flat())throw new IllegalArgumentException("五、六向立交仍需要平直且各自等高的主路");}
        if(axis*2<points.length&&points.length<5){
          var defaults=HostAxes.read(t);
          hostAxes.add(chain.isEmpty()?defaults.get(axis):HostAxes.chain(chain,class_2338.method_10092(points[axis*2])));
        }
      }
      if(!hostAxes.isEmpty())HostAxes.write(t,hostAxes);
      var terrain=data.terrainGround();
      if(terrain!=null)for(int axis=0;axis<2&&axis*2+1<nodes.size();axis++){
        V a=RoadRecord.readNode(nodes.method_10602(axis*2)).position(),b=RoadRecord.readNode(nodes.method_10602(axis*2+1)).position();
        V center=a.add(b).mul(.5);double floor=terrain.top(center.x(),center.z(),center.y());
        var settings=RoadRecord.readSettings(t.method_10562("Main"+(axis+1)));
        var reference=RoadGeometry.build(new Node(a,RoadPlanner.yaw(b.sub(a)),0),new Node(b,RoadPlanner.yaw(b.sub(a)),0),settings);
        t.method_10556("ServiceElevated"+axis,settings.structure()==Structure.BRIDGE
            ||Double.isFinite(floor)&&center.y()-floor>2
            ||RoadStructures.elevated(reference,RoadStructures.sample(reference,reference.length()/2),terrain));
      }
      if(points.length>=5&&HostAxes.read(t).stream().anyMatch(a->a.curved()||!a.flat()))throw new IllegalArgumentException("五、六向立交仍需要平直且各自等高的主路");
      if(id==null&&HostAxes.retiredInterchange(t))throw new IllegalArgumentException(HostAxes.RETIRED_MESSAGE);
      if(id==null)ContinuousRoads.capture(data,t);
      else if(t.method_10545("ContinuousSources")){
        // Keep point/paint edits made on generated mains when rebuilding the assembly.
        ContinuousReclaim.refresh(data,t);
      }
      if (id != null) {t.method_25927("Id", id);InterchangeJunctions.captureEdits(data,id,t);}
      return t;
    }
  }

  private static List<RoadRecord> thirdArmChain(RoadData data, class_2487 inputs, long[] points) {
    if (points.length != 3) return List.of();
    var tags = inputs.method_10554("Nodes", class_2520.field_33260);
    V a = RoadRecord.readNode(tags.method_10602(0)).position(),
        b = RoadRecord.readNode(tags.method_10602(1)).position(),
        c = RoadRecord.readNode(tags.method_10602(2)).position();
    V along = b.sub(a).horizontalUnit(), foot = a.add(along.mul(c.sub(a).dot(along)));
    foot = new V(foot.x(), c.y(), foot.z());
    // C describes a terminating approach, whose old tip need not be exactly at the mathematical
    // AB/CD intersection (or at AB's elevation). Follow its existing straight approach toward AB.
    V direction = foot.sub(c).horizontalUnit();
    double limit =
        foot.sub(c).horizontalLength()
            + RoadRecord.readSettings(inputs.method_10562("Main1")).width() / 2
            + 1;
    class_2338 start = class_2338.method_10092(points[2]), last = start;
    double farthest = 0;
    Set<class_2338> visited = new HashSet<>();
    ArrayDeque<class_2338> queue = new ArrayDeque<>();
    queue.add(start);
    visited.add(start);
    while (!queue.isEmpty() && visited.size() < 512) {
      class_2338 at = queue.remove();
      for (UUID id : data.index.atNode(at)) {
        var r = data.index.roads.get(id).record;
        if (r.assembly() != null || r.settings().style().ramp()) continue;
        boolean forward = r.a().equals(at);
        class_2338 next = forward ? r.b() : r.a();
        V point = (forward ? r.end() : r.start()).position();
        double distance = point.sub(c).dot(direction);
        if (distance <= .01
            || distance > limit
            || Math.abs(point.sub(c).dot(direction.left())) > Math.max(24,limit*.6)
            || visited.contains(next)) continue;
        visited.add(next);
        queue.add(next);
        if (distance > farthest) {
          farthest = distance;
          last = next;
        }
      }
    }
    return last.equals(start) ? List.of() : mainChain(data, start, last);
  }

  private static List<RoadRecord> branchProfile(RoadData data, class_2338 at) {
    return data.index.atNode(at).stream()
        .map(data.index.roads::get)
        .filter(Objects::nonNull)
        .map(b -> b.record)
        .filter(r -> r.assembly() == null && !r.settings().style().ramp())
        .sorted(Comparator.comparing(RoadRecord::id))
        .limit(1)
        .toList();
  }

  static List<RoadRecord> mainChain(RoadData data, class_2338 a, class_2338 b) {
    Map<class_2338, RoadRecord> via = new HashMap<>();
    Map<class_2338, class_2338> previous = new HashMap<>();
    ArrayDeque<class_2338> queue = new ArrayDeque<>();
    queue.add(a);
    previous.put(a, a);
    while (!queue.isEmpty() && previous.size() < 512) {
      class_2338 at = queue.remove();
      if (at.equals(b)) break;
      for (UUID id : data.index.atNode(at)) {
        var r = data.index.roads.get(id).record;
        if (r.junction()!=null||r.settings().style().ramp() || r.assembly() != null) continue;
        class_2338 next = r.a().equals(at) ? r.b() : r.a();
        if (previous.containsKey(next)) continue;
        previous.put(next, at);
        via.put(next, r);
        queue.add(next);
      }
    }
    if (!previous.containsKey(b)) return List.of();
    List<RoadRecord> chain = new ArrayList<>();
    for (class_2338 at = b; !at.equals(a); at = previous.get(at)) chain.add(via.get(at));
    Collections.reverse(chain);
    HostAxes.chain(chain,a); // Reject folded/angled chains, while retaining smooth curves and grades.
    Set<UUID> ids = new HashSet<>();
    chain.forEach(r -> ids.add(r.id()));
    for (var r : chain)
      for (class_2338 p : List.of(r.a(), r.b()))
        if (!p.equals(a) && !p.equals(b))
          for (UUID id : data.index.atNode(p))
            if (!ids.contains(id)) throw new IllegalArgumentException("选中的主路中间已有其他支路，请缩小选区或先处理该支路");
    return chain;
  }

  public static String build(class_3218 level, class_3222 player, class_2487 command) {
    try (var workChunks = RoadWorkChunks.open(level)) {
      RoadData data = RoadData.get(level);
      long[] points = command.method_10565("Points");
      UUID existing = command.method_25928("Id") ? command.method_25926("Id") : null;
      requireNoEndpointJunction(data,existing);
      class_2487 t = payload(level, player, points, existing);
      t.method_10566("Options", write(read(command.method_10562("Options"))));
      clearRemovedDesign(t);
      if(ParallelSpui.present(t)){
        ParallelSpui.capture(data,t,player);
        if(player!=null&&read(t.method_10562("Options")).adjustEndpoints()){
          var fitted=new class_2499();ParallelSpui.plan(t).anchors().forEach(node->fitted.add(RoadRecord.writeNode(node)));
          if(!command.method_10554("SourceNodes",class_2520.field_33260).equals(t.method_10554("Nodes",class_2520.field_33260))
              ||!command.method_10554("FittedNodes",class_2520.field_33260).equals(fitted))
            throw new IllegalArgumentException("端点或方案已变化，请重新打开立交并查看端点调整预览");
        }
        return ParallelSpui.build(level,player,t);
      }
      if(command.method_10545("Corridor"))t.method_10566("Corridor",command.method_10562("Corridor").method_10553());
      if (!t.method_10545("Corridor") && !HostAxes.presets(t)
          .contains(read(t.method_10562("Options")).preset()))
        throw new IllegalArgumentException("此布局不适用于当前向数，请重新选择立交预设");
      for (String key : List.of("Main1", "Main2", "Main3"))
        if (command.method_10545(key)) t.method_10566(key, command.method_10562(key).method_10553());
      validateMainStyles(t);
      if(t.method_10545("Corridor"))HostAxes.normalizeCorridor(t);
      if(player!=null&&command.method_10545("SourceAxesHash")&&command.method_10550("SourceAxesHash")!=HostAxes.signature(t))throw new IllegalArgumentException("主路曲线已改变，请重新打开生成器查看预览");
      var plan = t.method_10545("Corridor")?Corridors.resolve(level,player,t):
          player!=null&&ConfirmedInterchangeFit.eligible(t)&&read(t.method_10562("Options")).adjustEndpoints()
              ?confirmedPlan(t,command):plan(t);
      UUID group = t.method_25928("Id") ? t.method_25926("Id") : UUID.randomUUID(),
          owner =
              t.method_25928("Owner")
                  ? t.method_25926("Owner")
                  : player == null ? new UUID(0, 0) : player.method_5667();
      Set<UUID> removed = new HashSet<>();
      var retainedConnector=InterchangeConnectors.preserve(data,t,plan);
      if (!t.method_25928("Id"))
        for (int axis = 0; axis * 2 + 1 < points.length; axis++)
          for (var r :
              mainChain(data, class_2338.method_10092(points[axis * 2]), class_2338.method_10092(points[axis * 2 + 1]))) {
            if (player != null) RoadData.requireOwner(player, r.owner());
            removed.add(r.id());
          }

      if (!t.method_25928("Id") && points.length == 3)
        for (var r : thirdArmChain(data, t, points)) {
          if (player != null) RoadData.requireOwner(player, r.owner());
          removed.add(r.id());
        }
      for (var built : data.index.roads.values()) {
        var r = built.record;
        boolean main = false;
        for (int axis = 0; axis * 2 + 1 < points.length; axis++)
          main |=
              (r.a().method_10063() == points[axis * 2] && r.b().method_10063() == points[axis * 2 + 1])
                  || (r.b().method_10063() == points[axis * 2] && r.a().method_10063() == points[axis * 2 + 1]);
        if (InterchangeJunctions.belongs(data,group,r.assembly()) || main && r.assembly()==null) {
          if (player != null) RoadData.requireOwner(player, r.owner());
          removed.add(r.id());
        }
      }
      for(var leg:plan.legs()){UUID source=ContinuousRoads.sourceId(leg.name());if(source!=null){var old=data.index.roads.get(source);if(old!=null&&player!=null)RoadData.requireOwner(player,old.record.owner());removed.add(source);}}
      // Only unchanged recorded continuations accepted into this plan are replaced.
      var committedContinuousLimits=ContinuousRoads.committedLimits(t,plan.anchors());
      class_2499 proposedNodes = new class_2499();
      plan.anchors().forEach(node -> proposedNodes.add(RoadRecord.writeNode(node)));
      boolean adjust = read(t.method_10562("Options")).adjustEndpoints();
      if (player != null
          && adjust
          && (!command
                  .method_10554("SourceNodes", class_2520.field_33260)
                  .equals(t.method_10554("Nodes", class_2520.field_33260))
              || !command.method_10554("FittedNodes", class_2520.field_33260).equals(proposedNodes)))
        throw new IllegalArgumentException("端点或方案已变化，请重新打开立交并查看端点调整预览");
      List<RoadData.NodeMove> moves = new ArrayList<>();
      List<RoadIndex.Built> sharedChanges=new ArrayList<>();
      long[] sourcePoints = points.clone();
      points = points.clone();
      for (int i = 0; i < points.length; i++) {
        class_2338 from = class_2338.method_10092(sourcePoints[i]);
        var endpoint = InterchangeEndpoints.read(level, player, t, i);
        Node target = plan.anchors().get(i);
        boolean changed = !endpoint.node().equals(target);
        if (!changed && endpoint.marker() != null) continue;
        if(changed&&ContinuousRoads.virtual(t,i,target)){points[i]=class_2338.method_49637(target.position().x(),target.position().y(),target.position().z()).method_10063();continue;}
        class_2338 outer=ContinuousRoads.physicalEnd(t,i,target);if(!outer.equals(from)){from=outer;var marker=RoadData.requireNode(level,from,player);endpoint=new InterchangeEndpoints.Endpoint(marker.constructionNode(),marker,marker.method_38244());changed=!endpoint.node().equals(target);}
        if (changed && !adjust) throw new IllegalArgumentException("未允许调整端点");
        if(changed)SharedRoadEndpoints.stage(data,level,player,from,endpoint.node(),target,sharedChanges,removed);
        V p = target.position();
        class_2338 to = changed ? class_2338.method_49637(p.x(), p.y(), p.z()) : from;
        moves.add(new RoadData.NodeMove(endpoint.marker() == null ? null : from, to, target, endpoint.snapshot()));
        points[i] = to.method_10063();
      }
      if (Arrays.stream(points).distinct().count() != points.length)
        throw new IllegalArgumentException("调整后的端点方块重叠");
      HostAxes.fit(t,plan.anchors());
      t.method_10566("Nodes", proposedNodes);
      t.method_10566("PlanningNodes",proposedNodes.method_10612());
      t.method_10564("Points", points);
      if(points.length>=5)workChunks.multiInterchange();
      List<RoadIndex.Built> records = new ArrayList<>(sharedChanges);
      class_2499 roles = new class_2499();
      class_2499 signTopology = new class_2499();
      int part = 0;
      if(read(t.method_10562("Options")).toll().enabled()){t.method_10566("TollConnectorRoads",new class_2499());t.method_10551("TollConnectorShape");}
      t.method_10556("IntegratedToll",read(t.method_10562("Options")).toll().enabled());
      var junctionSpecs=new ArrayList<JunctionSpec>();
      var junctionTags=new ArrayList<class_2487>();
      for (var leg : plan.legs())
        for (Mesh mesh : List.of(leg.mesh())) {
          Node a = RoadRibbon.start(mesh), b = RoadRibbon.end(mesh);
          class_2338 pa = anchor(points, t, a.position()), pb = anchor(points, t, b.position());
          UUID sourceId=ContinuousRoads.sourceId(leg.name());
          UUID roadId = sourceId!=null?ContinuousSections.id(leg.name()):
              UUID.nameUUIDFromBytes(
                  (group + ":" + part++).getBytes(java.nio.charset.StandardCharsets.UTF_8));
          RoadRecord record =
              new RoadRecord(roadId, owner, pa, pb, a, b, mesh.settings(), false, 4)
                  .alignment(group, mesh);
          if(sourceId!=null){
            var source=ContinuousSections.source(t,leg.name());
            if(a.position().distance(source.start().position())<1e-6)pa=source.a();
            if(b.position().distance(source.end().position())<1e-6)pb=source.b();
            for(var move:moves){if(pa.equals(move.from()))pa=move.to();if(pb.equals(move.from()))pb=move.to();}
            // A sliced source position may straddle an integer by a few ulps.
            // The confirmed marker address takes precedence over that derived source address.
            pa=anchor(points,t,a.position(),pa);pb=anchor(points,t,b.position(),pb);
            record=new RoadRecord(roadId,source.owner(),pa,pb,a,b,mesh.settings(),source.automatic(),source.clearance(),List.of(),source.endCaps(),source.buildVersion(),ContinuousRoads.donor(leg.name())?null:group,mesh.samples(),source.furniturePhase());
          } else record=record.withAttachments(com.sora.splineroads.core.RoadAttachments.Data.EMPTY);
          if(leg.name().equals(DoubleTrumpetPlanner.CONNECTOR)){
            if(!retainedConnector.isEmpty()){
              for(var keep:retainedConnector){records.add(new RoadIndex.Built(keep));var signLeg=new class_2487();signLeg.method_25927("Road",keep.id());signLeg.method_10569("From",-1);signLeg.method_10569("To",-1);signLeg.method_10556("Ramp",false);signTopology.add(signLeg);}continue;
            }
            InterchangeConnectors.capture(t,record);
          }
          if(leg.toll()!=null)record=InterchangeConnectors.group(record.toll(leg.toll()),group);
          if(DoubleTrumpetToll.connector(leg.name())&&!leg.name().equals(DoubleTrumpetPlanner.CONNECTOR))InterchangeConnectors.capturePart(t,record);
          if(leg.junction()!=null){
            var spec=leg.junction().spec();int slot=junctionSpecs.indexOf(spec);
            if(slot<0){slot=junctionSpecs.size();junctionSpecs.add(spec);junctionTags.add(InterchangeJunctions.descriptor(group,owner,slot,spec));}
            record=InterchangeJunctions.piece(group,owner,slot,leg.junction());roadId=record.id();
          }
          records.add(new RoadIndex.Built(record));
          var signLeg=new class_2487();signLeg.method_25927("Road",roadId);signLeg.method_10569("From",leg.from());signLeg.method_10569("To",leg.to());signLeg.method_10556("Ramp",mesh.settings().style().ramp());signTopology.add(signLeg);
          if(t.method_10545("Corridor")){
            class_2487 role=new class_2487();role.method_25927("Road",roadId);role.method_10582("Role",leg.name());roles.add(role);
          }
        }
      var partitionOwners=ContinuousSections.signOwners(plan,records);
      for(var entry:partitionOwners.entrySet())for(var state:data.smartSigns.road(entry.getKey()))entry.getValue().putIfAbsent(state.key().slot(),entry.getKey());
      var logicalSources=new HashSet<UUID>();for(var leg:plan.legs())if(leg.name().contains("@")&&data.streets.containsKey(ContinuousRoads.sourceId(leg.name())))logicalSources.add(ContinuousRoads.sourceId(leg.name()));
      ContinuousSections.updateSources(t,ContinuousService.sourcePlan(t,plan));
      // A partition preserves point identities, while its owning road ID may change.
      var pointOwners=new HashMap<UUID,UUID>();for(var r:records)for(var p:r.record.settings().options().lanePoints().points())pointOwners.put(p.id(),r.record.id());
      var remapped=new ArrayList<RoadIndex.Built>();for(var old:data.index.roads.values())if(!removed.contains(old.record.id())){
        var r=ContinuousSections.remap(old.record,pointOwners);if(r!=old.record){removed.add(r.id());remapped.add(new RoadIndex.Built(r));}}
      records.addAll(remapped);
      for(int i=0;i<records.size();i++){var r=ContinuousSections.remap(records.get(i).record,pointOwners);if(r!=records.get(i).record)records.set(i,new RoadIndex.Built(r));}
      // Junction fill triangles are standard SR junction pieces, not additional
      // road alignments. Keep the original alignment budget and bound them separately.
      long junctionPieces=records.stream().filter(r->r.record.junction()!=null).count();
      if (records.size()-junctionPieces > 128 || junctionSpecs.size()>2 || junctionPieces>512)
        throw new IllegalArgumentException("立交道路或路口分段过多，请缩小范围");
      // Recheck every external road, not just the two selected axes, before any writes.
      for (var proposed : records)
        for (var old : data.index.roads.values())
          if (!removed.contains(old.record.id()) && RoadIndex.overlapXZ(proposed.mesh, old.mesh, 1))
            checkExternal(proposed.mesh, old.mesh);
      List<RoadIndex.Built> existingRoads = new ArrayList<>();
      for (UUID oldId : removed)
        if (data.index.roads.containsKey(oldId)) existingRoads.add(data.index.roads.get(oldId));
      workChunks.roads(existingRoads);
      for (long point : t.method_10565("PreservedNodes")) workChunks.node(class_2338.method_10092(point));
      Set<class_2338> preserved = new HashSet<>();
      for (long point : points) preserved.add(class_2338.method_10092(point));
      for (long point : t.method_10565("PreservedNodes"))
        if (level.method_8321(class_2338.method_10092(point)) instanceof NodeEntity)
          preserved.add(class_2338.method_10092(point));
      for (UUID oldId : removed) {
        var old = data.index.roads.get(oldId);
        if(t.method_10545("Corridor")&&old!=null)for(class_2338 end:List.of(old.record.a(),old.record.b())){
          boolean external=data.index.atNode(end).stream().anyMatch(r->!removed.contains(r));
          boolean retained=records.stream().anyMatch(r->r.record.a().equals(end)||r.record.b().equals(end));
          if(external&&!retained)throw new IllegalArgumentException("辅路端点已连接其他道路，不能改变该接点位置；请先处理外接道路");
        }
        if (old != null)
          for (var p : List.of(old.record.a(), old.record.b()))
            if (level.method_8321(p) instanceof NodeEntity) preserved.add(p);
      }
      if(t.method_10545("Corridor")||!ContinuousRoads.sources(t).isEmpty()){
        // Generated frontage and continuous-range endpoints are owned by this saved combination.
        // Retire obsolete ones in the SAME transaction as its new pavement,
        // including markers preserved by earlier versions after an update.
        for(class_2338 old:new ArrayList<>(preserved)){
          if(records.stream().anyMatch(r->r.record.a().equals(old)||r.record.b().equals(old)))continue;
          if(data.index.atNode(old).stream().anyMatch(id->!removed.contains(id)))continue;
          if(level.method_8321(old) instanceof NodeEntity&&moves.stream().noneMatch(m->old.equals(m.from())))moves.add(RoadData.NodeMove.retire(old));
          preserved.remove(old);
        }
      }
      Set<class_2338> destinations = new HashSet<>();
      for(var pos:InterchangeConnectors.obsoleteNodes(data,t,records,removed)){
        if(level.method_8321(pos) instanceof NodeEntity){RoadData.requireNode(level,pos,player);moves.add(RoadData.NodeMove.retire(pos));}
        preserved.remove(pos);
      }
      moves.forEach(move -> {if(move.to()!=null)destinations.add(move.to());});
      if(t.method_10545("Corridor")||!ContinuousRoads.sources(t).isEmpty()||plan.legs().stream().anyMatch(l->l.name().contains("@"))){
        if(t.method_10545("Corridor"))t.method_10566("CorridorRoles",roles);
        // Generated frontage ends are real selectable endpoints for local-road extensions.
        Set<class_2338> added=new HashSet<>();
        for(var record:records)if(!record.mesh.settings().style().ramp())for(boolean first:new boolean[]{true,false}){
          class_2338 pos=first?record.record.a():record.record.b();
          if(destinations.contains(pos)){preserved.add(pos);continue;}
          if(level.method_8321(pos) instanceof NodeEntity){RoadData.requireNode(level,pos,player);preserved.add(pos);continue;}
          if(!added.add(pos))continue;
          Node node=InterchangeEndpoints.generated(points,plan.anchors(),pos,first?record.record.start():record.record.end());
          class_2487 snapshot=new class_2487();snapshot.method_25927("Owner",record.record.owner());
          snapshot.method_10566("Node",RoadRecord.writeNode(node));snapshot.method_10556("HeightExplicit",true);
          moves.add(new RoadData.NodeMove(null,pos,node,snapshot));destinations.add(pos);preserved.add(pos);
        }
      }
      for (var p : preserved) if (!destinations.contains(p)) RoadData.requireNode(level,p,player);
      ContinuousService.prepare(t,plan,records,junctionTags,signTopology,group,owner);
      var snapshotSources=ContinuousReclaim.snapshotCandidates(data,t,owner);
      data.replaceAssembly(level, player, records, removed, preserved, moves,editLimit(t));
      if(!committedContinuousLimits.isEmpty())t.method_10566("ContinuousLimits",committedContinuousLimits);
      partitionOwners.forEach(data.smartSigns::splitKeys);
      for(var leg:plan.legs())if(logicalSources.contains(ContinuousRoads.sourceId(leg.name())))data.streets.put(ContinuousSections.id(leg.name()),data.index.roads.get(ContinuousSections.id(leg.name())).record);
      InterchangeJunctions.forget(data,group);
      for(var junction:junctionTags)data.junctions.put(junction.method_25926("Id"),junction);
      t.method_10556("StandardServiceJunctions",!junctionTags.isEmpty());
      for (var move : moves) if (!destinations.contains(move.from())) preserved.remove(move.from());
      t.method_10564(
          "PreservedNodes", preserved.stream().mapToLong(class_2338::method_10063).sorted().toArray());
      t.method_25927("Id", group);
      t.method_25927("Owner", owner);
      t.method_10551("Partial");
      class_2499 occupied=new class_2499();
      for(var record:records)if(group.equals(record.record.assembly())&&ContinuousRoads.sources(t).stream().anyMatch(source->source.road().id().equals(record.record.id()))){var range=new class_2487();range.method_25927("Road",record.record.id());var source=ContinuousRoads.sources(t).stream().filter(entry->entry.road().id().equals(record.record.id())).findFirst().orElseThrow();int first=source.axis()*2;double start=com.sora.splineroads.core.RoadAttachments.station(record.mesh,plan.anchors().get(first).position()),end=com.sora.splineroads.core.RoadAttachments.station(record.mesh,plan.anchors().get(first+1).position());range.method_10549("From",Math.min(start,end));range.method_10549("To",Math.max(start,end));range.method_10566("Start",RoadRecord.writeNode(new Node(com.sora.splineroads.core.RoadAttachments.at(record.mesh,Math.min(start,end)),0,0)));range.method_10566("End",RoadRecord.writeNode(new Node(com.sora.splineroads.core.RoadAttachments.at(record.mesh,Math.max(start,end)),0,0)));occupied.add(range);}
      t.method_10566("OccupiedRoads",occupied);
      for(class_2520 value:t.method_10554("ContinuousSources",class_2520.field_33260)){
        var source=(class_2487)value;var original=RoadRecord.load(source.method_10562("Road"));var current=data.index.roads.get(original.id());
        if(current!=null){var r=current.record;
          if(!source.method_10577("Detached")&&!source.method_10577(ContinuousService.LOGICAL))source.method_10566("Road",ContinuousRoads.updatedSource(original,r).header());
          else if(source.method_10577("Detached")&&(source.method_10577("Reclaimable")||snapshotSources.contains(original.id())||records.stream().anyMatch(built->built.record.id().equals(original.id())))){
            source.method_10566("Road",r.header());source.method_10556("DetachedExact",true);
          }
        }
        source.method_10551("Reclaimable");
      }
      ContinuousService.capture(data,t);
      t.method_10566("SignTopology",signTopology);
      data.interchanges.put(group, t.method_10553());data.smartSigns.assemblyChanged(group);
      data.method_80();
      return (t.method_10545("Corridor")?"道路组合已整体建成：":"立交已整体建成：")
          + plan.movements()
          + (t.method_10545("Corridor")?" 条同侧连接匝道，":" 条转向匝道，")
          + records.size()
          + " 个可分区加载的路段；对应生成器右键路面可整体编辑";
    }
  }

  private static class_2338 anchor(long[] points, class_2487 t, V p) {
    return anchor(points,t,p,class_2338.method_49637(p.x(),p.y(),p.z()));
  }

  static class_2338 anchor(long[] points, class_2487 t, V p, class_2338 fallback) {
    var nodes = t.method_10554("Nodes", class_2520.field_33260);
    for (int i = 0; i < points.length; i++)
      if (RoadRecord.readNode(nodes.method_10602(i)).position().distance(p) < 1e-5)
        return class_2338.method_10092(points[i]);
    return fallback;
  }

  static void checkExternal(Mesh a, Mesh b) { checkExternal(a,b,null); }
  static void checkExternal(Mesh a, Mesh b, Mesh previous) {
    RoadClearance.check(a,b,previous);
  }

  public static long[] points(RoadData data, UUID id) {
    var saved = data.interchanges.get(id);
    if (saved == null) throw new IllegalArgumentException("立交已不存在");
    return saved.method_10565("Points").clone();
  }

  private static Set<class_2338> selected(class_2487 saved) {
    Set<class_2338> nodes = new HashSet<>();
    if (saved != null)
      for (String key : List.of("Points", "PreservedNodes"))
        for (long point : saved.method_10565(key)) nodes.add(class_2338.method_10092(point));
    return nodes;
  }

  /** A partial deletion keeps the group editable, but never resurrects removed roads implicitly. */
  public static void removePart(class_3218 level, class_3222 player, UUID roadId) {
    var data = RoadData.get(level);
    var road = data.index.roads.get(roadId);
    if (road == null) throw new IllegalArgumentException("道路已经不存在");
    if (player != null) RoadData.requireOwner(player, road.record.owner());
    UUID group = InterchangeJunctions.parent(data,road.record.assembly());
    requireNoEndpointJunction(data,group);
    var saved = data.interchanges.get(group);
    if (saved != null && player != null) RoadData.requireOwner(player, saved.method_25926("Owner"));
    data.replaceAssembly(level, player, List.of(), Set.of(roadId), selected(saved),List.of(),editLimit(saved));
    if (saved != null) {
      if (data.index.roads.values().stream().noneMatch(r -> group.equals(r.record.assembly())))
        data.interchanges.remove(group);
      else saved.method_10556("Partial", true);
      data.method_80();
    }
  }

  /** Remove connecting facilities and detach the surviving axial roads, preserving their paths. */
  public static void removeRamps(class_3218 level, class_3222 player, UUID group) {
    var data = RoadData.get(level);
    if(data.interchanges.containsKey(group)&&ParallelSpui.present(data.interchanges.get(group))){ParallelSpui.remove(level,player,data.interchanges.get(group).method_10553());return;}
    requireNoEndpointJunction(data,group);
    var saved = data.interchanges.get(group);
    if (saved == null) throw new IllegalArgumentException("立交不存在");
    if (player != null) RoadData.requireOwner(player, saved.method_25926("Owner"));
    Set<UUID> removed = new HashSet<>();
    List<RoadIndex.Built> mains = new ArrayList<>();
    Set<class_2338> selected = selected(saved);
    List<RoadData.NodeMove> markers = new ArrayList<>();
    Set<class_2338> added = new HashSet<>();
    Set<UUID> restoredServiceMain=saved.method_10545("Options")?InterchangeJunctions.restoreMain(data,saved,mains):Set.of();
    try (var chunks = RoadWorkChunks.open(level)) {
      for (var built : data.index.roads.values()) {
        var r = built.record;
        if (!InterchangeJunctions.belongs(data,group,r.assembly())) continue;
        if (player != null) RoadData.requireOwner(player, r.owner());
        removed.add(r.id());
        if (restoredServiceMain.contains(r.id())||r.junction()!=null||r.settings().style().ramp()
            || r.settings().style() == Style.UNMARKED
            || built.mesh.closed()) continue;
        // Axial main roads are the only two-way carriageways; pads and ring facilities are
        // excluded.
        boolean continuousMain=ContinuousRoads.sources(saved).stream().anyMatch(source->source.road().id().equals(r.id()));
        if (!continuousMain&&!saved.method_10545("Corridor") && !RoadProfile.catalog(r.settings().style()).twoWay()) continue;
        // The terminating C stem belongs to the three-way interchange. Removing its ramps
        // must remove this generated stub as well, retaining only the user's C marker.
        int arms=saved.method_10565("Points").length;
        if (!continuousMain&&(arms==3||arms==5)
            && (r.a().method_10063() == saved.method_10565("Points")[arms-1]
                || r.b().method_10063() == saved.method_10565("Points")[arms-1])) continue;
        mains.add(new RoadIndex.Built(r.structures(List.of()).alignment(null, built.mesh)));
        for (boolean first : new boolean[] {true, false}) {
          class_2338 pos = first ? r.a() : r.b();
          selected.add(pos);
          chunks.node(pos);
          if (level.method_8321(pos) instanceof NodeEntity) {
            RoadData.requireNode(level, pos, player);
          } else if (added.add(pos)) {
            // Three-way mainline stubs have an internal endpoint without a physical marker.
            Node node = first ? r.start() : r.end();
            class_2487 snapshot = new class_2487();
            snapshot.method_25927("Owner", r.owner());
            snapshot.method_10566("Node", RoadRecord.writeNode(node));
            snapshot.method_10556("HeightExplicit", true);
            markers.add(new RoadData.NodeMove(null, pos, node, snapshot));
          }
        }
      }
      data.replaceAssembly(level, player, mains, removed, selected, markers,editLimit(saved));
      InterchangeJunctions.forget(data,group);
      data.interchanges.remove(group);
      data.method_80();
    }
  }

  public static void remove(class_3218 level, class_3222 player, UUID id) {
    var current=RoadData.get(level).interchanges.get(id);if(current!=null&&ParallelSpui.present(current)){ParallelSpui.remove(level,player,current.method_10553());return;}
    var data = RoadData.get(level);
    requireNoEndpointJunction(data,id);
    var saved = data.interchanges.get(id);
    if (saved == null) throw new IllegalArgumentException("立交不存在");
    if (player != null) RoadData.requireOwner(player, saved.method_25926("Owner"));
    Set<UUID> ids = new HashSet<>();
    for (var r : data.index.roads.values())
      if (InterchangeJunctions.belongs(data,id,r.record.assembly())) ids.add(r.record.id());
    data.replaceAssembly(
        level,
        player,
        List.of(),
        ids,
        Arrays.stream(saved.method_10565("Points"))
            .mapToObj(class_2338::method_10092)
            .collect(java.util.stream.Collectors.toSet()),InterchangeConnectors.obsoleteNodes(data,saved.method_10553(),List.of(),ids).stream().filter(p->level.method_8321(p) instanceof NodeEntity).map(RoadData.NodeMove::retire).toList(),editLimit(saved));
    InterchangeJunctions.forget(data,id);
    data.interchanges.remove(id);
    data.method_80();
  }

  static void requireNoEndpointJunction(RoadData data,UUID group){
    if(group!=null&&data.streets.values().stream().anyMatch(r->group.equals(r.assembly())))
      throw new IllegalArgumentException("组合端点已形成路口；请先删除该路口的外接支路，再调整或删除组合");
  }
  private static int editLimit(class_2487 t){return t!=null&&t.method_10565("Points").length>=3?RoadLimits.MAX_MULTI_INTERCHANGE_EDIT_CELLS:RoadLimits.MAX_EDIT_CELLS;}
  private Interchanges() {}
}
