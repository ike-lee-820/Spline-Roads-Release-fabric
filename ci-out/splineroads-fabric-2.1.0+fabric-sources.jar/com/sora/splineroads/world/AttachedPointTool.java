package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadAttachments.Data;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import java.util.*;

public final class AttachedPointTool extends class_1792 {
  static boolean supported(RoadRecord r){return SideHosts.attachable(r)||r.junction()==null&&r.toll()==null&&!r.railway()&&!r.settings().style().ramp()&&r.settings().mode()!=Mode.RING&&(RoadProfile.catalog(r.settings()).type()==RoadProfile.Type.ORDINARY||RoadProfile.catalog(r.settings()).type()==RoadProfile.Type.HIGHWAY);}
  public record Pick(RoadIndex.Built road,RoadAttachments.Point point,double distance){}
  /** Match the elevated visible handle; occluding world blocks still stop selection. */
  public static Pick pick(class_3222 player){
    var eye=player.method_33571();var direction=player.method_5720();var end=eye.method_1019(direction.method_1021(96));
    double stop=player.method_5745(96,0,false).method_17784().method_1022(eye)+.7;var index=RoadData.get(player.method_51469()).index;var ids=new HashSet<UUID>();
    for(int d=0;d<=96;d+=8){var at=eye.method_1019(direction.method_1021(d));int cx=(int)Math.floor(at.field_1352)>>4,cz=(int)Math.floor(at.field_1350)>>4;for(int x=-1;x<=1;x++)for(int z=-1;z<=1;z++)ids.addAll(index.inChunk(net.minecraft.class_1923.method_8331(cx+x,cz+z)));}
    Pick best=null;
    for(UUID id:ids){var road=index.roads.get(id);if(road==null||!supported(road.record)&&!ElevatedPointTool.supported(road.record))continue;
      for(var point:road.record.settings().options().attachments().points()){
        if(!point.elevated()&&!supported(road.record))continue;
        if(road.record.settings().options().routing().controls().stream().anyMatch(c->c.id().equals(point.id())))continue;
        var p=point.position();var hit=new net.minecraft.class_238(p.x()-.26,p.y()+1.6,p.z()-.26,p.x()+.26,p.y()+2.2,p.z()+.26).method_992(eye,end);
        if(hit.isPresent()){double distance=hit.get().method_1022(eye);if(distance<=stop&&(best==null||distance<best.distance()))best=new Pick(road,point,distance);}
      }
    }return best;
  }
  public AttachedPointTool(){super(new class_1793().method_7889(1));}
  static RoadAttachments.Point create(class_3218 level,class_3222 player,RoadIndex.Built road,V hit){
    var q=RoadQueries.horizontal(road.mesh,hit);if(q.horizontalDistance()>q.sample().halfWidth()+.05)throw new IllegalArgumentException("附属点必须位于道路路面");
    V pos=q.sample().center();var existing=nearest(road,pos);if(existing!=null)return existing;
    var point=new RoadAttachments.Point(UUID.randomUUID(),pos,pos,false);
    var metadata=road.record.settings().options().attachments();var points=new ArrayList<>(metadata.points());points.add(point);
    RoadData.get(level).updatePointMetadata(level,player,road.record,metadata.points(points));return point;
  }
  public static RoadAttachments.Point nearest(RoadIndex.Built road,V hit){return road.record.settings().options().attachments().points().stream().filter(p->road.record.settings().options().routing().controls().stream().noneMatch(c->c.id().equals(p.id()))).filter(p->p.position().sub(hit).horizontalLength()<1.1&&hit.y()-p.position().y()>=-.2&&hit.y()-p.position().y()<=2.5).min(Comparator.comparingDouble(p->p.position().sub(hit).horizontalLength())).orElse(null);}
  @Override public class_1269 method_7884(class_1838 c){
    if(c.method_8045().field_9236)return class_1269.field_5812;
    if(c.method_8036() instanceof class_3222 p)try{
      if(!p.method_7294()||p.method_7325())throw new IllegalArgumentException("没有建设权限");
      var hit=c.method_17698();V v=new V(hit.field_1352,hit.field_1351,hit.field_1350);var road=SideHosts.hostAt(RoadData.get(p.method_51469()),RoadTool.pick(p),v);if(road==null||!supported(road.record))throw new IllegalArgumentException("请右键道路路面，不能选路口中心铺装");
      RoadData.requireOwner(p,road.record.owner());var point=nearest(road,v);
      if(point==null){point=create(p.method_51469(),p,road,v);
        road=RoadData.get(p.method_51469()).index.roads.get(road.record.id());
      }
      RoadNetwork.open(p,payload(road.record,point));
    }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}
    return class_1269.field_21466;
  }
  public static class_2487 payload(RoadRecord r,RoadAttachments.Point p){var t=new class_2487();t.method_10582("Kind","attachedPoint");t.method_10556("Elevated",p.elevated());t.method_10566("Road",r.header());t.method_25927("Id",r.id());t.method_25927("Point",p.id());t.method_10569("Signature",GantryTool.signature(r));t.method_10566("Position",RoadRecord.writeNode(new Node(p.position(),0,0)));t.method_10566("Origin",RoadRecord.writeNode(new Node(p.origin(),0,0)));t.method_10556("MarkingsOnly",r.assembly()!=null);return t;}
  public static String edit(class_3218 level,class_3222 player,class_2487 t){
    var data=RoadData.get(level);var built=data.index.roads.get(t.method_25926("Id"));if(built==null||built.record.toll()!=null)throw new IllegalArgumentException("收费站请使用收费站生成器编辑");var r=built.record;
    if(player!=null){RoadData.requireOwner(player,r.owner());if(!player.method_7294()||player.method_7325())throw new IllegalArgumentException("没有建设权限");}
    if(t.method_10550("Signature")!=GantryTool.signature(r))throw new IllegalArgumentException("道路已改变，请重新选择附属点");
    var metadata=r.settings().options().attachments();var point=metadata.points().stream().filter(p->p.id().equals(t.method_25926("Point"))).findFirst().orElseThrow(()->new IllegalArgumentException("附属点已改变所属道路，请重新选择"));
    var points=new ArrayList<>(metadata.points());
    if(t.method_10577("Delete")){
      double d=RoadAttachments.station(built.mesh,point.position());
      if(d>1e-5&&d<built.mesh.length()-1e-5&&!RoadAttachments.paint(built.mesh,d-1e-5).equals(RoadAttachments.paint(built.mesh,d+1e-5)))throw new IllegalArgumentException("附属点两侧标线不同，请先统一两个区间的标线后再删除");
      points.remove(point);if(point.controlled())data.removeAttachedPoint(level,player,r,metadata.points(points),point.id());else data.updatePointMetadata(level,player,r,metadata.points(points));return "附属点已删除";
    }
    throw new IllegalArgumentException("附属点固定在道路断面中央，不能调整坐标或用作曲线控制点");
  }
}
