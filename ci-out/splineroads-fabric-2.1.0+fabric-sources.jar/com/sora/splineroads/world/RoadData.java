package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.RoadGeometry;
import com.sora.splineroads.core.RoadConnectionChecks;
import com.sora.splineroads.core.RoadClearance;
import com.sora.splineroads.core.RoadWaterPolicy;
import com.sora.splineroads.core.SmartSigns.Key;
import com.sora.splineroads.core.LanePoints;
import com.sora.splineroads.core.LanePoints.Lane;
import com.sora.splineroads.core.LanePoints.Link;
import com.sora.splineroads.core.ElevatedAccess.Reservation;
import com.sora.splineroads.core.JunctionPlanner.Ref;
import com.sora.splineroads.core.JunctionSpec;
import com.sora.splineroads.core.LaneAdditions;
import com.sora.splineroads.core.RoadGantry;
import com.sora.splineroads.core.RoadGantry.Station;
import com.sora.splineroads.core.RoadLaneLines;
import com.sora.splineroads.core.RoadLaneLines.Edit;
import com.sora.splineroads.core.RoadAttachments;
import com.sora.splineroads.core.RoadAttachments.Data;
import com.sora.splineroads.core.RoadAttachments.Paint;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadAttachments.Range;
import com.sora.splineroads.core.RoadAprons;
import com.sora.splineroads.core.StreetLampClearance;
import com.sora.splineroads.core.TollPlanner;
import com.sora.splineroads.core.RoadRaster;
import com.sora.splineroads.core.RoadRaster.Cell;
import com.sora.splineroads.core.RoadSolidOverlap.Index;
import com.sora.splineroads.core.RoadInfrastructure;
import com.sora.splineroads.core.RoadInfrastructure.Config;
import com.sora.splineroads.core.RoadStructures;
import com.sora.splineroads.core.RoadStructures.Part;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RailwayCrossings;
import com.sora.splineroads.core.RoadTunnel;
import com.sora.splineroads.core.RoadTunnelFit;
import com.sora.splineroads.core.RoadNoses;
import com.sora.splineroads.core.RoadLimits;
import com.sora.splineroads.core.RoadPlanner;
import com.sora.splineroads.core.RoadPlanner.Hint;
import com.sora.splineroads.core.RoadPlanner.Plan;
import com.sora.splineroads.core.RoadPlanningBudget;
import com.sora.splineroads.core.RoadProfile;
import com.sora.splineroads.core.RoadProfile.Options;
import com.sora.splineroads.core.RoadProfile.Type;
import com.sora.splineroads.core.RoadQueries;
import com.sora.splineroads.core.RoadQueries.Projection;
import com.sora.splineroads.core.RoadQueries.Scope;
import com.sora.splineroads.core.RoadTransitions;
import com.sora.splineroads.core.RoadTransitions.Ends;
import com.sora.splineroads.core.RoadTransitions.Section;
import com.sora.splineroads.core.RoadEndpointSections;
import com.sora.splineroads.core.RoadTimings;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RailbedStore.Entry;
import com.sora.splineroads.world.RoadBlocks.Fill;
import com.sora.splineroads.world.RoadCycleChain.Leg;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.world.RoadIndex.Built.Column;
import com.sora.splineroads.world.RoadTerrain.Cache;
import com.sora.splineroads.world.StructurePlanner.Stage;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.class_18;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_26;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.nbt.*;

public final class RoadData extends class_18 {
  public final RoadIndex index = new RoadIndex();
  public final RailbedStore railbeds = new RailbedStore();
  class_2680 railbedOriginal(long key){return terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564());}
  record StreetLedger(class_2680 fill,class_2680 original,class_2680 sidewalk,boolean apron){}
  StreetLedger streetLedger(long key){return new StreetLedger(terrainFill.get(key),terrainOriginal.get(key),sidewalkPlaced.get(key),apronPlaced.contains(key));}
  void streetLedger(long key,StreetLedger value){
    if(value.fill()==null)terrainFill.remove(key);else terrainFill.put(key,value.fill());
    if(value.original()==null)terrainOriginal.remove(key);else terrainOriginal.put(key,value.original());
    if(value.sidewalk()==null)sidewalkPlaced.remove(key);else sidewalkPlaced.put(key,value.sidewalk());
    if(value.apron())apronPlaced.add(key);else apronPlaced.remove(key);
  }
  class_2487 streetObjects(Set<UUID> ids,Set<UUID> centers){
    var t=new class_2487();var roads=new class_2499();var logical=new class_2499();var junctionsTag=new class_2499();
    ids.stream().sorted().forEach(id->{var r=index.roads.get(id);if(r!=null)roads.add(r.record.save());if(streets.containsKey(id))logical.add(streets.get(id).save());});
    centers.stream().sorted().forEach(id->{if(junctions.containsKey(id))junctionsTag.add(junctions.get(id).method_10553());});
    t.method_10566("Roads",roads);t.method_10566("Streets",logical);t.method_10566("Centers",junctionsTag);return t;
  }
  void restoreStreetObjects(class_3218 level,Set<UUID> ids,Set<UUID> centers,class_2487 snapshot){
    for(var id:ids){index.remove(id);streets.remove(id);}centers.forEach(junctions::remove);
    for(class_2520 value:snapshot.method_10554("Roads",class_2520.field_33260)){var r=RoadRecord.load((class_2487)value);index.put(RoadIndex.Built.loading(r));}
    for(class_2520 value:snapshot.method_10554("Streets",class_2520.field_33260)){var r=RoadRecord.load((class_2487)value);streets.put(r.id(),r);}
    for(class_2520 value:snapshot.method_10554("Centers",class_2520.field_33260)){var t=(class_2487)value;junctions.put(t.method_25926("Id"),t.method_10553());}
    for(var id:ids){var r=index.roads.get(id);if(r==null)RoadNetwork.broadcastDelete(level,id);else RoadNetwork.broadcastRoad(level,r.record);}method_80();
  }
  static void restoreStreetBlocks(class_3218 level,Map<Long,class_2680> states,Map<Long,class_2487> entities){restoreBlocks(level,states,entities,failure->{throw failure;},true);}
  static void restorePlannerBlocks(class_3218 level,Map<Long,class_2680> states,Map<Long,class_2487> entities){restoreBlocks(level,states,entities,failure->{throw failure;},false);}
  void railbedOwns(long key){terrainOriginal.remove(key);terrainFill.remove(key);}
  public final SmartSignRoads smartSigns = new SmartSignRoads(this);
  public RoadData(){index.changed=smartSigns::changed;}
  private class_3218 owningLevel;
  RoadStructures.Ground terrainGround(){return owningLevel==null?null:RoadTerrain.read(owningLevel,terrainFill,terrainOriginal,new RoadTerrain.Cache(terrainFill,terrainOriginal));}
  RoadStructures.Ground railbedTerrain(Map<Long,class_2680> prior){
    var originals=new Long2ObjectOpenHashMap<class_2680>(terrainOriginal);for(var entry:railbeds.entries.values())entry.original.forEach(originals::putIfAbsent);originals.putAll(prior);
    return RoadTerrain.read(owningLevel,terrainFill,originals,new RoadTerrain.Cache(terrainFill,originals));
  }
  boolean withinHeight(com.sora.splineroads.core.RoadGeometry.Mesh mesh){return owningLevel==null||mesh.min().y()-mesh.settings().thickness()>=owningLevel.method_31607()&&mesh.max().y()+4<owningLevel.method_31600();}
  int minimumBuildHeight(){return owningLevel==null?Integer.MIN_VALUE:owningLevel.method_31607();}
  private Set<UUID> confirmedLaneDeletes=Set.of();
  void removeWithDependents(class_3218 level,class_3222 player,UUID id,Set<UUID> dependents){for(var v:dependents)if(player!=null)requireOwner(player,index.roads.get(v).record.owner());confirmedLaneDeletes=Set.copyOf(dependents);try{remove(level,player,id);}finally{confirmedLaneDeletes=Set.of();}}
  final Map<UUID,RoadRecord> streets = new LinkedHashMap<>();
  /** Logical street settings are the editor's authority, ahead of derived pieces. */
  public RoadRecord editableRoad(UUID id){var street=streets.get(id);var built=index.roads.get(id);
    if(street!=null&&built!=null&&!LaneTopology.metadata(built.record).access().isEmpty())return street.withLanePoints(ElevatedAccessRoads.logicalLanes(street,built.record));
    return street!=null?street:built==null?null:built.record;}
  final Map<UUID, class_2487> junctions = new HashMap<>();
  final Map<UUID, class_2487> interchanges = new HashMap<>();
  private final Map<Long,Set<UUID>> islandRepair=new HashMap<>();
  private final Map<Long,List<Long>> groundJoinRepair=new HashMap<>();
  private final Map<Long,List<RoadStructures.Part>> retiredSignsByChunk=new HashMap<>();
  private Long2ObjectOpenHashMap<class_2680> sidewalkPlaced = new Long2ObjectOpenHashMap<>();
  private final Map<Long,List<Long>> apronWidthRepair=new HashMap<>();
  private final Map<Long,List<RoadStructures.Part>> structureRepair103=new HashMap<>();
  private final Set<UUID> supportRepair104=new LinkedHashSet<>(),attemptedSupportRepair104=new HashSet<>();
  private Set<Long> apronPlaced = new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
  private final Long2ObjectOpenHashMap<class_2680> terrainOriginal = new Long2ObjectOpenHashMap<>();
  private final Long2ObjectOpenHashMap<class_2680> terrainFill = new Long2ObjectOpenHashMap<>();
  private final Map<Long, Set<UUID>> repairedChunks = new LinkedHashMap<>(128,.75f,true) {
    @Override protected boolean removeEldestEntry(Map.Entry<Long, Set<UUID>> e) { return size() > 4096; }
  };

  public static RoadData get(class_3218 level) {
    var storage=level.method_17983();var data=storage.method_20786(RoadData::load,"splineroads");
    if(data==null){
      // DimensionDataStorage logs and returns null when a loader throws. Never
      // mistake an unreadable existing save for an empty new world.
      var folder=net.minecraft.class_2874.method_12488(level.method_27983(),level.method_8503().method_27050(net.minecraft.class_5218.field_24188));
      if(java.nio.file.Files.exists(folder.resolve("data").resolve("splineroads.dat")))
        throw new IllegalStateException("Spline Roads saved data could not be loaded; original file preserved. See the saved-data error in the server log.");
      data=new RoadData();storage.method_123("splineroads",data);
    }
    data.owningLevel=level;return data;
  }

  public static RoadData load(class_2487 root) {
    if (root.method_10550("Version") > 73)
      throw new IllegalStateException("Spline Roads save is newer than this mod");
    if (root.method_10550("Version") < 70)
      throw new IllegalStateException("Spline Roads supports save format 70 or newer; original file preserved");
    if(root.method_10550("Version")==70)for(String kind:List.of("Roads","LogicalStreets"))for(class_2520 entry:root.method_10554(kind,class_2520.field_33260)){
      var legacy=((class_2487)entry).method_10562("Settings").method_10562("Infrastructure").method_10554("Signs",class_2520.field_33260);
      if(!legacy.isEmpty())throw new IllegalStateException("Spline Roads format 70 contains retired custom signs; conversion required, original file preserved");
    }
    long loadStarted=System.nanoTime();
    RoadData data = new RoadData();
    data.railbeds.load(root.method_10562("Railbeds"));
    Map<class_2487,class_2680> palette=new HashMap<>();
    for(class_2520 t:root.method_10554("Roads",class_2520.field_33260)){
      var r=RoadRecord.load((class_2487)t);
      if(r.toll()!=null&&root.method_10550("Version")<48){
        var oldParts=r.structures().stream().filter(p->p.model()!=null&&p.model().startsWith("sr:toll_")).toList();
        var parts=new ArrayList<>(r.structures());parts.removeAll(oldParts);parts.addAll(TollPlanner.plan(r.toll()).structures());
        for(var part:oldParts){double pad=part.halfExtent();for(int x=(int)Math.floor(Math.min(part.a().x(),part.b().x())-pad)>>4;x<=(int)Math.floor(Math.max(part.a().x(),part.b().x())+pad)>>4;x++)for(int z=(int)Math.floor(Math.min(part.a().z(),part.b().z())-pad)>>4;z<=(int)Math.floor(Math.max(part.a().z(),part.b().z())+pad)>>4;z++)data.retiredSignsByChunk.computeIfAbsent(net.minecraft.class_1923.method_8331(x,z),k->new ArrayList<>()).add(part);}
        r=r.structures(parts);data.method_80();
      }
      var ref=r.junction();
      if(ref!=null&&ref.geometryVersion()==42&&ref.spec().kind()==com.sora.splineroads.core.JunctionSpec.Kind.ROUNDABOUT){
        var next=new com.sora.splineroads.core.JunctionPlanner.Ref(ref.spec(),ref.piece(),43);
        var parts=new ArrayList<>(r.structures());
        if(ref.get().arm()<0&&ref.spec().greenIsland()){
          var oldIsland=ref.get().structures().stream().filter(p->(p.material()==RoadStructures.Material.SOIL||p.material()==RoadStructures.Material.GREEN)&&p.a().sub(ref.spec().center()).horizontalLength()<ref.spec().islandRadius()).toList();
          parts.removeAll(oldIsland);parts.addAll(next.get().structures().stream().filter(p->p.model().startsWith("sr:roundabout_")).toList());
        }
        r=r.junction(r.assembly(),next).structures(parts);var rebuilt=RoadIndex.Built.loading(r);
        if(ref.get().arm()<0&&ref.spec().greenIsland())for(long c:rebuilt.chunks)data.islandRepair.computeIfAbsent(c,k->new HashSet<>()).add(r.id());
        data.index.put(rebuilt);data.method_80();
      }else data.index.put(RoadIndex.Built.loading(r));
    }
    if(root.method_10550("Version")<52)for(var built:List.copyOf(data.index.roads.values())){
      var record=built.record;var old=record.structures();var fresh=new ArrayList<>(RoadStructures.repairJoinedPlanting(built.mesh,old));
      if(record.toll()!=null&&!record.toll().config().name().isEmpty()){
        fresh.removeIf(p->p.model().startsWith("sr:toll_model_name_"));
        fresh.addAll(TollPlanner.plan(record.toll()).structures().stream().filter(p->p.model().startsWith("sr:toll_model_name_")).toList());
      }
      if(record.settings().structure()==Structure.TUNNEL&&record.settings().options().cycleRail()){
        var nearby=data.index.surfaceNeighbors(built);
        var ground=new RoadStructures.Ground(){public double top(double x,double z,double y){return Double.NaN;}public boolean blocked(RoadStructures.Part part){return false;}
          public boolean joined(V point){return nearby.stream().anyMatch(n->RoadQueries.contains(n.mesh,point,.05,.2));}};
        var rails=new ArrayList<RoadStructures.Part>();RoadStructures.cycleFurniture(built.mesh,ground,rails);
        var existing=new HashSet<>(fresh);for(var rail:rails)if(existing.add(rail))fresh.add(rail);
      }
      var oldSet=new HashSet<>(old);var nextSet=new HashSet<>(fresh);var delta=new ArrayList<RoadStructures.Part>();
      for(var part:oldSet)if(!nextSet.contains(part))delta.add(part);for(var part:nextSet)if(!oldSet.contains(part))delta.add(part);
      if(delta.isEmpty())continue;
      data.index.put(RoadIndex.Built.loading(record.structures(fresh)));
      for(var part:delta){double pad=part.halfExtent();for(int x=(int)Math.floor(Math.min(part.a().x(),part.b().x())-pad)>>4;x<=(int)Math.floor(Math.max(part.a().x(),part.b().x())+pad)>>4;x++)for(int z=(int)Math.floor(Math.min(part.a().z(),part.b().z())-pad)>>4;z<=(int)Math.floor(Math.max(part.a().z(),part.b().z())+pad)>>4;z++)data.structureRepair103.computeIfAbsent(net.minecraft.class_1923.method_8331(x,z),k->new ArrayList<>()).add(part);}
      data.method_80();
    }
    for(class_2520 value:root.method_10554("StructureRepair103",class_2520.field_33260)){var tag=(class_2487)value;data.structureRepair103.computeIfAbsent(tag.method_10537("Chunk"),k->new ArrayList<>()).addAll(RoadRecord.unpackStructures(tag.method_10547("Parts")));}
    // Existing generated lamps also respect the new signs after a save is loaded.
    // Cleanup is limited to exact lamp parts; chunk repair preserves other owners.
    var sight=JunctionSignRoads.lampClearance(List.copyOf(data.index.roads.values()));
    for(var built:List.copyOf(data.index.roads.values())){
      var removed=com.sora.splineroads.core.StreetLampClearance.removed(built.record.structures(),sight);if(removed.isEmpty())continue;
      for(var part:removed){double pad=part.halfExtent();for(int x=(int)Math.floor(Math.min(part.a().x(),part.b().x())-pad)>>4;x<=(int)Math.floor(Math.max(part.a().x(),part.b().x())+pad)>>4;x++)for(int z=(int)Math.floor(Math.min(part.a().z(),part.b().z())-pad)>>4;z<=(int)Math.floor(Math.max(part.a().z(),part.b().z())+pad)>>4;z++)data.retiredSignsByChunk.computeIfAbsent(net.minecraft.class_1923.method_8331(x,z),k->new ArrayList<>()).add(part);}
      data.index.put(RoadIndex.Built.loading(built.record.structures(built.record.structures().stream().filter(p->!removed.contains(p)).toList())));
    }
    for(class_2520 value:root.method_10554("RetiredSignCleanup",class_2520.field_33260)){var tag=(class_2487)value;data.retiredSignsByChunk.computeIfAbsent(tag.method_10537("Chunk"),k->new ArrayList<>()).addAll(RoadRecord.unpackStructures(tag.method_10547("Parts")));}
    RoadBlockStorage.read(root.method_10554(root.method_10545("TerrainFillPalette")?"TerrainFillPalette":"OriginalPalette", class_2520.field_33260), data.terrainFill);
    RoadBlockStorage.read(root.method_10554("SidewalkPalette", class_2520.field_33260), data.sidewalkPlaced);
    for(long key:root.method_10565("RoadAprons"))if(data.sidewalkPlaced.containsKey(key))data.apronPlaced.add(key);
    var pendingAprons=new HashSet<Long>();for(long c:root.method_10565("ApronWidthRepair"))pendingAprons.add(c);
    for(long key:data.apronPlaced){long c=new net.minecraft.class_1923(class_2338.method_10092(key)).method_8324();if(root.method_10550("Version")<51||pendingAprons.contains(c))data.apronWidthRepair.computeIfAbsent(c,k->new ArrayList<>()).add(key);}
    if(!data.apronWidthRepair.isEmpty())data.method_80();
    RoadBlockStorage.read(root.method_10554("TerrainOriginalPalette", class_2520.field_33260), data.terrainOriginal);
    for (class_2520 entry : root.method_10554("Interchanges", class_2520.field_33260)) {
      class_2487 t = (class_2487) entry;
      data.interchanges.put(t.method_25926("Id"), t.method_10553());
    }
    for (class_2520 entry : root.method_10554("Junctions", class_2520.field_33260)) {
      class_2487 t = (class_2487)entry; data.junctions.put(t.method_25926("Id"),t.method_10553());
    }
    for(class_2520 t:root.method_10554("LogicalStreets",class_2520.field_33260)){var r=RoadRecord.load((class_2487)t);data.streets.put(r.id(),r);}
    if(root.method_10550("Version")<18)for(class_2520 entry:root.method_10554("SidewalkBlocks",class_2520.field_33260)) {var t=(class_2487)entry;data.sidewalkPlaced.put(t.method_10537("Pos"),palette.computeIfAbsent(t.method_10562("State"),v->class_2512.method_10681(class_7923.field_41175.method_46771(),v)));}
    if(!data.retiredSignsByChunk.isEmpty())data.method_80();
    for(class_2520 value:root.method_10554("IslandRepair",class_2520.field_33260)){var t=(class_2487)value;if(t.method_25928("Road"))data.islandRepair.computeIfAbsent(t.method_10537("Chunk"),k->new HashSet<>()).add(t.method_25926("Road"));}
    var pendingGround=new HashSet<Long>();for(long c:root.method_10565("GroundJoinRepair"))pendingGround.add(c);
    for(long key:data.terrainOriginal.keySet()){long c=new net.minecraft.class_1923(class_2338.method_10092(key)).method_8324();if(root.method_10550("Version")<49||pendingGround.contains(c))data.groundJoinRepair.computeIfAbsent(c,k->new ArrayList<>()).add(key);}
    if(!data.groundJoinRepair.isEmpty())data.method_80();
    LaneTopology.initialize(data);
    for(class_2520 value:root.method_10554("SupportRepair104",class_2520.field_33260)){var t=(class_2487)value;if(t.method_25928("Road")&&data.index.roads.containsKey(t.method_25926("Road")))data.supportRepair104.add(t.method_25926("Road"));}
    // Do not scan every saved pier against every road during world loading.
    // Normal explicit edits still rebuild supports against the complete corridor index.
    data.smartSigns.load(root.method_10554("SmartSigns",class_2520.field_33260));
    if(data.railbeds.pending.isEmpty())data.adoptRailbeds(null);
    RoadTimings.reportLoad(loadStarted,data.index.roads.size());
    return data;
  }

  @Override
  public class_2487 method_75(class_2487 root) {
    root.method_10566("Railbeds",railbeds.save());
    root.method_10569("Version", 73);
    var supportRepairs=new class_2499();for(UUID id:supportRepair104){var t=new class_2487();t.method_25927("Road",id);supportRepairs.add(t);}root.method_10566("SupportRepair104",supportRepairs);
    var repair103=new class_2499();structureRepair103.forEach((chunk,parts)->{var t=new class_2487();t.method_10544("Chunk",chunk);t.method_10570("Parts",RoadRecord.packStructures(parts));repair103.add(t);});root.method_10566("StructureRepair103",repair103);
    root.method_10564("ApronWidthRepair",apronWidthRepair.keySet().stream().mapToLong(Long::longValue).toArray());
    var islands=new class_2499();islandRepair.forEach((c,ids)->ids.forEach(id->{var t=new class_2487();t.method_10544("Chunk",c);t.method_25927("Road",id);islands.add(t);}));root.method_10566("IslandRepair",islands);
    root.method_10564("GroundJoinRepair",groundJoinRepair.keySet().stream().mapToLong(Long::longValue).toArray());
    root.method_10566("SmartSigns",smartSigns.save());
    var cleanup=new class_2499();retiredSignsByChunk.forEach((chunk,parts)->{var t=new class_2487();t.method_10544("Chunk",chunk);t.method_10570("Parts",RoadRecord.packStructures(parts));cleanup.add(t);});root.method_10566("RetiredSignCleanup",cleanup);
    class_2499 logical=new class_2499();streets.values().forEach(r->logical.add(r.save()));root.method_10566("LogicalStreets",logical);
    class_2499 roads = new class_2499();
    index.roads.values().forEach(r -> roads.add(r.record.save()));
    class_2499 groups = new class_2499();
    interchanges.values().forEach(t -> groups.add(t.method_10553()));
    root.method_10566("Interchanges", groups);
    class_2499 junctionTags = new class_2499(); junctions.values().forEach(t -> junctionTags.add(t.method_10553()));
    root.method_10566("Junctions", junctionTags);
    root.method_10566("TerrainOriginalPalette", RoadBlockStorage.write(terrainOriginal));
    root.method_10566("TerrainFillPalette", RoadBlockStorage.write(terrainFill));
    root.method_10551("OriginalPalette");
    root.method_10566("SidewalkPalette", RoadBlockStorage.write(sidewalkPlaced));
    root.method_10564("RoadAprons",apronPlaced.stream().mapToLong(Long::longValue).toArray());
    root.method_10551("OriginalEntities");
    root.method_10566("Roads", roads);
    root.method_10551("Originals");
    root.method_10551("SidewalkBlocks");
    return root;
  }

  public boolean linked(class_2338 pos) {
    return !index.atNode(pos).isEmpty();
  }

  public static void requireOwner(class_3222 player, UUID owner) {
    if (owner != null && !owner.equals(player.method_5667()) && !player.method_5687(2))
      throw new IllegalArgumentException("只能编辑自己创建的道路和端点");
  }

  public static NodeEntity requireNode(class_3218 level, class_2338 pos, class_3222 player) {
    try (var work = RoadWorkChunks.open(level)) {
      work.node(pos);
      if (!(level.method_8321(pos) instanceof NodeEntity node))
        throw new IllegalArgumentException("端点不存在，可能已被删除，请重新选择");
      if (player != null) {
        requireOwner(player, node.owner);
        if (!player.method_7294() || !level.method_8505(player, pos))
          throw new IllegalArgumentException("此处没有建设权限");
      }
      return node;
    }
  }

  public RoadRecord connect(
      class_3218 level,
      class_3222 player,
      class_2338 a,
      class_2338 b,
      Settings settings,
      UUID replace) {
    return connect(level, player, a, b, settings, replace, false);
  }

  public RoadRecord connect(
      class_3218 level,
      class_3222 player,
      class_2338 a,
      class_2338 b,
      Settings settings,
      UUID replace,
      boolean levelEnds) {
    return connect(level,player,a,b,settings,replace,levelEnds,false);
  }

  public RoadRecord connect(class_3218 level,class_3222 player,class_2338 a,class_2338 b,Settings settings,UUID replace,boolean levelEnds,boolean forceJunction) {return connect(level,player,a,b,settings,replace,levelEnds,forceJunction,forceJunction);}
  public RoadRecord connect(class_3218 level,class_3222 player,class_2338 a,class_2338 b,Settings settings,UUID replace,boolean levelEnds,boolean forceA,boolean forceB) {return connect(level,player,a,b,settings,replace,levelEnds,forceA,forceB,List.of());}
  public RoadRecord connect(class_3218 level,class_3222 player,class_2338 a,class_2338 b,Settings settings,UUID replace,boolean levelEnds,boolean forceA,boolean forceB,List<class_2338> controlNodes) {
    if(replace==null)JunctionPointTool.requireDifferent(level,a,b);
    else if(JunctionPointConnections.group(this,replace)!=null)throw new IllegalArgumentException("请使用附属点连接道路的整体编辑器");
    if(settings.style()==Style.TOLL)throw new IllegalArgumentException("请使用收费站生成器");
    if(TollRoads.reverseConnection(this,a,b))return connectDirected(level,player,b,a,settings,replace,levelEnds,forceB,forceA,controlNodes);
    return connectDirected(level,player,a,b,settings,replace,levelEnds,forceA,forceB,controlNodes);
  }
  private RoadRecord connectDirected(class_3218 level,class_3222 player,class_2338 a,class_2338 b,Settings settings,UUID replace,boolean levelEnds,boolean forceA,boolean forceB,List<class_2338> controlNodes) {
    var existingLane=replace==null?null:index.roads.get(replace);
    var current=replace==null?null:editableRoad(replace);
    if(replace!=null&&(current==null||!current.a().equals(a)||!current.b().equals(b)))
      throw new IllegalArgumentException("编辑目标与端点不一致，请重新右键目标道路");
    var savedAttachments=current==null?RoadAttachments.Data.EMPTY:current.settings().options().attachments();
    savedAttachments=CurveControlNodes.attachments(savedAttachments,current==null?List.of():current.settings().options().routing().controls(),settings.options().routing().controls());
    settings=settings.options(settings.options().attachments(savedAttachments).lanePoints(existingLane==null?LanePoints.Data.EMPTY:ElevatedAccessRoads.logicalLanes(current,existingLane.record)));
    settings=settings.options(settings.options().lanePoints(LaneAdditions.reserveAuthored(settings.options().lanePoints(),RoadProfile.catalog(settings).lanes())));
    // Individual gantries belong to the gantry tool. A stale ordinary editor
    // must neither erase a later edit nor restore a gantry that was removed.
    if(current!=null)settings=settings.options(settings.options().infrastructure(
        settings.options().infrastructure().gantryEdits(current.settings().options().infrastructure().gantryEdits())));
    try (var timing=RoadTimings.start("connect",index.roads.size(),1);
         var workChunks = RoadWorkChunks.open(level)) {
      var roadType=RoadProfile.catalog(settings.style()).type();
      if(roadType==RoadProfile.Type.HIGHWAY){forceA=false;forceB=false;}
      boolean throughRoad=roadType==RoadProfile.Type.ORDINARY||roadType==RoadProfile.Type.HIGHWAY;
      if(streets.containsKey(replace)&&!throughRoad)throw new IllegalArgumentException("路口接路不能直接改为匝道，请先删除此支路");
      boolean simpleVertical=com.sora.splineroads.core.RoadTunnelFit.enabled(settings)&&AutoJunctions.center(this,a)==null&&AutoJunctions.center(this,b)==null&&AutoJunctions.degree(this,a,replace)<2&&AutoJunctions.degree(this,b,replace)<2&&!forceA&&!forceB;
      if(throughRoad && !simpleVertical && (AutoJunctions.handles(this,a,b,replace,forceA||forceB)
          ||roadType==RoadProfile.Type.ORDINARY&&AutoJunctions.incompatible(this,a,b,replace,settings)))
        return AutoJunctions.connect(level,player,a,b,settings,replace,forceA,forceB,levelEnds,controlNodes);
      if (a.equals(b)) throw new IllegalArgumentException("请选择两个不同的端点");
      if (Math.hypot((double) a.method_10263() - b.method_10263(), (double) a.method_10260() - b.method_10260())
          > com.sora.splineroads.core.RoadLimits.MAX_ENDPOINT_DISTANCE + 24)
        throw new IllegalArgumentException("端点距离超过 2048 格，请增加中间端点");
      NodeEntity na = requireNode(level, a, player), nb = requireNode(level, b, player);
      ManualPlannerHistory.capture(level,List.of(a.method_10063(),b.method_10063()));
      RoadRecord previous =
          replace == null
              ? null
              : Optional.ofNullable(index.roads.get(replace))
                  .orElseThrow(() -> new IllegalArgumentException("道路已经被删除"))
                  .record;
      UUID owner =
          previous == null
              ? (player == null ? new UUID(0, 0) : player.method_5667())
              : previous.owner();
      if (previous != null) {
        if (previous.assembly() != null) throw new IllegalArgumentException("自动立交需要使用立交连接器整体编辑");
        if (player != null) requireOwner(player, owner);
        if (!previous.a().equals(a) || !previous.b().equals(b))
          throw new IllegalArgumentException("道路端点已改变");
      }
      for (var road : index.roads.values())
        if (!road.record.id().equals(replace) && !(settings.laneRamp() && road.record.settings().laneRamp())
            && ((road.record.a().equals(a) && road.record.b().equals(b))
                || (road.record.a().equals(b) && road.record.b().equals(a))))
          throw new IllegalArgumentException("这两个端点已经有道路，右键路面即可编辑");

      var ah =
          constructionHint(level, a, true, replace, nb.constructionNode().position(), levelEnds);
      var bh =
          constructionHint(level, b, false, replace, na.constructionNode().position(), levelEnds);
      boolean linkedA = ah.linked(), linkedB = bh.linked();
      var seamA=ah;var seamB=bh;
      if (settings.mode() != Mode.AUTO) {
        Node ma =
            previous == null
                ? connectionNode(level,a,true,replace,nb.constructionNode().position())
                : new Node(
                    na.constructionNode().position(),
                    previous.start().yaw(),
                    previous.start().grade());
        Node mb =
            previous == null
                ? connectionNode(level,b,false,replace,na.constructionNode().position())
                : new Node(
                    nb.constructionNode().position(), previous.end().yaw(), previous.end().grade());
        if(liveEndpoint(a,replace))ma=new Node(seamA.node().position(),ma.yaw(),ma.grade());
        if(liveEndpoint(b,replace))mb=new Node(seamB.node().position(),mb.yaw(),mb.grade());
        if (levelEnds) {
          ma = atGround(ma, a);
          mb = atGround(mb, b);
        }
        ah = RoadPlanner.Hint.free(ma);
        bh = RoadPlanner.Hint.free(mb);
      }
      settings = joinWidths(settings, endpointWidth(a, replace), endpointWidth(b, replace));
      class_2487 joins=new class_2487();jointPayload(joins,a,b,replace);
      settings = joinSections(settings,joins,previous);
      var plan = previous==null?null:previous.retainedPlan(settings,ah,bh,
          new Node(na.constructionNode().position(),previous.start().yaw(),previous.start().grade()),
          new Node(nb.constructionNode().position(),previous.end().yaw(),previous.end().grade()));
      if(plan==null)plan = RoadTunnelFit.plan(ah, bh, settings);
      RoadConnectionChecks.require(plan,seamA,seamB);
      RoadRecord record =
          new RoadRecord(
              replace == null ? UUID.randomUUID() : replace,
              owner,
              a,
              b,
              plan.start(),
              plan.end(),
              plan.settings(),
              settings.mode() == Mode.AUTO,
              4);
      if(previous!=null)record=previous.retainAlignment(record,settings,na.constructionNode(),nb.constructionNode());
      record=RoadCrossingTransitions.fit(record,RoadCrossingTransitions.candidates(this));
      if(!AutoCrossings.hits(record,AutoJunctions.logical(this).values()).isEmpty())
        return AutoJunctions.connectRecord(level,player,record,new class_2487(),controlNodes);
      List<RoadIndex.Built> changes = new ArrayList<>();
      Set<UUID> removed = new HashSet<>();
      if (replace != null) removed.add(replace);
      // A retained AUTO slice can reject the provisional plan's live median
      // shift. Commit its actual saved endpoints to the markers as well, so a
      // second furniture edit still sees the same authored nodes.
      Node movedA = new Node(record.start().position(), na.yaw, levelEnds ? 0 : na.grade),
          movedB = new Node(record.end().position(), nb.yaw, levelEnds ? 0 : nb.grade);
      Map<class_2338, Node> updates = new LinkedHashMap<>();
      if (!liveEndpoint(a,replace) && (movedA.position().distance(na.node().position()) > 1e-8 || levelEnds))
        updates.put(a, movedA);
      if (!liveEndpoint(b,replace) && (movedB.position().distance(nb.node().position()) > 1e-8 || levelEnds))
        updates.put(b, movedB);
      // Migrate the connected legacy-default cluster together; no new half-level seam is
      // introduced.
      ArrayDeque<class_2338> queue = new ArrayDeque<>(updates.keySet());
      while (!queue.isEmpty()) {
        class_2338 pos = queue.removeFirst();
        for (var built : index.roads.values()) {
          var r = built.record;
          if (!r.a().equals(pos) && !r.b().equals(pos)) continue;
          class_2338 other = r.a().equals(pos) ? r.b() : r.a();
          if (updates.containsKey(other)) continue;
          NodeEntity entity = requireNode(level, other, player);
          Node next = entity.constructionNode();
          if (next.position().distance(entity.node().position()) > 1e-8) {
            updates.put(other, next);
            queue.add(other);
          }
        }
      }
      for (var built : index.roads.values()) {
        RoadRecord r = built.record;
        if (r.id().equals(replace) || (!updates.containsKey(r.a()) && !updates.containsKey(r.b())))
          continue;
        // Ground-ended saves visit shared markers even when their geometry is
        // unchanged. Keep those roads out of the direct-edit list; a changed
        // joint section is still enlisted below by normalizeTransitions.
        boolean changedA=updates.containsKey(r.a())&&!sameNodeIntent(updates.get(r.a()),requireNode(level,r.a(),null).node());
        boolean changedB=updates.containsKey(r.b())&&!sameNodeIntent(updates.get(r.b()),requireNode(level,r.b(),null).node());
        if(!changedA&&!changedB)continue;
        if (RoadTunnelFit.enabled(settings) && r.assembly()!=null)
          throw new IllegalArgumentException("要移动的桥隧端点属于路口或立交；请固定该端，仅调整另一端");
        if (player != null) requireOwner(player, r.owner());
        var ha = hint(level, r.a(), true, r.id());
        var hb = hint(level, r.b(), false, r.id());
        Node aa = r.start(), bb = r.end();
        if (updates.containsKey(r.a())) {
          Node before = requireNode(level, r.a(), null).node();
          ha = editedHint(ha, updates.get(r.a()), before);
          aa =
              editedHint(new RoadPlanner.Hint(aa, true, true, true), updates.get(r.a()), before)
                  .node();
        }
        if (updates.containsKey(r.b())) {
          Node before = requireNode(level, r.b(), null).node();
          hb = editedHint(hb, updates.get(r.b()), before);
          bb =
              editedHint(new RoadPlanner.Hint(bb, true, true, true), updates.get(r.b()), before)
                  .node();
        }
        Settings oldSettings = r.settings();
 if (r.automatic()) {
          var adjusted =
              RoadPlanner.plan(
                  ha, hb, RoadPlanner.mode(oldSettings, Mode.AUTO, oldSettings.arcDegrees()));
          aa = adjusted.start();
          bb = adjusted.end();
          oldSettings = adjusted.settings();
        }
        // A marker move can leave this particular locked road unchanged too.
        // Preserve its saved alignment, phase and derived-history receipt.
        if(aa.equals(r.start())&&bb.equals(r.end())&&oldSettings.equals(r.settings()))continue;
        changes.add(
            new RoadIndex.Built(
                new RoadRecord(
                    r.id(),
                    r.owner(),
                    r.a(),
                    r.b(),
                    aa,
                    bb,
                    oldSettings,
                    r.automatic(),
                    r.clearance())));
        removed.add(r.id());
      }
      changes.add(new RoadIndex.Built(record));
      Map<class_2338,class_2338> relocated=new HashMap<>();List<NodeMove> moves=new ArrayList<>();
      for(var pos:controlNodes){requireNode(level,pos,player);if(pos.equals(a)||pos.equals(b)||linked(pos))throw new IllegalArgumentException("控制端点已被使用");moves.add(NodeMove.retire(pos));}
      if(RoadTunnelFit.enabled(settings))for(var entry:updates.entrySet()){
        class_2338 from=entry.getKey();Node target=entry.getValue();var marker=requireNode(level,from,player);
        if(target.position().sub(marker.node().position()).horizontalLength()<1e-7)continue;
        V p=target.position();class_2338 to=class_2338.method_49637(p.x(),p.y(),p.z());
        relocated.put(from,to);moves.add(new NodeMove(from,to,target,marker.method_38244()));
      }
      if(!moves.isEmpty()){
        for(int i=0;i<changes.size();i++){
          var r=changes.get(i).record;
          changes.set(i,new RoadIndex.Built(new RoadRecord(r.id(),r.owner(),relocated.getOrDefault(r.a(),r.a()),relocated.getOrDefault(r.b(),r.b()),
              r.start(),r.end(),r.settings(),r.automatic(),r.clearance(),r.structures(),r.endCaps(),r.buildVersion(),r.assembly(),r.alignment(),r.furniturePhase(),r.junction(),r.toll(),r.fragment())));
        }
        var selected=new HashSet<>(updates.keySet());selected.addAll(controlNodes);replaceBatch(level,player,changes,removed,false,selected,moves);
      }else replaceBatch(level, player, changes, removed);
      updates.forEach((pos, n) -> requireNode(level, relocated.getOrDefault(pos,pos), null).apply(n));
      na=requireNode(level,relocated.getOrDefault(a,a),null);nb=requireNode(level,relocated.getOrDefault(b,b),null);
      na.apply(!linkedA && !na.headingLocked ? record.start() : movedA);
      nb.apply(!linkedB && !nb.headingLocked ? record.end() : movedB);
      if (levelEnds) {
        na.heightExplicit = false;
        nb.heightExplicit = false;
        na.gradeLocked = false;
        nb.gradeLocked = false;
        na.method_5431();
        nb.method_5431();
      }
      return index.roads.get(record.id()).record;
    }
  }

  public static Node atGround(Node n, class_2338 p) {
    return new Node(new V(n.position().x(), p.method_10264(), n.position().z()), n.yaw(), 0);
  }

  public RoadPlanner.Hint constructionHint(
      class_3218 level, class_2338 pos, boolean start, UUID exclude, V towards, boolean levelEnds) {
    var base = hint(level, pos, start, exclude, towards);
    Node n = requireNode(level, pos, null).constructionNode();
    // A physical merge port may be laterally shifted from its logical marker.
    // Keep the marker and authored host axis unchanged; only the new road starts at the live port.
    Node v = new Node(liveEndpoint(pos,exclude)?base.node().position():n.position(), base.node().yaw(), base.node().grade());
    if (levelEnds) v = atGround(v, pos);
    return new RoadPlanner.Hint(
        v, base.headingLocked(), levelEnds || base.gradeLocked(), base.linked());
  }

  /** Manual modes share the same authored heading in preview and commit. */
  public Node connectionNode(class_3218 level,class_2338 pos,boolean start,UUID exclude,V towards){
    var entity=requireNode(level,pos,null);var node=entity.constructionNode();
    if(!entity.plannerHeading||entity.headingLocked)return node;
    var seam=constructionHint(level,pos,start,exclude,towards,false);
    V chord=start?towards.sub(node.position()):node.position().sub(towards);
    return new Node(liveEndpoint(pos,exclude)?seam.node().position():node.position(),
        seam.linked()?seam.node().yaw():RoadPlanner.yaw(chord),node.grade());
  }

  public RoadPlanner.Hint hint(class_3218 level, class_2338 pos, boolean start, UUID exclude) {
    var current = exclude == null ? null : index.roads.get(exclude);
    V towards =
        current == null
            ? null
            : (current.record.a().equals(pos)
                ? current.record.end().position()
                : current.record.start().position());
    return hint(level, pos, start, exclude, towards);
  }

  public RoadPlanner.Hint hint(
      class_3218 level, class_2338 pos, boolean start, UUID exclude, V towards) {
    NodeEntity entity = requireNode(level, pos, null);
    Node n = entity.node();
    RoadIndex.Built best = null;
    double bestScore = -Double.MAX_VALUE;
    for (var built : index.roads.values()) {
      if (built.record.id().equals(exclude)
          || (!built.record.a().equals(pos) && !built.record.b().equals(pos))
          || !transitionEndpoint(built,pos)&&!built.record.settings().style().ramp()) continue;
      double score =
          towards == null
              ? built.record.settings().width()
              : -away(built, pos).horizontalUnit().dot(towards.sub(n.position()).horizontalUnit());
      if (best == null
          || score > bestScore + 1e-8
          || (Math.abs(score - bestScore) < 1e-8
              && built.record.id().compareTo(best.record.id()) < 0)) {
        best = built;
        bestScore = score;
      }
    }
    if (best != null && best.mesh.closed()) {
      // Diameter markers are points ON a closed carriageway, not its start/end caps.
      // Normal feeders meet the ring at grade.
      var q = RoadQueries.project(best.mesh, n.position());
      return new RoadPlanner.Hint(
          new Node(q.sample().center(), n.yaw(), 0), entity.headingLocked, true, true);
    }
    if (best != null) {
      V d = away(best, pos).mul(start ? -1 : 1);
      return new RoadPlanner.Hint(
          new Node(best.record.fragment()!=null||RoadEndpointSections.changed(best.mesh,best.record.a().equals(pos))?com.sora.splineroads.core.RoadMedianAnchor.position(best.record.caps(0).mesh(),best.record.a().equals(pos)):n.position(), RoadPlanner.yaw(d), d.y()), true, true, true);
    }
    return new RoadPlanner.Hint(n, entity.headingLocked, entity.gradeLocked, false);
  }

  public long connectionsAt(class_2338 p) {
    return index.atNode(p).size();
  }

  public double endpointWidth(class_2338 p, UUID exclude) {
    double width = 0;
    for (var built : index.roads.values())
      if (!built.record.id().equals(exclude)
          && (transitionEndpoint(built,p)||built.record.settings().style().ramp())
          && (built.record.a().equals(p) || built.record.b().equals(p)))
        width =
            Math.max(
                width,
                2
                    * (built.record.a().equals(p) ? built.mesh.first() : built.mesh.last())
                        .halfWidth());
    return width;
  }

  public Settings endpointSettings(class_2338 p, UUID exclude) {
    return index.atNode(p).stream()
        .filter(id -> !id.equals(exclude))
        .map(index.roads::get)
        .filter(r -> r != null && transitionEndpoint(r,p) && !r.record.settings().style().ramp())
        .sorted(Comparator.comparing(r -> r.record.id()))
        .map(r -> RoadEndpointSections.changed(r.mesh,r.record.a().equals(p))?endpointSection(r,p):r.record.fragment()==null && r.record.assembly() == null && !r.record.settings().options().ends().persistent() ? authoredSection(r.record.settings()) : endpointSection(r, p))
        .findFirst()
        .orElse(null);
  }

  private boolean liveEndpoint(class_2338 p,UUID exclude){
    return index.atNode(p).stream().filter(id->!id.equals(exclude)).map(index.roads::get)
        .anyMatch(r->transitionEndpoint(r,p)&&(r.record.toll()!=null||r.record.fragment()!=null||RoadEndpointSections.changed(r.mesh,r.record.a().equals(p))));
  }
  private Settings endpointSettings(class_2338 p,UUID exclude,boolean start){
    var donor=index.atNode(p).stream().filter(id->!id.equals(exclude)).map(index.roads::get)
        .filter(r->r!=null&&transitionEndpoint(r,p)&&!r.record.settings().style().ramp())
        .sorted(Comparator.comparing(r->r.record.id())).findFirst();
    if(donor.isEmpty())return null;var r=donor.get();boolean first=r.record.a().equals(p);
    var section=RoadEndpointSections.changed(r.mesh,first)?endpointSection(r,p):
        r.record.fragment()==null&&r.record.assembly()==null&&!r.record.settings().options().ends().persistent()?authoredSection(r.record.settings()):endpointSection(r,p);
    return RoadEndpointSections.orient(section,first==start);
  }

  /** Never feed an automatically derived seam back into the next seam calculation. */
  static Settings authoredSection(Settings s) {
    return s.taper(s.width(),s.width()).options(s.options().ends(RoadTransitions.Ends.NONE));
  }

  /** Junction pads have no traffic profile. Only an approach's real outside port can be joined. */
  static boolean transitionEndpoint(RoadIndex.Built road,class_2338 pos){
    var r=road.record;
    if(LaneTopology.metadata(r).link()!=null)return false;
    if(r.junction()!=null)return r.junction().get().arm()>=0&&r.a().equals(pos)&&!r.b().equals(pos);
    // A trimmed street retains the logical junction marker, but its physical port is
    // at the cutback. The junction owns that seam, not other streets at the marker.
    var ends=r.settings().options().ends();
    if(r.fragment()!=null){
      boolean first=r.a().equals(pos);var physical=RoadSplitGeometry.node(road.mesh,first?0:road.mesh.length()).position();
      if(class_2338.method_49637(physical.x(),physical.y(),physical.z()).equals(pos))return true;
      // Lossless slices include the old free end's half-block cap. Its marker
      // remains the logical endpoint; the next road must meet the actual cap.
      var node=first?r.start():r.end();
      V outward=(first?road.mesh.first():road.mesh.last()).left().left().mul(first?1:-1);
      // A junction-trimmed fragment stores its cutback as start/end too. That
      // is not the logical center marker and must never become a live port.
      // A later slice may also store the actual half-block free cap as its node.
      V uncapped=node.position().sub(outward.mul(.5)).add(new V(0,node.grade()*(first?.5:-.5),0));
      if(!class_2338.method_49637(node.position().x(),node.position().y(),node.position().z()).equals(pos)
          &&!class_2338.method_49637(uncapped.x(),uncapped.y(),uncapped.z()).equals(pos))return false;
      V delta=physical.sub(node.position());
      double along=delta.dot(outward);
      return along>=-1e-7&&along<=1+1e-7&&Math.abs(delta.dot(outward.left()))<1e-6
          &&Math.abs(delta.y()-along*node.grade()*(first?-1:1))<1e-6;
    }
    if(r.a().equals(pos)&&ends.trimmedStart()>1e-6
        ||r.b().equals(pos)&&ends.trimmedEnd()>1e-6)return false;
    // Standalone legacy unmarked roads still have ordinary endpoints; assembly infill does not.
    return r.assembly()==null||r.settings().style()!=Style.UNMARKED;
  }

  /** Read the section actually built at this end, including assembly grid padding/tapers. */
  static Settings endpointSection(RoadIndex.Built road, class_2338 pos) {
    boolean first = road.record.a().equals(pos);
    if(road.record.toll()!=null)return com.sora.splineroads.core.TollPlaza.port(road.record.toll(),first);
    if(road.record.fragment()!=null||RoadEndpointSections.changed(road.mesh,first)
        ||road.record.assembly()!=null&&road.record.junction()==null&&!road.record.settings().style().ramp())
      return RoadEndpointSections.section(road.record.caps(0).mesh(),first,false);
    var at = first ? road.mesh.first() : road.mesh.last();
    var base = road.record.junction()!=null&&road.record.junction().get().arm()>=0
        ? JunctionRoads.editable(road.record.junction().spec().arms().get(road.record.junction().get().arm()))
        : road.record.settings();
    var end = first ? base.options().ends().start() : base.options().ends().end();
    // Junction approach settings describe its own outer port. External end tapers
    // belong to the original street and may describe a different, remote road.
    if(road.record.junction()!=null) end=null;
    var s = end == null ? base : end.settings(base.options().leftTraffic());
    var options = s.options().ends(RoadTransitions.Ends.NONE)
        .infrastructure(base.options().infrastructure()).cycleFinish(s.options().cycle() ? (base.options().cycleAsphalt() ? RoadProfile.Options.CycleFinish.ASPHALT : RoadProfile.Options.CycleFinish.GREEN) : RoadProfile.Options.CycleFinish.NONE);
    // Old section records predate sidewalks. Missing is inheritance, never "disabled".
    if(end == null || end.sidewalk() == null) options=options.sidewalk(base.options().sidewalk());
    var result=new Settings(Mode.STRAIGHT,s.style(),at.halfWidth()*2,base.thickness(),
        base.tension(),base.arcDegrees()).structure(base.structure()).options(options);
    result.validate();
    return result;
  }

  public void jointPayload(class_2487 payload, class_2338 a, class_2338 b, UUID exclude) {
    payload.method_10551("JoinSectionA");payload.method_10551("JoinSectionB");
    Settings start = endpointSettings(a, exclude,true), end = endpointSettings(b, exclude,false);
    if (start != null) payload.method_10566("JoinSectionA", RoadRecord.writeSettings(start));
    if (end != null) payload.method_10566("JoinSectionB", RoadRecord.writeSettings(end));
    payload.method_10556("FixedSectionA",fixedEndpoint(a,exclude));
    payload.method_10556("LiveSectionA",liveEndpoint(a,exclude));
    payload.method_10556("FixedSectionB",fixedEndpoint(b,exclude));
    payload.method_10556("LiveSectionB",liveEndpoint(b,exclude));
  }

  private boolean fixedEndpoint(class_2338 p,UUID exclude){return index.atNode(p).stream().filter(id->!id.equals(exclude)).map(index.roads::get).anyMatch(r->(r.record.fragment()!=null||r.record.assembly()!=null||RoadEndpointSections.changed(r.mesh,r.record.a().equals(p)))&&transitionEndpoint(r,p)&&!r.record.settings().style().ramp());}

  public static Settings joinSections(Settings s, class_2487 payload) {
    return joinSections(s,payload,payload.method_10545("Road")?RoadRecord.load(payload.method_10562("Road")):null);
  }

  public static Settings joinSections(Settings s, class_2487 payload,RoadRecord previous) {
    return RoadRecord.joinSections(s,
        payload.method_10545("JoinSectionA")?RoadRecord.readSettings(payload.method_10562("JoinSectionA")):null,
        payload.method_10545("JoinSectionB")?RoadRecord.readSettings(payload.method_10562("JoinSectionB")):null,
        payload.method_10577("FixedSectionA"),payload.method_10577("FixedSectionB"),previous);
  }

  public static Settings joinWidths(Settings s, double a, double b) {
    return s.style().ramp() && !s.laneRamp()
        ? s.taper(Math.max(s.width(), a), Math.max(s.width(), b))
        : s;
  }

  public static class_2487 writeHint(RoadPlanner.Hint hint) {
    class_2487 t = RoadRecord.writeNode(hint.node());
    t.method_10556("HeadingLocked", hint.headingLocked());
    t.method_10556("GradeLocked", hint.gradeLocked());
    t.method_10556("Linked", hint.linked());
    return t;
  }

  public static RoadPlanner.Hint readHint(class_2487 t) {
    return new RoadPlanner.Hint(
        RoadRecord.readNode(t),
        t.method_10577("HeadingLocked"),
        t.method_10577("GradeLocked"),
        t.method_10577("Linked"));
  }

  public double inheritedWidth(class_2338 a, class_2338 b, double fallback, UUID exclude) {
    for (var r : index.roads.values())
      if (!r.record.id().equals(exclude)
          && (r.record.a().equals(a)
              || r.record.b().equals(a)
              || r.record.a().equals(b)
              || r.record.b().equals(b))) return r.record.settings().width();
    return fallback;
  }

  public void editNode(class_3218 level, class_3222 player, class_2338 pos, Node node) {
    try (var timing=RoadTimings.start("edit_node",index.roads.size(),index.atNode(pos).size());
         var workChunks = RoadWorkChunks.open(level)) {
      if (index.atNode(pos).stream().anyMatch(id -> index.roads.get(id).record.assembly() != null))
        throw new IllegalArgumentException("路口或立交的端点请使用对应连接器整体编辑，或先删除该整体");
      NodeEntity entity = requireNode(level, pos, player);
      V p = node.position();
      if (!RoadGeometry.finite(p.x(), p.y(), p.z(), node.yaw(), node.grade())
          || Math.abs(p.x() - pos.method_10263() - .5) > 8
          || Math.abs(p.z() - pos.method_10260() - .5) > 8
          || p.y() - pos.method_10264() < -8
          || p.y() - pos.method_10264() > 16
          || Math.abs(node.grade()) > .5)
        throw new IllegalArgumentException("端点偏移 X/Z：±8，Y：-8–16；坡度：±50%");
      // Saving the unchanged form must not rebuild an exact split fragment.
      if(sameNodeIntent(node,entity.node()))return;
      ManualPlannerHistory.capture(level,List.of(pos.method_10063()));
      List<RoadIndex.Built> replacements = new ArrayList<>();
      Set<UUID> ids = new HashSet<>();
      for (var built : index.roads.values()) {
        RoadRecord r = built.record;
        if (r.a().equals(pos) || r.b().equals(pos)) {
          if (player != null) requireOwner(player, r.owner());
          ids.add(r.id());
          replacements.add(
              new RoadIndex.Built(
                  planNodeEdit(
                      r,
                      pos,
                      node,
                      entity.node(),
                      hint(level, r.a(), true, r.id()),
                      hint(level, r.b(), false, r.id()))));
        }
      }
      replaceBatch(level, player, replacements, ids);
      if (Math.abs(node.yaw() - entity.yaw) > 1e-7) entity.headingLocked = true;
      if (Math.abs(node.grade() - entity.grade) > 1e-7) entity.gradeLocked = true;
      if (Math.abs(node.position().y() - entity.node().position().y()) > 1e-8)
        entity.heightExplicit = true;
      entity.apply(node);
    }
  }

  /** Shared with the client: edits use exactly the same endpoint constraints as the preview. */
  public static RoadRecord planNodeEdit(
      RoadRecord r,
      class_2338 pos,
      Node edited,
      Node original,
      RoadPlanner.Hint ha,
      RoadPlanner.Hint hb) {
    if(sameNodeIntent(edited,original))return r;
    Node aa = r.start(), bb = r.end();
    Settings settings = r.settings();
 if (r.automatic()) {
      if (r.a().equals(pos)) ha = editedHint(ha, edited, original);
      if (r.b().equals(pos)) hb = editedHint(hb, edited, original);
      var plan =
          RoadPlanner.plan(ha, hb, RoadPlanner.mode(settings, Mode.AUTO, settings.arcDegrees()));
      aa = plan.start();
      bb = plan.end();
      settings = plan.settings();
    } else {
      if (r.a().equals(pos))
        aa = editedHint(new RoadPlanner.Hint(aa, true, true, true), edited, original).node();
      if (r.b().equals(pos))
        bb = editedHint(new RoadPlanner.Hint(bb, true, true, true), edited, original).node();
    }
    return new RoadRecord(
        r.id(), r.owner(), r.a(), r.b(), aa, bb, settings, r.automatic(), r.clearance());
  }

  private static boolean sameNodeIntent(Node a,Node b){
    return RoadGeometry.finite(a.position().x(),a.position().y(),a.position().z(),a.yaw(),a.grade())
        &&a.position().distance(b.position())<=1e-8&&Math.abs(Math.IEEEremainder(a.yaw()-b.yaw(),360))<=1e-7&&Math.abs(a.grade()-b.grade())<=1e-7;
  }
  private static RoadPlanner.Hint editedHint(RoadPlanner.Hint hint, Node edited, Node original) {
    boolean yawChanged = Math.abs(Math.IEEEremainder(edited.yaw() - original.yaw(),360)) > 1e-7,
        gradeChanged = Math.abs(edited.grade() - original.grade()) > 1e-7;
    double sign = hint.node().direction().dot(original.direction()) < 0 ? -1 : 1;
    V offset = hint.node().position().sub(original.position());
    double angle = Math.toRadians(edited.yaw() - original.yaw());
    V rotated =
        new V(
            offset.x() * Math.cos(angle) - offset.z() * Math.sin(angle),
            offset.y(),
            offset.x() * Math.sin(angle) + offset.z() * Math.cos(angle));
    Node n =
        new Node(
            edited.position().add(rotated),
            hint.node().yaw() + (yawChanged ? edited.yaw() - original.yaw() : 0),
            gradeChanged ? sign * edited.grade() : hint.node().grade());
    return new RoadPlanner.Hint(
        n, hint.headingLocked() || yawChanged, hint.gradeLocked() || gradeChanged, hint.linked());
  }

  public void remove(class_3218 level, class_3222 player, UUID id) {
    var road = index.roads.get(id);
    if (road == null) throw new IllegalArgumentException("道路已经不存在");
    if(road.record.toll()!=null){TollRoads.remove(level,player,id);return;}
    if (player != null) requireOwner(player, road.record.owner());
    if(streets.containsKey(id)&&road.record.assembly()==null){AutoJunctions.removeStreet(level,player,id);return;}
    if (road.record.junction() != null) { Junctions.remove(level,player,road.record.assembly()); return; }
    if(ElevatedAccessRoads.saved(this,road.record.assembly())){ElevatedAccessRoads.remove(level,player,road.record.assembly());return;}
    if (road.record.assembly() != null) {
      if(interchanges.getOrDefault(road.record.assembly(),new class_2487()).method_10577("YJunction")){Interchanges.remove(level,player,road.record.assembly());return;}
      Interchanges.removePart(level, player, id);
      return;
    }
    replaceBatch(level, player, List.of(), Set.of(id));
  }

  RoadRecord planSideHost(class_3218 level,RoadIndex.Built host,List<RoadIndex.Built> all){
    int mask=0;for(boolean first:new boolean[]{true,false}){class_2338 pos=first?host.record.a():host.record.b();if(all.stream().noneMatch(r->!r.record.id().equals(host.record.id())&&LaneTopology.metadata(r.record).link()==null&&(r.record.a().equals(pos)||r.record.b().equals(pos))))mask|=first?1:2;}
    var capped=host.caps(mask);all.set(all.indexOf(host),capped);
    return StructurePlanner.plan(level,capped,all,terrainFill,terrainOriginal,new RoadTerrain.Cache(terrainFill,terrainOriginal),new RoadPlanningIndex(all));
  }

  public void updatePointMetadata(class_3218 level,class_3222 player,RoadRecord r,RoadAttachments.Data value){
    if(r.toll()!=null)throw new IllegalArgumentException("收费站请使用收费站生成器编辑");
    if(player!=null){requireOwner(player,r.owner());for(var p:value.points())if(!level.method_8505(player,class_2338.method_49637(p.position().x(),p.position().y(),p.position().z())))throw new IllegalArgumentException("附属点位于受保护区域");}
    if(SideHosts.host(r)){SideHosts.updatePoints(level,r,value);return;}
    for(var access:r.settings().options().lanePoints().access()){
      var old=r.settings().options().attachments().points().stream().filter(p->p.id().equals(access.point())).findFirst().orElse(null);
      if(old==null)continue; // The access marker can belong to the preceding host.
      if(value.points().stream().noneMatch(old::equals))throw new IllegalArgumentException("请先删除高架连接，再移动或删除其出入点");
    }
    var next=r.withAttachments(value);
    index.put(RoadIndex.Built.loading(next));if(streets.containsKey(r.id()))streets.put(r.id(),streets.get(r.id()).withAttachments(value));method_80();RoadNetwork.broadcastRoad(level,next);
  }

  void removeAttachedPoint(class_3218 level,class_3222 player,RoadRecord road,RoadAttachments.Data value,UUID point){
    var next=road.withAttachments(value).structures(List.of());var proposed=new RoadIndex.Built(next);
    for(var other:index.roads.values())if(!other.record.id().equals(road.id())&&RoadIndex.overlapXZ(proposed.mesh,other.mesh,1))Interchanges.checkExternal(proposed.mesh,other.mesh,road.mesh());
    replaceBatch(level,player,List.of(proposed),Set.of(road.id()),true,Set.of(road.a(),road.b()),List.of(),RoadLimits.MAX_EDIT_CELLS,Set.of(point));
  }

  /** Unreferenced lane markers are metadata, not a road construction transaction. */
  void updateLanePointMetadata(class_3218 level, class_3222 player, RoadRecord r, LanePoints.Data value) {
    if(r.toll()!=null)throw new IllegalArgumentException("收费站内部和接口不支持车道点");
    value=value.points(java.util.stream.Stream.concat(value.points().stream().filter(p->!p.automatic()),value.points().stream().filter(LanePoints.Point::automatic)).toList());
    if (player != null) {
      requireOwner(player, r.owner());
      if (!player.method_7294() || player.method_7325()) throw new IllegalArgumentException("没有建设权限");
      for (var point : value.points())
        if (!level.method_8505(player, class_2338.method_49637(point.position().x(), point.position().y(), point.position().z())))
          throw new IllegalArgumentException("车道点位于受保护区域");
    }
    var before = LaneTopology.metadata(r);
    for (var point : before.points()) {
      var next = value.points().stream().filter(p -> p.id().equals(point.id())).findFirst().orElse(null);
      if (!point.equals(next) && index.laneReferenced(LanePoints.Ref.lane(r.id(), point.id())))
        throw new IllegalArgumentException("已使用的车道点必须同步重建依赖匝道");
    }
    var next = index.lanePoints(r.id(), value).record;
    if (streets.containsKey(r.id())) streets.put(r.id(), streets.get(r.id()).withLanePoints(value));
    method_80();
    RoadNetwork.broadcastLanePoints(level, r, next);
  }

  public void editLaneLine(class_3218 level,class_3222 player,class_2487 t){
    var built=index.roads.get(t.method_25926("Id"));if(built==null||built.record.junction()!=null||built.record.toll()!=null)throw new IllegalArgumentException("路段已改变，请重新选择");
    var r=built.record;if(player!=null)requireOwner(player,r.owner());
    if(t.method_10550("Signature")!=GantryTool.signature(r))throw new IllegalArgumentException("道路已更新，请重新选择");
    var options=r.settings().options();
    if(t.method_10545("Station")){
      double station=t.method_10574("Station");if(!Double.isFinite(station)||station<0||station>built.mesh.length())throw new IllegalArgumentException("标线区间无效");
      var range=RoadAttachments.range(built.mesh,station);var paint=RoadAttachments.paint(built.mesh,station);
      if(t.method_10545("HideArrows"))paint=new RoadAttachments.Paint(paint.lines(),t.method_10577("HideArrows"));
      else {String key=t.method_10558("Key");if(RoadLaneLines.lines(built.mesh).stream().noneMatch(l->l.key().equals(key)))throw new IllegalArgumentException("这根车道线已不存在");paint=new RoadAttachments.Paint(RoadLaneLines.with(paint.lines(),new RoadLaneLines.Edit(key,RoadLaneLines.Pattern.valueOf(t.method_10558("Pattern")),t.method_10574("Width"))),paint.hideArrows());}
      updatePointMetadata(level,player,r,RoadAttachments.edit(built.mesh,range,paint));return;
    }
    if(!options.attachments().points().isEmpty())throw new IllegalArgumentException("请重新选择标线编辑区间");
    if(t.method_10545("HideArrows"))options=options.hideArrows(t.method_10577("HideArrows"));
    else {
      String key=t.method_10558("Key");if(RoadLaneLines.lines(built.mesh).stream().noneMatch(l->l.key().equals(key)))throw new IllegalArgumentException("这根车道线已不存在");
      var e=new RoadLaneLines.Edit(key,RoadLaneLines.Pattern.valueOf(t.method_10558("Pattern")),t.method_10574("Width"));
      options=options.laneLines(RoadLaneLines.with(options.laneLines(),e));
    }
    var settings=r.settings().options(options);
    // Paint-only edit: preserve every stored sample, support, neighboring record and world block.
    var next=new RoadRecord(r.id(),r.owner(),r.a(),r.b(),r.start(),r.end(),settings,r.automatic(),r.clearance(),r.structures(),r.endCaps(),r.buildVersion(),r.assembly(),r.alignment(),r.furniturePhase(),r.junction(),r.toll(),r.fragment());
    index.put(RoadIndex.Built.loading(next));if(streets.containsKey(r.id()))streets.put(r.id(),streets.get(r.id()).settings(settings));method_80();RoadNetwork.broadcastRoad(level,next);
  }

  public void editGantry(class_3218 level,class_3222 player,class_2487 command) { editGantry(level,player,command,null); }
  public int createGantry(class_3218 level,class_3222 player,UUID road,V point){
    var built=index.roads.get(road);if(built==null||built.record.junction()!=null||built.record.toll()!=null||LaneTopology.metadata(built.record).link()!=null)throw new IllegalArgumentException("请右键要放置龙门架的普通道路或高速道路");
    var q=RoadQueries.horizontal(built.mesh,point);if(Math.abs(q.lateral())>q.sample().halfWidth()+2||Math.abs(point.y()-q.sample().center().y())>3)throw new IllegalArgumentException("请右键道路表面选择放置位置");
    var creation=RoadGantry.create(built.mesh,q.sample().distance());var command=new class_2487();command.method_25927("Id",road);command.method_10569("Signature",GantryTool.signature(built.record));command.method_10569("Slot",creation.slot());
    editGantry(level,player,command,creation);return creation.slot();
  }
  private void editGantry(class_3218 level,class_3222 player,class_2487 command,RoadGantry.Edit creation) {
    var built=index.roads.get(command.method_25926("Id"));
    if(built==null||built.record.junction()!=null||built.record.toll()!=null)throw new IllegalArgumentException("道路已改变，请重新选择龙门架");
    var r=built.record;if(player!=null){requireOwner(player,r.owner());if(!player.method_7294()||player.method_7325())throw new IllegalArgumentException("没有建设权限");}
    if(command.method_10550("Signature")!=GantryTool.signature(r))throw new IllegalArgumentException("道路已更新，请重新打开龙门架编辑器");
    int slot=command.method_10550("Slot");var oldEdit=creation==null?RoadGantry.station(built.mesh,slot).edit():creation;
    boolean remove=command.method_10577("Remove");
    int flow=command.method_10550("Flow");if(flow==2){if(player==null)throw new IllegalArgumentException("当前方向需要玩家朝向");var look=player.method_5720();flow=RoadGantry.playerFlow(RoadGantry.station(built.mesh,slot).sample(),new V(look.field_1352,look.field_1351,look.field_1350));}
    var signKeys=new ArrayList<com.sora.splineroads.core.SmartSigns.Key>();
    com.sora.splineroads.core.SmartSigns.Mode signMode=command.method_10545("SignMode")?com.sora.splineroads.core.SmartSigns.Mode.valueOf(command.method_10558("SignMode")):null;
    if(signMode!=null&&!remove){
      if(flow==0&&signMode!=com.sora.splineroads.core.SmartSigns.Mode.SPEED_LIMIT&&signMode!=com.sora.splineroads.core.SmartSigns.Mode.LANE_INDICATOR&&!command.method_10577("Reset"))throw new IllegalArgumentException("限速或车道指示龙门架支持双向设置");
      for(int direction:flow==0?new int[]{1,-1}:new int[]{flow}){
        var key=new com.sora.splineroads.core.SmartSigns.Key(r.id(),slot,direction);
        smartSigns.validateMode(key,signMode,command.method_10537(flow==0&&direction<0?"ReverseSignRevision":"SignRevision"));signKeys.add(key);
      }
    }
    var c=r.settings().options().infrastructure();
    if(creation!=null)c=c.edit(creation);else if(remove)c=oldEdit.independent()?c.reset(slot):c.edit(oldEdit.parameters(oldEdit.offset(),oldEdit.clearance(),RoadInfrastructure.Gantry.OFF,oldEdit.reverse()));
    else if(command.method_10577("Reset"))c=oldEdit.independent()?c.edit(oldEdit.parameters(0,5.6,RoadInfrastructure.Gantry.SIGNS,false)):c.reset(slot);
    else c=c.edit(oldEdit.parameters(command.method_10574("Offset"),command.method_10574("Clearance"),RoadInfrastructure.Gantry.valueOf(command.method_10558("Style")),command.method_10577("Reverse")));
    var settings=r.settings().options(r.settings().options().infrastructure(c));
    var next=r.settings(settings);
    try(var rasters=RoadEditRasters.open();var budget=com.sora.splineroads.core.RoadPlanningBudget.cancellable("龙门架局部编辑");var chunks=RoadWorkChunks.open(level)){
      var candidate=new RoadIndex.Built(next);
      var st=RoadGantry.station(remove?built.mesh:candidate.mesh,slot);
      if(player!=null&&player.method_19538().method_1025(new net.minecraft.class_243(st.sample().center().x(),st.sample().center().y(),st.sample().center().z()))>256*256)throw new IllegalArgumentException("离所选龙门架太远");
      // Terrain probes load only the selected feet; no whole-road clearance scan.
      var members=new ArrayList<>(creation==null?RoadGantry.members(built.mesh,slot,r.structures()):List.<RoadStructures.Part>of());
      var retainedParts=new ArrayList<>(r.structures());retainedParts.removeAll(members);
      var fresh=remove?List.<RoadStructures.Part>of():StructurePlanner.gantry(level,candidate.structures(retainedParts),List.copyOf(index.roads.values()),terrainFill,terrainOriginal,slot);
      var parts=new ArrayList<>(r.structures());parts.removeAll(members);parts.addAll(fresh);
      candidate=candidate.structures(parts);
      var changed=new ArrayList<>(members);changed.addAll(fresh);
      Set<Long> touched=new HashSet<>();
      for(var cell:RoadRaster.structures(changed,null).keySet())touched.add(class_2338.method_10064(cell.x(),cell.y(),cell.z()));
      var finalRoads=new ArrayList<RoadIndex.Built>();for(var road:index.roads.values())finalRoads.add(road==built?candidate:road);
      Map<Long,List<RoadIndex.Built>> byChunk=new HashMap<>(),body=new HashMap<>();Set<Long> air=new HashSet<>(),dry=new HashSet<>(),needed=new HashSet<>();
      for(long key:touched)needed.add(new net.minecraft.class_1923(class_2338.method_10092(key)).method_8324());chunks.load(needed);
      for(var road:finalRoads)for(long chunk:road.chunks)if(needed.contains(chunk))byChunk.computeIfAbsent(chunk,k->new ArrayList<>()).add(road);
      for(long key:touched){var pos=class_2338.method_10092(key);for(var road:byChunk.getOrDefault(new net.minecraft.class_1923(pos).method_8324(),List.of())){
        if(!road.boxes(pos).isEmpty())body.computeIfAbsent(key,k->new ArrayList<>()).add(road);
        if(road.clearanceAt(pos)){air.add(key);if(road.tunnelAt(pos))dry.add(key);}
      }}
      // The normal atomic validator still enforces ownership, protection, containers,
      // world bounds, road collision retention and terrain restoration on the delta.
      validateAndCommit(level,player,new PreparedEdit(List.of(candidate),Set.of(r.id()),false,touched,Set.of(),Set.of(),
          new HashMap<>(sidewalkPlaced),Set.copyOf(apronPlaced),body,air,dry,byChunk,Set.of(r.a(),r.b()),finalRoads,List.of(),RoadLimits.MAX_EDIT_CELLS,RoadWorkChunks.held(level)),false);
      if(!signKeys.isEmpty())smartSigns.applyModes(signKeys,signMode);
    }
  }

  private void checkJoints(List<RoadIndex.Built> replacements, Set<UUID> removed) {
    List<RoadIndex.Built> all = new ArrayList<>();
    for (var r : index.roads.values()) if (!removed.contains(r.record.id())) all.add(r);
    all.addAll(replacements);
    Set<class_2338> checked = new HashSet<>();
    for (var road : replacements)
      for (class_2338 p : List.of(road.record.a(), road.record.b())) {
        if (!checked.add(p)) continue;
        var links =
            all.stream().filter(r -> r.record.a().equals(p) || r.record.b().equals(p)).toList();
        // Automatic approaches share a logical center marker but have different trimmed
        // physical endpoints. The junction planner owns those seams, not this point check.
        if(links.stream().anyMatch(r->r.record.junction()!=null))continue;
        links=links.stream().filter(r->transitionEndpoint(r,p)).toList();
        UUID sameGroup = links.isEmpty() ? null : links.get(0).record.assembly();
        if (sameGroup != null
            && links.stream().allMatch(r -> sameGroup.equals(r.record.assembly()))) continue;
        long laneRamps = links.stream().filter(r -> r.record.settings().laneRamp()).count();
        if (laneRamps > 16) throw new IllegalArgumentException("同一端点最多连接 16 条匝道，请分组增加端点");
        links = links.stream().filter(r -> !r.record.settings().laneRamp()).toList();
        if (links.size() > 3) throw new IllegalArgumentException("一个端点支持主路和两条支路；更多分叉请增加端点");
        if (links.size() < 2) continue;
        var rings = links.stream().filter(r -> r.mesh.closed()).toList();
        if (!rings.isEmpty()) {
          for (var ring : rings)
            for (var feeder : links) {
              if (feeder == ring) continue;
              V point =
                  (feeder.record.a().equals(p) ? feeder.mesh.first() : feeder.mesh.last()).center();
              var q = RoadQueries.project(ring.mesh, point);
              if (q.horizontalDistance() > .05
                  || Math.abs(point.y() - q.sample().center().y()) > .01)
                throw new IllegalArgumentException("接环道路必须与环道路面等高并接在环道上");
            }
          continue;
        }
        boolean ramp = links.stream().anyMatch(r -> r.record.settings().style().ramp());
        if (links.size() == 3 && !ramp) throw new IllegalArgumentException("Y 字分叉请选择单车道或双车道匝道样式");
        var first = links.get(0);
        V reference = away(first, p);
        var origin = first.record.a().equals(p) ? first.mesh.first() : first.mesh.last();
        boolean opposite = false;
        for (int i = 1; i < links.size(); i++) {
          var r = links.get(i);
          V d = away(r, p);
          double dot = reference.horizontalUnit().dot(d.horizontalUnit());
          double sign = dot < 0 ? -1 : 1;
          var sample = r.record.a().equals(p) ? r.mesh.first() : r.mesh.last();
          if (first.record.junction() == null && r.record.junction() == null)
            RoadTransitions.requireCompatible(endpointSection(first,p), RoadEndpointSections.orient(endpointSection(r,p),origin.left().dot(sample.left())<0));
          if (Math.abs(origin.center().y()-sample.center().y()) > 1e-6)
            throw new IllegalArgumentException(String.format(java.util.Locale.ROOT,"接点高程不一致：两侧实际路面 Y=%.3f / %.3f（差 %.3f 格），请检查接头高程",origin.center().y(),sample.center().y(),Math.abs(origin.center().y()-sample.center().y())));
          if (origin.center().sub(sample.center()).horizontalLength() > 1e-6)
            throw new IllegalArgumentException(String.format(java.util.Locale.ROOT,"接点横向断面未对齐（并非高程不同）：两侧中心偏移 %.3f 格；合并后的实际断面需要续接匹配",origin.center().sub(sample.center()).horizontalLength()));
          if (Math.abs(origin.halfWidth() - sample.halfWidth()) > 1e-6)
            throw new IllegalArgumentException(String.format(java.util.Locale.ROOT,"接缝过渡宽度不一致：%s，两侧 %.3f / %.3f 格",p.method_23854(),origin.halfWidth()*2,sample.halfWidth()*2));
          if (Math.abs(dot) < .99999999
              || (!ramp && dot > 0)
              || Math.abs(d.y() - sign * reference.y()) > 1e-5)
            throw new IllegalArgumentException("接缝方向或坡度不连续，请切回智能模式或调整端点");
          if (dot < 0) opposite = true;
        }
        if (links.size() == 3 && !opposite)
          throw new IllegalArgumentException("Y 字节点需要一条主路和两条支路，不能三条都朝同侧");
      }
  }

  private static V away(RoadIndex.Built b, class_2338 p) {
    boolean first = b.record.a().equals(p);
    var sample = first ? b.mesh.first() : b.mesh.last();
    V forward = sample.left().left().mul(-1);
    double grade = first ? b.record.start().grade() : b.record.end().grade();
    return new V(forward.x(), grade, forward.z()).mul(first ? 1 : -1);
  }

  /** Validates every affected cell before writing any block or index entry. */
  private void replaceBatch(
      class_3218 level, class_3222 player, List<RoadIndex.Built> built, Set<UUID> removed) {
    replaceBatch(level, player, built, removed, false, Set.of(), List.of());
  }

  /** Rebuild both sides in the same transaction; no stale taper after an edit or deletion. */
  private void normalizeTransitions(
      List<RoadIndex.Built> built, Set<UUID> removed, class_3222 player, boolean deleting) {
    Map<UUID, RoadIndex.Built> all = new LinkedHashMap<>(index.roads);
    Set<class_2338> affected = new HashSet<>();
    for (UUID id : removed) {
      var old = all.remove(id);
      if (old != null) {
        affected.add(old.record.a());
        affected.add(old.record.b());
      }
    }
    for (var r : built) {
      all.put(r.record.id(), r);
      affected.add(r.record.a());
      affected.add(r.record.b());
    }
    Map<class_2338, List<RoadIndex.Built>> joints = new HashMap<>();
    for (var r : all.values()) {
      if (r.record.settings().style().ramp() || r.mesh.closed()) continue;
      for (class_2338 pos : List.of(r.record.a(), r.record.b()))
        if(transitionEndpoint(r,pos))joints.computeIfAbsent(pos, p -> new ArrayList<>()).add(r);
    }
    for (var r : all.values()) {
      var record = r.record;
      if (record.fragment()!=null||record.assembly() != null
          || record.settings().style().ramp()
          || r.mesh.closed()
          || !RoadProfile.modern(record.settings().style())
          || !affected.contains(record.a()) && !affected.contains(record.b())) continue;
      var a = affected.contains(record.a()) && transitionEndpoint(r,record.a()) ? jointSection(r, record.a(), joints.getOrDefault(record.a(), List.of()),deleting) : record.settings().options().ends().start();
      var b = affected.contains(record.b()) && transitionEndpoint(r,record.b()) ? jointSection(r, record.b(), joints.getOrDefault(record.b(), List.of()),deleting) : record.settings().options().ends().end();
      Settings s = RoadTransitions.ends(record.settings(), a, b);
      if (s.equals(record.settings())) continue;
      if (player != null) requireOwner(player, record.owner());
      // User-created mainlines are resampled from their saved curve; assembly alignments stay
      // fixed.
      var next = new RoadIndex.Built(record.settings(s));
      int position = -1;
      for (int i = 0; i < built.size(); i++)
        if (built.get(i).record.id().equals(record.id())) position = i;
      if (position >= 0) built.set(position, next);
      else built.add(next);
      if (index.roads.containsKey(record.id())) removed.add(record.id());
    }
  }

  private static RoadTransitions.Section jointSection(
      RoadIndex.Built road, class_2338 pos, List<RoadIndex.Built> links, boolean deleting) {
    boolean first=road.record.a().equals(pos);
    if(RoadEndpointSections.changed(road.mesh,first))return first?road.record.settings().options().ends().start():road.record.settings().options().ends().end();
    var fixed=links.stream().filter(r->!r.record.id().equals(road.record.id())&&(r.record.fragment()!=null||r.record.assembly()!=null||RoadEndpointSections.changed(r.mesh,r.record.a().equals(pos)))).findFirst();
    if(fixed.isPresent()){
      Settings target=RoadEndpointSections.orient(endpointSection(fixed.get(),pos),(fixed.get().record.a().equals(pos)?fixed.get().mesh.first():fixed.get().mesh.last()).left().dot((first?road.mesh.first():road.mesh.last()).left())<0);if(deleting&&!RoadTransitions.compatible(road.record.settings(),target))return null;RoadTransitions.requireCompatible(road.record.settings(),target);
      return RoadTransitions.Section.of(target);
    }
    // All incident roads choose in one stable physical frame, then reflect the
    // complete result back. Local forward-count tie breaks alone are not enough
    // when the neighboring road was drawn in the opposite direction.
    var reference=links.stream().min(java.util.Comparator.comparing(r->r.record.id())).orElse(road);
    V referenceLeft=(reference.record.a().equals(pos)?reference.mesh.first():reference.mesh.last()).left();
    boolean reverse=(first?road.mesh.first():road.mesh.last()).left().dot(referenceLeft)<0;
    Settings authored=RoadEndpointSections.orient(authoredSection(road.record.settings()),reverse);
    RoadTransitions.Section section = null;
    for (RoadIndex.Built other : links) {
      if (other.record.id().equals(road.record.id())) continue;
      if(deleting&&!RoadTransitions.compatible(road.record.settings(),other.record.settings()))continue;
      var next = RoadTransitions.common(authored, RoadEndpointSections.orient(authoredSection(other.record.settings()),(other.record.a().equals(pos)?other.mesh.first():other.mesh.last()).left().dot(referenceLeft)<0));
      section =
          section == null
              ? next
              : RoadTransitions.common(section.settings(false), next.settings(false));
    }
    return section==null?null:RoadTransitions.Section.of(RoadEndpointSections.orient(section.settings(road.record.settings().options().leftTraffic()),reverse));
  }

  void replaceAssembly(
      class_3218 level,
      class_3222 player,
      List<RoadIndex.Built> built,
      Set<UUID> removed,
      Set<class_2338> selectedNodes) {
    replaceAssembly(level, player, built, removed, selectedNodes, List.of());
  }

  void replaceCurveControl(class_3218 level,class_3222 player,RoadRecord before,RoadRecord next,UUID deleted){
    replaceBatch(level,player,List.of(new RoadIndex.Built(next)),Set.of(before.id()),true,Set.of(before.a(),before.b()),List.of(),RoadLimits.MAX_EDIT_CELLS,deleted==null?Set.of():Set.of(deleted));
  }
  public record NodeMove(class_2338 from, class_2338 to, Node target, class_2487 snapshot) {
    static NodeMove retire(class_2338 from){return new NodeMove(from,null,null,null);}
  }

  void replaceAssembly(
      class_3218 level,
      class_3222 player,
      List<RoadIndex.Built> built,
      Set<UUID> removed,
      Set<class_2338> selectedNodes,
      List<NodeMove> moves) {
    replaceBatch(level, player, built, removed, true, selectedNodes, moves);
  }

  /** A logical street edit includes unchanged neighbours in its draft. Keep the
   * player's actual targets separate from that complete, atomic replacement list.
   * Other assembly callers retain the strict all-inputs-direct default below. */
  void replaceAssembly(class_3218 level,class_3222 player,List<RoadIndex.Built> built,
      Set<UUID> removed,Set<class_2338> selectedNodes,List<NodeMove> moves,Set<UUID> directlyEditedRoads){
    replaceBatch(level,player,built,removed,true,selectedNodes,moves,RoadLimits.MAX_EDIT_CELLS,Set.of(),null,directlyEditedRoads);
  }

  /** A complete five/six-way layout may exceed a normal road edit; all checks remain atomic. */
  void replaceAssembly(class_3218 level,class_3222 player,List<RoadIndex.Built> built,
      Set<UUID> removed,Set<class_2338> selectedNodes,List<NodeMove> moves,int limit){
    if(limit<RoadLimits.MAX_EDIT_CELLS||limit>RoadLimits.MAX_MULTI_INTERCHANGE_EDIT_CELLS)throw new IllegalArgumentException("修改范围上限无效");
    replaceBatch(level,player,built,removed,true,selectedNodes,moves,limit);
  }
  /** One-time detection against every saved corridor, including a ramp's own
   * lower taper. EXTRA approaches and generated ramps do not carry additions. */
  private void queueLegacySupportRepairs(){
    for(var corridor:index.roads.values()){
      var ids=new HashSet<UUID>();for(long chunk:corridor.chunks)ids.addAll(index.inChunk(chunk));
      for(UUID id:ids){var old=index.roads.get(id);if(old==null||supportRepair104.contains(id)||!RoadIndex.overlapXZ(old.mesh,corridor.mesh,8))continue;
        for(var part:old.record.structures())if(part.pier()&&part.material()==RoadStructures.Material.CONCRETE&&part.height()>.8&&RoadClearance.structureInvades(part,corridor.mesh,4.25)){supportRepair104.add(id);break;}
      }
    }
  }
  /** Lane topology may widen a host far beyond the connector's own bounds. */
  private void enlistCycleContinuations(List<RoadIndex.Built> changed,Set<UUID> removed){
    var records=new LinkedHashMap<UUID,RoadRecord>();
    for(var r:index.roads.values())if(!removed.contains(r.record.id()))records.put(r.record.id(),r.record);
    for(var r:changed)records.put(r.record.id(),r.record);
    var selected=new HashSet<UUID>();changed.forEach(r->selected.add(r.record.id()));
    var visited=new HashSet<UUID>();
    for(var r:List.copyOf(changed))if(RoadCycleChain.eligible(r.record)&&visited.add(r.record.id())){
      var chain=RoadCycleChain.of(records,r.record.id());
      for(var leg:chain.legs()){
        visited.add(leg.road().id());
        if(selected.add(leg.road().id())){changed.add(new RoadIndex.Built(leg.road().structures(List.of())));removed.add(leg.road().id());}
      }
    }
  }
  private void enlistSupportDependencies(List<RoadIndex.Built> changed,Set<UUID> removed){
    var corridors=List.copyOf(changed);var selected=new HashSet<UUID>();changed.forEach(r->selected.add(r.record.id()));
    var groups=new HashSet<UUID>();
    for(var old:index.roads.values())if(!removed.contains(old.record.id())&&!selected.contains(old.record.id())){
      boolean conflict=false;
      for(var next:corridors){
        var previous=index.roads.get(next.record.id());
        if(previous!=null&&previous.mesh.equals(next.mesh))continue;
        if(!RoadIndex.overlapXZ(old.mesh,next.mesh,8))continue;
        for(var part:old.record.structures())if(part.pier()&&RoadClearance.structureInvades(part,next.mesh,4.25)
            &&(previous==null||!RoadClearance.structureInvades(part,previous.mesh,4.25))){conflict=true;break;}
        if(conflict)break;
      }
      if(conflict){changed.add(old.structures(List.of()));removed.add(old.record.id());selected.add(old.record.id());if(old.record.junction()!=null)groups.add(old.record.assembly());}
    }
    for(var old:index.roads.values())if(old.record.junction()!=null&&groups.contains(old.record.assembly())&&!removed.contains(old.record.id())&&!selected.contains(old.record.id())){changed.add(old.structures(List.of()));removed.add(old.record.id());}
  }

  private void replaceBatch(class_3218 level,class_3222 player,List<RoadIndex.Built> built,
      Set<UUID> removed,boolean assembly,Set<class_2338> selectedNodes,List<NodeMove> moves){
    replaceBatch(level,player,built,removed,assembly,selectedNodes,moves,RoadLimits.MAX_EDIT_CELLS);
  }
  private void replaceBatch(
      class_3218 level,
      class_3222 player,
      List<RoadIndex.Built> built,
      Set<UUID> removed,
      boolean assembly,
      Set<class_2338> selectedNodes,
      List<NodeMove> moves,int editCellLimit) {
    replaceBatch(level,player,built,removed,assembly,selectedNodes,moves,editCellLimit,Set.of());
  }
  private void replaceBatch(class_3218 level,class_3222 player,List<RoadIndex.Built> built,Set<UUID> removed,boolean assembly,Set<class_2338> selectedNodes,List<NodeMove> moves,int editCellLimit,Set<UUID> deletedPoints) {
    replaceBatch(level,player,built,removed,assembly,selectedNodes,moves,editCellLimit,deletedPoints,null);
  }
  List<RoadIndex.Built> previewAssembly(class_3218 level,class_3222 player,List<RoadIndex.Built> built,
      Set<UUID> removed,Set<class_2338> selectedNodes,List<NodeMove> moves){
    return prepareAssembly(level,player,built,removed,selectedNodes,moves,null);
  }
  private record PreparedEdit(List<RoadIndex.Built> built,Set<UUID> removed,boolean deleting,
      Set<Long> touched,Set<Long> moveSources,Set<Long> moveTargets,Map<Long,class_2680> sidewalks,Set<Long> aprons,
      Map<Long,List<RoadIndex.Built>> body,Set<Long> air,Set<Long> dry,
      Map<Long,List<RoadIndex.Built>> finalByChunk,Set<class_2338> endpoints,
      List<RoadIndex.Built> finalRoads,List<NodeMove> moves,int editCellLimit,Set<Long> chunks){}
  List<RoadRecord> splitJunctionStructures(class_3218 level,List<RoadRecord> roads,UUID replaced){
    var all=new ArrayList<RoadIndex.Built>();for(var r:index.roads.values())if(!r.record.id().equals(replaced)&&roads.stream().noneMatch(n->n.id().equals(r.record.id())))all.add(r);
    var built=roads.stream().map(RoadIndex.Built::new).toList();all.addAll(built);var out=new ArrayList<RoadRecord>();var cache=new RoadTerrain.Cache(terrainFill,terrainOriginal);var lookup=new RoadPlanningIndex(all);
    try(var chunks=RoadWorkChunks.open(level)){chunks.roads(built);for(var r:built)out.add(r.record.junction()==null?r.record:StructurePlanner.plan(level,r,all,terrainFill,terrainOriginal,cache,lookup));}return List.copyOf(out);
  }
  record SplitPrepared(PreparedEdit edit,long revision,Map<UUID,RoadRecord> dependencies){int cells(){return edit.touched().size();}}
  private boolean exactSplit;
  static java.util.function.Consumer<String> splitFault=stage->{};
  static java.util.function.Consumer<String> editFault=stage->{};
  SplitPrepared prepareSplit(class_3218 level,class_3222 player,List<RoadIndex.Built> built,Set<UUID> removed,NodeMove node,boolean junction){
    try(var rasters=RoadEditRasters.open();var chunks=RoadWorkChunks.open(level)){
      var old=new ArrayList<RoadIndex.Built>();for(UUID id:removed){var r=index.roads.get(id);if(r!=null)old.add(r);}
      var finalRoads=new ArrayList<RoadIndex.Built>();for(var r:index.roads.values())if(!removed.contains(r.record.id()))finalRoads.add(r);finalRoads.addAll(built);
      chunks.roads(built);chunks.roads(old);
      var touched=new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
      for(var r:old){touched.addAll(r.cells.keySet());touched.addAll(r.clearanceCells);}
      for(var r:built){touched.addAll(r.cells.keySet());touched.addAll(r.clearanceCells);}
      touched.add(node.to().method_10063());
      Map<Long,class_2680> sidewalks=new HashMap<>(sidewalkPlaced);Set<Long> aprons=new HashSet<>(apronPlaced);
      if(junction){var terrainRoads=new ArrayList<>(old);terrainRoads.addAll(built);sidewalks=SmartSidewalks.plan(finalRoads,level,terrainFill,sidewalkPlaced,apronPlaced,built,terrainRoads);aprons=SmartRoadAprons.plan(sidewalks,finalRoads,level,terrainOriginal,sidewalkPlaced,apronPlaced,terrainRoads);
        for(var e:sidewalkPlaced.entrySet())if(!e.getValue().equals(sidewalks.get(e.getKey())))touched.add(e.getKey());for(var e:sidewalks.entrySet())if(!e.getValue().equals(sidewalkPlaced.get(e.getKey())))touched.add(e.getKey());
      }
      if(touched.size()>RoadLimits.MAX_EDIT_CELLS)throw new IllegalArgumentException("一次分割涉及的世界范围过大");
      Map<Long,List<RoadIndex.Built>> body=new HashMap<>(),finalByChunk=new HashMap<>();Set<Long> air=new HashSet<>(),dry=new HashSet<>(),touchedChunks=new HashSet<>();
      Map<Long,List<class_2338>> touchedByChunk=new HashMap<>();for(long key:touched){var pos=class_2338.method_10092(key);long chunk=new net.minecraft.class_1923(pos).method_8324();touchedChunks.add(chunk);touchedByChunk.computeIfAbsent(chunk,k->new ArrayList<>()).add(pos);}chunks.load(touchedChunks);
      for(var r:finalRoads)for(long chunk:r.chunks)if(touchedChunks.contains(chunk)){finalByChunk.computeIfAbsent(chunk,k->new ArrayList<>()).add(r);for(var pos:touchedByChunk.get(chunk)){long key=pos.method_10063();if(!r.boxes(pos).isEmpty())body.computeIfAbsent(key,k->new ArrayList<>()).add(r);if(r.clearanceAt(pos)){air.add(key);if(r.tunnelAt(pos))dry.add(key);}}}
      Set<class_2338> endpoints=new HashSet<>();for(var r:built){endpoints.add(r.record.a());endpoints.add(r.record.b());}endpoints.add(node.to());
      // A saved connector changes only its source point's owning slice. Its
      // still-linked target/parent markers remain the same legitimate contacts
      // that its original build checked; unrelated endpoints stay protected.
      var finalRecords=new LinkedHashMap<UUID,RoadRecord>();for(var r:finalRoads)finalRecords.put(r.record.id(),r.record);
      for(var r:built)if(LaneTopology.metadata(r.record).link()!=null)
        endpoints.addAll(LaneRamps.contactEndpoints(finalRecords,r.record));
      var edit=new PreparedEdit(List.copyOf(built),Set.copyOf(removed),false,touched,Set.of(),Set.of(node.to().method_10063()),sidewalks,aprons,body,air,dry,finalByChunk,endpoints,List.copyOf(finalRoads),List.of(node),RoadLimits.MAX_EDIT_CELLS,Set.copyOf(touchedChunks));
      var dependencies=new LinkedHashMap<UUID,RoadRecord>();for(UUID id:removed){var previous=index.roads.get(id);if(previous!=null)dependencies.put(id,previous.record);}
      validateAndCommit(level,player,edit,true);return new SplitPrepared(edit,index.revision(),Map.copyOf(dependencies));
    }
  }
  /** Full rollback includes overwritten marker entities and every ownership ledger. */
  void commitSplit(class_3218 level,class_3222 player,SplitPrepared prepared,Runnable metadata){
    if(prepared.revision()!=index.revision())throw new IllegalArgumentException("道路已被修改，请重新选择");
    for(var entry:prepared.dependencies().entrySet()){var live=index.roads.get(entry.getKey());if(live==null||live.record!=entry.getValue())throw new IllegalArgumentException("相关道路元数据已改变，请重新预览");}
    var edit=prepared.edit();try(var rasters=RoadEditRasters.open();var chunks=RoadWorkChunks.open(level)){chunks.load(edit.chunks());validateAndCommit(level,player,edit,true);
      var snapshot=new EditSnapshot(level,edit,true);var callback=index.changed;index.changed=id->{};exactSplit=true;
      RoadNetwork.PreparedBatch packet;
      try{validateAndCommit(level,player,edit,false);splitFault.accept("world");metadata.run();splitFault.accept("metadata");packet=RoadNetwork.prepareBatch(level,edit.built().stream().map(r->r.record).toList(),edit.removed(),edit.moves().get(0).to());method_80();}
      catch(RuntimeException failure){
        snapshot.restore(level,failure);throw failure;
      }finally{index.changed=callback;exactSplit=false;}
      for(var r:edit.built())smartSigns.changed(r.record.id());
      RoadNetwork.broadcastBatch(level,edit.built().stream().map(r->r.record).toList(),edit.removed(),packet);
    }
  }
  /** One rollback implementation for ordinary edits, cached previews, gantries and splits. */
  private final class EditSnapshot {
    final Map<UUID,RoadIndex.Built> roadsBefore=new LinkedHashMap<>(index.roads);
    final Map<UUID,RailbedStore.Entry> railbedsBefore=new LinkedHashMap<>(railbeds.entries);
    final Map<UUID,RoadRecord> streetsBefore;
    final Map<UUID,class_2487> junctionsBefore,interchangesBefore;
    final SmartSignRoads.Snapshot signsBefore;final boolean dirtyBefore=method_79(),fullMetadata;
    final Map<Long,class_2680> world=new HashMap<>(),original=new HashMap<>(),fill=new HashMap<>();
    // A commit publishes fresh paving maps only after all world writes succeed.
    // Retaining the previous generation is sufficient for rollback; it is never
    // mutated by this transaction and needs no city-wide preparation copy.
    final Long2ObjectOpenHashMap<class_2680> walks=sidewalkPlaced;
    final Map<Long,class_2487> entities=new HashMap<>();final Set<Long> aprons=apronPlaced;
    EditSnapshot(class_3218 level,PreparedEdit edit,boolean fullMetadata){
      this.fullMetadata=fullMetadata;
      streetsBefore=new LinkedHashMap<>();
      if(fullMetadata)streetsBefore.putAll(streets);
      else for(var road:edit.built()){var saved=streets.get(road.record.id());if(saved!=null)streetsBefore.put(saved.id(),saved);}
      junctionsBefore=fullMetadata?copyTags(junctions):copyTags(junctions,junctionGroups(edit));
      // Only the split metadata callback writes interchange/sign authority while
      // index notifications are suppressed. Ordinary commits update existing
      // logical roads and the junction groups selected above, then publish later.
      interchangesBefore=fullMetadata?copyTags(interchanges):Map.of();
      signsBefore=fullMetadata?smartSigns.snapshot():null;
      int captured=0;for(long key:edit.touched()){if((captured++&1023)==0)com.sora.splineroads.core.RoadPlanningBudget.check();var pos=class_2338.method_10092(key);world.put(key,level.method_8320(pos));var be=level.method_8321(pos);if(be!=null)entities.put(key,be.method_38242());if(terrainOriginal.containsKey(key))original.put(key,terrainOriginal.get(key));if(terrainFill.containsKey(key))fill.put(key,terrainFill.get(key));}
      com.sora.splineroads.core.RoadPlanningBudget.check();
    }
    void restore(class_3218 level,RuntimeException failure){
      for(UUID id:new ArrayList<>(index.roads.keySet()))if(index.roads.get(id)!=roadsBefore.get(id))index.remove(id);
      for(var road:roadsBefore.values())if(index.roads.get(road.record.id())!=road)index.put(road);
      index.restoreOrder(roadsBefore);
      railbeds.entries.clear();railbeds.entries.putAll(railbedsBefore);
      if(fullMetadata){streets.clear();junctions.clear();interchanges.clear();interchanges.putAll(interchangesBefore);}
      streets.putAll(streetsBefore);junctions.putAll(junctionsBefore);
      for(long key:world.keySet()){terrainOriginal.remove(key);terrainFill.remove(key);}terrainOriginal.putAll(original);terrainFill.putAll(fill);sidewalkPlaced=walks;apronPlaced=aprons;
      restoreBlocks(level,world,entities,failure::addSuppressed);
      if(signsBefore!=null)smartSigns.restore(signsBefore);method_78(dirtyBefore);
      if(failure.getSuppressed().length!=0)System.getLogger("SplineRoads/transaction").log(System.Logger.Level.ERROR,"An external world hook prevented complete rollback",failure);
    }
  }
  private static void checkedSetBlock(class_3218 level,class_2338 pos,class_2680 state,int flags){
    // setBlock(false) is normal when the desired state already exists.
    level.method_8652(pos,state,flags);requireBlockState(level,pos,state);
  }
  private static void requireBlockState(class_3218 level,class_2338 pos,class_2680 state){
    var actual=level.method_8320(pos);
    if(!actual.equals(state))throw new IllegalStateException("世界拒绝写入道路方块："+pos.method_23854()+" target="+state+" actual="+actual);
  }
  /** Original states may depend on each other (e.g. the two halves of seagrass).
   * Restore every state and entity before replaying the normal shape notifications.
   * Commit failures throw; rollback collects failures and keeps restoring other cells. */
  private static void restoreBlocks(class_3218 level,Map<Long,class_2680> states,
      Map<Long,class_2487> entities,java.util.function.Consumer<RuntimeException> failed){
    restoreBlocks(level,states,entities,failed,false);
  }
  private static void restoreBlocks(class_3218 level,Map<Long,class_2680> states,
      Map<Long,class_2487> entities,java.util.function.Consumer<RuntimeException> failed,boolean terrainRestore){
    var changed=new LinkedHashMap<Long,class_2680>();
    for(var entry:states.entrySet())try{
      var pos=class_2338.method_10092(entry.getKey());var previous=level.method_8320(pos);
      checkedSetBlock(level,pos,entry.getValue(),net.minecraft.class_2248.field_31028|net.minecraft.class_2248.field_31031);
      if(!previous.equals(entry.getValue()))changed.put(entry.getKey(),previous);
    }catch(RuntimeException failure){failed.accept(failure);}
    // A forward edit can remove the soil beneath an archived plant. Restore all
    // solid ground first, then retire only plants that cannot survive that new
    // terrain. Rollback remains exact and never takes this path.
    if(terrainRestore)for(int pass=0;pass<2;pass++)for(var entry:states.entrySet()){
      var pos=class_2338.method_10092(entry.getKey());var state=entry.getValue();
      if(state.method_26204() instanceof net.minecraft.class_2261&&!state.method_26184(level,pos)){
        var empty=state.method_26227().method_15767(net.minecraft.class_3486.field_15517)?class_2246.field_10382.method_9564():class_2246.field_10124.method_9564();
        entry.setValue(empty);checkedSetBlock(level,pos,empty,net.minecraft.class_2248.field_31028|net.minecraft.class_2248.field_31031);
      }
    }
    // Forward terrain restoration may change the neighbours of fences, walls,
    // stairs, etc. Their archived connection properties are not an immutable
    // block identity. Reconcile only same-block, same-fluid states without a
    // block entity; destructive/support changes and exact rollback still fail.
    if(terrainRestore)for(int pass=0;pass<8;pass++){
      boolean adjusted=false;
      for(var entry:states.entrySet())try{
        var pos=class_2338.method_10092(entry.getKey());var state=entry.getValue();
        var stable=net.minecraft.class_2248.method_9510(state,level,pos);
        if(!stable.equals(state)&&stable.method_26204()==state.method_26204()&&!state.method_31709()
            &&stable.method_26227().equals(state.method_26227())){
          requireBlockState(level,pos,state);
          checkedSetBlock(level,pos,stable,net.minecraft.class_2248.field_31028|net.minecraft.class_2248.field_31031);
          entry.setValue(stable);changed.putIfAbsent(entry.getKey(),state);adjusted=true;
        }
      }catch(RuntimeException failure){failed.accept(failure);}
      if(!adjusted)break;
    }
    for(var entry:entities.entrySet())try{
      var pos=class_2338.method_10092(entry.getKey());var state=states.get(entry.getKey());requireBlockState(level,pos,state);
      // load() need not clear absent optional fields (e.g. NodeEntity.Owner or
      // ForgeData). A fresh instance restores absence as well as stored values.
      var be=net.minecraft.class_2586.method_11005(pos,state,entry.getValue().method_10553());
      if(be==null||!state.method_31709()||!be.method_11017().method_20526(state))throw new IllegalStateException("无法恢复端点/填充实体："+pos.method_23854());
      level.method_8544(pos);level.method_8438(be);
      if(level.method_8321(pos)!=be||be.method_11015()||!be.method_11016().equals(pos)||!be.method_11010().equals(state))throw new IllegalStateException("无法挂接恢复的端点/填充实体："+pos.method_23854());
      be.method_5431();level.method_8413(pos,state,state,3);
    }catch(RuntimeException failure){failed.accept(failure);}
    for(var entry:changed.entrySet())try{
      var pos=class_2338.method_10092(entry.getKey());var state=states.get(entry.getKey());requireBlockState(level,pos,state);
      // Same flags/depth as Level's shape updates for a normal UPDATE_CLIENTS write.
      entry.getValue().method_26198(level,pos,2,511);
      state.method_26183(level,pos,2,511);
      state.method_26198(level,pos,2,511);
    }catch(RuntimeException failure){failed.accept(failure);}
    for(var entry:states.entrySet())try{
      var pos=class_2338.method_10092(entry.getKey());var state=entry.getValue();requireBlockState(level,pos,state);
      // Updating neighbours need not revisit the newly restored cell itself.
      // In particular, an upper-only plant must not be accepted as a stable restore.
      var stable=net.minecraft.class_2248.method_9510(state,level,pos);
      if(!stable.equals(state))throw new IllegalStateException("世界拒绝写入道路方块："+pos.method_23854()+" target="+state+" supported="+stable);
      var entity=level.method_8321(pos);var tag=entities.get(entry.getKey());
      if(tag!=null&&(entity==null||entity.method_11015()||!entity.method_11016().equals(pos)||!entity.method_11010().equals(state)
          ||!entity.method_11017().method_20526(state)||!entity.method_38242().equals(tag)))throw new IllegalStateException("恢复后端点/填充实体不一致："+pos.method_23854());
      if(!state.method_31709()&&entity!=null)throw new IllegalStateException("恢复后残留方块实体："+pos.method_23854());
    }
    catch(RuntimeException failure){failed.accept(failure);}
  }
  private static Map<UUID,class_2487> copyTags(Map<UUID,class_2487> source){var out=new LinkedHashMap<UUID,class_2487>();source.forEach((key,value)->out.put(key,value.method_10553()));return out;}
  private static Map<UUID,class_2487> copyTags(Map<UUID,class_2487> source,Set<UUID> ids){var out=new LinkedHashMap<UUID,class_2487>();for(UUID id:ids){var value=source.get(id);if(value!=null)out.put(id,value.method_10553());}return out;}
  private Set<UUID> junctionGroups(PreparedEdit edit){
    var groups=new HashSet<UUID>();
    for(var road:edit.built())junctionGroups(groups,road.record);
    for(UUID id:edit.removed()){var previous=index.roads.get(id);if(previous!=null)junctionGroups(groups,previous.record);}
    return groups;
  }
  private static void junctionGroups(Set<UUID> groups,RoadRecord record){
    if(record.junction()!=null&&record.assembly()!=null)groups.add(record.assembly());
    var link=LaneTopology.metadata(record).link();if(link!=null&&link.to().junction()!=null)groups.add(link.to().junction());
  }
  private record PreparedEntry(PreparedEdit edit,RoadPlanInputs inputs,UUID owner,long revision,long created){}
  private final LinkedHashMap<UUID,PreparedEntry> preparedEdits=new LinkedHashMap<>();
  private static final Set<RoadData> PREVIEW_DATA=Collections.newSetFromMap(new WeakHashMap<>());
  public static void expirePreviews(){long now=System.nanoTime();RoadSplitter.expire(now);for(var data:new ArrayList<>(PREVIEW_DATA))data.prunePreviews(now);}
  public static void forgetPreviews(UUID owner){for(var data:new ArrayList<>(PREVIEW_DATA))data.discardPreviews(owner);}
  /** Discard only this tool's prepared token; a later editor's preview remains valid. */
  public static void forgetPreview(UUID owner,UUID token){
    if(owner==null||token==null)return;
    for(var data:new ArrayList<>(PREVIEW_DATA)){
      var entry=data.preparedEdits.get(token);
      if(entry!=null&&owner.equals(entry.owner()))data.preparedEdits.remove(token);
      if(data.preparedEdits.isEmpty())PREVIEW_DATA.remove(data);
    }
  }
  public static void clearPreviews(){for(var data:new ArrayList<>(PREVIEW_DATA))data.preparedEdits.clear();PREVIEW_DATA.clear();}
  void prunePreviews(long now){preparedEdits.entrySet().removeIf(e->now-e.getValue().created()>600_000_000_000L||e.getValue().revision()!=index.contentRevision());if(preparedEdits.isEmpty())PREVIEW_DATA.remove(this);}
  public void discardPreviews(UUID owner){preparedEdits.entrySet().removeIf(e->Objects.equals(e.getValue().owner(),owner));if(preparedEdits.isEmpty())PREVIEW_DATA.remove(this);}
  int preparedPreviewCount(){return preparedEdits.size();}

  List<RoadIndex.Built> prepareAssembly(class_3218 level,class_3222 player,List<RoadIndex.Built> built,
      Set<UUID> removed,Set<class_2338> selectedNodes,List<NodeMove> moves,UUID token){
    return prepareAssembly(level,player,built,removed,selectedNodes,moves,token,Set.of(),true);
  }
  List<RoadIndex.Built> prepareAssembly(class_3218 level,class_3222 player,List<RoadIndex.Built> built,
      Set<UUID> removed,Set<class_2338> selectedNodes,List<NodeMove> moves,UUID token,Set<UUID> directlyEditedRoads,boolean validatePreview){
    var result=new ArrayList<PreparedEdit>();
    try(var inputs=RoadPlanInputs.open(level,token!=null)){
      replaceBatch(level,player,built,removed,true,selectedNodes,moves,RoadLimits.MAX_EDIT_CELLS,Set.of(),result,directlyEditedRoads,validatePreview);
      var edit=result.get(0);
      if(token!=null){
        // Replace the owner's prior preview only after every validation passes.
        // The in-progress plan and the retained cache each keep their own limits.
        UUID owner=player==null?null:player.method_5667();
        preparedEdits.entrySet().removeIf(e->Objects.equals(e.getValue().owner(),owner)||expired(e.getValue()));
        preparedEdits.put(token,new PreparedEntry(edit,inputs,owner,index.contentRevision(),System.nanoTime()));PREVIEW_DATA.add(this);
        // Retain at most two previews, with one ordinary transaction's total cell budget.
        while(preparedEdits.size()>1&&(preparedEdits.size()>2||preparedEdits.values().stream().mapToLong(e->e.edit().touched().size()).sum()>RoadLimits.MAX_EDIT_CELLS||preparedEdits.values().stream().mapToLong(e->e.inputs().retainedStates()).sum()>4_000_000))
          preparedEdits.remove(preparedEdits.keySet().iterator().next());
      }
      return List.copyOf(edit.built());
    }
  }
  private static boolean expired(PreparedEntry e){return System.nanoTime()-e.created()>600_000_000_000L;}
  /** Publish immutable fixtures and authored gantries for the entire batch before
   * any road searches for automatic piers. A UUID order must not decide whether
   * a harmless rail edit can rebuild an already configured gantry. */
  private void reserveBatchFixtures(class_3218 level,List<RoadIndex.Built> built,
      List<RoadIndex.Built> planning,Map<Long,class_2680> retained,Map<Long,class_2680> originals,
      Map<class_2338,List<net.minecraft.class_238>> terrainCache,RoadPlanningIndex lookup,Set<UUID> explicit,Set<UUID> removed){
    // A station with physical members or user-authored signs is mandatory even if its
    // original support began as an automatic placement before a road split.
    for(int i=0;i<built.size();i++){
      var old=built.get(i);var infra=old.record.settings().options().infrastructure();
      var edits=infra.gantryEdits().stream().map(e->e.automatic()&&authoredGantry(old.record.id(),e.slot())
          ?e.parameters(e.offset(),e.clearance(),e.kind(),e.reverse()):e).toList();
      if(!edits.equals(infra.gantryEdits())){
        var next=new RoadIndex.Built(old.record.settings(old.record.settings().options(old.record.settings().options().infrastructure(infra.fixedStations(edits)))));
        built.set(i,next);int slot=planning.indexOf(old);planning.set(slot,next);lookup.replace(slot,next);
      }
    }
    lookup.editHistory(built,index.roads,explicit);
    lookup.optionalAutomaticAnchors(optionalAutomaticAnchors(built));
    // A later topology pass must never see an earlier pass's provisional piers.
    for(int i=0;i<built.size();i++){
      var r=built.get(i);var next=r.structures(List.of());built.set(i,next);
      int slot=planning.indexOf(r);planning.set(slot,next);lookup.replace(slot,next);
    }
    // Publish every derived cycle excavation before planning any bridge footing.
    lookup.resetCyclePlans();
    for(int i=0;i<built.size();i++){
      var r=built.get(i);var next=StructurePlanner.prepareCrossings(level,r,retained,originals,terrainCache,lookup);
      if(next!=r){built.set(i,next);int slot=planning.indexOf(r);planning.set(slot,next);lookup.replace(slot,next);}
    }
    lookup.preservedGantries(RoadGantryRetention.capture(built,index.roads,explicit,removed));
    boolean authored=built.stream().anyMatch(r->r.record.junction()==null&&r.record.toll()==null&&r.mesh.settings().structure()!=Structure.TUNNEL
        &&!r.record.settings().options().infrastructure().gantryEdits().isEmpty());
    for(var stage:authored?List.of(StructurePlanner.Stage.FIXED,StructurePlanner.Stage.GANTRIES,StructurePlanner.Stage.PAVING):List.of(StructurePlanner.Stage.PAVING))
      for(int i=0;i<built.size();i++){
        var r=built.get(i);var next=r.planned(StructurePlanner.reserve(level,r,planning,retained,originals,terrainCache,lookup,stage));
        built.set(i,next);int slot=planning.indexOf(r);planning.set(slot,next);lookup.replace(slot,next);
      }
  }
  /** A split saves automatic stations in the edit list even when no frame was
   * generated. Preserve that absence only when the old world proves it, never
   * by inferring authorship from default-looking parameters alone. */
  private boolean authoredGantry(UUID id,int slot){
    var old=index.roads.get(id);
    if(old!=null&&RoadGantry.exists(old.mesh,slot)&&!RoadGantry.members(old.mesh,slot,old.record.structures()).isEmpty())return true;
    return smartSigns.road(id).stream().anyMatch(s->s.key().slot()==slot
            &&(s.mode()!=com.sora.splineroads.core.SmartSigns.Mode.NORMAL&&s.mode()!=com.sora.splineroads.core.SmartSigns.Mode.EXIT_AUTO
                ||!s.text().isEmpty()||!s.drafts().isEmpty()||!s.hiddenHeaders().isEmpty()||!s.hiddenAccessories().isEmpty()||!s.closedLanes().isEmpty()));
  }
  private Map<UUID,Set<Integer>> optionalAutomaticAnchors(List<RoadIndex.Built> candidates){
    var optional=new HashMap<UUID,Set<Integer>>();
    for(var next:candidates){
      var old=index.roads.get(next.record.id());if(old==null)continue;
      var before=old.mesh.settings().options().infrastructure();var after=next.mesh.settings().options().infrastructure();
      if(!after.fixedStations()||before.gantry()!=after.gantry()
          ||old.mesh.settings().structure()==Structure.TUNNEL||next.mesh.settings().structure()==Structure.TUNNEL)continue;
      for(var edit:after.gantryEdits()){
        com.sora.splineroads.core.RoadPlanningBudget.check();
        if(!edit.anchored()||edit.independent()||edit.kind()!=RoadInfrastructure.Gantry.AUTO
            ||edit.offset()!=0||edit.clearance()!=5.6||edit.reverse())continue;
        var prior=before.gantryEdits().stream().filter(e->e.slot()==edit.slot()).findFirst().orElse(null);
        if(prior!=null&&(!prior.anchored()||prior.independent()||prior.kind()!=RoadInfrastructure.Gantry.AUTO
            ||prior.offset()!=0||prior.clearance()!=5.6||prior.reverse()))continue;
        int slot=edit.slot();
        if(smartSigns.road(old.record.id()).stream().anyMatch(s->s.key().slot()==slot
                &&(s.mode()!=com.sora.splineroads.core.SmartSigns.Mode.NORMAL&&s.mode()!=com.sora.splineroads.core.SmartSigns.Mode.EXIT_AUTO
                    ||!s.text().isEmpty()||!s.drafts().isEmpty()||!s.hiddenHeaders().isEmpty()||!s.hiddenAccessories().isEmpty()||!s.closedLanes().isEmpty())))continue;
        try{
          if(!RoadGantry.exists(old.mesh,slot)||!RoadGantry.exists(next.mesh,slot)
              ||RoadGantry.station(old.mesh,slot).kind()==RoadInfrastructure.Gantry.OFF
              ||!RoadGantry.members(old.mesh,slot,old.record.structures()).isEmpty())continue;
          optional.computeIfAbsent(next.record.id(),id->new HashSet<>()).add(slot);
        }catch(IllegalArgumentException invalid){/* An invalid old station keeps the normal hard rejection; cancellation propagates. */}
      }
    }
    return optional;
  }
  boolean preparedValid(class_3218 level,UUID token){
    var entry=preparedEdits.get(token);if(entry==null||expired(entry)||entry.revision()!=index.contentRevision())return false;
    try{entry.inputs().validate(level);return true;}catch(IllegalArgumentException changed){return false;}
  }
  /** Adopt old restoration receipts without moving or rebuilding any world block. */
  void adoptRailbeds(class_3218 level){
    if(!railbeds.pending.isEmpty())throw new IllegalArgumentException("旧铁路事务正在恢复，请稍候");
    for(var entry:List.copyOf(railbeds.entries.values()))if(entry.road.legacyRailway()){
      var r=entry.road;var settings=r.settings().structure(entry.mode).options(r.settings().options().railbed(new com.sora.splineroads.core.RailbedProfile(entry.paths,entry.width,entry.options)).outerRail(RoadProfile.OuterRail.ON));
      var next=new RoadRecord(r.id(),r.owner(),r.a(),r.b(),r.start(),r.end(),settings,false,5,r.structures(),r.endCaps(),141,null,r.alignment(),r.furniturePhase());
      entry.original.forEach((key,state)->terrainOriginal.putIfAbsent(key,state));
      index.put(RoadIndex.Built.loading(next));railbeds.entries.put(r.id(),RailbedRoads.entry(next));method_80();
    }
  }
  void buildPrepared(class_3218 level,class_3222 player,UUID token){
    buildPrepared(level,player,token,null);
  }
  /** A local insertion publishes its road fragments and metadata as one transaction. */
  void buildPrepared(class_3218 level,class_3222 player,UUID token,Runnable metadata){
    var entry=preparedEdits.get(token);
    if(entry==null||expired(entry)){preparedEdits.remove(token);throw new IllegalArgumentException("预览缓存已过期，请重新预览");}
    if(!Objects.equals(entry.owner(),player==null?null:player.method_5667()))throw new IllegalArgumentException("预览不属于当前玩家");
    if(entry.revision()!=index.contentRevision()){preparedEdits.remove(token);throw new IllegalArgumentException("道路已改变，请重新预览");}
    try(var rasters=RoadEditRasters.open();var budget=com.sora.splineroads.core.RoadPlanningBudget.cancellable("提交已验证预览");
        var timing=RoadTimings.start("preview_commit",index.roads.size(),entry.edit().built().size());
        var chunks=RoadWorkChunks.open(level)){
      chunks.load(entry.edit().chunks());entry.inputs().validate(level);
      timing.stage("cached_world_inputs");
      if(metadata==null)validateAndCommit(level,player,entry.edit(),false);
      else {
        var edit=entry.edit();var snapshot=new EditSnapshot(level,edit,true);var callback=index.changed;
        index.changed=id->{};exactSplit=true;RoadNetwork.PreparedBatch packet;
        try{validateAndCommit(level,player,edit,false);metadata.run();packet=RoadNetwork.prepareBatch(level,edit.built().stream().map(r->r.record).toList(),edit.removed(),edit.moves().isEmpty()?edit.built().get(0).record.a():edit.moves().get(0).to());method_80();}
        catch(RuntimeException failure){snapshot.restore(level,failure);throw failure;}
        finally{index.changed=callback;exactSplit=false;}
        var ids=new LinkedHashSet<>(edit.removed());edit.built().forEach(r->ids.add(r.record.id()));ids.forEach(callback);
        for(var r:edit.built())smartSigns.changed(r.record.id());
        RoadNetwork.broadcastBatch(level,edit.built().stream().map(r->r.record).toList(),edit.removed(),packet);
      }
      timing.stage("validation_commit_sync");
    }finally{preparedEdits.remove(token);}
  }
  /** Resolve the pending topology's cap frame before deriving lane stations.
   * A new edit record starts without caps; deriving first would shift an
   * unchanged analytic road's lane taper by the half-metre start extension. */
  private List<RoadIndex.Built> capPlanning(List<RoadIndex.Built> built,Set<UUID> removed){
    built.removeIf(r->confirmedLaneDeletes.contains(r.record.id()));
    var planning=new ArrayList<RoadIndex.Built>();
    for(var old:index.roads.values())if(!removed.contains(old.record.id())
        &&!confirmedLaneDeletes.contains(old.record.id()))planning.add(old);
    planning.addAll(built);
    for(int i=0;i<built.size();i++){
      var old=built.get(i);int mask=0;
      if(!old.mesh.closed()&&!old.record.settings().style().ramp()&&LaneTopology.metadata(old.record).link()==null){
        for(boolean first:new boolean[]{true,false}){
          class_2338 pos=first?old.record.a():old.record.b();
          boolean shared=planning.stream().anyMatch(r->!r.record.id().equals(old.record.id())
              &&LaneTopology.metadata(r.record).link()==null&&(r.record.a().equals(pos)||r.record.b().equals(pos)));
          if(!shared)mask|=first?1:2;
        }
      }
      var next=old.record.endCaps()==mask&&old.record.buildVersion()==17?old:old.caps(mask);
      built.set(i,next);planning.set(planning.indexOf(old),next);
    }
    return planning;
  }
  private void replaceBatch(class_3218 level,class_3222 player,List<RoadIndex.Built> built,Set<UUID> removed,boolean assembly,Set<class_2338> selectedNodes,List<NodeMove> moves,int editCellLimit,Set<UUID> deletedPoints,List<PreparedEdit> previewResult) {
    replaceBatch(level,player,built,removed,assembly,selectedNodes,moves,editCellLimit,deletedPoints,previewResult,
        built.stream().map(r->r.record.id()).collect(java.util.stream.Collectors.toUnmodifiableSet()));
  }
  private void replaceBatch(class_3218 level,class_3222 player,List<RoadIndex.Built> built,Set<UUID> removed,boolean assembly,Set<class_2338> selectedNodes,List<NodeMove> moves,int editCellLimit,Set<UUID> deletedPoints,List<PreparedEdit> previewResult,Set<UUID> directlyEditedRoads) {
    replaceBatch(level,player,built,removed,assembly,selectedNodes,moves,editCellLimit,deletedPoints,previewResult,directlyEditedRoads,true);
  }
  private void replaceBatch(class_3218 level,class_3222 player,List<RoadIndex.Built> built,Set<UUID> removed,boolean assembly,Set<class_2338> selectedNodes,List<NodeMove> moves,int editCellLimit,Set<UUID> deletedPoints,List<PreparedEdit> previewResult,Set<UUID> directlyEditedRoads,boolean validatePreview) {
    if(built.stream().anyMatch(r->r.record.legacyRailway())||removed.stream().anyMatch(id->index.roads.containsKey(id)&&index.roads.get(id).record.legacyRailway()))throw new IllegalArgumentException("铁路路基请使用铁路路基连接器编辑或删除");
    try (var projections=RoadQueries.scope();var rasters=RoadEditRasters.open();var budget=com.sora.splineroads.core.RoadPlanningBudget.cancellable("道路事务预检查");
         var timing=RoadTimings.start("edit",index.roads.size(),built.size());
         var workChunks = RoadWorkChunks.open(level)) {
      boolean deleting=built.isEmpty();
      built = new ArrayList<>(built);
      var explicit=Set.copyOf(directlyEditedRoads);
      var inputIds=new HashSet<>(removed);built.forEach(r->inputIds.add(r.record.id()));
      if(!inputIds.containsAll(explicit))throw new IllegalArgumentException("本次道路事务缺少直接编辑目标");
      removed = new HashSet<>(removed);
      removed.addAll(confirmedLaneDeletes);
      built.removeIf(b->confirmedLaneDeletes.contains(b.record.id()));
      ElevatedAccessRoads.protect(this,built,removed);
      // Junction pads are filtered by transitionEndpoint; ordinary external
      // approaches still need their taper updated when an assembly is replaced.
      RailbedJoints.normalize(index,built,removed,player);
      normalizeTransitions(built, removed, player,deleting);
      timing.stage("normalize_transitions");com.sora.splineroads.core.RoadPlanningBudget.phase("normalize_transitions");
      List<RoadIndex.Built> requested = new ArrayList<>(built);
      // Prove an incidental endpoint-only rail change once, before scanning
      // dependencies. A long host must not propagate that edit along its length.
      var derived=new HashMap<UUID,List<com.sora.splineroads.core.RoadBoundsIndex.Bounds>>();
      for(var candidate:built)if(!explicit.contains(candidate.record.id())){
        var scope=RoadEditScope.endpointRails(index.roads.get(candidate.record.id()),candidate);
        if(scope!=null)derived.put(candidate.record.id(),scope);
      }
      if(!deleting)for(var old:index.roads.values())if(!removed.contains(old.record.id())&&LaneTopology.metadata(old.record).link()!=null)
        for(var proposed:built)if(!derived.containsKey(proposed.record.id())||RoadEditScope.affects(derived.get(proposed.record.id()),old))RoadInteractions.influences(proposed,old);
      for (UUID id : removed) if (index.roads.containsKey(id)) requested.add(index.roads.get(id));
      // Re-plan affected structures, including a saved ramp joined by a new
      // child mouth. influences keeps independent saved ramp furniture unchanged.
      // Deletion only releases recorded reservations/openings below. It must not
      // enlist a surviving broken connector merely because it shares endpoints.
      for (var old : index.roads.values())
        if (!removed.contains(old.record.id())
            && (!deleting || LaneTopology.metadata(old.record).link()==null)
            && requested.stream().anyMatch(r -> (!derived.containsKey(r.record.id())
                ||RoadEditScope.affects(derived.get(r.record.id()),old))&&RoadInteractions.influences(r, old))) {
          built.add(old.structures(List.of()));
          removed.add(old.record.id());
        }
      // Central junction supports have one shared owner across its fill triangles.
      // If a lower road changes any part of the pad, rebuild the complete junction.
      var supportGroups=new HashSet<UUID>();
      for(var r:built)if(r.record.junction()!=null)supportGroups.add(r.record.assembly());
      for(var old:index.roads.values())if(old.record.junction()!=null&&supportGroups.contains(old.record.assembly())&&!removed.contains(old.record.id())&&built.stream().noneMatch(r->r.record.id().equals(old.record.id()))){built.add(old.structures(List.of()));removed.add(old.record.id());}
      timing.stage("affected_structures");com.sora.splineroads.core.RoadPlanningBudget.phase("affected_structures");
      if(!deleting)AttachedPoints.reconcile(this,built,removed,false,deletedPoints);
      timing.stage("attached_points");com.sora.splineroads.core.RoadPlanningBudget.phase("attached_points");
      capPlanning(built,removed);
      if(deleting){
        LaneTopology.reconcileDeletion(this,built,removed);
        normalizeTransitions(built,removed,player,true);
        LaneTopology.refreshDeletionPoints(this,built,removed);
      }else LaneTopology.reconcile(this,built,removed);
      enlistSupportDependencies(built,removed);
      enlistCycleContinuations(built,removed);
      timing.stage("topology");com.sora.splineroads.core.RoadPlanningBudget.phase("topology");
      built.sort(Comparator.comparing(r -> r.record.id()));
      List<RoadIndex.Built> planning=capPlanning(built,removed);
      List<RoadIndex.Built> terrainRoads = new ArrayList<>(built);
      for (UUID id : removed)
        if (index.roads.containsKey(id)) terrainRoads.add(index.roads.get(id));
      boolean largeAssembly=terrainRoads.stream().anyMatch(r->{
        var descriptor=r.record.assembly()==null?null:interchanges.get(r.record.assembly());
        return descriptor!=null&&descriptor.method_10565("Points").length>=3;
      });
      if(largeAssembly){workChunks.multiInterchange();editCellLimit=Math.max(editCellLimit,RoadLimits.MAX_MULTI_INTERCHANGE_EDIT_CELLS);}
      timing.stage("caps_and_dependencies");com.sora.splineroads.core.RoadPlanningBudget.phase("caps_and_dependencies");
      workChunks.roads(terrainRoads);
      timing.stage("terrain_chunk_access");com.sora.splineroads.core.RoadPlanningBudget.phase("terrain_chunk_access");
      Map<class_2338, List<net.minecraft.class_238>> terrainCache = new RoadTerrain.Cache(terrainFill,terrainOriginal);
      // Keep saved origins; anchor newly added sections to the already-built connected road.
      List<RoadIndex.Built> spacingReferences = new ArrayList<>(index.roads.values());
      for (int i = 0; i < built.size(); i++) {
        var r = built.get(i);
        var next = r.phase(FurnitureSpacing.resolve(r.record, r.mesh, spacingReferences));
        built.set(i, next);
        planning.set(planning.indexOf(r), next);
        spacingReferences.removeIf(o -> o.record.id().equals(r.record.id()));
        spacingReferences.add(next);
      }
      timing.stage("furniture_phase");com.sora.splineroads.core.RoadPlanningBudget.phase("furniture_phase");
      var structureLookup=new RoadPlanningIndex(planning,built.size());
      reserveBatchFixtures(level,built,planning,terrainFill,terrainOriginal,terrainCache,structureLookup,explicit,removed);
      timing.stage("structure_candidate_index");com.sora.splineroads.core.RoadPlanningBudget.phase("structure_candidate_index");
      for (int i = 0; i < built.size(); i++) {
        var r = built.get(i);
        RoadRecord planned = StructurePlanner.plan(level, r, planning, terrainFill, terrainOriginal, terrainCache,structureLookup);
        var next = r.planned(planned);
        built.set(i, next);
        int slot=planning.indexOf(r);planning.set(slot,next);structureLookup.replace(slot,next);
      }
      timing.stage("structure_plan");com.sora.splineroads.core.RoadPlanningBudget.phase("structure_plan");
      LaneTopology.snapPlannedPoints(built,planning);
      // Terrain-derived raised medians can change a lane center after planning. Resolve
      // dependent ports again before any world write; never save an off-center marker.
      for(int pass=0;!deleting&&(LaneTopology.needsRefresh(this,planning,built.stream().map(b->b.record.id()).toList())||LaneCrossSections.needsRestoreRefresh(planning,built.stream().map(b->b.record.id()).toList()));pass++){
        if(pass>=3){
          for(var pending:planning)if(built.stream().anyMatch(v->v.record.id().equals(pending.record.id())))for(var point:LaneTopology.metadata(pending.record).points()){
            var resolved=LanePoints.lane(pending.mesh,point);double drift=resolved.position().distance(point.position());
            if(drift>1e-5)System.getLogger("SplineRoads/topology").log(System.Logger.Level.WARNING,"Unstable lane {0} road={1} delta={2} station={3} point={4} anchor={5} resolved={6}",point.lane(),pending.record.id(),drift,resolved.station(),point.position(),point.anchor(),resolved.position());
          }
          throw new IllegalArgumentException("断面与车道点未能稳定，请调整道路样式后重试");
        }
        LaneTopology.reconcile(this,built,removed);
      enlistSupportDependencies(built,removed);
        // Late topology can enlist a remote support owner; its terrain must be loaded too.
        workChunks.roads(built);
        planning=capPlanning(built,removed);
        structureLookup=new RoadPlanningIndex(planning,built.size());
        reserveBatchFixtures(level,built,planning,terrainFill,terrainOriginal,terrainCache,structureLookup,explicit,removed);
        for(int i=0;i<built.size();i++){var r=built.get(i);var next=r.planned(StructurePlanner.plan(level,r,planning,terrainFill,terrainOriginal,terrainCache,structureLookup));built.set(i,next);int slot=planning.indexOf(r);planning.set(slot,next);structureLookup.replace(slot,next);}
        LaneTopology.snapPlannedPoints(built,planning);
      }
      timing.stage("dependent_replanning");com.sora.splineroads.core.RoadPlanningBudget.phase("dependent_replanning");
      // Both build orders see the final supports. Earlier provisional planting
      // must not survive inside a bridge column planned later in this batch.
      if(built.stream().anyMatch(r->com.sora.splineroads.core.RoadStreetscape.hasPlanting(r.mesh))){
      var supports=new com.sora.splineroads.core.RoadSolidOverlap.Index(planning.stream()
          .flatMap(r->r.record.structures().stream()).filter(p->p.material()==com.sora.splineroads.core.RoadStructures.Material.CONCRETE&&p.height()>.5)
          .toList());
      for(int i=0;i<built.size();i++){
        var r=built.get(i);var parts=com.sora.splineroads.core.RoadStreetscape.clearBlockedPlanting(
            r.record.structures(),r.mesh,r.record.furniturePhase()==null?com.sora.splineroads.core.RoadFurniture.Phase.DEFAULT:r.record.furniturePhase(),supports::intersects);
        if(parts!=r.record.structures())built.set(i,r.structures(parts));
      }
      }
      var noseCaps =
          RoadNoses.connectors(
              built.stream().map(r -> r.mesh).toList(),
              built.stream().map(r -> r.record.structures()).toList());
      for (var entry : noseCaps.entrySet()) {
        var old = built.get(entry.getKey());
        var parts = new ArrayList<>(old.record.structures());
        parts.addAll(entry.getValue());
        built.set(entry.getKey(), old.structures(parts));
      }
      LampSpacing.reconcile(this,built,removed);
      RailbedRoadEdits.enlist(this,level,built,removed,requested);
      workChunks.roads(built);
      // Check the FINAL list (nose caps may have replaced entries since planning).
      // Replaying an unchanged saved conflict must not prevent removing an unrelated road.
      var shellFinal=new ArrayList<RoadIndex.Built>();
      for(var old:index.roads.values())if(!removed.contains(old.record.id()))shellFinal.add(old);
      shellFinal.addAll(built);
      var shellChanged=new HashSet<UUID>();for(var changed:built)shellChanged.add(changed.record.id());
      // Deletion may rebuild surviving walls or end collars. The validator already
      // exempts unchanged saved parts against unchanged travel geometry; newly
      // introduced conflicts must still fail before any world or ledger write.
      TunnelShellValidation.check(shellFinal,shellChanged,index.roads);
      RoadTravelValidation.check(shellFinal,shellChanged,index.roads);
      if(!deleting)for(var road:built)RoadExternalClearance.validate(road.record);
      if(!deleting){TollRoads.validateConnections(shellFinal);checkJoints(built, removed);}
      timing.stage("caps_shell_and_joint_validation");com.sora.splineroads.core.RoadPlanningBudget.phase("caps_shell_and_joint_validation");
      final List<RoadIndex.Built> committed = built;
      final Set<UUID> removedIds = removed;
      Set<Long> touched = new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
      int scanLimit=editCellLimit==RoadLimits.MAX_MULTI_INTERCHANGE_EDIT_CELLS?RoadLimits.MAX_MULTI_INTERCHANGE_SCAN_CELLS:editCellLimit;
      for (UUID id : removed) {
        var old = index.roads.get(id);
        if (old != null) {
          if(old.record.legacyRailway()){touched.addAll(RailbedRoadEdits.cells(old.record));continue;}
          touched.addAll(old.cells.keySet());
          touched.addAll(old.clearanceCells);
        }
      }
      for (var r : built) {
        if(r.record.legacyRailway()){touched.addAll(RailbedRoadEdits.cells(r.record));continue;}
        touched.addAll(r.cells.keySet());
        touched.addAll(r.clearanceCells);
      }
      Set<Long> moveSources = new HashSet<>(), moveTargets = new HashSet<>();
      for (var move : moves) {
        if (move.from() != null) moveSources.add(move.from().method_10063());
        if (move.from() != null) touched.add(move.from().method_10063());
        if(move.to()!=null){
          if (!moveTargets.add(move.to().method_10063())) throw new IllegalArgumentException("端点目标重叠");
          touched.add(move.to().method_10063());
        }
      }
      if (touched.size() > scanLimit)
        throw new IllegalArgumentException("本次需检查 "+touched.size()+" 格，超过单次范围上限 "+scanLimit+"，请分段建造");
      List<RoadIndex.Built> finalRoads = new ArrayList<>();
      for (var r : index.roads.values()) if (!removed.contains(r.record.id())) finalRoads.add(r);
      finalRoads.addAll(built);
      timing.stage("edit_raster");com.sora.splineroads.core.RoadPlanningBudget.phase("edit_raster");
      Map<Long,class_2680> sidewalks=SmartSidewalks.plan(finalRoads,level,terrainFill,sidewalkPlaced,apronPlaced,built,terrainRoads);
      var aprons=SmartRoadAprons.plan(sidewalks,finalRoads,level,terrainOriginal,sidewalkPlaced,apronPlaced,terrainRoads);
      for(var e:sidewalkPlaced.entrySet())if(!e.getValue().equals(sidewalks.get(e.getKey())))touched.add(e.getKey());
      for(var e:sidewalks.entrySet())if(!e.getValue().equals(sidewalkPlaced.get(e.getKey())))touched.add(e.getKey());
      if(touched.size()>scanLimit)throw new IllegalArgumentException("含路侧铺装需检查 "+touched.size()+" 格，超过单次范围上限 "+scanLimit+"，请分段建造");
      timing.stage("sidewalks");com.sora.splineroads.core.RoadPlanningBudget.phase("sidewalks");
      Map<Long, List<RoadIndex.Built>> body = new HashMap<>();
      Set<Long> air = new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
      Set<Long> dry = new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
      Set<Long> touchedChunks = new HashSet<>();
      for (long key : touched)
        touchedChunks.add(new net.minecraft.class_1923(class_2338.method_10092(key)).method_8324());
      workChunks.load(touchedChunks);
      Map<Long,List<class_2338>> touchedByChunk=new HashMap<>();
      Map<Long,List<RoadIndex.Built>> finalByChunk=new HashMap<>();
      for(long key:touched){var pos=class_2338.method_10092(key);touchedByChunk.computeIfAbsent(net.minecraft.class_1923.method_8331(pos.method_10263()>>4,pos.method_10260()>>4),k->new ArrayList<>()).add(pos);}
      for (var r : finalRoads) {
        if (Collections.disjoint(r.chunks, touchedChunks)) continue;
        for(long chunk:r.chunks)if(touchedChunks.contains(chunk))finalByChunk.computeIfAbsent(chunk,k->new ArrayList<>()).add(r);
        if(r.rasterized()) {
          for (long key : r.cells.keySet())if (touched.contains(key))body.computeIfAbsent(key,k->new ArrayList<>()).add(r);
          for (long key : r.clearanceCells)if(touched.contains(key)){air.add(key);if(r.tunnelAt(class_2338.method_10092(key)))dry.add(key);}
        } else {
          // A short edit next to a kilometres-long unchanged road must not materialize its
          // entire deck, furniture and clearance volume. Query only touched local columns.
          for(long chunk:r.chunks)for(var pos:touchedByChunk.getOrDefault(chunk,List.of())) {
            long key=pos.method_10063();
            if(!r.boxes(pos).isEmpty())body.computeIfAbsent(key,k->new ArrayList<>()).add(r);
            if(r.clearanceAt(pos)){air.add(key);if(r.tunnelAt(class_2338.method_10092(key)))dry.add(key);}
          }
        }
      }
      timing.stage("local_collision");com.sora.splineroads.core.RoadPlanningBudget.phase("local_collision");
      Set<class_2338> endpoints = new HashSet<>(selectedNodes);
      // Explicit node moves are validated below and committed atomically with the road.
      // Their old markers may lie inside the extended deck until that transaction commits.
      for(long source:moveSources)endpoints.add(class_2338.method_10092(source));
      for (var r : built) {
        endpoints.add(r.record.a());
        endpoints.add(r.record.b());
      }
      if (assembly)
        for (UUID id : removed) {
          var old = index.roads.get(id);
          if (old != null) {
            endpoints.add(old.record.a());
            endpoints.add(old.record.b());
          }
        }
      // Only markers belonging to a rebuilt, already existing assembly are exempt.
      // Unrelated markers in a new road's footprint remain errors.
      for(var center:junctions.values())if(center.method_10577("GeneratedRing") && built.stream().anyMatch(r->center.method_25926("Id").equals(r.record.assembly())))
        for(long port:center.method_10565("Ports"))endpoints.add(class_2338.method_10092(port));
      var prepared=new PreparedEdit(List.copyOf(built),Set.copyOf(removed),deleting,touched,moveSources,moveTargets,
          sidewalks,aprons,body,air,dry,finalByChunk,Set.copyOf(endpoints),List.copyOf(finalRoads),List.copyOf(moves),editCellLimit,
          RoadWorkChunks.held(level));
      // Queued street preparation retains geometry and its exact read set only.
      // The next tick runs ALL protection/write validation before any mutation.
      // Interactive previews retain their existing immediate validation behavior.
      if(previewResult==null||validatePreview)validateAndCommit(level,player,prepared,previewResult!=null);
      if(previewResult!=null)previewResult.add(prepared);
      timing.stage("validation_commit_sync");
    }
  }

  /** Refreshing an existing road must not reject an unchanged local contact with
   * another retained road's endpoint. New body/air and orphan markers still block. */
  private boolean retainedNodeContact(class_2338 pos,RoadIndex.Built next,List<RoadIndex.Built> finalRoads){
    var before=index.roads.get(next.record.id());
    if(before==null||!before.boxes(pos).equals(next.boxes(pos))
        ||next.clearanceAt(pos)&&!before.clearanceAt(pos))return false;
    return finalRoads.stream().anyMatch(road->{
      if(!road.record.a().equals(pos)&&!road.record.b().equals(pos))return false;
      var old=index.roads.get(road.record.id());
      return old!=null&&(old.record.a().equals(pos)||old.record.b().equals(pos));
    });
  }

  /** Reuses all geometry/raster planning; world protection and current block contents are
   * always checked again, before the first write. No route search occurs on this path. */
  private void validateAndCommit(class_3218 level,class_3222 player,PreparedEdit edit,boolean preview){
    var built=edit.built();var committed=built;var removed=edit.removed();var removedIds=removed;
    boolean deleting=edit.deleting();var touched=edit.touched();var moveSources=edit.moveSources();var moveTargets=edit.moveTargets();
    var sidewalks=edit.sidewalks();var body=edit.body();var air=edit.air();var dry=edit.dry();
    var finalByChunk=edit.finalByChunk();var endpoints=edit.endpoints();var finalRoads=edit.finalRoads();var moves=edit.moves();int editCellLimit=edit.editCellLimit();
      Map<Long, class_2680> writes = new HashMap<>();
      for (long key : touched) {
        com.sora.splineroads.core.RoadPlanningBudget.check();
        class_2338 p = class_2338.method_10092(key);
        if (level.method_31606(p) || !level.method_8621().method_11952(p))
          throw new IllegalArgumentException("道路超出世界高度或边界");
        if (!level.method_22340(p)) throw new IllegalArgumentException("道路区块加载失败，请稍后重试");
        if (player != null && !level.method_8505(player, p))
          throw new IllegalArgumentException("道路经过受保护区域");
        class_2680 state = RoadPlanInputs.state(level,p);
        boolean roadBody = body.containsKey(key), headroom = air.contains(key);
        boolean walkway=sidewalks.containsKey(key);
        if (!roadBody && !headroom && !walkway) continue;
        var localRoads=finalByChunk.getOrDefault(new net.minecraft.class_1923(p).method_8324(),List.of());
        boolean ordinaryBody=body.getOrDefault(key,List.of()).stream().anyMatch(r->!r.record.legacyRailway());
        boolean ordinaryAir=localRoads.stream().anyMatch(r->!r.record.legacyRailway()&&r.clearanceAt(p));
        boolean railBody=body.getOrDefault(key,List.of()).stream().anyMatch(r->r.record.legacyRailway());
        if(!deleting){
          if(net.minecraft.class_7923.field_41175.method_10221(state.method_26204()).method_12836().equals("mtr")){
            boolean selectedNode=com.sora.splineroads.compat.mtr.MtrRailAccess.trainNode(state.method_26204())&&localRoads.stream().anyMatch(r->r.record.settings().options().railbed().paths().stream().flatMap(path->path.segments().stream()).anyMatch(segment->RailbedCodec.pos(segment.from()).equals(p)||RailbedCodec.pos(segment.to()).equals(p)));
            boolean motorConflict=localRoads.stream().anyMatch(r->!r.record.railway()&&(!r.boxes(p).isEmpty()||r.clearanceAt(p)));
            boolean fixture=localRoads.stream().filter(r->r.record.railway()).anyMatch(r->r.prepareCollision().structureAt(new RoadRaster.Cell(p.method_10263(),p.method_10264(),p.method_10260()),part->true));
            boolean levelCrossing=localRoads.stream().filter(r->r.record.railway()).anyMatch(r->localRoads.stream().anyMatch(other->RailwayCrossings.at(r.mesh,other.mesh,new V(p.method_10263()+.5,p.method_10264(),p.method_10260()+.5),.5)));
            if(selectedNode&&(!motorConflict||levelCrossing)&&!fixture)continue;
            throw new IllegalArgumentException("道路施工碰到 MTR 设施："+p.method_23854());
          }
          for(var candidate:localRoads)if(candidate.record.legacyRailway()&&((ordinaryBody||ordinaryAir||walkway)&&!candidate.boxes(p).isEmpty()||(ordinaryBody||walkway)&&candidate.clearanceAt(p)))throw new IllegalArgumentException("道路施工侵入铁路路基本体或列车通行空间："+p.method_23854());
        }
        // A dependency refresh owns its support cells, never the existing
        // railway's deck, MTR markers or air corridor.
        if(!ordinaryBody&&!ordinaryAir&&!walkway&&localRoads.stream().anyMatch(r->r.record.legacyRailway()&&r.clearanceAt(p))&&!railBody)continue;
        if (state.method_27852(SplineRoads.NODE.get())) {
          if (!endpoints.contains(p)
              && !deleting
              && (walkway || committed.stream()
                  .anyMatch(r -> (r.cells.containsKey(key) || r.clearanceCells.contains(key))
                      && !retainedNodeContact(p,r,finalRoads))))
            throw new IllegalArgumentException("道路范围内有其他端点：" + p.method_23854());
          continue;
        }
        // A road always owns its slab collision, including a deck flush with terrain.
        // Existing infrastructure above the new driving corridor cannot be silently erased.
        if (!deleting && headroom
            && !roadBody
            && RoadBlocks.isCollider(state)
            && index.at(key).stream().anyMatch(id -> !removedIds.contains(id)))
          throw new IllegalArgumentException("通行空间与另一条道路相交");
        // Restored host clearance must not erase a surviving road or the user's
        // blocks while deleting. Its existing geometry is allowed to remain.
        if(deleting&&!roadBody&&!walkway)continue;
        if(deleting&&!RoadBlocks.isCollider(state)&&(state.method_31709()||state.method_26214(level,p)<0))continue;
        boolean railEdge=!roadBody&&!walkway&&headroom&&!dry.contains(key)&&RailbedTerrainEdge.present(p,retainedSource(key,state,null),localRoads);
        class_2680 target = railEdge?SplineRoads.FILLED_COLLIDER.get().method_9564():railBody&&!ordinaryBody&&!walkway
            ? (RoadBlocks.isCollider(state)?state:SplineRoads.COLLIDER.get().method_9564())
            : roadBody ? collisionState(key, state, body.get(key), sidewalks.get(key),dry.contains(key),finalByChunk.getOrDefault(new net.minecraft.class_1923(p).method_8324(),List.of())) : walkway ? sidewalks.get(key) : dry.contains(key)?SplineRoads.TUNNEL_AIR.get().method_9564():class_2246.field_10124.method_9564();
        if (state.equals(target) && !(target.method_27852(SplineRoads.FILLED_COLLIDER.get())
            && level.method_8321(p) instanceof RoadFillEntity fill
            && (!fill.fill().equals(retainedSource(key,state,sidewalks.get(key)))||!fill.edge().equals(RailbedTerrainEdge.boxes(p,retainedSource(key,state,sidewalks.get(key)),localRoads))||Math.abs(fill.cap()-GroundTerrainJoin.cap(p,retainedSource(key,state,sidewalks.get(key)),localRoads))>1e-8))) continue;
        RoadClearing.validate(level,p,state,state.equals(sidewalkPlaced.get(key)));
        writes.put(key, target);
      }
      for (var move : moves) {
        if (move.from() != null) requireNode(level, move.from(), player);
        if(move.to()==null){
          if(move.from()==null||finalRoads.stream().anyMatch(r->r.record.a().equals(move.from())||r.record.b().equals(move.from())))throw new IllegalArgumentException("仍在使用的端点不能清理");
          long key=move.from().method_10063();
          writes.put(key,body.containsKey(key)?collisionState(key,class_2246.field_10124.method_9564(),body.get(key),sidewalks.get(key),dry.contains(key),finalByChunk.getOrDefault(new net.minecraft.class_1923(move.from()).method_8324(),List.of())):dry.contains(key)?SplineRoads.TUNNEL_AIR.get().method_9564():class_2246.field_10124.method_9564());
          continue;
        }
        class_2680 state = level.method_8320(move.to());
        boolean movableMarker = moveSources.contains(move.to().method_10063());
        boolean replacedRoad =
            RoadBlocks.isCollider(state)
                && index.at(move.to().method_10063()).stream().allMatch(removedIds::contains);
        // The transaction has already approved these terrain writes, but has not
        // applied them yet. A fitted marker inside the new road must use that
        // same clearing decision instead of treating the old ground as occupied.
        // Do not extend this exemption to containers or unrelated road colliders.
        long targetKey = move.to().method_10063();
        boolean clearedByConstruction =
            writes.containsKey(targetKey)
                && !RoadBlocks.isCollider(state)
                && !state.method_31709()
                && level.method_8321(move.to()) == null
                && committed.stream().anyMatch(r ->
                    r.cells.containsKey(targetKey) || r.clearanceCells.contains(targetKey));
        if (!movableMarker
            && !replacedRoad
            && !clearedByConstruction
            && (!state.method_45474() || state.method_31709() || level.method_8321(move.to()) != null))
          throw new IllegalArgumentException("端点目标被占用：" + move.to().method_23854()
              + "（" + state.method_26204().method_9518().getString() + " / "
              + class_7923.field_41175.method_10221(state.method_26204()) + "）");
        long source = move.from() == null ? 0 : move.from().method_10063();
        if (move.from() != null && !moveTargets.contains(source))
          writes.put(
              source,
              body.containsKey(source)
                  ? collisionState(source, class_2246.field_10124.method_9564(), body.get(source),sidewalks.get(source),dry.contains(source),finalByChunk.getOrDefault(new net.minecraft.class_1923(class_2338.method_10092(source)).method_8324(),List.of()))
                  : dry.contains(source)?SplineRoads.TUNNEL_AIR.get().method_9564():class_2246.field_10124.method_9564());
        writes.put(move.to().method_10063(), SplineRoads.NODE.get().method_9564());
      }
      // Count only world writes. Cleared headroom has no restoration history.
      long changed=writes.size();var streetRestores=StreetEditScope.active()?new HashSet<Long>():null;
      for(long key:touched) {
        if(body.containsKey(key)||!deleting&&air.contains(key)||sidewalks.containsKey(key)||moveTargets.contains(key))continue;
        class_2680 current=level.method_8320(class_2338.method_10092(key));
        if(RoadBlocks.isCollider(current)||current.method_27852(SplineRoads.TUNNEL_AIR.get())||current.equals(sidewalkPlaced.get(key)))changed++;
        if(streetRestores!=null&&(RoadBlocks.isCollider(current)||TunnelAir.isAirSpace(current)||current.equals(sidewalkPlaced.get(key))||terrainOriginal.containsKey(key)||terrainFill.containsKey(key)))streetRestores.add(key);
      }
      if(changed>editCellLimit)throw new IllegalArgumentException("实际需修改 "+changed+" 个方块，超过本次上限 "+editCellLimit);
      StreetEditScope.prepare(level,built,removed,touched,writes,sidewalks,edit.aprons(),streetRestores,preview);
      if(preview)return;
      ManualPlannerHistory.capture(level,touched);
      if(player!=null){
        for(var write:writes.entrySet()){var p=class_2338.method_10092(write.getKey());RoadEditProtection.check(level,player,p,level.method_8320(p),write.getValue());}
        for(long key:touched){
          if(body.containsKey(key)||!deleting&&air.contains(key)||sidewalks.containsKey(key)||moveTargets.contains(key))continue;
          var p=class_2338.method_10092(key);var current=level.method_8320(p);
          if(RoadBlocks.isCollider(current)||TunnelAir.isAirSpace(current)||current.equals(sidewalkPlaced.get(key)))
            RoadEditProtection.check(level,player,p,current,terrainOriginal.getOrDefault(key,terrainFill.getOrDefault(key,class_2246.field_10124.method_9564())));
        }
      }
      com.sora.splineroads.core.RoadPlanningBudget.check();
      var groups=exactSplit?Set.<UUID>of():junctionGroups(edit);
      var snapshot=exactSplit?null:new EditSnapshot(level,edit,false);
      var callback=index.changed;if(snapshot!=null)index.changed=id->{};
      try{
      com.sora.splineroads.core.RoadPlanningBudget.committing();
      // A terrain apron can already equal the ground. It still acquires ownership,
      // so save its original even when no block-state write is needed.
      for(long key:sidewalks.keySet())if(!sidewalkPlaced.containsKey(key)&&!terrainOriginal.containsKey(key)){
        var state=level.method_8320(class_2338.method_10092(key));if(!RoadBlocks.isCollider(state))terrainOriginal.put(key,state);
      }
      // Old railway piers used a separate restoration ledger. Hand their
      // original terrain to this atomic edit before moving/removing supports.
      for(var road:built)if(road.record.legacyRailway()){
        var prior=railbeds.entries.get(road.record.id());for(long key:RailbedRoadEdits.cells(prior.road))if(prior.original.containsKey(key))terrainOriginal.putIfAbsent(key,prior.original.get(key));
      }
      // All range/permission/geometry checks completed before any block is cleared.
      for (UUID id : removed) index.remove(id);
      if(!exactSplit)editFault.accept("remove");
      for (var r : built) {
        index.put(r);if(exactSplit)splitFault.accept("index");else editFault.accept("index");
        var logical=streets.get(r.record.id());
        if(!exactSplit&&logical!=null&&r.record.junction()==null) {
          // A continuation may be built with the ordinary road tool even when the far
          // end belongs to an auto junction. Persist its section in the full logical path.
          var settings=r.record.settings();var ends=settings.options().ends();
          var full=settings.options(settings.options().ends(new RoadTransitions.Ends(ends.start(),ends.end(),ends.persistent()).paintPhase(ends.paintPhase())));
          // An untrimmed fitted tunnel owns its newly moved endpoints. Retaining the old
          // logical path here resurrected the short, over-steep tunnel on the next edit/delete.
          streets.put(logical.id(),logical.fragment()!=null?logical.settings(settings.options(settings.options().ends(logical.settings().options().ends()))).caps(r.record.endCaps()):ends.trimmedStart()==0&&ends.trimmedEnd()==0
              ?r.record.settings(full):logical.settings(full).caps(r.record.endCaps()));
        }
      }
      for (var entry : writes.entrySet()) {
        long key = entry.getKey();
        class_2338 p = class_2338.method_10092(key);
        class_2680 old = level.method_8320(p);
        class_2680 target=entry.getValue();
        // Excavation belongs to the transaction too. Retain cleared natural solids
        // above the deck so replanning sees the original cover and retired cuts heal.
        if(!terrainOriginal.containsKey(key)&&!RoadBlocks.isCollider(old)&&!old.method_27852(SplineRoads.TUNNEL_AIR.get())&&!old.method_27852(SplineRoads.NODE.get())&&!old.equals(sidewalkPlaced.get(key))) {
          boolean ground=body.containsKey(key)||sidewalks.containsKey(key)
              ||air.contains(key)&&old.method_26225()&&!old.method_26164(net.minecraft.class_3481.field_15503)&&!old.method_26164(net.minecraft.class_3481.field_15475);
          if(!ground&&air.contains(key)&&old.method_26225())for(var road:committed){
            var q=RoadQueries.horizontal(road.mesh,new V(p.method_10263()+.5,p.method_10264(),p.method_10260()+.5));
            if(p.method_10264()<=q.sample().center().y()+.001&&q.horizontalDistance()<=q.sample().halfWidth()+road.record.settings().options().sidewalk().width()+1){ground=true;break;}
          }
          if(ground)terrainOriginal.put(key,old);
        }
        class_2680 fill=retainedSource(key,old,sidewalks.get(key));
        boolean retained=RoadBlocks.isCollider(target)&&(target.method_27852(SplineRoads.FILLED_COLLIDER.get())||target.method_11654(RoadBlocks.Road.FILL)!=RoadBlocks.Fill.NONE);
        if(retained&&!TunnelAir.isAirSpace(fill)&&!RoadBlocks.isCollider(fill))terrainFill.put(key,fill);
        else terrainFill.remove(key);
        if(!exactSplit)editFault.accept("ledger");
        checkedSetBlock(level,p,entry.getValue(),2);if(exactSplit)splitFault.accept("write");else editFault.accept("write");
        if(level.method_8321(p) instanceof RoadFillEntity filled){var material=sidewalks.getOrDefault(key,terrainFill.getOrDefault(key,class_2246.field_10124.method_9564()));filled.fill(material,GroundTerrainJoin.cap(p,material,finalByChunk.getOrDefault(new net.minecraft.class_1923(p).method_8324(),List.of())));}
      }
      for (var move : moves) {
        if(move.to()==null)continue;
        if(!(level.method_8321(move.to()) instanceof NodeEntity marker))throw new IllegalStateException("道路端点实体创建失败："+move.to().method_23854());
        marker.method_11014(move.snapshot().method_10553());
        marker.heightExplicit = true;
        marker.apply(move.target());
        if(!exactSplit)editFault.accept("node");
      }
      var restoredBlocks=new LinkedHashMap<Long,class_2680>();
      for (long key : touched) {
        com.sora.splineroads.core.RoadPlanningBudget.check();
        // Net clearance belongs to every surviving road, including during deletion.
        if (body.containsKey(key) || air.contains(key) || sidewalks.containsKey(key) || moveTargets.contains(key)) continue;
        class_2338 p = class_2338.method_10092(key);
        class_2680 current = level.method_8320(p);
        class_2680 fill = terrainFill.remove(key);
        class_2680 original = terrainOriginal.remove(key);
        if (RoadBlocks.isCollider(current)) {
          // Only infill visibly retained inside a live collider survives removal.
          boolean retained=current.method_27852(SplineRoads.FILLED_COLLIDER.get())||current.method_11654(RoadBlocks.Road.FILL)!=RoadBlocks.Fill.NONE;
          restoredBlocks.put(key,original!=null?original:retained&&fill!=null&&!sidewalkPlaced.containsKey(key)?fill:class_2246.field_10124.method_9564());
        } else if(TunnelAir.isAirSpace(current)||current.equals(sidewalkPlaced.get(key)))restoredBlocks.put(key,original!=null?original:class_2246.field_10124.method_9564());
      }
      restoreBlocks(level,restoredBlocks,Map.of(),failure->{throw failure;},true);
      RailbedRoadEdits.sync(this,level,built);
      RailbedRoads.sync(this,built,removed);
      sidewalkPlaced=new Long2ObjectOpenHashMap<>(sidewalks);apronPlaced=new it.unimi.dsi.fastutil.longs.LongOpenHashSet(edit.aprons());
      if(!exactSplit)RampJunctions.sync(this,groups);
      for(var r:built)if(streets.containsKey(r.record.id())){var logical=streets.get(r.record.id());streets.put(logical.id(),logical.withLanePoints(ElevatedAccessRoads.logicalLanes(logical,r.record)));}
      method_80();
      if(!exactSplit)editFault.accept("metadata");
      }catch(RuntimeException failure){if(snapshot!=null)snapshot.restore(level,failure);throw failure;}
      finally{if(snapshot!=null)index.changed=callback;}
      if(exactSplit)return;
      ElevatedAccessRoads.prune(this);
      var changedIds=new LinkedHashSet<>(removed);for(var r:built)changedIds.add(r.record.id());changedIds.forEach(callback);
      for (UUID id : removed)
        if (committed.stream().noneMatch(b -> b.record.id().equals(id)))
          RoadNetwork.broadcastDelete(level, id);
      for (var r : built) RoadNetwork.broadcastRoad(level, r.record);
  }

  class_2680 railbedCollision(class_2338 p,class_2680 original,List<RoadIndex.Built> nearby){
    var owners=nearby.stream().filter(r->!r.boxes(p).isEmpty()).toList();
    return collisionState(p.method_10063(),original,owners,null,nearby.stream().anyMatch(r->r.tunnelAt(p)&&r.clearanceAt(p)),nearby);
  }

  private class_2680 collisionState(long key, class_2680 previous, List<RoadIndex.Built> roads) {
    return collisionState(key,previous,roads,sidewalkPlaced.get(key));
  }
  private class_2680 collisionState(long key, class_2680 previous, List<RoadIndex.Built> roads,class_2680 sidewalk) {
    var pos=class_2338.method_10092(key);
    var nearby=index.inChunk(new net.minecraft.class_1923(pos).method_8324()).stream()
        .map(index.roads::get).filter(Objects::nonNull).toList();
    boolean dryInterior=nearby.stream().anyMatch(r->r.tunnelAt(pos)&&r.clearanceAt(pos));
    return collisionState(key,previous,roads,sidewalk,dryInterior,nearby);
  }
  private class_2680 collisionState(long key, class_2680 previous, List<RoadIndex.Built> roads,class_2680 sidewalk,boolean dryInterior,List<RoadIndex.Built> nearby) {
    class_2338 p = class_2338.method_10092(key);
    class_2680 terrain =
        sidewalk!=null ? sidewalk : sidewalkPlaced.containsKey(key) ? terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564()) : RoadBlocks.isCollider(previous)||previous.equals(sidewalkPlaced.get(key))
            ? terrainFill.getOrDefault(key, class_2246.field_10124.method_9564())
            : previous;
    // Legacy edge cells may have cleared their visible fill but retained the original material.
    if(TunnelAir.isAirSpace(terrain)&&RoadBlocks.isCollider(previous))terrain=terrainOriginal.getOrDefault(key,terrain);
    RoadBlocks.Fill fill = RoadBlocks.Fill.of(terrain);
    boolean generic=fill==RoadBlocks.Fill.NONE&&!TunnelAir.isAirSpace(terrain)&&(sidewalk!=null||previous.method_27852(SplineRoads.FILLED_COLLIDER.get()));
    boolean deck = false;
    boolean gantryFill=previous.method_27852(SplineRoads.FILLED_COLLIDER.get())&&roads.stream().anyMatch(r->RoadBlocks.gantryCell(r,new RoadRaster.Cell(p.method_10263(),p.method_10264(),p.method_10260())));
    for (var r : roads) {
      var c = r.column(p);
      if (c == null) continue;
      deck = true;
      if (p.method_10264() + fill.top() > c.minTop() + 1e-7) fill = RoadBlocks.Fill.NONE;
      if(!gantryFill&&p.method_10264()+1>c.minTop()+1e-7)generic=false;
    }
    if (!deck && fill != RoadBlocks.Fill.NONE) {
      double lowest =
          roads.stream()
              .flatMap(r -> r.boxes(p).stream())
              .mapToDouble(com.sora.splineroads.core.RoadRaster.Box::y0)
              .min()
              .orElse(0);
      if (fill.top() > lowest + 1e-7) fill = RoadBlocks.Fill.NONE;
    }
    // Preserve only full original terrain that does not enter ANY final travel volume.
    // A global maximum arch height falsely classified roof/portal exterior as interior.
    // Use the final neighboring roads, not only owners of this exact structural cell.
    boolean exteriorShell=roads.stream().anyMatch(r->r.shellAt(p));
    if(exteriorShell&&TunnelTerrainSpace.safe(p,nearby)){
      class_2680 original=terrain;
      if(TunnelAir.isAirSpace(original)&&RoadBlocks.isCollider(previous))original=terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564());
      if(!original.method_31709()&&original.method_26227().method_15769()){
        fill=RoadBlocks.Fill.of(original);
        generic=fill==RoadBlocks.Fill.NONE&&!TunnelAir.isAirSpace(original)&&original.method_26225();
      }
    }
    // Retain the full original terrain under/along a diagonal sidewalk cell.
    // The continuous SR surface sits above it; only actual elevated voids stay empty.
    double walkTop=roads.stream().mapToDouble(r->r.walkTopAt(p)).max().orElse(Double.NEGATIVE_INFINITY);
    if(!deck&&Double.isFinite(walkTop)&&!terrain.method_31709()&&terrain.method_26227().method_15769()&&!TunnelAir.isAirSpace(terrain)){
      var retained=RoadBlocks.Fill.of(terrain);double top=retained==RoadBlocks.Fill.NONE?1:retained.top();
      if(p.method_10264()+top<=walkTop+1e-6){fill=retained;generic=fill==RoadBlocks.Fill.NONE&&terrain.method_26225();}
    }
    // Rails/skirt foundations used to discard an entire grass cube whenever a
    // small shaft entered it. Keep the original solid around buried structures;
    // test all final travel volumes so this never fills a road/cycle/tunnel lane.
    if(!deck&&!TunnelAir.isAirSpace(terrain)&&terrain.method_26225()&&!terrain.method_31709()
        &&terrain.method_26227().method_15769()&&TunnelTerrainSpace.exteriorInfill(p,nearby)){
      fill=RoadBlocks.Fill.of(terrain);generic=fill==RoadBlocks.Fill.NONE;
    }
    // A lowered cycle floor is not in columnData. The sidewalk maximum and
    // exterior-shell preservation above must never restore terrain into its air.
    double terrainCap=GroundTerrainJoin.cap(p,terrain,nearby);
    if(terrainCap<1){fill=RoadBlocks.Fill.NONE;generic=GroundTerrainJoin.usable(terrainCap);}
    boolean cycleBody=roads.stream().anyMatch(r->r.cycleBodyAt(p));
    if(dryInterior||cycleBody){fill=RoadBlocks.Fill.NONE;generic=false;}
    if(!dryInterior&&!cycleBody&&RailbedTerrainEdge.present(p,terrain,nearby)){fill=RoadBlocks.Fill.NONE;generic=true;}
    // Keep water only in exterior partial-shell cells, never in an interior clearance
    // cell or the actual road slab. The caller supplies the union of ALL tunnel air
    // reservations, including tunnels not owning this particular body cell.
    boolean deckHere=roads.stream().anyMatch(r->{var c=r.column(p);return c!=null
        &&p.method_10264()+1>c.minTop()-r.record.settings().thickness()+1e-7&&p.method_10264()<c.maxTop()-1e-7;});
    boolean tunnelOwner=roads.stream().anyMatch(RoadIndex.Built::hasTunnel);
    boolean shell=roads.stream().anyMatch(r->r.shellAt(p));
    boolean permeable=RoadWaterPolicy.permeable(deckHere,generic||fill!=RoadBlocks.Fill.NONE,tunnelOwner,shell,dryInterior);
    boolean originalWater=terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564()).method_26227().method_15767(net.minecraft.class_3486.field_15517);
    boolean water=RoadWaterPolicy.waterlogged(permeable,terrain.method_26227().method_15767(net.minecraft.class_3486.field_15517),
        previous.method_26227().method_15767(net.minecraft.class_3486.field_15517),originalWater);
    return (generic?SplineRoads.FILLED_COLLIDER:SplineRoads.COLLIDER)
        .get()
        .method_9564()
        .method_11657(RoadBlocks.Road.FILL, fill)
        .method_11657(RoadBlocks.Road.LIT, roads.stream().anyMatch(r -> r.lightAt(p)))
        .method_11657(RoadBlocks.Road.PERMEABLE,permeable)
        .method_11657(RoadBlocks.Road.WATERLOGGED,water)
        .method_11657(RoadBlocks.Road.SEALED, shell);
  }

  /** Preserve the material, including uncommon full terrain, when repairing a shell
   * cell whose old collision state deliberately contained no visible infill. */
  private class_2680 retainedSource(long key,class_2680 previous,class_2680 sidewalk){
    if(sidewalk!=null)return sidewalk;
    if(sidewalkPlaced.containsKey(key))return terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564());
    var fill=terrainFill.getOrDefault(key,previous);
    return RoadBlocks.isCollider(fill)||TunnelAir.isAirSpace(fill)&&RoadBlocks.isCollider(previous)
        ?terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564()):fill;
  }

  /** Fill the unused part of a deck cell without replacing the independent road collision. */
  public boolean infill(class_3218 level,class_2338 p,class_2680 fill,class_3222 player) {
    if(!RoadBlocks.canInfill(level,p,fill))return false;
    if(!mayEditFill(level,p,player))return false;
    class_2680 old=level.method_8320(p);
    terrainFill.put(p.method_10063(),fill);
    terrainOriginal.put(p.method_10063(),fill);
    level.method_8652(p,SplineRoads.FILLED_COLLIDER.get().method_9564().method_11657(RoadBlocks.Road.LIT,old.method_11654(RoadBlocks.Road.LIT)).method_11657(RoadBlocks.Road.SEALED,old.method_11654(RoadBlocks.Road.SEALED)),3);
    var nearby=index.inChunk(new net.minecraft.class_1923(p).method_8324()).stream().map(index.roads::get).filter(Objects::nonNull).toList();
    ((RoadFillEntity)level.method_8321(p)).fill(fill,GroundTerrainJoin.cap(p,fill,nearby));method_80();return true;
  }

  /** Filling and excavation share the authority of every road occupying this cell. */
  private boolean mayEditFill(class_3218 level,class_2338 p,class_3222 player) {
    if(player==null)return true;
    if(!player.method_7294()||!level.method_8505(player,p))return false;
    if(player.method_5687(2))return true;
    for(UUID id:index.at(p.method_10063())){
      var road=index.roads.get(id);
      if(road!=null&&road.record.owner()!=null&&!road.record.owner().equals(player.method_5667()))return false;
    }
    return true;
  }

  /** Dig the retained terrain while leaving the independent road slab in the same block cell. */
  public boolean excavateSupport(class_3218 level, class_2338 p, class_3222 player) {
    class_2680 current = level.method_8320(p);
    if (!RoadBlocks.isCollider(current)
        || current.method_11654(RoadBlocks.Road.FILL) == RoadBlocks.Fill.NONE && !current.method_27852(SplineRoads.FILLED_COLLIDER.get())) return false;
    if (!mayEditFill(level,p,player)) return false;
    class_2680 terrain =
        terrainFill.getOrDefault(p.method_10063(), current.method_11654(RoadBlocks.Road.FILL).state());
    if (player != null && !player.method_7337() && player.method_7305(terrain))
      net.minecraft.class_2248.method_9511(
          terrain, level, p, null, player, player.method_6047());
    terrainFill.put(p.method_10063(), class_2246.field_10124.method_9564());
    terrainOriginal.put(p.method_10063(), class_2246.field_10124.method_9564());

    var owners=index.at(p.method_10063()).stream().map(index.roads::get).filter(Objects::nonNull).toList();
    // Re-evaluate the now-empty cell against all remaining geometry. A shell may
    // admit exterior water, whereas a slab or any neighboring tunnel's air stays
    // dry. Passing no paving prevents reintroducing the material just excavated.
    var empty=collisionState(p.method_10063(),current,owners,null);
    level.method_8652(p,empty,3);
    if(empty.method_11654(RoadBlocks.Road.WATERLOGGED))
      level.method_39281(p,net.minecraft.class_3612.field_15910,
          net.minecraft.class_3612.field_15910.method_15789(level));
    method_80();
    return true;
  }

  /** Remove obstructing lamps on already-built approach roads after sign relocation.
   * Only exact lamp furniture and its local collider cells are touched. */
  void clearSignSightlines(class_3218 level,Set<UUID> changed){
    var ids=new HashSet<UUID>();
    for(UUID id:changed){var road=index.roads.get(id);if(road==null)continue;
      for(long key:road.chunks){var c=new net.minecraft.class_1923(key);for(int x=c.field_9181-6;x<=c.field_9181+6;x++)for(int z=c.field_9180-6;z<=c.field_9180+6;z++)ids.addAll(index.inChunk(net.minecraft.class_1923.method_8331(x,z)));}}
    if(ids.isEmpty())return;var roads=ids.stream().map(index.roads::get).filter(Objects::nonNull).toList();
    var sight=JunctionSignRoads.lampClearance(roads);var chunks=new HashSet<Long>();
    for(var built:roads){var removed=StreetLampClearance.removed(built.record.structures(),sight);if(removed.isEmpty())continue;
      var changedChunks=removeSightlineLamps(level,built,removed);if(changedChunks!=null)chunks.addAll(changedChunks);
    }
    for(long key:chunks){var chunk=new net.minecraft.class_1923(key);if(level.method_8393(chunk.field_9181,chunk.field_9180))repairChunk(level,chunk);}
  }

  /** Commit one checked lamp result. Null asks a budgeted caller to recheck its
   * stale road snapshot; returned chunks can be repaired in later bounded work. */
  Set<Long> removeSightlineLamps(class_3218 level,RoadIndex.Built expected,List<RoadStructures.Part> removed){
    if(index.roads.get(expected.record.id())!=expected)return null;
    if(removed.isEmpty())return Set.of();
    var removedSet=new HashSet<>(removed);
    var next=expected.record.structures(expected.record.structures().stream().filter(p->!removedSet.contains(p)).toList());
    index.put(RoadIndex.Built.loading(next));method_80();RoadNetwork.broadcastRoad(level,next);
    var chunks=new HashSet<Long>();
    for(var part:removed){double pad=part.halfExtent();
      for(int x=(int)Math.floor(Math.min(part.a().x(),part.b().x())-pad)>>4;x<=(int)Math.floor(Math.max(part.a().x(),part.b().x())+pad)>>4;x++)
        for(int z=(int)Math.floor(Math.min(part.a().z(),part.b().z())-pad)>>4;z<=(int)Math.floor(Math.max(part.a().z(),part.b().z())+pad)>>4;z++){
          long key=net.minecraft.class_1923.method_8331(x,z);chunks.add(key);retiredSignsByChunk.computeIfAbsent(key,k->new ArrayList<>()).add(part);
        }
    }
    return chunks;
  }

  /** Upgrade legacy flush decks as their chunks are watched; geometry stays unchanged. */
  private void releaseRetiredCell(class_3218 level,class_2338 pos,class_2680 state){
    long key=pos.method_10063();var walkway=sidewalkPlaced.get(key);
    // Pavement still owns its original terrain even when its last collider leaves.
    if(walkway!=null){if(RoadBlocks.isCollider(state))checkedSetBlock(level,pos,walkway,3);terrainFill.remove(key);return;}
    if(RoadBlocks.isCollider(state)){
      var restored=terrainOriginal.getOrDefault(key,terrainFill.getOrDefault(key,state.method_11654(RoadBlocks.Road.FILL).state()));
      checkedSetBlock(level,pos,restored,3);
    }
    // A player replacement is retained. Only the stale ownership snapshots are consumed.
    terrainFill.remove(key);terrainOriginal.remove(key);
  }

  public void repairChunk(class_3218 level, net.minecraft.class_1923 chunk) {
    // Bridge geometry repairs run through explicit road edits, never while a chunk is watched.
    var revised=structureRepair103.remove(chunk.method_8324());
    if(revised!=null){
      var nearby=index.inChunk(chunk.method_8324()).stream().map(index.roads::get).filter(Objects::nonNull).toList();
      for(var cell:RoadRaster.structures(revised,null).keySet()){
        if(cell.x()>>4!=chunk.field_9181||cell.z()>>4!=chunk.field_9180)continue;
        var p=new class_2338(cell.x(),cell.y(),cell.z());long key=p.method_10063();var state=level.method_8320(p);
        var owners=nearby.stream().filter(r->!r.boxes(p).isEmpty()).toList();
        if(owners.isEmpty()){
          releaseRetiredCell(level,p,state);
        }else if(TunnelAir.isAirSpace(state)||RoadBlocks.isCollider(state)){level.method_8652(p,collisionState(key,state,owners),3);if(level.method_8321(p) instanceof RoadFillEntity fill)fill.fill(terrainFill.getOrDefault(key,class_2246.field_10124.method_9564()));}
      }
      method_80();
    }
    var apronCells=apronWidthRepair.remove(chunk.method_8324());
    if(apronCells!=null){
      var ids=new HashSet<UUID>();for(int x=chunk.field_9181-1;x<=chunk.field_9181+1;x++)for(int z=chunk.field_9180-1;z<=chunk.field_9180+1;z++)ids.addAll(index.inChunk(net.minecraft.class_1923.method_8331(x,z)));
      var nearby=ids.stream().map(index.roads::get).filter(Objects::nonNull).toList();
      for(long key:apronCells){if(!apronPlaced.contains(key))continue;var p=class_2338.method_10092(key);
        boolean keep=false;for(var road:nearby){if(!RoadAprons.eligible(road.mesh))continue;var q=RoadQueries.horizontal(road.mesh,new V(p.method_10263()+.5,p.method_10264(),p.method_10260()+.5));if(Math.abs(q.lateral())<=q.sample().halfWidth()+1+1e-7&&Math.abs(q.sample().center().y()-(p.method_10264()+1))<2.01){keep=true;break;}}
        if(keep)continue;
        var expected=sidewalkPlaced.get(key);var state=level.method_8320(p);var fillEntity=level.method_8321(p);
        boolean owned=state.equals(expected)||state.method_27852(SplineRoads.FILLED_COLLIDER.get())&&fillEntity instanceof RoadFillEntity f&&f.fill().equals(expected);
        apronPlaced.remove(key);sidewalkPlaced.remove(key);
        var owners=nearby.stream().filter(b->!b.boxes(p).isEmpty()).toList();
        // A replaced apron no longer owns its old restoration history. Keep the
        // player's block, but do not let a later road resurrect pre-migration soil.
        // A surviving collider owner still needs its original terrain snapshot.
        if(!owned){if(owners.isEmpty()){terrainFill.remove(key);terrainOriginal.remove(key);}continue;}
        var original=terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564());
        if(owners.isEmpty()){terrainFill.remove(key);terrainOriginal.remove(key);level.method_8652(p,original,3);}
        else {terrainFill.put(key,original);level.method_8652(p,collisionState(key,state,owners),3);if(level.method_8321(p) instanceof RoadFillEntity f)f.fill(original,GroundTerrainJoin.cap(p,original,nearby));}
      }method_80();
    }
    var islands=islandRepair.remove(chunk.method_8324());
    if(islands!=null){
      var nearby=index.inChunk(chunk.method_8324()).stream().map(index.roads::get).filter(Objects::nonNull).toList();
      for(UUID id:islands){var road=index.roads.get(id);if(road==null||road.record.junction()==null)continue;var spec=road.record.junction().spec();
        for(var cell:road.prepareCollision().cellsInChunk(chunk.field_9181,chunk.field_9180)){
          if(new V(cell.x()+.5,spec.center().y(),cell.z()+.5).sub(spec.center()).horizontalLength()>spec.islandRadius()+.75||cell.y()<Math.floor(spec.center().y())||cell.y()>Math.floor(spec.center().y()+.75))continue;
          var p=new class_2338(cell.x(),cell.y(),cell.z());var previous=level.method_8320(p);if(!TunnelAir.isAirSpace(previous)&&!RoadBlocks.isCollider(previous))continue;
          var owners=nearby.stream().filter(b->!b.boxes(p).isEmpty()).toList();if(owners.isEmpty())continue;
          level.method_8652(p,collisionState(p.method_10063(),previous,owners),3);
        }
      }method_80();
    }
    var groundCells=groundJoinRepair.remove(chunk.method_8324());
    if(groundCells!=null){
      var nearby=index.inChunk(chunk.method_8324()).stream().map(index.roads::get).filter(Objects::nonNull).toList();
      for(long key:groundCells){var p=class_2338.method_10092(key);var state=level.method_8320(p);if(!RoadBlocks.isCollider(state)||state.method_27852(SplineRoads.FILLED_COLLIDER.get())||state.method_11654(RoadBlocks.Road.FILL)!=RoadBlocks.Fill.NONE)continue;
        var original=terrainOriginal.getOrDefault(key,class_2246.field_10124.method_9564());double cap=GroundTerrainJoin.cap(p,original,nearby);if(cap>=1)continue;
        var owners=nearby.stream().filter(b->!b.boxes(p).isEmpty()).toList();if(owners.isEmpty())continue;var next=collisionState(key,state,owners);
        if(!next.method_27852(SplineRoads.FILLED_COLLIDER.get()))continue;
        terrainFill.put(key,original);level.method_8652(p,next,3);if(level.method_8321(p) instanceof RoadFillEntity filled)filled.fill(original,cap);
      }method_80();
    }
    var retired=retiredSignsByChunk.remove(chunk.method_8324());
    if(retired!=null){
      for(var cell:RoadRaster.structures(retired,null).keySet()){
        if(cell.x()>>4!=chunk.field_9181||cell.z()>>4!=chunk.field_9180)continue;
        var p=new class_2338(cell.x(),cell.y(),cell.z());long key=p.method_10063();var state=level.method_8320(p);
        var owners=index.inChunk(chunk.method_8324()).stream().map(index.roads::get).filter(r->!r.boxes(p).isEmpty()).toList();
        if(owners.isEmpty())releaseRetiredCell(level,p,state);
        else if(RoadBlocks.isCollider(state)){level.method_8652(p,collisionState(key,state,owners),3);if(level.method_8321(p) instanceof RoadFillEntity fill)fill.fill(terrainFill.getOrDefault(key,class_2246.field_10124.method_9564()));}
      }method_80();
    }
    // Walking is not an edit transaction. Preserve saved geometry, load no remote chunks,
    // and leave geometry upgrades to an explicit editor save.
    for (UUID id : List.copyOf(index.inChunk(chunk.method_8324()))) {
      var built = index.roads.get(id);
      // Current transactions persist colliders with their road. Only legacy saves need this scan.
      // Re-scanning modern roads on every chunk watch would eagerly rasterize an entire city.
      if (built == null || built.record.buildVersion() >= 17) continue;
      var done = repairedChunks.computeIfAbsent(chunk.method_8324(), ignored -> new HashSet<>());
      if (done.contains(id)) continue;
      for (var cell : built.prepareCollision().cellsInChunk(chunk.field_9181, chunk.field_9180)) {
        class_2338 p = new class_2338(cell.x(),cell.y(),cell.z());
        long key = p.method_10063();
        class_2680 state = level.method_8320(p);
        if (state.method_27852(SplineRoads.NODE.get())
            || RoadBlocks.isCollider(state)
            || state.method_26214(level, p) < 0 || state.method_31709()) continue;
        var owners = index.at(key).stream().map(index.roads::get).toList();
        level.method_8652(p, collisionState(key, state, owners), 2);
        method_80();
      }
      done.add(id);
    }
  }
}
