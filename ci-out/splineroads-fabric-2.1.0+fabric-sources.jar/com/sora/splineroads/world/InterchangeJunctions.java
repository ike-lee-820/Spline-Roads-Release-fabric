package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.InterchangePlanner.Leg;
import com.sora.splineroads.core.InterchangePlanner.Options;
import com.sora.splineroads.core.JunctionPlanner.Plan;
import com.sora.splineroads.core.JunctionSpec.Arm;
import com.sora.splineroads.core.RoadClearance.DetailedContact;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.RoadIndex.Built;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Ordinary SR junctions owned by an interchange, with independent editor identities. */
final class InterchangeJunctions {
  static UUID parent(RoadData data,UUID id){
    var child=data.junctions.get(id);
    return child!=null&&child.method_25928("Interchange")?child.method_25926("Interchange"):id;
  }
  static boolean belongs(RoadData data,UUID parent,UUID assembly){return assembly!=null&&parent.equals(parent(data,assembly));}
  static UUID id(UUID parent,int index){return UUID.nameUUIDFromBytes((parent+":service-junction:"+index).getBytes(StandardCharsets.UTF_8));}
  static class_2487 descriptor(UUID parent,UUID owner,int index,JunctionSpec spec){
    var t=new class_2487();t.method_10582("Kind","junction");t.method_25927("Id",id(parent,index));t.method_25927("Owner",owner);t.method_25927("Interchange",parent);t.method_10569("InterchangeSlot",index);t.method_10566("Spec",JunctionCodec.write(spec));
    long[] points=new long[spec.arms().size()+1];points[0]=pos(spec.center()).method_10063();for(int i=0;i<spec.arms().size();i++)points[i+1]=pos(spec.arms().get(i).endpoint().position()).method_10063();t.method_10564("Points",points);return t;
  }
  static class_2338 pos(V p){return class_2338.method_49637(p.x(),p.y(),p.z());}
  static RoadRecord piece(UUID parent,UUID owner,int index,JunctionPlanner.Ref ref){
    UUID group=id(parent,index),id=UUID.nameUUIDFromBytes((group+":junction:"+ref.piece()).getBytes(StandardCharsets.UTF_8));
    var mesh=ref.get().mesh();int arm=ref.get().arm();var center=pos(ref.spec().center());
    return new RoadRecord(id,owner,arm<0?center:pos(ref.spec().arms().get(arm).endpoint().position()),center,RoadRibbon.start(mesh),RoadRibbon.end(mesh),mesh.settings(),false,4).junction(group,ref);
  }
  static void forget(RoadData data,UUID parent){data.junctions.entrySet().removeIf(e->e.getValue().method_25928("Interchange")&&parent.equals(e.getValue().method_25926("Interchange")));}
  static Set<UUID> restoreMain(RoadData data,class_2487 saved,List<RoadIndex.Built> mains){
    var options=Interchanges.read(saved.method_10562("Options"));
    if(options.preset()!=InterchangePlanner.Preset.DIAMOND&&options.preset()!=InterchangePlanner.Preset.SPUI)return Set.of();
    // Old releases kept an untrimmed cross road; only the new standard-junction
    // topology has gaps to close when removing all ramps and junctions.
    UUID parent=saved.method_25926("Id");boolean children=saved.method_10577("StandardServiceJunctions")||data.junctions.values().stream().anyMatch(t->t.method_25928("Interchange")&&parent.equals(t.method_25926("Interchange")));
    if(!children)return Set.of();
    int axis=options.junctionAxis();Set<UUID> pieces=new HashSet<>();
    for(class_2520 value:saved.method_10554("SignTopology",class_2520.field_33260)){var t=(class_2487)value;if(!t.method_10577("Ramp")&&t.method_10550("From")==axis&&t.method_10550("To")==axis+2&&t.method_25928("Road"))pieces.add(t.method_25926("Road"));}
    var found=pieces.stream().map(data.index.roads::get).filter(Objects::nonNull).findFirst();if(found.isEmpty())return Set.of();
    var nodes=saved.method_10554("Nodes",class_2520.field_33260);Node a=RoadRecord.readNode(nodes.method_10602(axis*2)),b=RoadRecord.readNode(nodes.method_10602(axis*2+1));
    var source=found.get();double length=a.position().sub(b.position()).horizontalLength();var samples=new ArrayList<Sample>();V left=b.position().sub(a.position()).horizontalUnit().left();
    for(int i=0,n=(int)Math.ceil(length/.5);i<=n;i++)samples.add(new Sample(a.position().mul(1-i/(double)n).add(b.position().mul(i/(double)n)),left,0,source.mesh.first().halfWidth()));
    Mesh mesh=RoadRibbon.mesh(samples,source.record.settings());UUID id=UUID.nameUUIDFromBytes((parent+":restored-service-main").getBytes(StandardCharsets.UTF_8));
    mains.add(new RoadIndex.Built(new RoadRecord(id,saved.method_25926("Owner"),class_2338.method_10092(saved.method_10565("Points")[axis*2]),class_2338.method_10092(saved.method_10565("Points")[axis*2+1]),a,b,mesh.settings(),false,4).alignment(null,mesh)));
    return pieces;
  }
  static void captureEdits(RoadData data,UUID parent,class_2487 payload){
    var tags=new class_2499();data.junctions.values().stream().filter(t->t.method_25928("Interchange")&&parent.equals(t.method_25926("Interchange")))
        .sorted(Comparator.comparingInt(t->t.method_10550("InterchangeSlot"))).forEach(t->{var copy=new class_2487();copy.method_10569("Slot",t.method_10550("InterchangeSlot"));copy.method_10566("Spec",t.method_10562("Spec").method_10553());tags.add(copy);});
    payload.method_10566("ServiceJunctionEdits",tags);
  }
  static InterchangePlanner.Plan applyEdits(InterchangePlanner.Plan plan,class_2487 payload){
    var saved=payload.method_10554("ServiceJunctionEdits",class_2520.field_33260);if(saved.isEmpty())return plan;
    var specs=new ArrayList<JunctionSpec>();var legs=new ArrayList<InterchangePlanner.Leg>();
    for(var leg:plan.legs()){
      if(leg.junction()==null){legs.add(leg);continue;}
      var fresh=leg.junction().spec();if(specs.contains(fresh))continue;int slot=specs.size();specs.add(fresh);
      var oldTag=saved.stream().map(t->(class_2487)t).filter(t->t.method_10550("Slot")==slot).findFirst();
      JunctionSpec spec=fresh;
      if(oldTag.isPresent()){
        var old=JunctionCodec.read(oldTag.get().method_10562("Spec"));
        if(old.arms().size()==fresh.arms().size()){
          var arms=new ArrayList<JunctionSpec.Arm>();
          for(int i=0;i<fresh.arms().size();i++){
            var a=fresh.arms().get(i);var b=old.arms().get(i);
            arms.add(a.incoming()==b.incoming()&&a.outgoing()==b.outgoing()?new JunctionSpec.Arm(a.endpoint(),a.inward(),a.external(),a.incoming(),a.outgoing(),a.width(),a.median(),a.medianKind(),a.cycleWidth(),a.curbWidth(),b.crosswalk(),b.crossingWidth(),b.crossingSetback(),b.stopGap(),b.phase(),b.lanes(),true,b.advanceSign(),b.nameSign()):a);
          }
          spec=new JunctionSpec(fresh.center(),fresh.kind(),fresh.leftTraffic(),old.cornerRadius(),old.islandRadius(),old.ringLanes(),old.ringLaneWidth(),fresh.thickness(),old.control(),old.greenSeconds(),old.yellowSeconds(),old.allRedSeconds(),old.timeOffset(),old.guides(),old.greenIsland(),old.outerRail(),arms,fresh.parallelApproaches());
        }
      }
      var junction=JunctionPlanner.plan(spec);for(int i=0;i<junction.pieces().size();i++)legs.add(new InterchangePlanner.Leg(leg.name(),-1,-1,junction.pieces().get(i).mesh(),new JunctionPlanner.Ref(spec,i)));
    }
    double clearance=Interchanges.read(payload.method_10562("Options")).clearance();
    for(int i=0;i<legs.size();i++)for(int j=0;j<i;j++)if(legs.get(i).junction()!=null||legs.get(j).junction()!=null)
      for(var contact:RoadClearance.detailedContacts(legs.get(i).mesh(),legs.get(j).mesh()))if(!contact.coplanar()&&contact.contact().usableClearance()+1e-7<Math.max(clearance,contact.contact().required()))throw new IllegalArgumentException("编辑后的路口与立交道路净高不足，请调整路口参数");
    return new InterchangePlanner.Plan(List.copyOf(legs),plan.movements(),plan.minRadius(),plan.highest(),plan.center(),plan.anchors());
  }
  static InterchangePlanner.Plan elevationDefaults(InterchangePlanner.Plan plan,class_2487 payload){
    int axis=Interchanges.read(payload.method_10562("Options")).junctionAxis();
    if(!payload.method_10577("ServiceElevated"+axis)||!payload.method_10554("ServiceJunctionEdits",class_2520.field_33260).isEmpty())return plan;
    var legs=new ArrayList<InterchangePlanner.Leg>();var seen=new HashSet<JunctionSpec>();
    for(var leg:plan.legs()){
      if(leg.junction()==null){legs.add(leg);continue;}
      var spec=leg.junction().spec();if(!seen.add(spec))continue;
      spec=spec.arms(spec.arms().stream().map(a->a.external().options().sidewalk().enabled()?a:a.crossing(false)).toList());
      var junction=JunctionPlanner.plan(spec);
      for(int i=0;i<junction.pieces().size();i++)legs.add(new InterchangePlanner.Leg(leg.name(),-1,-1,junction.pieces().get(i).mesh(),new JunctionPlanner.Ref(spec,i)));
    }
    return new InterchangePlanner.Plan(List.copyOf(legs),plan.movements(),plan.minRadius(),plan.highest(),plan.center(),plan.anchors());
  }
  private InterchangeJunctions(){}
}
