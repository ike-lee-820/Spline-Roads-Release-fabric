package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Data;
import com.sora.splineroads.core.LanePoints.Lane;
import com.sora.splineroads.core.LanePoints.Point;
import com.sora.splineroads.core.LaneSections.Cut;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.world.RoadPointIndex.Marker;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.phys.*;
import java.util.*;

public final class LanePointTool extends class_1792 {
  public LanePointTool(){super(new class_1793().method_7889(1));}
  private record Pending(UUID token,long expires) {}
  private static final Map<class_3222,Pending> OPENING=new WeakHashMap<>();
  static UUID pendingToken(class_3222 p){var v=OPENING.get(p);return v==null?null:v.token();}
  public static void acknowledge(class_3222 p,UUID token){var v=OPENING.get(p);if(v!=null&&v.token().equals(token))OPENING.remove(p);}
  private static void open(class_3222 p,RoadRecord r,LanePoints.Point point){
    var t=payload(RoadData.get(p.method_51469()),r,point);UUID token=UUID.randomUUID();
    OPENING.put(p,new Pending(token,p.method_51469().method_8510()+100));t.method_25927("Interaction",token);RoadNetwork.open(p,t);
  }
  public record Pick(RoadRecord road,LanePoints.Point point,double distance){}
  public static Pick pick(class_3222 player){
    var eye=player.method_33571();double stop=player.method_5745(96,0,false).method_17784().method_1022(eye)+.7;
    return pick(RoadData.get(player.method_51469()).index,eye,player.method_5720(),stop,player.method_5715());
  }
  static Pick pick(RoadIndex index,class_243 eye,class_243 direction,double stop,boolean preferAutomatic){
    var end=eye.method_1019(direction.method_1021(96));var hits=new ArrayList<Pick>();
    var origin=new V(eye.field_1352,eye.field_1351,eye.field_1350);var vector=new V(direction.field_1352,direction.field_1351,direction.field_1350);
    for(var marker:index.lanePointCandidates(origin,vector,96)){
      var road=index.roads.get(marker.road());if(road==null)continue;
      var hit=RoadPointIndex.bounds(marker.point()).method_992(eye,end);
      if(hit.isPresent()&&hit.get().method_1022(eye)<stop)hits.add(new Pick(road.record,marker.point(),hit.get().method_1022(eye)));
    }
    // Candidates retain road insertion/point order, including exact distance ties.
    hits.sort(Comparator.comparingDouble(Pick::distance));if(hits.isEmpty())return null;
    double nearest=hits.get(0).distance();
    return hits.stream().filter(h->h.distance()<nearest+.15)
        .min(Comparator.comparingInt(h->h.point().automatic()==preferAutomatic?0:1)).orElse(hits.get(0));
  }
  public static LanePoints.Point create(class_3218 level,class_3222 player,UUID id,V hit){var data=RoadData.get(level);var b=data.index.roads.get(id);if(b==null||b.record.railway()||b.record.junction()!=null||b.record.toll()!=null)throw new IllegalArgumentException("请在独立路段的机动车道上放点");if(player!=null)RoadData.requireOwner(player,b.record.owner());for(var other:data.index.roads.values())if(other.record.toll()!=null&&TollPlanner.contains(other.mesh,hit,.03,other.record.toll().config().clearHeight()))throw new IllegalArgumentException("收费站内部和 A/B 接口不能创建匝道车道点");var lane=LanePoints.clicked(b.mesh,hit);var md=LaneTopology.metadata(b.record);var existing=md.points().stream().filter(p->!p.automatic()&&p.lane()==lane.index()&&p.position().distance(lane.position())<.65).findFirst();if(existing.isPresent())return existing.get();var p=LanePoints.point(UUID.randomUUID(),LanePoints.Origin.MANUAL,b.mesh,lane.station(),lane.index());var points=new ArrayList<>(md.points());points.add(p);update(level,player,b.record,md.points(points),Set.of());return p;}
  private void select(class_3222 p,V hit){var pending=OPENING.get(p);if(pending!=null&&p.method_51469().method_8510()<pending.expires())return;try{if(!p.method_7294()||p.method_7325())throw new IllegalArgumentException("没有建设权限");var picked=pick(p);if(picked!=null&&!(p.method_5715()&&picked.point().automatic()&&LaneTopology.metadata(picked.road()).points().stream().noneMatch(v->!v.automatic()&&v.position().distance(picked.point().position())<.65))){RoadData.requireOwner(p,picked.road().owner());open(p,picked.road(),picked.point());return;}var b=RoadTool.pick(p);if(b==null||hit==null)throw new IllegalArgumentException("请右键机动车道创建蓝色车道点，或右键已有蓝色点");var point=create(p.method_51469(),p,b.record.id(),hit);open(p,RoadData.get(p.method_51469()).index.roads.get(b.record.id()).record,point);}catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}}
  @Override public class_1269 method_7884(class_1838 c){if(c.method_8036() instanceof class_3222 p){var h=c.method_17698();select(p,new V(h.field_1352,h.field_1351,h.field_1350));}return class_1269.method_29236(c.method_8045().field_9236);}
  @Override public class_1271<class_1799> method_7836(class_1937 l,class_1657 p,class_1268 hand){if(p instanceof class_3222 sp)select(sp,null);return class_1271.method_29237(p.method_5998(hand),l.field_9236);}
  public static class_2487 payload(RoadData data,RoadRecord r,LanePoints.Point p){var t=new class_2487();t.method_10582("Kind","lanePoint");t.method_10566("Road",r.header());t.method_25927("Id",r.id());t.method_25927("Point",p.id());t.method_10569("Signature",r.header().hashCode());t.method_10556("Supported",r.assembly()==null&&LanePoints.supported(r.settings()));var refs=LaneTopology.references(data,LanePoints.Ref.lane(r.id(),p.id()));var dependencies=LaneTopology.dependents(data,new HashSet<>(refs));var all=new TreeSet<UUID>(refs);all.addAll(dependencies);var list=new class_2499();all.forEach(id->list.add(class_2519.method_23256(id.toString())));for(var cut:LaneTopology.metadata(r).cuts())if(cut.connection().equals(p.id())&&cut.replacement()!=null){all.add(cut.replacement());all.addAll(LaneTopology.dependents(data,Set.of(cut.replacement())));}
    list.clear();all.forEach(id->list.add(class_2519.method_23256(id.toString())));t.method_10566("Dependencies",list);return t;}
  public static String edit(class_3218 level,class_3222 player,class_2487 t){var data=RoadData.get(level);var b=data.index.roads.get(t.method_25926("Id"));if(b==null)throw new IllegalArgumentException("道路已不存在");var r=b.record;if(player!=null)RoadData.requireOwner(player,r.owner());if(t.method_10550("Signature")!=r.header().hashCode())throw new IllegalArgumentException("道路已变化，请重新打开车道点");var md=LaneTopology.metadata(r);var p=LaneTopology.point(r,t.method_25926("Point"));if(p.automatic())throw new IllegalArgumentException("自动尽头点不能删除或切换车道");var points=new ArrayList<>(md.points());Set<UUID> removed=new HashSet<>();
    if(t.method_10545("MergeLength")){
      if(r.assembly()!=null||!LanePoints.supported(r.settings()))throw new IllegalArgumentException("仅独立且支持车道连接的道路可设置合流缩减");
      double length=t.method_10574("MergeLength");var next=p.merge(length);
      if(length>0)LaneMerge.event(r.rawMesh(),next);else if(length<0)LaneExpansion.addition(r.rawMesh(),next,8);
      if(p.mergeLength()>0&&length==0&&md.cuts().stream().anyMatch(c->c.connection().equals(p.id())&&c.replacement()!=null))
        throw new IllegalArgumentException("此空位已有补入匝道，请先删除或改为其他汇入模式，再取消合流缩减");
      points.set(points.indexOf(p),next);update(level,player,r,md.points(points),Set.of());return length>0?"外侧车道已合流缩减，下游空位可补入":length<0?"已设置外侧扩流，下游新增一条同向车道":"车道增减已取消，主路已恢复";
    }

    if(t.method_10577("Delete")){for(var cut:md.cuts())if(cut.connection().equals(p.id())&&cut.replacement()!=null)removed.add(cut.replacement());var refs=LaneTopology.references(data,LanePoints.Ref.lane(r.id(),p.id()));removed.addAll(refs);removed.addAll(LaneTopology.dependents(data,removed));LaneDeletes.requireConfirmation(t,removed);if(player!=null)for(UUID id:removed)RoadData.requireOwner(player,data.index.roads.get(id).record.owner());points.remove(p);}else{if(p.mergeLength()!=0)throw new IllegalArgumentException("请先取消车道增减，再切换此车道点");int lane=t.method_10550("Lane");var selected=LanePoints.lane(b.mesh,LanePoints.lane(b.mesh,p).station(),lane);points.set(points.indexOf(p),p.at(selected,b.mesh));}
    update(level,player,r,md.points(points),removed);return t.method_10577("Delete")?"手动车道点及确认的依赖匝道已删除":"车道已切换，依赖匝道已同步重建";}
  static void update(class_3218 level,class_3222 player,RoadRecord r,LanePoints.Data md,Set<UUID> deleted){
    var data=RoadData.get(level);boolean referenced=false;
    for(var p:LaneTopology.metadata(r).points()) {
      var next=md.points().stream().filter(v->v.id().equals(p.id())).findFirst().orElse(null);
      if(!p.equals(next)&&data.index.laneReferenced(LanePoints.Ref.lane(r.id(),p.id()))){referenced=true;break;}
    }
    if(!referenced&&deleted.isEmpty()&&LaneMerge.sameDefinitions(LaneTopology.metadata(r),md)){data.updateLanePointMetadata(level,player,r,md);return;}
    var removed=new HashSet<>(deleted);removed.add(r.id());data.replaceAssembly(level,player,List.of(new RoadIndex.Built(r.withLanePoints(md))),removed,Set.of(r.a(),r.b()));
  }
  @Override public void method_7851(class_1799 s,class_1937 l,List<class_2561> lines,class_1836 f){lines.add(class_2561.method_43470("右键机动车道吸附到该车道中轴线；右键蓝色点编辑"));lines.add(class_2561.method_43470("Shift＋右键自动点创建手动点；重合时 Shift 选择自动点"));}
}
