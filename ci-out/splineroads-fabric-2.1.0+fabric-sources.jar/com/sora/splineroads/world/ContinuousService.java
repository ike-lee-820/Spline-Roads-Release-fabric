package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.InterchangePlanner.*;
import com.sora.splineroads.core.JunctionPlanner.Ref;
import com.sora.splineroads.core.JunctionSpec.Arm;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** A service crossroad replaces the managed interior, never its ordinary outside continuations. */
final class ContinuousService {
  static final String LOGICAL="ServiceLogical", RECEIPT="ContinuousServiceReceipt";
  static final String INVALID="原立交服务主路记录已修改、删除或不再完整，不能自动恢复连续主路；请先处理该道路组合";

  static int axis(class_2487 tag,Plan plan){
    var options=Interchanges.read(tag.method_10562("Options"));
    int axis=options.junctionAxis();
    return (options.preset()==Preset.DIAMOND||options.preset()==Preset.SPUI)
        &&plan.legs().stream().anyMatch(l->l.junction()!=null)
        &&ContinuousRoads.sources(tag).stream().anyMatch(s->s.axis()==axis)?axis:-1;
  }
  private static Plan coverage(class_2487 tag,Plan plan,int axis){
    String prefix="主路 "+(axis+1)+" · ";
    var piece=plan.legs().stream().filter(l->l.name().startsWith(prefix)&&l.junction()==null).findFirst()
        .orElseThrow(()->new IllegalArgumentException("服务路口两端需保留至少两格普通主路，请扩大端点范围"));
    V a=plan.anchors().get(axis*2).position(),b=plan.anchors().get(axis*2+1).position();
    var samples=new ArrayList<Sample>();double length=b.sub(a).horizontalLength();
    for(int i=0,n=(int)Math.ceil(length/.5);i<=n;i++)
      samples.add(new Sample(a.mul(1-i/(double)n).add(b.mul(i/(double)n)),b.sub(a).horizontalUnit().left(),0,piece.mesh().first().halfWidth()));
    var full=new Leg("主路 "+(axis+1),axis,axis+2,RoadRibbon.mesh(samples,piece.mesh().settings()));
    var single=new Plan(List.of(full),plan.movements(),plan.minRadius(),plan.highest(),plan.center(),plan.anchors());
    return ContinuousRoads.segment(tag,single,ContinuousRoads.sources(tag));
  }
  static void outside(class_2487 tag,Plan plan,List<Leg> result){
    int axis=axis(tag,plan);if(axis<0)return;
    // Process the complete occupied range ONCE; per-junction main pieces cannot be
    // independently segmented because that duplicates donors and source identities.
    for(var leg:coverage(tag,plan,axis).legs())if(ContinuousRoads.donor(leg.name()))result.add(leg);
  }
  static Plan sourcePlan(class_2487 tag,Plan visible){
    int axis=axis(tag,visible);if(axis<0)return visible;
    var legs=new ArrayList<>(visible.legs());
    for(var leg:coverage(tag,visible,axis).legs())if(!ContinuousRoads.donor(leg.name()))legs.add(leg);
    return new Plan(List.copyOf(legs),visible.movements(),visible.minRadius(),visible.highest(),visible.center(),visible.anchors());
  }
  static boolean logical(class_2487 tag,UUID id){
    return tag.method_10554("ContinuousSources",class_2520.field_33260).stream().map(v->(class_2487)v)
        .anyMatch(q->q.method_10577(LOGICAL)&&q.method_10562("Road").method_25926("Id").equals(id));
  }
  static void prepare(class_2487 tag,Plan plan,List<RoadIndex.Built> staged,List<class_2487> children,class_2499 topology,UUID group,UUID owner){
    int axis=axis(tag,plan);
    var occupied=new HashSet<UUID>();
    if(axis>=0)for(var leg:coverage(tag,plan,axis).legs())
      if(leg.name().startsWith(ContinuousRoads.MAIN))occupied.add(ContinuousSections.id(leg.name()));
    tag.method_10551(RECEIPT);
    for(var value:tag.method_10554("ContinuousSources",class_2520.field_33260))((class_2487)value).method_10551(LOGICAL);
    if(axis<0)return;
    var receipt=new class_2487();receipt.method_10569("Axis",axis);var sources=new class_2499();
    for(var value:tag.method_10554("ContinuousSources",class_2520.field_33260)){
      var q=(class_2487)value;if(q.method_10550("Axis")!=axis||q.method_10577("Detached"))continue;
      if(!occupied.contains(q.method_10562("Road").method_25926("Id")))throw new IllegalArgumentException(INVALID);
      q.method_10556(LOGICAL,true);var id=new class_2487();id.method_25927("Id",q.method_10562("Road").method_25926("Id"));sources.add(id);
    }
    var rootIds=new HashSet<UUID>();
    for(var value:topology){var q=(class_2487)value;if(!q.method_10577("Ramp")&&q.method_10550("From")==axis&&q.method_10550("To")==axis+2)rootIds.add(q.method_25926("Road"));}
    var roots=new class_2499();var members=new class_2499();var junctions=new class_2499();
    for(var built:staged){
      var road=built.record;
      if(!group.equals(road.assembly()))continue;
      if(rootIds.contains(road.id())){var id=new class_2487();id.method_25927("Id",road.id());roots.add(id);}
      if(rootIds.contains(road.id()))members.add(road.header());
    }
    for(var child:children){
      if(!child.method_25926("Owner").equals(owner)||!child.method_25926("Interchange").equals(group))throw new IllegalArgumentException(INVALID);
      var spec=JunctionCodec.read(child.method_10562("Spec"));var expected=JunctionPlanner.plan(spec);UUID childId=child.method_25926("Id");int slot=child.method_10550("InterchangeSlot");
      if(staged.stream().filter(b->childId.equals(b.record.assembly())).count()!=expected.pieces().size())throw new IllegalArgumentException(INVALID);
      for(int i=0;i<expected.pieces().size();i++){
        var ref=new JunctionPlanner.Ref(spec,i);var record=InterchangeJunctions.piece(group,owner,slot,ref);
        if(staged.stream().noneMatch(b->b.record.id().equals(record.id())&&b.record.owner().equals(owner)&&b.mesh.samples().equals(ref.get().mesh().samples())))throw new IllegalArgumentException(INVALID);
      }
      junctions.add(child.method_10553());
    }
    if(sources.isEmpty()||roots.size()<2||members.isEmpty()||junctions.isEmpty())throw new IllegalArgumentException(INVALID);
    receipt.method_10566("Sources",sources);receipt.method_10566("Roots",roots);receipt.method_10566("Members",members);receipt.method_10566("Junctions",junctions);tag.method_10566(RECEIPT,receipt);
  }
  /** Structure and completeness were checked before replaceAssembly. Only snapshot final headers. */
  static void capture(RoadData data,class_2487 tag){
    if(!tag.method_10545(RECEIPT))return;
    var receipt=tag.method_10562(RECEIPT);var members=new class_2499();
    for(var value:receipt.method_10554("Members",class_2520.field_33260)){
      var old=(class_2487)value;var actual=data.index.roads.get(old.method_25926("Id"));
      members.add(actual==null?old.method_10553():actual.record.header());
    }
    receipt.method_10566("Members",members);
  }
  static void refresh(RoadData data,class_2487 tag,Set<UUID> roots,Map<UUID,RoadRecord> records,Map<UUID,Integer> axes){
    var logical=new HashSet<UUID>();
    for(var value:tag.method_10554("ContinuousSources",class_2520.field_33260)){var q=(class_2487)value;if(q.method_10577(LOGICAL))logical.add(q.method_10562("Road").method_25926("Id"));}
    if(logical.isEmpty()){if(tag.method_10545(RECEIPT))throw new IllegalArgumentException(INVALID);return;}
    var receipt=tag.method_10562(RECEIPT);int axis=receipt.method_10550("Axis");var listed=new HashSet<UUID>();
    for(var value:receipt.method_10554("Sources",class_2520.field_33260))listed.add(((class_2487)value).method_25926("Id"));
    if(!logical.equals(listed)||!tag.method_25928("Id")||!tag.method_25928("Owner"))throw new IllegalArgumentException(INVALID);
    for(var value:tag.method_10554("ContinuousSources",class_2520.field_33260)){var q=(class_2487)value;if(q.method_10577(LOGICAL)&&(q.method_10577("Detached")||q.method_10550("Axis")!=axis))throw new IllegalArgumentException(INVALID);}
    var members=new HashMap<UUID,RoadRecord>();
    for(var value:receipt.method_10554("Members",class_2520.field_33260)){
      var saved=RoadRecord.load((class_2487)value);var built=data.index.roads.get(saved.id());
      if(built==null||!built.record.owner().equals(tag.method_25926("Owner"))
          ||!InterchangeJunctions.belongs(data,tag.method_25926("Id"),built.record.assembly())
          ||!saved.header().equals(built.record.header())||members.put(saved.id(),built.record)!=null)throw new IllegalArgumentException(INVALID);
    }
    for(var value:receipt.method_10554("Junctions",class_2520.field_33260)){
      var before=(class_2487)value;UUID id=before.method_25926("Id");var current=data.junctions.get(id);
      if(current==null||!current.method_25928("Owner")||!current.method_25926("Owner").equals(tag.method_25926("Owner"))
          ||!current.method_25928("Interchange")||!current.method_25926("Interchange").equals(tag.method_25926("Id"))
          ||current.method_10550("InterchangeSlot")!=before.method_10550("InterchangeSlot"))throw new IllegalArgumentException(INVALID);
      var old=JunctionCodec.read(before.method_10562("Spec"));var spec=JunctionCodec.read(current.method_10562("Spec"));
      if(!old.center().equals(spec.center())||old.arms().size()!=spec.arms().size())throw new IllegalArgumentException(INVALID);
      for(int i=0;i<old.arms().size();i++){
        var a=old.arms().get(i);var b=spec.arms().get(i);
        // Match Junctions.buildRoad's attached-port invariants. Width, lane counts,
        // crossings and controls are legal independent edits and use the current spec.
        if(!a.endpoint().equals(b.endpoint())||!a.inward().equals(b.inward())
            ||a.attached()!=b.attached()||!a.external().equals(b.external()))throw new IllegalArgumentException(INVALID);
      }
      var expected=JunctionPlanner.plan(spec);
      if(data.index.roads.values().stream().filter(b->id.equals(b.record.assembly())).count()!=expected.pieces().size())throw new IllegalArgumentException(INVALID);
      for(int i=0;i<expected.pieces().size();i++){
        var ref=new JunctionPlanner.Ref(spec,i);var record=InterchangeJunctions.piece(tag.method_25926("Id"),tag.method_25926("Owner"),current.method_10550("InterchangeSlot"),ref);var live=data.index.roads.get(record.id());
        if(live==null||!live.record.owner().equals(tag.method_25926("Owner"))||!id.equals(live.record.assembly())
            ||live.record.junction()==null||!live.record.junction().spec().equals(ref.spec())||live.record.junction().piece()!=i
            ||!live.mesh.samples().equals(ref.get().mesh().samples()))throw new IllegalArgumentException(INVALID);
      }
    }
    int count=0;
    for(var value:receipt.method_10554("Roots",class_2520.field_33260)){
      UUID id=((class_2487)value).method_25926("Id");var road=members.get(id);
      if(road==null||road.junction()!=null||road.toll()!=null||!RoadContinuity.eligible(road.caps(0).mesh()))throw new IllegalArgumentException(INVALID);
      roots.add(id);records.put(id,road);axes.put(id,axis);count++;
    }
    if(count<2)throw new IllegalArgumentException(INVALID);
  }
  private ContinuousService(){}
}
