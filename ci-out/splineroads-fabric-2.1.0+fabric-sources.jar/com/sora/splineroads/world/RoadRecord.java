package com.sora.splineroads.world;

import com.sora.splineroads.core.RoadGeometry;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadInfrastructure.Config;
import com.sora.splineroads.core.RoadLaneLines.Edit;
import com.sora.splineroads.core.RoadProfile;
import com.sora.splineroads.core.RoadProfile.Control;
import com.sora.splineroads.core.RoadProfile.Layout;
import com.sora.splineroads.core.RoadProfile.Options;
import com.sora.splineroads.core.RoadSlicing.Fragment;
import com.sora.splineroads.core.RoadStreetscape.Span;
import com.sora.splineroads.core.RoadPlanner;
import com.sora.splineroads.core.RoadPlantings;
import com.sora.splineroads.core.RoadStructures.Part;
import com.sora.splineroads.core.RoadTransitions;
import com.sora.splineroads.core.RoadTransitions.Ends;
import com.sora.splineroads.core.RoadTransitions.Port;
import com.sora.splineroads.core.RoadTransitions.Section;
import com.sora.splineroads.core.TollPlanner.Plan;
import ;
import com.sora.splineroads.core.LanePoints.Data;
import com.sora.splineroads.core.RoadFurniture;
import java.io.*;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

public record RoadRecord(
    UUID id,
    UUID owner,
    class_2338 a,
    class_2338 b,
    Node start,
    Node end,
    Settings settings,
    boolean automatic,
    int clearance,
    List<Part> structures,
    int endCaps,
    int buildVersion,
    UUID assembly,
    List<Sample> alignment,
    RoadFurniture.Phase furniturePhase, com.sora.splineroads.core.JunctionPlanner.Ref junction,
    com.sora.splineroads.core.TollPlaza.Spec toll, com.sora.splineroads.core.RoadSlicing.Fragment fragment) {
  public RoadRecord(UUID id,UUID owner,class_2338 a,class_2338 b,Node start,Node end,Settings settings,boolean automatic,int clearance,List<Part> structures,int endCaps,int buildVersion,UUID assembly,List<Sample> alignment,RoadFurniture.Phase phase,com.sora.splineroads.core.JunctionPlanner.Ref junction,com.sora.splineroads.core.TollPlaza.Spec toll){
    this(id,owner,a,b,start,end,settings,automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,phase,junction,toll,null);
  }
  public RoadRecord fragment(com.sora.splineroads.core.RoadSlicing.Fragment value){return new RoadRecord(id,owner,a,b,start,end,settings,automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,furniturePhase,junction,toll,value);}

  public RoadRecord(UUID id,UUID owner,class_2338 a,class_2338 b,Node start,Node end,Settings settings,boolean automatic,int clearance,List<Part> structures,int endCaps,int buildVersion,UUID assembly,List<Sample> alignment,RoadFurniture.Phase phase,com.sora.splineroads.core.JunctionPlanner.Ref junction){
    this(id,owner,a,b,start,end,settings,automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,phase,junction,null);
  }
  public RoadRecord toll(com.sora.splineroads.core.TollPlaza.Spec spec){
    var plan=com.sora.splineroads.core.TollPlanner.plan(spec);
    return new RoadRecord(id,owner,a,b,spec.a(),spec.b(),plan.mesh().settings(),false,4,plan.structures(),0,41,id,List.of(),null,null,spec);
  }
  public com.sora.splineroads.core.TollPlanner.Plan tollPlan(){return toll==null?null:TOLL_PLANS.get(this,r->com.sora.splineroads.core.TollPlanner.plan(r.toll()));}
  private static final com.sora.splineroads.core.WeakIdentityCache<RoadRecord,com.sora.splineroads.core.TollPlanner.Plan> TOLL_PLANS = new com.sora.splineroads.core.WeakIdentityCache<>(24,150_000,p->p.mesh().samples().size()+p.structures().size()+p.paint().size());

  public RoadRecord(UUID id, UUID owner, class_2338 a, class_2338 b, Node start, Node end, Settings settings, boolean automatic, int clearance, List<Part> structures, int endCaps, int buildVersion, UUID assembly, List<Sample> alignment, RoadFurniture.Phase phase) {
    this(id,owner,a,b,start,end,settings,automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,phase,null);
  }
  public RoadRecord junction(UUID group, com.sora.splineroads.core.JunctionPlanner.Ref ref) {
    return new RoadRecord(id,owner,a,b,start,end,settings,automatic,clearance,ref.get().structures(),0,18,group,List.of(),furniturePhase,ref);
  }
  public RoadRecord(UUID id, UUID owner, class_2338 a, class_2338 b, Node start, Node end,
      Settings settings, boolean automatic, int clearance, List<Part> structures,
      int endCaps, int buildVersion, UUID assembly, List<Sample> alignment) {
    this(id, owner, a, b, start, end, settings, automatic, clearance, structures,
        endCaps, buildVersion, assembly, alignment, null);
  }

  public RoadRecord furniturePhase(RoadFurniture.Phase phase) {
    if(Objects.equals(furniturePhase,phase))return this;
    return new RoadRecord(id, owner, a, b, start, end, settings, automatic, clearance,
        structures, endCaps, buildVersion, assembly, alignment, phase, junction,toll,fragment);
  }
  public RoadRecord(
      UUID id,
      UUID owner,
      class_2338 a,
      class_2338 b,
      Node start,
      Node end,
      Settings settings,
      boolean automatic,
      int clearance,
      List<Part> structures,
      int caps,
      int version) {
    this(
        id,
        owner,
        a,
        b,
        start,
        end,
        settings,
        automatic,
        clearance,
        structures,
        caps,
        version,
        null,
        List.of());
  }

  public RoadRecord alignment(UUID group, Mesh mesh) {
    return new RoadRecord(
        id,
        owner,
        a,
        b,
        start,
        end,
        settings,
        automatic,
        clearance,
        structures,
        endCaps,
        buildVersion,
        group,
        mesh.samples(), furniturePhase, junction,toll,fragment);
  }

  public RoadRecord(
      UUID id,
      UUID owner,
      class_2338 a,
      class_2338 b,
      Node start,
      Node end,
      Settings settings,
      boolean automatic,
      int clearance,
      List<Part> structures) {
    this(id, owner, a, b, start, end, settings, automatic, clearance, structures, 0, 17);
  }

  public RoadRecord caps(int mask) {
    return new RoadRecord(
        id,
        owner,
        a,
        b,
        start,
        end,
        settings,
        automatic,
        clearance,
        structures,
        mask,
        junction == null ? 17 : 18,
        assembly,
        alignment, furniturePhase, junction,toll,fragment);
  }

  public RoadRecord(
      UUID id,
      UUID owner,
      class_2338 a,
      class_2338 b,
      Node start,
      Node end,
      Settings settings,
      boolean automatic,
      int clearance) {
    this(id, owner, a, b, start, end, settings, automatic, clearance, List.of());
  }

  private static final int MAX_STRUCTURES=50_000;
  public RoadRecord {
    if(structures.size()>MAX_STRUCTURES)throw new IllegalArgumentException(com.sora.splineroads.core.RoadPartCompaction.budgetMessage(id,structures,MAX_STRUCTURES));
    structures = junction==null?List.copyOf(structures):com.sora.splineroads.core.JunctionSignals.refreshHeads(structures,junction.get().structures());
    if(structures.size()>MAX_STRUCTURES)throw new IllegalArgumentException(com.sora.splineroads.core.RoadPartCompaction.budgetMessage(id,structures,MAX_STRUCTURES));
    alignment = List.copyOf(alignment);
  }

  public RoadRecord structures(List<Part> parts) {
    parts=com.sora.splineroads.core.RoadPartCompaction.compact(parts);
    if(structures.equals(parts))return this;
    return new RoadRecord(
        id,
        owner,
        a,
        b,
        start,
        end,
        settings,
        automatic,
        clearance,
        parts,
        endCaps,
        buildVersion,
        assembly,
        alignment, furniturePhase, junction,toll,fragment);
  }

  public RoadRecord(
      UUID id, UUID owner, class_2338 a, class_2338 b, Node start, Node end, Settings settings) {
    this(id, owner, a, b, start, end, settings, false, 0);
  }

  public class_2487 save() {
    class_2487 t = new class_2487();
    t.method_25927("Id", id);
    t.method_25927("Owner", owner);
    t.method_10544("A", a.method_10063());
    t.method_10544("B", b.method_10063());
    t.method_10566("Start", writeNode(start));
    t.method_10566("End", writeNode(end));
    t.method_10566("Settings", writeSettings(settings));
    t.method_10556("Automatic", automatic);
    t.method_10569("Clearance", clearance);
    t.method_10569("EndCaps", endCaps);
    t.method_10569("BuildVersion", buildVersion);
    t.method_10570("StructuresPacked", packStructures());
    if (furniturePhase != null) {
      t.method_10549("FurnitureOrigin", furniturePhase.origin());
      t.method_10569("FurnitureDirection", furniturePhase.direction());
    }
    if (junction != null) t.method_10566("Junction", JunctionCodec.writeRef(junction));
    if(toll!=null)t.method_10566("Toll",TollCodec.write(toll));
    if(fragment!=null)t.method_10566("Slice",RoadSliceCodec.write(fragment));
    if (assembly != null) t.method_25927("Assembly", assembly);
    if (!alignment.isEmpty()) t.method_10570("Alignment", packAlignment());
    return t;
  }

  /** Editing and host lookup only need the path, never the baked furniture. */
  public class_2487 header() {
    return structures(List.of()).save();
  }

  private byte[] packStructures() {return packStructures(structures);}
  public static byte[] packStructures(List<Part> structures) {
    if(structures.size()>MAX_STRUCTURES)throw new IllegalArgumentException("设施数量 "+structures.size()+" 超过每路上限 "+MAX_STRUCTURES);
    try {
      var bytes = new ByteArrayOutputStream();
      var out = new DataOutputStream(bytes);
      out.writeInt(-32);out.writeInt(structures.size());
      for (Part p : structures) {
        writeVector(out, p.a());
        writeVector(out, p.b());
        out.writeDouble(p.width());
        out.writeDouble(p.height());
        out.writeByte(
            (p.pier() ? 1 : 0) | (p.frameA() != null ? 2 : 0) | (p.frameB() != null ? 4 : 0) | (p.heights()!=null?8:0));
        out.writeByte(p.material().ordinal());
        if (p.frameA() != null) writeVector(out, p.frameA());
        if (p.frameB() != null) writeVector(out, p.frameB());
        out.writeUTF(p.model());
        if(p.heights()!=null)for(int i=0;i<4;i++)out.writeDouble(p.heights().get(i));
      }
      out.flush();
      return bytes.toByteArray();
    } catch (IOException e) {
      throw new IllegalStateException(e);
    }
  }

  private static void writeVector(DataOutput out, V v) throws IOException {
    out.writeDouble(v.x());
    out.writeDouble(v.y());
    out.writeDouble(v.z());
  }

  private static V readVector(DataInput in) throws IOException {
    return new V(in.readDouble(), in.readDouble(), in.readDouble());
  }

  public static List<Part> unpackStructures(byte[] bytes) {
    try {
      var in = new DataInputStream(new ByteArrayInputStream(bytes));
      int count = in.readInt();boolean corners=count==-32,models=corners||count==-31;if(models)count=in.readInt();
      if (count < 0 || count > MAX_STRUCTURES || (long) count * 66 > bytes.length - 4)
        throw new IOException("invalid structure count");
      List<Part> parts = new ArrayList<>(count);
      var materials = com.sora.splineroads.core.RoadStructures.Material.values();
      for (int i = 0; i < count; i++) {
        V a = readVector(in), b = readVector(in);
        double w = in.readDouble(), h = in.readDouble();
        int flags = in.readUnsignedByte(), material = in.readUnsignedByte();
        if (flags > (corners?15:7) || material >= materials.length)
          throw new IOException("invalid structure type");
        parts.add(
            new Part(
                a,
                b,
                w,
                h,
                (flags & 1) != 0,
                materials[material],
                (flags & 2) != 0 ? readVector(in) : null,
                (flags & 4) != 0 ? readVector(in) : null,models?in.readUTF():"",(flags&8)!=0?new com.sora.splineroads.core.RoadStructures.Heights(in.readDouble(),in.readDouble(),in.readDouble(),in.readDouble()):null));
      }
      if (in.available() != 0) throw new IOException("trailing structure data");
      return parts;
    } catch (IOException e) {
      throw new IllegalArgumentException("道路设施数据损坏", e);
    }
  }

  public static RoadRecord load(class_2487 t) {
    List<Part> parts = new ArrayList<>();
    for (class_2520 tag : t.method_10554("Structures", class_2520.field_33260)) {
      class_2487 q = (class_2487) tag;
      parts.add(
          new Part(
              readNode(q.method_10562("A")).position(),
              readNode(q.method_10562("B")).position(),
              q.method_10574("Width"),
              q.method_10574("Height"),
              q.method_10577("Pier"),
              q.method_10545("Material")
                  ? com.sora.splineroads.core.RoadStructures.Material.valueOf(
                      q.method_10558("Material"))
                  : com.sora.splineroads.core.RoadStructures.Material.DEFAULT,
              q.method_10545("FrameA") ? readNode(q.method_10562("FrameA")).position() : null,
              q.method_10545("FrameB") ? readNode(q.method_10562("FrameB")).position() : null));
    }
    if (t.method_10573("StructuresPacked", class_2520.field_33257))
      parts = unpackStructures(t.method_10547("StructuresPacked"));
    return new RoadRecord(
        t.method_25926("Id"),
        t.method_25926("Owner"),
        class_2338.method_10092(t.method_10537("A")),
        class_2338.method_10092(t.method_10537("B")),
        readNode(t.method_10562("Start")),
        readNode(t.method_10562("End")),
        readSettings(t.method_10562("Settings")),
        t.method_10577("Automatic"),
        Math.max(0, Math.min(t.method_10562("Settings").method_10558("Style").equals("RAILBED")?5:4, t.method_10550("Clearance"))),
        parts,
        t.method_10550("EndCaps"),
        t.method_10550("BuildVersion"),
        t.method_25928("Assembly") ? t.method_25926("Assembly") : null,
        t.method_10545("Alignment") ? unpackAlignment(t.method_10547("Alignment")) : List.of(),
        t.method_10545("FurnitureOrigin")
            ? new RoadFurniture.Phase(t.method_10574("FurnitureOrigin"), t.method_10550("FurnitureDirection"))
            : null,
        t.method_10545("Junction") ? JunctionCodec.readRef(t.method_10562("Junction")) : null,
        t.method_10545("Toll")?TollCodec.read(t.method_10562("Toll")):null,t.method_10545("Slice")?RoadSliceCodec.read(t.method_10562("Slice")):null);
  }

  public static class_2487 writeNode(Node n) {
    class_2487 t = new class_2487();
    t.method_10549("X", n.position().x());
    t.method_10549("Y", n.position().y());
    t.method_10549("Z", n.position().z());
    t.method_10549("Yaw", n.yaw());
    t.method_10549("Grade", n.grade());
    return t;
  }

  public static Node readNode(class_2487 t) {
    return new Node(
        new V(t.method_10574("X"), t.method_10574("Y"), t.method_10574("Z")),
        t.method_10574("Yaw"),
        t.method_10574("Grade"));
  }

  public static class_2487 writeSettings(Settings s) {
    class_2487 t = new class_2487();
    t.method_10582("Mode", s.mode().name());
    t.method_10582("Style", s.style().name());
    t.method_10582("Structure", s.structure().name());
    t.method_10569("TaperVersion", s.taperVersion());
    t.method_10582("RampTurn", s.rampTurn().name());
    t.method_10549("Width", s.width());
    t.method_10549("StartWidth", s.startWidth());
    t.method_10549("EndWidth", s.endWidth());
    t.method_10549("Thickness", s.thickness());
    t.method_10549("Tension", s.tension());
    t.method_10549("Angle", s.arcDegrees());
    var o = s.options();
    if(!o.levelCrossings().isEmpty())t.method_10566("RailwayCrossings",RailwayCrossingCodec.write(o.levelCrossings()));
    if(o.railbed().active())t.method_10566("RailbedProfile",RailbedCodec.profile(o.railbed()));
    if(o.lanes().explicit()){var lanes=new class_2487();lanes.method_10569("Forward",o.lanes().forward());lanes.method_10569("Reverse",o.lanes().reverse());t.method_10566("DirectionalLanes",lanes);}
    class_2499 lines=new class_2499();for(var line:o.laneLines()){var tag=new class_2487();tag.method_10582("Key",line.key());tag.method_10582("Pattern",line.pattern().name());tag.method_10549("Width",line.width());lines.add(tag);}t.method_10566("LaneLines",lines);
    t.method_10556("LeftTraffic", o.leftTraffic());
    t.method_10556("CycleLane", o.cycle());t.method_10556("CycleAsphalt",o.cycleAsphalt());
    t.method_10556("CycleRail", o.cycleRail());
    t.method_10556("Curb", o.curb());
    class_2487 walk=new class_2487();walk.method_10556("Enabled",o.sidewalk().enabled());walk.method_10582("Side",o.sidewalk().side().name());walk.method_10569("Width",o.sidewalk().width());walk.method_10582("Material",o.sidewalk().material());walk.method_10556("Smooth",o.sidewalk().smooth());walk.method_10556("Tactile",o.sidewalk().tactile());t.method_10566("Sidewalk",walk);
    var infra=o.infrastructure();class_2487 facilities=new class_2487();
    facilities.method_10582("Bridge",infra.bridge().name());facilities.method_10549("Span",infra.span());facilities.method_10582("Tunnel",infra.tunnel().name());facilities.method_10549("Headroom",infra.headroom());facilities.method_10582("Gantry",infra.gantry().name());facilities.method_10549("Spacing",infra.spacing());facilities.method_10549("TunnelDepth",infra.tunnelDepth());facilities.method_10582("TunnelAdjustment",infra.adjustment().name());facilities.method_10569("DipProfile",infra.efficientDip()?1:0);facilities.method_10549("BridgeRise",infra.bridgeRise());facilities.method_10549("MaxGrade",infra.maxGrade());facilities.method_10556("AutoSpan",infra.autoSpan());facilities.method_10556("SupportsEnabled",infra.supportsEnabled());facilities.method_10556("FixedStations",infra.fixedStations());facilities.method_10582("MedianConversion",infra.medianConversion().name());
    class_2499 edits=new class_2499();for(var edit:infra.gantryEdits()){
      class_2487 e=new class_2487();e.method_10569("Slot",edit.slot());e.method_10549("Offset",edit.offset());e.method_10549("Clearance",edit.clearance());e.method_10582("Kind",edit.kind().name());e.method_10556("Reverse",edit.reverse());e.method_10556("Independent",edit.independent());e.method_10549("Position",edit.position());e.method_10556("Anchored",edit.anchored());e.method_10556("Automatic",edit.automatic());edits.add(e);
    }facilities.method_10566("GantryEdits",edits);t.method_10566("Infrastructure",facilities);
    t.method_10582("OuterRail", o.outerRail().name());
    t.method_10556("HideArrows",o.hideArrows());
    t.method_10566("AttachedRoadPoints",AttachedPointCodec.write(o.attachments()));
    t.method_10566("LanePointsV2",LanePointCodec.write(o.lanePoints()));
    {var decor=new class_2487();var c=o.streetscape();decor.method_10582("Separator",c.separator().name());decor.method_10582("Apron",c.apron().name());var tunnels=new class_2499();for(var span:c.tunnels()){var item=new class_2487();item.method_10549("From",span.from());item.method_10549("To",span.to());tunnels.add(item);}decor.method_10566("Tunnels",tunnels);decor.method_10556("Parking",c.parking());decor.method_10556("Lamps",c.lamps());decor.method_10549("LampSpacing",c.lampSpacing());decor.method_10556("WalkLamps",c.walkLamps());decor.method_10549("WalkLampSpacing",c.walkLampSpacing());decor.method_10582("Planting",c.planting().name());decor.method_10549("PlantingSpacing",c.plantingSpacing());var plants=c.plantings();decor.method_10549("MedianGreenWidth",plants.greenWidth());decor.method_10549("MedianRailGap",plants.railGap());decor.method_10582("MedianTrees",plants.medianTrees().name());decor.method_10549("MedianTreeSpacing",plants.medianSpacing());decor.method_10582("SeparatorTrees",plants.separatorTrees().name());decor.method_10549("SeparatorTreeSpacing",plants.separatorSpacing());var raised=new class_2499();for(var span:c.raisedSpans()){var item=new class_2487();item.method_10549("From",span.from());item.method_10549("To",span.to());raised.add(item);}decor.method_10566("Raised",raised);var crossings=new class_2499();for(var span:c.crossings()){var item=new class_2487();item.method_10569("Side",span.side());item.method_10549("Start",span.start());item.method_10549("From",span.from());item.method_10549("To",span.to());item.method_10549("End",span.end());item.method_10549("Delta",span.delta());crossings.add(item);}decor.method_10566("CycleCrossings",crossings);var sideTag=new class_2487();for(int side:new int[]{-1,1})for(boolean cut:new boolean[]{false,true}){var spans=new class_2499();for(var span:cut?c.sides().cut(side):c.sides().raised(side)){var item=new class_2487();item.method_10549("From",span.from());item.method_10549("To",span.to());spans.add(item);}sideTag.method_10566((side<0?"Negative":"Positive")+(cut?"Cut":"Raised"),spans);}decor.method_10566("SideStructures",sideTag);t.method_10566("Streetscape",decor);}
    t.method_10549("LiftPosition", o.liftPosition());
    t.method_10549("LiftHeight", o.liftHeight());
    t.method_10582("SourceSide", o.ports().source().name());
    t.method_10582("TargetSide", o.ports().target().name());
    t.method_10549("SourceOutset", o.ports().sourceOutset());
    t.method_10549("TargetOutset", o.ports().targetOutset());
    t.method_10582("SourceJoin", o.ports().sourceJoin().name());
    t.method_10582("TargetJoin", o.ports().targetJoin().name());
    var controls=new class_2499();for(var c:o.routing().controls()){var item=new class_2487();item.method_25927("Id",c.id());item.method_10566("Position",writeNode(new Node(c.position(),0,0)));controls.add(item);}t.method_10566("CurveControls",controls);
    t.method_10582("RouteKind", o.routing().kind().name());
    if(o.routing().through())t.method_10556("CurveThrough",true);
    t.method_10549("LoopRadius", o.routing().radius());
    t.method_10549("ControlX", o.routing().offsetX());
    t.method_10549("ControlZ", o.routing().offsetZ());
    t.method_10556("FitEdges", o.routing().fitEdges());
    t.method_10549("Transition", o.routing().transition());
    if(o.routing().fanArms()>0){t.method_10569("FanArms",o.routing().fanArms());t.method_10549("FanStart",o.routing().fanStart());t.method_10549("FanEnd",o.routing().fanEnd());}
    if(o.ends().startHold()!=0||o.ends().endHold()!=0){t.method_10549("StartHold",o.ends().startHold());t.method_10549("EndHold",o.ends().endHold());}
    if(o.ends().paintPhase()!=0)t.method_10549("PaintPhase",o.ends().paintPhase());
    if (o.ends().start() != null) t.method_10566("StartSection", writeSection(o.ends().start()));
    if (o.ends().end() != null) t.method_10566("EndSection", writeSection(o.ends().end()));
    t.method_10556("KeepEndSections", o.ends().persistent());
    if(o.ends().trimmedStart()!=0||o.ends().trimmedEnd()!=0){t.method_10549("TrimmedStart",o.ends().trimmedStart());t.method_10549("TrimmedEnd",o.ends().trimmedEnd());}
    if(o.ends().port()!=null){var p=o.ends().port();var c=new class_2487();c.method_10549("MotorMin",p.motorMin());c.method_10549("MotorMax",p.motorMax());c.method_10549("Median",p.median());c.method_10549("MedianCenter",p.medianCenter());c.method_10549("CurbLeft",p.curbLeft());c.method_10549("CurbRight",p.curbRight());var d=new class_2499();p.dividers().forEach(v->d.add(class_2489.method_23241(v)));c.method_10566("Dividers",d);t.method_10566("JunctionPort",c);}
    return t;
  }

  private static List<RoadProfile.Control> readControls(class_2487 t){var list=t.method_10554("CurveControls",class_2520.field_33260);if(list.size()>32)throw new IllegalArgumentException("曲线控制点超过32个");var out=new ArrayList<RoadProfile.Control>();for(var tag:list){var c=(class_2487)tag;out.add(new RoadProfile.Control(c.method_25926("Id"),readNode(c.method_10562("Position")).position()));}return List.copyOf(out);}
  public static Settings readSettings(class_2487 t) {
    if (!t.method_10545("Mode")) return Settings.defaults();
    Settings s =
        new Settings(
            Mode.valueOf(t.method_10558("Mode")),
            Style.valueOf(t.method_10558("Style")),
            t.method_10574("Width"),
            t.method_10574("Thickness"),
            t.method_10574("Tension"),
            t.method_10574("Angle"),
            t.method_10545("StartWidth") ? t.method_10574("StartWidth") : t.method_10574("Width"),
            t.method_10545("EndWidth") ? t.method_10574("EndWidth") : t.method_10574("Width"),
            t.method_10545("Structure") ? Structure.valueOf(t.method_10558("Structure")) : Structure.AUTO,
            t.method_10545("TaperVersion") ? t.method_10550("TaperVersion") : 1,
            t.method_10545("RampTurn") ? RampTurn.valueOf(t.method_10558("RampTurn")) : RampTurn.LEGACY);
    s =
        s.options(
            new RoadProfile.Options(
                t.method_10577("LeftTraffic"),
                t.method_10577("CycleLane"),
                t.method_10577("CycleRail"),
                t.method_10577("Curb"),
                t.method_10545("LiftPosition") ? t.method_10574("LiftPosition") : .5,
                t.method_10574("LiftHeight"),
                new RoadProfile.Ports(
                    t.method_10545("SourceSide")
                        ? RoadProfile.Side.valueOf(t.method_10558("SourceSide"))
                        : RoadProfile.Side.AUTO,
                    t.method_10545("TargetSide")
                        ? RoadProfile.Side.valueOf(t.method_10558("TargetSide"))
                        : RoadProfile.Side.AUTO,
                    t.method_10574("SourceOutset"),
                    t.method_10574("TargetOutset"),
                    t.method_10545("SourceJoin")
                        ? RoadProfile.JoinMode.valueOf(t.method_10558("SourceJoin"))
                        : RoadProfile.JoinMode.ADDED,
                    t.method_10545("TargetJoin")
                        ? RoadProfile.JoinMode.valueOf(t.method_10558("TargetJoin"))
                        : RoadProfile.JoinMode.ADDED),
                new RoadProfile.Routing(
                    t.method_10545("RouteKind")
                        ? RoadProfile.RouteKind.valueOf(t.method_10558("RouteKind"))
                        : RoadProfile.RouteKind.DIRECT,
                    t.method_10545("LoopRadius") ? t.method_10574("LoopRadius") : 24,
                    t.method_10574("ControlX"),
                    t.method_10574("ControlZ"),
                    t.method_10577("FitEdges"),
                    t.method_10545("Transition") ? t.method_10574("Transition") : 36,
                    t.method_10550("FanArms"),t.method_10574("FanStart"),t.method_10574("FanEnd"),readControls(t),t.method_10577("CurveThrough")),
                t.method_10545("OuterRail")
                    ? RoadProfile.OuterRail.valueOf(t.method_10558("OuterRail"))
                    : RoadProfile.OuterRail.AUTO));
    s =
        s.options(
            s.options()
                .ends(
                    new com.sora.splineroads.core.RoadTransitions.Ends(
                        t.method_10545("StartSection")
                            ? readSection(t.method_10562("StartSection"))
                            : null,
                        t.method_10545("EndSection") ? readSection(t.method_10562("EndSection")) : null,
                        t.method_10577("KeepEndSections"),t.method_10574("TrimmedStart"),t.method_10574("TrimmedEnd"),null)));
    s=s.options(s.options().ends(s.options().ends().hold(t.method_10574("StartHold"),t.method_10574("EndHold"))));
    if(t.method_10545("PaintPhase"))s=s.options(s.options().ends(s.options().ends().paintPhase(t.method_10574("PaintPhase"))));
    if(t.method_10545("JunctionPort")){var p=t.method_10562("JunctionPort");var d=new ArrayList<Double>();for(class_2520 v:p.method_10554("Dividers",class_2520.field_33256))d.add(((class_2489)v).method_10697());s=s.options(s.options().ends(s.options().ends().port(new RoadTransitions.Port(p.method_10574("MotorMin"),p.method_10574("MotorMax"),p.method_10574("Median"),d,p.method_10574("CurbLeft"),p.method_10574("CurbRight"),p.method_10574("MedianCenter")))));}
    if(t.method_10545("Sidewalk")) {
      var walk=t.method_10562("Sidewalk");s=s.options(s.options().sidewalk(new com.sora.splineroads.core.RoadSidewalks.Config(walk.method_10577("Enabled"),com.sora.splineroads.core.RoadSidewalks.Side.valueOf(walk.method_10558("Side")),walk.method_10550("Width"),walk.method_10558("Material"),walk.method_10577("Smooth"),!walk.method_10545("Tactile")||walk.method_10577("Tactile"))));
    }
    if(t.method_10545("Infrastructure")){var i=t.method_10562("Infrastructure");s=s.options(s.options().infrastructure(new com.sora.splineroads.core.RoadInfrastructure.Config(com.sora.splineroads.core.RoadInfrastructure.Bridge.valueOf(i.method_10558("Bridge")),i.method_10574("Span"),com.sora.splineroads.core.RoadInfrastructure.Tunnel.valueOf(i.method_10558("Tunnel")),i.method_10574("Headroom"),com.sora.splineroads.core.RoadInfrastructure.Gantry.valueOf(i.method_10558("Gantry")),i.method_10574("Spacing"),i.method_10574("TunnelDepth"),i.method_10554("GantryEdits",class_2520.field_33260).stream().map(tag->{var e=(class_2487)tag;return new com.sora.splineroads.core.RoadGantry.Edit(e.method_10550("Slot"),e.method_10574("Offset"),e.method_10574("Clearance"),com.sora.splineroads.core.RoadInfrastructure.Gantry.valueOf(e.method_10558("Kind")),e.method_10577("Reverse"),e.method_10577("Independent"),e.method_10574("Position"),e.method_10577("Anchored"),e.method_10577("Automatic"));}).toList(),i.method_10545("TunnelAdjustment")?com.sora.splineroads.core.RoadTunnelFit.Adjustment.valueOf(i.method_10558("TunnelAdjustment")):com.sora.splineroads.core.RoadTunnelFit.Adjustment.OFF,i.method_10550("DipProfile")>=1,i.method_10574("BridgeRise"),i.method_10574("MaxGrade"),i.method_10577("AutoSpan"),i.method_10577("FixedStations"),i.method_10545("MedianConversion")?com.sora.splineroads.core.RoadInfrastructure.MedianConversion.valueOf(i.method_10558("MedianConversion")):com.sora.splineroads.core.RoadInfrastructure.MedianConversion.BOTH,!i.method_10545("SupportsEnabled")||i.method_10577("SupportsEnabled"))));}
    else s=s.options(s.options().infrastructure(s.options().infrastructure().grade(0).autoSpan(false)));
    var lines=new ArrayList<com.sora.splineroads.core.RoadLaneLines.Edit>();for(class_2520 tag:t.method_10554("LaneLines",class_2520.field_33260)){var e=(class_2487)tag;lines.add(new com.sora.splineroads.core.RoadLaneLines.Edit(e.method_10558("Key"),com.sora.splineroads.core.RoadLaneLines.Pattern.valueOf(e.method_10558("Pattern")),e.method_10574("Width")));}s=s.options(s.options().laneLines(lines).hideArrows(t.method_10577("HideArrows")).attachments(AttachedPointCodec.read(t.method_10562("AttachedRoadPoints"))).lanePoints(LanePointCodec.read(t.method_10562("LanePointsV2"))));
    if(t.method_10545("DirectionalLanes")){var lanes=t.method_10562("DirectionalLanes");s=s.options(s.options().lanes(new com.sora.splineroads.core.RoadLanes.Counts(lanes.method_10550("Forward"),lanes.method_10550("Reverse"))));}
    s.validate();
    if(s.options().cycle()&&t.method_10577("CycleAsphalt"))s=s.options(s.options().cycleFinish(RoadProfile.Options.CycleFinish.ASPHALT));
    if(t.method_10545("Streetscape")){var c=t.method_10562("Streetscape");s=s.options(s.options().streetscape(new com.sora.splineroads.core.RoadStreetscape.Config(com.sora.splineroads.core.RoadStreetscape.Separator.valueOf(c.method_10558("Separator")),c.method_10577("Parking"),c.method_10574("LampSpacing"),c.method_10577("WalkLamps"),c.method_10574("WalkLampSpacing"),com.sora.splineroads.core.RoadStreetscape.Planting.valueOf(c.method_10558("Planting")),c.method_10574("PlantingSpacing"))));var spans=new ArrayList<com.sora.splineroads.core.RoadStreetscape.Span>();for(var item:c.method_10554("Raised",class_2520.field_33260)){var r=(class_2487)item;spans.add(new com.sora.splineroads.core.RoadStreetscape.Span(r.method_10574("From"),r.method_10574("To")));}var crossings=new ArrayList<com.sora.splineroads.core.RoadsideBypass.Span>();for(var item:c.method_10554("CycleCrossings",class_2520.field_33260)){var r=(class_2487)item;crossings.add(new com.sora.splineroads.core.RoadsideBypass.Span(r.method_10550("Side"),r.method_10574("Start"),r.method_10574("From"),r.method_10574("To"),r.method_10574("End"),r.method_10574("Delta")));}s=s.options(s.options().streetscape(s.options().streetscape().raisedSpans(spans).crossings(crossings).apron(c.method_10545("Apron")?com.sora.splineroads.core.RoadStreetscape.Apron.valueOf(c.method_10558("Apron")):com.sora.splineroads.core.RoadStreetscape.Apron.ROAD).tunnels(c.method_10554("Tunnels",class_2520.field_33260).stream().map(item->{var span=(class_2487)item;return new com.sora.splineroads.core.RoadStreetscape.Span(span.method_10574("From"),span.method_10574("To"));}).toList())));}
    if(t.method_10562("Streetscape").method_10545("Lamps"))s=s.options(s.options().streetscape(s.options().streetscape().lamps(t.method_10562("Streetscape").method_10577("Lamps"))));
    if(t.method_10562("Streetscape").method_10545("SideStructures")){
      var c=t.method_10562("Streetscape").method_10562("SideStructures");
      java.util.function.Function<String,List<com.sora.splineroads.core.RoadStreetscape.Span>> read=key->c.method_10554(key,class_2520.field_33260).stream().map(item->{var v=(class_2487)item;return new com.sora.splineroads.core.RoadStreetscape.Span(v.method_10574("From"),v.method_10574("To"));}).toList();
      s=s.options(s.options().streetscape(s.options().streetscape().sideStructures(new com.sora.splineroads.core.RoadStreetscape.SideStructures(read.apply("NegativeRaised"),read.apply("PositiveRaised"),read.apply("NegativeCut"),read.apply("PositiveCut")))));
    }
    if(t.method_10545("Streetscape")){var c=t.method_10562("Streetscape");var defaults=com.sora.splineroads.core.RoadPlantings.DEFAULT;
      var plants=new com.sora.splineroads.core.RoadPlantings(c.method_10545("MedianGreenWidth")?c.method_10574("MedianGreenWidth"):defaults.greenWidth(),c.method_10545("MedianRailGap")?c.method_10574("MedianRailGap"):0,
          c.method_10545("MedianTrees")?com.sora.splineroads.core.RoadStreetscape.Planting.valueOf(c.method_10558("MedianTrees")):defaults.medianTrees(),c.method_10545("MedianTreeSpacing")?c.method_10574("MedianTreeSpacing"):16,
          c.method_10545("SeparatorTrees")?com.sora.splineroads.core.RoadStreetscape.Planting.valueOf(c.method_10558("SeparatorTrees")):defaults.separatorTrees(),c.method_10545("SeparatorTreeSpacing")?c.method_10574("SeparatorTreeSpacing"):16);
      s=s.options(s.options().streetscape(s.options().streetscape().plantings(plants)));}

    if(t.method_10545("RailwayCrossings"))s=s.options(s.options().levelCrossings(RailwayCrossingCodec.read(t.method_10554("RailwayCrossings",class_2520.field_33260))));
    if(t.method_10545("RailbedProfile"))s=s.options(s.options().railbed(RailbedCodec.profile(t.method_10562("RailbedProfile"))));
    return s;
  }

  private static class_2487 writeSection(com.sora.splineroads.core.RoadTransitions.Section s) {
    var tag=writeSettings(s.settings(false));if(s.sidewalk()==null)tag.method_10551("Sidewalk");return tag;
  }

  private static com.sora.splineroads.core.RoadTransitions.Section readSection(class_2487 t) {
    // Endpoint descriptions contain a plain cross-section, never nested transition descriptions.
    class_2487 flat = t.method_10553();
    flat.method_10551("StartSection");
    flat.method_10551("EndSection");
    var settings=readSettings(flat);var section=com.sora.splineroads.core.RoadTransitions.Section.of(settings).port(settings.options().ends().port());return t.method_10545("Sidewalk")?section:new com.sora.splineroads.core.RoadTransitions.Section(section.style(),section.width(),section.cycle(),section.cycleRail(),section.curb(),section.outerRail(),null,section.cycleAsphalt(),section.port(),section.streetscape(),section.lanes());
  }

  /** Motor-road profile, including rail crossings, independent of cycle bypasses and lane cuts. */
  public Mesh terrainClassificationMesh(){return com.sora.splineroads.core.RailwayCrossings.shape(derivedStreetscape(settings.options().streetscape().raisedSpans(List.of()).crossings(List.of()).tunnels(List.of())).rawMesh());}
  public RoadRecord withLevelCrossings(List<com.sora.splineroads.core.RailwayCrossings.Surface> value){
    if(settings.options().levelCrossings().equals(value))return this;
    return new RoadRecord(id,owner,a,b,start,end,settings.options(settings.options().levelCrossings(value)),automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,furniturePhase,junction,toll,fragment);
  }
  public RoadRecord derivedStreetscape(com.sora.splineroads.core.RoadStreetscape.Config config){
    if(settings.options().streetscape().equals(config))return this;
    return new RoadRecord(id,owner,a,b,start,end,settings.options(settings.options().streetscape(config)),automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,furniturePhase,junction,toll,fragment);
  }
  public RoadRecord withLanePoints(com.sora.splineroads.core.LanePoints.Data value){
    if(settings.options().lanePoints().equals(value))return this;
    var old=settings.options().lanePoints();var nextFragment=fragment;if(fragment!=null&&(!old.cuts().equals(value.cuts())||!old.additions().equals(value.additions())||!old.bands().equals(value.bands())))nextFragment=fragment.geometry(new com.sora.splineroads.core.RoadSlicing.Geometry(List.of()));
    return new RoadRecord(id,owner,a,b,start,end,settings.options(settings.options().lanePoints(value)),automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,furniturePhase,junction,toll,nextFragment);
  }
  public RoadRecord withAttachments(com.sora.splineroads.core.RoadAttachments.Data value){
    if(settings.options().attachments().equals(value))return this;
    return new RoadRecord(id,owner,a,b,start,end,settings.options(settings.options().attachments(value)),automatic,clearance,structures,endCaps,buildVersion,assembly,alignment,furniturePhase,junction,toll,fragment);
  }
  private static double sectionWidth(RoadTransitions.Section section,double ownWidth){return section==null?ownWidth:section.width();}
  private static boolean authoredWidthChanged(Settings before,Settings after){
    return before.width()!=after.width()||before.style()!=after.style()||!before.options().lanes().equals(after.options().lanes())||before.options().leftTraffic()!=after.options().leftTraffic()
      ||before.options().cycle()!=after.options().cycle()||before.options().curb()!=after.options().curb();
  }
  private static boolean widthChanged(Settings before,Settings after){
    return authoredWidthChanged(before,after)
      // A clipped curved cross-section can project 16 m as 15.9999993 m.
      // Only derived seams get this tolerance; authored width edits above stay exact.
      ||Math.abs(sectionWidth(before.options().ends().start(),before.width())-sectionWidth(after.options().ends().start(),after.width()))>1e-5
      ||Math.abs(sectionWidth(before.options().ends().end(),before.width())-sectionWidth(after.options().ends().end(),after.width()))>1e-5;
  }
  /** Test a donor before raw-section compatibility or automatic-junction routing.
   * Several valid lane removals can differ from the authored count by more than
   * one; their unchanged live port is still the same existing seam. */
  public boolean sameDerivedLaneEnd(Settings proposed,boolean first,Settings candidate){
    if(candidate==null)return false;var before=unchangedLaneMesh(proposed);
    return before!=null&&retainedLaneEnd(before,first,RoadTransitions.Section.of(candidate));
  }
  private Mesh unchangedLaneMesh(Settings proposed){
    if(authoredWidthChanged(settings,proposed)||junction!=null||toll!=null
        ||settings.options().lanePoints().link()!=null)return null;
    var lanes=settings.options().lanePoints();
    return lanes.cuts().stream().anyMatch(c->!c.temporary())||!lanes.additions().isEmpty()?caps(0).mesh():null;
  }
  /** Shared pure join for decoded server and preview requests. Only a donor
   * equal to this road's existing effective port bypasses raw-count comparison;
   * new roads and genuine endpoint/profile changes keep the ordinary checks. */
  public static Settings joinSections(Settings proposed,Settings start,Settings end,
      boolean fixedStart,boolean fixedEnd,RoadRecord previous){
    var before=previous==null?null:previous.unchangedLaneMesh(proposed);
    boolean keepStart=before!=null&&start!=null&&retainedLaneEnd(before,true,RoadTransitions.Section.of(start));
    boolean keepEnd=before!=null&&end!=null&&retainedLaneEnd(before,false,RoadTransitions.Section.of(end));
    var joined=RoadTransitions.join(proposed,keepStart?null:start,keepEnd?null:end);
    if(!proposed.style().ramp()&&RoadProfile.modern(proposed.style())&&(fixedStart||fixedEnd)){
      var ends=joined.options().ends();
      joined=RoadTransitions.ends(joined,fixedStart&&start!=null?RoadTransitions.Section.of(start):ends.start(),
          fixedEnd&&end!=null?RoadTransitions.Section.of(end):ends.end());
    }
    return previous==null?joined:previous.retainAuthoredLaneEnds(joined,keepStart,keepEnd);
  }
  private Settings retainAuthoredLaneEnds(Settings proposed,boolean keepStart,boolean keepEnd){
    if(!keepStart&&!keepEnd)return proposed;
    var old=settings.options().ends();var next=proposed.options().ends();
    return proposed.taper(keepStart?settings.startWidth():proposed.startWidth(),keepEnd?settings.endWidth():proposed.endWidth())
        .options(proposed.options().ends(new RoadTransitions.Ends(
            keepStart?old.start():next.start(),keepEnd?old.end():next.end(),next.persistent(),
            next.trimmedStart(),next.trimmedEnd(),next.port(),next.paintPhase(),next.startHold(),next.endHold())));
  }
  private static boolean retainedLaneEnd(Mesh built,boolean first,RoadTransitions.Section candidate){
    if(candidate==null||!com.sora.splineroads.core.RoadEndpointSections.changed(built,first))return false;
    var actual=com.sora.splineroads.core.RoadEndpointSections.section(built,first,false);
    var proposed=candidate.settings(built.settings().options().leftTraffic());
    if(!com.sora.splineroads.core.RoadLanes.counts(actual).equals(com.sora.splineroads.core.RoadLanes.counts(proposed))
        ||Math.abs(actual.width()-candidate.width())>1e-5)return false;
    var a=RoadProfile.layout(actual,actual.width());var b=candidate.layout(built.settings().options().leftTraffic());
    if(Math.abs(a.motorMin()-b.motorMin())>1e-5||Math.abs(a.motorMax()-b.motorMax())>1e-5
        ||Math.abs(a.median()-b.median())>1e-5||Math.abs(a.medianCenter()-b.medianCenter())>1e-5
        ||Math.abs(a.laneWidth()-b.laneWidth())>1e-5||a.dividers().size()!=b.dividers().size())return false;
    for(int i=0;i<a.dividers().size();i++)if(Math.abs(a.dividers().get(i)-b.dividers().get(i))>1e-5)return false;
    return true;
  }
  private static boolean sameNode(Node a,Node b){return a.position().distance(b.position())<1e-7&&Math.abs(Math.IEEEremainder(a.yaw()-b.yaw(),360))<1e-6&&Math.abs(a.grade()-b.grade())<1e-8;}
  /** Resolve an unchanged slice BEFORE fitting a new curve to its shortened ends.
   * Re-fitting can fail curvature checks even though the saved subpath is valid.
   * The same route/profile checks as retainAlignment decide whether reuse is legal;
   * width changes still validate the resulting sampled ribbon. */
  /** Interpret legacy split handles only for an explicit editor operation; never rewrite the world on load. */
  public RoadRecord localCurveForEditing(){
    if(fragment==null||!fragment.curveAnchors().isEmpty()||settings.mode()!=Mode.CURVE&&settings.options().routing().controls().isEmpty()||alignment.isEmpty())return this;
    return RoadSplitGeometry.range(this,0,mesh().length(),id,a,b,start,end,fragment.connection());
  }
  private Settings localizedRequest(Settings request,RoadRecord localized){
    return request.options().routing().equals(settings.options().routing())
        ?request.options(request.options().route(localized.settings().options().routing())):request;
  }
  public RoadPlanner.Plan retainedPlan(Settings request,RoadPlanner.Hint a,RoadPlanner.Hint b,Node authoredStart,Node authoredEnd){
    var localized=localCurveForEditing();if(localized!=this)return localized.retainedPlan(localizedRequest(request,localized),a,b,authoredStart,authoredEnd);
    if(fragment==null||alignment.isEmpty()||!sameNode(start,authoredStart)||!sameNode(end,authoredEnd))return null;
    boolean auto=automatic&&request.mode()==Mode.AUTO;
    var wanted=auto?RoadPlanner.mode(request,settings.mode(),request.arcDegrees()):request;
    var probe=new RoadRecord(id,owner,this.a,this.b,a.node(),b.node(),wanted,automatic,clearance);
    if(!sameSavedEndpoints(probe))return null;
    var candidate=new RoadRecord(id,owner,this.a,this.b,start,end,wanted,automatic,clearance);
    var kept=retainAlignment(candidate);
    if(kept.fragment()==null)return null;
    var mesh=kept.rawMesh();
    // Connection hints refer to the median axis, while stored samples are physical
    // pavement centres. Restore the axis only for the shared endpoint preflight.
    var samples=mesh.samples().stream().map(p->{var layout=RoadProfile.layout(mesh,p);return new Sample(p.at(layout.catalog().twoWay()?layout.medianCenter():0,0),p.left(),p.distance(),p.halfWidth());}).toList();
    var axis=new Mesh(samples,mesh.settings(),mesh.min(),mesh.max(),mesh.length(),mesh.closed());
    return new RoadPlanner.Plan(start,end,kept.settings(),axis,"保留已保存的道路曲线");
  }
  /** Furniture/width edits do not discard a saved sampled ordinary-road path.
   * A real endpoint, route, curve or vertical-profile edit still replans it. */
  /** AUTO stores its resolved curve mode. Re-solving a shorter split fragment can
   * pick another mode or heading even when the user only changed furniture/width.
   * Compare authored endpoint intent first; actual path/profile edits still use
   * the normal replan checks below. */
  public RoadRecord retainAlignment(RoadRecord proposal,Settings requested,Node authoredStart,Node authoredEnd){
    if(fragment!=null&&automatic&&requested.mode()==Mode.AUTO
        &&sameNode(start,authoredStart)&&sameNode(end,authoredEnd)
        &&requested.arcDegrees()==settings.arcDegrees()&&sameSavedEndpoints(proposal)){
      var ps=proposal.settings();
      var normalized=new Settings(settings.mode(),ps.style(),ps.width(),ps.thickness(),requested.tension(),settings.arcDegrees(),ps.startWidth(),ps.endWidth(),ps.structure(),ps.taperVersion(),ps.rampTurn(),ps.options());
      var candidate=new RoadRecord(proposal.id(),proposal.owner(),proposal.a(),proposal.b(),start,end,normalized,
          proposal.automatic(),proposal.clearance(),proposal.structures(),proposal.endCaps(),proposal.buildVersion(),proposal.assembly(),proposal.alignment(),proposal.furniturePhase(),proposal.junction(),proposal.toll(),proposal.fragment());
      var retained=retainAlignment(candidate);
      if(retained.fragment()!=null)return retained;
    }
    return retainAlignment(proposal);
  }
  /** A split marker and its effective lane port use different interpolation frames.
   * A live continuation may therefore return the original physical median instead
   * of the marker. Accept only one of those two saved positions; an authored node
   * move or a changed neighbour port still takes the normal replan path. */
  private boolean sameSavedEndpoints(RoadRecord proposal){
    boolean a=start.position().distance(proposal.start().position())<1e-7;
    boolean b=end.position().distance(proposal.end().position())<1e-7;
    if(a&&b)return true;
    var saved=caps(0).mesh();
    return (a||com.sora.splineroads.core.RoadMedianAnchor.position(saved,true).distance(proposal.start().position())<1e-7)
        &&(b||com.sora.splineroads.core.RoadMedianAnchor.position(saved,false).distance(proposal.end().position())<1e-7);
  }
  public RoadRecord retainAlignment(RoadRecord proposal){
    var localized=localCurveForEditing();if(localized!=this)return localized.retainAlignment(proposal.settings(localizedRequest(proposal.settings(),localized)));
    var s=proposal.settings();var a=settings.options();var b=s.options();
    if(alignment.isEmpty()||!sameNode(start,proposal.start())||!sameNode(end,proposal.end())
        ||settings.mode()!=s.mode()||settings.tension()!=s.tension()||settings.arcDegrees()!=s.arcDegrees()
        ||settings.rampTurn()!=s.rampTurn()||settings.structure()!=s.structure()
        ||!a.routing().equals(b.routing())&&!com.sora.splineroads.core.RoadSlicing.localCurve(fragment,a.routing(),b.routing())||!a.ports().equals(b.ports())
        ||a.liftPosition()!=b.liftPosition()||a.liftHeight()!=b.liftHeight()
        ||a.infrastructure().tunnelDepth()!=b.infrastructure().tunnelDepth()
        ||a.infrastructure().bridgeRise()!=b.infrastructure().bridgeRise()
        ||a.infrastructure().efficientDip()!=b.infrastructure().efficientDip()
        ||a.infrastructure().maxGrade()!=b.infrastructure().maxGrade()
        ||a.infrastructure().adjustment()!=b.infrastructure().adjustment())return proposal;
    if(fragment!=null){
      // A neighbour slice advertises its EFFECTIVE port, including stable added
      // lanes. Reusing that as this slice's raw end applies the expansion twice
      // and discards its source-relative trim. Furniture edits retain both the
      // authored taper widths and saved ends; actual width/profile edits below
      // still use the requested seam and the ordinary continuation checks.
      if(!authoredWidthChanged(settings,s))s=s.taper(settings.startWidth(),settings.endWidth()).options(s.options().ends(settings.options().ends()));
      else{var ends=s.options().ends();var old=settings.options().ends();s=s.options(s.options().ends(new RoadTransitions.Ends(ends.start(),ends.end(),ends.persistent()).port(ends.port()).paintPhase(old.paintPhase()+old.trimmedStart())));}
    }
    var adjusted=settings(s);
    return new RoadRecord(proposal.id(),proposal.owner(),proposal.a(),proposal.b(),start,end,s,
        proposal.automatic(),proposal.clearance(),List.of(),proposal.endCaps(),proposal.buildVersion(),proposal.assembly(),adjusted.alignment(),furniturePhase,proposal.junction(),proposal.toll(),adjusted.fragment());
  }
  public RoadRecord settings(Settings value) {
    var slots=com.sora.splineroads.core.LaneAdditions.reserveAuthored(value.options().lanePoints(),com.sora.splineroads.core.RoadProfile.catalog(value).lanes());
    if(slots!=value.options().lanePoints())return settings(value.options(value.options().lanePoints(slots)));
    if(settings.equals(value))return this;
    List<Sample> adjusted = alignment;var retainedFragment=fragment;
    if(fragment!=null&&!settings.options().routing().controls().equals(value.options().routing().controls()))retainedFragment=fragment.geometry(new com.sora.splineroads.core.RoadSlicing.Geometry(List.of()));
    if (!alignment.isEmpty() && widthChanged(settings,value)) {
      if(fragment!=null)retainedFragment=fragment.geometry(new com.sora.splineroads.core.RoadSlicing.Geometry(List.of()));
      double length = alignment.get(alignment.size() - 1).distance();
      var before=fragment==null?null:com.sora.splineroads.core.RoadSlicing.mesh(alignment,settings);
      adjusted =
          alignment.stream()
              .map(
                  p ->
                      new Sample(
                          p.center().add(p.left().mul(fragment==null?0:medianShift(before,p,value,length))),
                          p.left(),
                          p.distance(),
                          RoadTransitions.width(value,p.distance()+value.options().ends().trimmedStart(),length+value.options().ends().trimmedStart()+value.options().ends().trimmedEnd()) / 2))
              .toList();
    }
    return new RoadRecord(
        id,
        owner,
        a,
        b,
        start,
        end,
        value,
        automatic,
        clearance,
        List.of(),
        endCaps,
        buildVersion,
        assembly,
        adjusted, furniturePhase, junction,toll,retainedFragment);
  }

  private double medianShift(Mesh before,Sample point,Settings next,double length){
    double width=RoadTransitions.width(next,point.distance()+next.options().ends().trimmedStart(),length+next.options().ends().trimmedStart()+next.options().ends().trimmedEnd());
    var mesh=new Mesh(before.samples(),next,before.min(),before.max(),length,false);var after=new Sample(point.center(),point.left(),point.distance(),width/2);
    return RoadProfile.layout(before,point).medianCenter()-RoadProfile.layout(mesh,after).medianCenter();
  }
  private byte[] packAlignment() {
    try {
      var bytes = new ByteArrayOutputStream();
      var out = new DataOutputStream(bytes);
      out.writeInt(fragment==null?alignment.size():-alignment.size());
      for (var p : alignment) {
        writeVector(out, p.center());
        out.writeDouble(p.left().x());
        out.writeDouble(p.left().z());
        out.writeDouble(p.halfWidth());if(fragment!=null)out.writeDouble(p.distance());
      }
      return bytes.toByteArray();
    } catch (IOException e) {
      throw new IllegalArgumentException("道路路径编码失败", e);
    }
  }

  private static List<Sample> unpackAlignment(byte[] bytes) {
    try {
      var in = new DataInputStream(new ByteArrayInputStream(bytes));
      int count = in.readInt();boolean stations=count<0;int n=Math.abs(count);
      if (n < 2
          || n > com.sora.splineroads.core.RoadLimits.MAX_SAMPLES
          || bytes.length != 4 + n * (stations?56:48)) throw new IOException("invalid alignment");
      List<Sample> samples = new ArrayList<>();
      double distance = 0;
      V previous = null;
      for (int i = 0; i < n; i++) {
        V p = readVector(in), left = new V(in.readDouble(), 0, in.readDouble());
        double half = in.readDouble();
        if (!RoadGeometry.finite(p.x(), p.y(), p.z(), left.x(), left.z(), half)
            || half < .25
            || half > 32
            || Math.abs(left.horizontalLength() - 1) > .001)
          throw new IOException("invalid path point");
        if(stations){double next=in.readDouble();if(!Double.isFinite(next)||next<0||previous!=null&&next<=distance)throw new IOException("invalid path station");distance=next;}
        else if (previous != null) distance += p.distance(previous);
        samples.add(new Sample(p, left, distance, half));
        previous = p;
      }
      return List.copyOf(samples);
    } catch (IOException e) {
      throw new IllegalArgumentException("道路路径数据损坏", e);
    }
  }

  // Immutable snapshots are the cache key, not UUIDs: preview/edit geometry cannot go stale.
  private static final com.sora.splineroads.core.WeakIdentityCache<RoadRecord,Mesh> RAW_MESHES =
      new com.sora.splineroads.core.WeakIdentityCache<>(2048,750_000,m->m.samples().size());
  private static final com.sora.splineroads.core.WeakIdentityCache<RoadRecord,Mesh> SHAPED_MESHES =
      new com.sora.splineroads.core.WeakIdentityCache<>(2048,750_000,m->m.samples().size());
  public static void clearMeshCaches(){com.sora.splineroads.core.RoadRaster.clearSavedRasters();com.sora.splineroads.core.RoadTunnelSpace.clearPreparedCache();RAW_MESHES.clear();SHAPED_MESHES.clear();TOLL_PLANS.clear();}
  public static String meshCacheStats(){return "raw="+RAW_MESHES.stats()+", shaped="+SHAPED_MESHES.stats();}
  public boolean legacyRailway(){return railway()&&!settings.options().railbed().active();}
  public boolean railway(){return settings.style()==Style.RAILBED;}
  public RoadGeometry.Mesh mesh() {if(railway())return rawMesh();return SHAPED_MESHES.get(this,r->{var mesh=com.sora.splineroads.core.RoadsideBypass.sampled(com.sora.splineroads.core.LaneSections.apply(r.rawMesh()));return com.sora.splineroads.core.RailwayCrossings.shape(r.fragment==null||!r.fragment.applied().points().equals(r.settings.options().attachments().points())||!r.fragment.curveAnchors().isEmpty()&&!r.fragment.curveAnchors().equals(r.settings.options().routing().controls())?mesh:com.sora.splineroads.core.RoadSlicing.attach(mesh,r.fragment.geometry()));});}
  public RoadGeometry.Mesh rawMesh() {return RAW_MESHES.get(this,RoadRecord::buildRawMesh);}
  private RoadGeometry.Mesh buildRawMesh() {
    if(toll!=null)return tollPlan().mesh();
    if (junction != null) {
      var mesh=junction.get().mesh();
      if(junction.spec().oneSide()!=null)return mesh;
      if(junction.geometryVersion()>=47&&junction.get().arm()>=0){var section=mesh.settings().options(mesh.settings().options().streetscape(settings.options().streetscape()));
        // A refuge cuts a polygon out of one side of an approach. Its stored
        // sections remain ordered along the original road, not a new driving
        // centerline through the asymmetric cut's section midpoints.
        if(junction.geometryVersion()>=49&&com.sora.splineroads.core.JunctionSlips.enabled(junction.spec()))return new Mesh(mesh.samples(),section,mesh.min(),mesh.max(),mesh.length(),mesh.closed());
        return com.sora.splineroads.core.RoadRibbon.mesh(mesh.samples(),section);
      }
      return mesh;
    }
    if (!alignment.isEmpty()) {
      var mesh = fragment==null?com.sora.splineroads.core.RoadRibbon.mesh(alignment, settings):com.sora.splineroads.core.RoadSlicing.mesh(alignment,settings);
      if(railway())return mesh;
      if (mesh.first().center().distance(mesh.last().center()) < 1e-6)
        return new Mesh(
            mesh.samples(),
            mesh.settings(),
            mesh.min(),
            mesh.max(),
            mesh.length(),
            true,
            mesh.controlPoint());
      return fragment==null?com.sora.splineroads.core.RoadAttachments.deform(mesh,settings):com.sora.splineroads.core.RoadSlicing.deform(mesh,settings,fragment);
    }
    return RoadGeometry.endCaps(
        (assembly==null?com.sora.splineroads.core.RoadMedianAnchor.apply(RoadGeometry.build(start,end,settings)):RoadGeometry.build(start,end,settings)), endCaps, start.grade(), end.grade());
  }
}
