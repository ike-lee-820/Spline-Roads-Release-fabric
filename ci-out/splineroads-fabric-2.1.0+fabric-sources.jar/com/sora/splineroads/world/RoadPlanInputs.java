package com.sora.splineroads.world;

import com.sora.splineroads.core.RoadPlanningBudget;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_3218;

/** Server-thread read set for cached structure/sidewalk planning. World-write checks are
 * independently rerun at commit. Neighbors cover terrain collision-shape dependencies. */
final class RoadPlanInputs implements AutoCloseable {
  private static final ThreadLocal<RoadPlanInputs> CURRENT=new ThreadLocal<>();
  private RoadPlanInputs previous;
  private final class_3218 level;
  private final boolean recording;
  private final Map<Long,class_2680> states=new Long2ObjectOpenHashMap<>();
  private it.unimi.dsi.fastutil.longs.LongOpenHashSet probes=new it.unimi.dsi.fastutil.longs.LongOpenHashSet();
  private final Map<Long,class_2487> nodes=new HashMap<>();
  private final Map<Long,Integer> heights=new HashMap<>();
  private RoadPlanInputs(class_3218 level,boolean recording){
    this.level=level;this.recording=recording;previous=CURRENT.get();CURRENT.set(this);
  }
  static RoadPlanInputs open(class_3218 level,boolean recording){return new RoadPlanInputs(level,recording);}
  /** Continue an incremental server-thread plan without retaining a thread scope
   * between ticks. The accumulated read set remains exact across all steps. */
  RoadPlanInputs resume(){previous=CURRENT.get();CURRENT.set(this);probes=new it.unimi.dsi.fastutil.longs.LongOpenHashSet();return this;}
  static class_2680 state(class_3218 level,class_2338 pos){
    var state=level.method_8320(pos);var scope=CURRENT.get();
    if(scope!=null&&scope.recording&&scope.level==level&&scope.probes.add(pos.method_10063())){
      // Save the actual states, not hashes: different terrain cannot alias a valid plan.
      for(int dx=-1;dx<=1;dx++)for(int dy=-1;dy<=1;dy++)for(int dz=-1;dz<=1;dz++){
        var p=pos.method_10069(dx,dy,dz);
        // putIfAbsent still evaluated getBlockState for every overlapping
        // neighbor. Read each cell once per synchronous planning scope.
        if(!level.method_31606(p)&&!scope.states.containsKey(p.method_10063()))
          {if(scope.states.size()>=4_000_000)throw new IllegalArgumentException("预览地形读取量过大，请分段施工");scope.states.put(p.method_10063(),p.equals(pos)?state:level.method_8320(p));}
      }
    }
    return state;
  }
  static class_2586 node(class_3218 level,class_2338 pos){
    var entity=level.method_8321(pos);var scope=CURRENT.get();
    if(scope!=null&&scope.recording&&scope.level==level&&!scope.nodes.containsKey(pos.method_10063()))
      scope.nodes.put(pos.method_10063(),entity==null?null:entity.method_38242());
    return entity;
  }
  static int height(class_3218 level,int x,int z){
    int height=level.method_8624(net.minecraft.class_2902.class_2903.field_13202,x,z);
    var scope=CURRENT.get();if(scope!=null&&scope.recording&&scope.level==level)scope.heights.putIfAbsent(class_2338.method_10064(x,0,z),height);
    return height;
  }
  void validate(class_3218 current){
    if(current!=level)throw new IllegalArgumentException("预览世界已改变，请重新预览");
    var chunks=new HashSet<Long>();for(var keys:List.of(states.keySet(),heights.keySet(),nodes.keySet()))for(long key:keys)chunks.add(new net.minecraft.class_1923(class_2338.method_10092(key)).method_8324());
    try(var lease=RoadWorkChunks.open(level)){
      lease.load(chunks);
      for(var entry:heights.entrySet()){
        RoadPlanningBudget.check();var p=class_2338.method_10092(entry.getKey());
        if(level.method_8624(net.minecraft.class_2902.class_2903.field_13202,p.method_10263(),p.method_10260())!=entry.getValue())
          throw new IllegalArgumentException("预览后地形高度已改变，请重新预览");
      }
      for(var entry:states.entrySet()){
        RoadPlanningBudget.check();
        var pos=class_2338.method_10092(entry.getKey());var now=level.method_8320(pos);var before=entry.getValue();
        if(!equivalentTerrain(before,now))
          throw new IllegalArgumentException("预览后地形已改变："+pos.method_23854()+"，"+before+" → "+now+"；请重新预览");
      }
      for(var entry:nodes.entrySet()){
        var entity=level.method_8321(class_2338.method_10092(entry.getKey()));
        if(!Objects.equals(entry.getValue(),entity==null?null:entity.method_38242()))
          throw new IllegalArgumentException("预览后端点已改变，请重新预览");
      }
    }
  }
  /** Vanilla grass decay/spread changes no supporting shape, fluid, or clearance.
   * Construction still rereads actual blocks when forming protected writes, so the
   * current terrain is preserved. Every other material/state change stays strict. */
  static boolean equivalentTerrain(class_2680 before,class_2680 now){
    if(before.equals(now)||(soil(before)&&soil(now)))return true;
    // Vanilla leaf-distance propagation does not alter shape, fluid or material.
    // Keep persistence/waterlogging and every other property strict.
    var distance=net.minecraft.class_2741.field_12541;
    return before.method_26204()==now.method_26204()&&before.method_26204() instanceof net.minecraft.class_2397
        &&before.method_28498(distance)&&now.method_28498(distance)
        &&before.method_11657(distance,now.method_11654(distance)).equals(now);
  }
  private static boolean soil(class_2680 state){return state.method_27852(class_2246.field_10219)||state.method_27852(class_2246.field_10566);}
  int retainedStates(){return states.size();}
  @Override public void close(){if(previous==null)CURRENT.remove();else CURRENT.set(previous);previous=null;probes=null;}
}
