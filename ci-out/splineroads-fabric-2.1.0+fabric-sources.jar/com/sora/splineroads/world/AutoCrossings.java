package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Splits only intersections involving the road currently being created or edited. */
public final class AutoCrossings {
  public record Hit(UUID road,double proposed,double other,V center) {}
  record Cut(double station,V center) {}
  record Split(List<RoadRecord> roads,List<RoadData.NodeMove> nodes,Map<UUID,List<RoadRecord>> pieces) {}
  static boolean eligible(RoadRecord r){return AutoJunctions.ordinary(r)&&!r.mesh().closed()&&!RoadTunnelFit.enabled(r.settings());}
  private static V median(Mesh m,Sample s){return s.at(RoadProfile.layout(m,s).medianCenter(),0);}
  private static double cross(V a,V b){return a.x()*b.z()-a.z()*b.x();}
  private record Segment(V start,V delta,double length,RoadBoundsIndex.Bounds bounds){}
  private static List<Segment> segments(Mesh mesh){
    var points=mesh.samples().stream().map(s->median(mesh,s)).toList();var result=new ArrayList<Segment>();
    for(int i=1;i<points.size();i++){var p=points.get(i-1);var q=points.get(i);var delta=q.sub(p);double length=delta.horizontalLength();
      // The exact test accepts parameters 1e-7 beyond either endpoint.
      double margin=length*1e-7+1e-7;
      result.add(new Segment(p,delta,length,new RoadBoundsIndex.Bounds(Math.min(p.x(),q.x())-margin,Math.min(p.z(),q.z())-margin,Math.max(p.x(),q.x())+margin,Math.max(p.z(),q.z())+margin)));
    }return result;
  }
  public static List<Hit> hits(RoadRecord proposed,Collection<RoadRecord> roads){
    if(!eligible(proposed))return List.of();var result=new ArrayList<Hit>();var a=proposed.mesh();
    var as=segments(a);
    for(var road:roads){if(road.id().equals(proposed.id())||!eligible(road))continue;var b=road.mesh();if(!RoadIndex.overlapXZ(a,b,0))continue;
      var bs=segments(b);var index=new RoadBoundsIndex(bs.stream().map(Segment::bounds).toList(),16);
      for(int i=1;i<a.samples().size();i++){RoadPlanningBudget.check();var a0=a.samples().get(i-1);var a1=a.samples().get(i);var sa=as.get(i-1);V p=sa.start(),u=sa.delta();
        for(int slot:index.query(sa.bounds(),0)){int j=slot+1;var b0=b.samples().get(j-1);var b1=b.samples().get(j);var sb=bs.get(slot);V q=sb.start(),v=sb.delta();double det=cross(u,v);
          if(Math.abs(det)<1e-8*sa.length()*sb.length())continue;
          double t=cross(q.sub(p),v)/det,s=cross(q.sub(p),u)/det;if(t< -1e-7||t>1+1e-7||s< -1e-7||s>1+1e-7)continue;
          t=Math.max(0,Math.min(1,t));s=Math.max(0,Math.min(1,s));V x=p.add(u.mul(t)),y=q.add(v.mul(s));if(Math.abs(x.y()-y.y())>.02)continue;
          double ad=a0.distance()+(a1.distance()-a0.distance())*t,bd=b0.distance()+(b1.distance()-b0.distance())*s;
          // Shared endpoints already belong to the normal junction path.
          if((ad<.01||ad>a.length()-.01)&&(bd<.01||bd>b.length()-.01))continue;
          V center=x.add(y).mul(.5);
          // Free ends include a short pavement cap beyond their node. A shared
          // node is already handled by AutoJunctions, even when that cap crosses.
          if(sharedEnd(proposed,road,center))continue;
          if(result.stream().noneMatch(h->h.road().equals(road.id())&&h.center().distance(center)<.1))result.add(new Hit(road.id(),ad,bd,center));
        }
      }
    }return List.copyOf(result);
  }
  private static boolean sharedEnd(RoadRecord a,RoadRecord b,V p){for(boolean first:new boolean[]{true,false}){var pos=first?a.a():a.b();if((pos.equals(b.a())||pos.equals(b.b()))&&p.distance((first?a.start():a.end()).position())<2)return true;}return false;}
  static List<RoadRecord> candidates(class_2487 t){var out=new ArrayList<RoadRecord>();for(class_2520 entry:t.method_10554("CrossingCandidates",class_2520.field_33260))out.add(RoadRecord.load(((class_2487)entry).method_10562("Road")));return out;}
  static void enrich(class_2487 command,RoadData data,class_2338 a,class_2338 b,UUID id){enrich(command,data,a,b,id,true);}
  static void enrich(class_2487 command,RoadData data,class_2338 a,class_2338 b,UUID id,boolean structures){
    var list=new class_2499();double reach=RoadLimits.MAX_ENDPOINT_DISTANCE;
    var available=new LinkedHashMap<>(AutoJunctions.logical(data));data.index.roads.values().stream().map(built->built.record).filter(RoadRecord::railway).forEach(r->available.put(r.id(),r));
    for(var r:available.values()){if(r.id().equals(id)||!eligible(r)&&!r.railway())continue;var m=r.mesh();
      if(m.max().x()<Math.min(a.method_10263(),b.method_10263())-reach||m.min().x()>Math.max(a.method_10263(),b.method_10263())+reach||m.max().z()<Math.min(a.method_10260(),b.method_10260())-reach||m.min().z()>Math.max(a.method_10260(),b.method_10260())+reach)continue;
      var entry=new class_2487();entry.method_10566("Road",r.header());entry.method_10566("Graph",r.railway()?new class_2487():AutoJunctions.context(data,Set.of(r.a(),r.b()),structures));list.add(entry);
    }command.method_10566("CrossingCandidates",list);
  }
  static class_2487 graph(class_2487 command,List<Hit> hits){
    var result=command.method_10562("JunctionGraph").method_10553();
    for(class_2520 entry:command.method_10554("CrossingCandidates",class_2520.field_33260)){var t=(class_2487)entry;if(hits.stream().anyMatch(h->h.road().equals(t.method_10562("Road").method_25926("Id"))))merge(result,t.method_10562("Graph"));}
    var active=new LinkedHashSet<Long>();for(long p:result.method_10565("ActiveNodes"))active.add(p);for(var h:hits)active.add(at(h.center()).method_10063());result.method_10564("ActiveNodes",active.stream().mapToLong(Long::longValue).toArray());return result;
  }
  private static void merge(class_2487 into,class_2487 from){
    for(String key:List.of("Streets","Centers","RemoteTrims")){var entries=new LinkedHashMap<UUID,class_2487>();for(class_2520 v:into.method_10554(key,class_2520.field_33260)){var t=(class_2487)v;entries.put(t.method_25926("Id"),t);}for(class_2520 v:from.method_10554(key,class_2520.field_33260)){var t=(class_2487)v;entries.put(t.method_25926("Id"),t.method_10553());}var list=new class_2499();entries.values().forEach(list::add);into.method_10566(key,list);}
    var continuations=into.method_10554("SlipNext",class_2520.field_33260);
    for(class_2520 edge:from.method_10554("SlipNext",class_2520.field_33260))if(!continuations.contains(edge))continuations.add(edge.method_10707());
    into.method_10566("SlipNext",continuations);
    var active=new LinkedHashSet<Long>();for(long p:into.method_10565("ActiveNodes"))active.add(p);for(long p:from.method_10565("ActiveNodes"))active.add(p);into.method_10564("ActiveNodes",active.stream().mapToLong(Long::longValue).toArray());
    // A previously remote end is now being rebuilt, so its old trim must not survive.
    for(class_2520 v:into.method_10554("RemoteTrims",class_2520.field_33260)){var trim=(class_2487)v;for(class_2520 q:into.method_10554("Streets",class_2520.field_33260)){var r=(class_2487)q;if(!r.method_25926("Id").equals(trim.method_25926("Id")))continue;if(active.contains(r.method_10537("A")))trim.method_10551("Start");if(active.contains(r.method_10537("B")))trim.method_10551("End");}}
  }
  static Split split(List<RoadRecord> roads,RoadRecord proposal,List<Hit> hits,List<class_2487> centers){
    if(hits.isEmpty())return new Split(roads,List.of(),Map.of());var cuts=new LinkedHashMap<UUID,List<Cut>>();var nodes=new LinkedHashMap<class_2338,RoadData.NodeMove>();
    for(var hit:hits){cuts.computeIfAbsent(proposal.id(),k->new ArrayList<>()).add(new Cut(hit.proposed(),hit.center()));cuts.computeIfAbsent(hit.road(),k->new ArrayList<>()).add(new Cut(hit.other(),hit.center()));
      class_2338 pos=at(hit.center());Node node=new Node(hit.center(),0,0);var tag=new class_2487();tag.method_25927("Owner",proposal.owner());tag.method_10566("Node",RoadRecord.writeNode(node));tag.method_10556("HeightExplicit",true);nodes.put(pos,new RoadData.NodeMove(null,pos,node,tag));
      if(centers.stream().noneMatch(t->t.method_10537("CenterPos")==pos.method_10063()))centers.add(AutoJunctions.config(pos,proposal.owner()));
    }
    var output=new ArrayList<RoadRecord>();var pieces=new LinkedHashMap<UUID,List<RoadRecord>>();
    for(var road:roads){var points=cuts.get(road.id());if(points==null){output.add(road);continue;}var unique=new TreeMap<Double,V>();for(var c:points)if(c.station()>.01&&c.station()<road.mesh().length()-.01&&unique.keySet().stream().noneMatch(d->Math.abs(d-c.station())<.1))unique.put(c.station(),c.center());
      if(unique.isEmpty()){output.add(road);continue;}var segments=new ArrayList<RoadRecord>();double from=0;class_2338 a=road.a();Node start=road.start();
      unique.put(road.mesh().length(),road.end().position());int part=0;
      for(var entry:unique.entrySet()){double to=entry.getKey();boolean last=to==road.mesh().length();V p=entry.getValue();Node end=last?road.end():new Node(p,RoadSplitGeometry.node(road.mesh(),to).yaw(),0);class_2338 b=last?road.b():at(p);UUID id=part++==0?road.id():UUID.nameUUIDFromBytes((road.id()+":cross:"+a.method_10063()).getBytes(StandardCharsets.UTF_8));
        var piece=RoadSplitGeometry.junctionRange(road,from,to,id,a,b,start,end,RoadSlicing.Connection.JUNCTION);segments.add(piece);from=to;a=b;start=end;
      }output.addAll(segments);pieces.put(road.id(),List.copyOf(segments));
      // Existing far-junction lane/phase references move with the far segment.
      for(var c:centers)if(c.method_10537("CenterPos")==road.b().method_10063()){var arms=c.method_10554("ArmRoads",class_2520.field_33258);for(int i=0;i<arms.size();i++)if(arms.method_10608(i).equals(road.id().toString()))arms.method_10606(i,class_2519.method_23256(segments.get(segments.size()-1).id().toString()));}
    }return new Split(List.copyOf(output),List.copyOf(nodes.values()),Map.copyOf(pieces));
  }
  static RoadRecord remap(RoadRecord road,Map<UUID,List<RoadRecord>> pieces){var next=road;for(var entry:pieces.entrySet())for(var piece:entry.getValue())if(!piece.id().equals(entry.getKey())){var points=new HashSet<UUID>();for(var p:piece.settings().options().lanePoints().points())points.add(p.id());next=RoadSplitter.remapLinks(next,entry.getKey(),piece.id(),points);}return next;}
  private static class_2338 at(V p){return class_2338.method_49637(p.x(),p.y(),p.z());}
  private AutoCrossings(){}
}
