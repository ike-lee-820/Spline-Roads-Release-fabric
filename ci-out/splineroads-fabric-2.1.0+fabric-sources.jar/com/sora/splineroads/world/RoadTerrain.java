package com.sora.splineroads.world;
import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
/** Per-transaction original terrain, shared by route policy and structural sections. */
final class RoadTerrain {
 /** One transaction's restored-terrain column index, shared by every replanned road. */
 static final class Cache extends HashMap<class_2338,List<class_238>> {
  final Map<Mesh,List<RoadAutoTunnels.RoofRegion>> cycleRoofs=new IdentityHashMap<>();
  final it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap originalTop=new it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap();
  Cache(Map<Long,class_2680> retained,Map<Long,class_2680> originals){
   originalTop.defaultReturnValue(Integer.MIN_VALUE);
   for(var map:List.of(retained,originals))for(var entry:map.entrySet())if(!TunnelAir.isAirSpace(entry.getValue())){
    RoadPlanningBudget.check();
    var p=class_2338.method_10092(entry.getKey());long column=class_2338.method_10064(p.method_10263(),0,p.method_10260());
    originalTop.put(column,Math.max(originalTop.get(column),p.method_10264()));
   }
  }
 }
 static RoadStructures.Ground read(class_3218 level,Map<Long,class_2680> retained,Map<Long,class_2680> originals,Map<class_2338,List<class_238>> terrainCache){
  var index=RoadData.get(level).index;
  var cover=new RoadTerrainCover(chunk->index.inChunk(chunk).stream().map(index.roads::get).filter(Objects::nonNull).toList());
  return new RoadStructures.Ground(){
    public double top(double x, double z, double deckY) {
      return Math.min(solidTop(x,z,deckY),deckY);
    }
    public double surface(double x,double z,double roadY){
      double surface=cover.surface(x,z,roadY,probe->solidTop(x,z,probe));
      // A marker, an old excavated portal or a shallow natural cavity can break
      // the connected column at deck level. Actual soil at roof height still
      // establishes underground cover; road colliders never count as that soil.
      double probe=roadY+RoadAutoTunnels.MIN_COVER+.05;
      double overhead=solidTop(x,z,probe);
      // A one-block suspended roof is a structure, not a buried soil column.
      // Require solid material below the probe as well as at roof height.
      if(Double.isFinite(overhead)&&overhead>probe+1e-7){
        double below=probe-1.05,under=solidTop(x,z,below);
        if(Double.isFinite(under)&&under>below+1e-7){
          double top=RoadTerrainSurface.connected(probe,p->solidTop(x,z,p));
          if(Double.isFinite(top))surface=Double.isFinite(surface)?Math.max(surface,top):top;
        }
      }
      return surface;
    }
    private double solidTop(double x,double z,double deckY){
      class_2338 key = class_2338.method_49637(x, Math.min(level.method_31600()-1,deckY), z);
      if(!RoadWorkChunks.terrainAvailable(level,key))return Double.NaN;
      var surfaces=terrainCache.computeIfAbsent(key,k->{
        var out=new ArrayList<class_238>();
        int bottom=Math.max(level.method_31607(),key.method_10264()-(int)RoadStructures.MAX_DROP);
        int first=key.method_10264();
        if(terrainCache instanceof Cache indexed){
          // WORLD_SURFACE bounds real non-air blocks. Restored terrain can be
          // above it (a buried road cleared the old surface), so include both.
          int top=RoadPlanInputs.height(level,key.method_10263(),key.method_10260())-1;
          top=Math.max(top,indexed.originalTop.get(class_2338.method_10064(key.method_10263(),0,key.method_10260())));
          first=Math.min(first,top);
        }
        for(int y=first;y>=bottom;y--){
          RoadPlanningBudget.check();
          class_2338 p=new class_2338(key.method_10263(),y,key.method_10260());
          if(!level.method_22340(p))break;
          class_2680 state=RoadPlanInputs.state(level,p);
          state=RoadFoundation.source(p.method_10063(),state,
              RoadBlocks.isCollider(state)||state.method_27852(SplineRoads.TUNNEL_AIR.get()),
              TunnelAir.isAirSpace(state),originals,retained,
              net.minecraft.class_2246.field_10124.method_9564());
          if(state.method_26164(net.minecraft.class_3481.field_15503)
              ||state.method_26164(net.minecraft.class_3481.field_15475)
              ||state.method_27852(SplineRoads.NODE.get())||!state.method_26227().method_15769())continue;
          var shape=state.method_26220(level,p);
          for(var box:shape.method_1090())out.add(box.method_996(p));
          // A full cube hides every lower surface in this column.
          if(y<key.method_10264()&&net.minecraft.class_2248.method_9614(shape))break;
        }
        out.sort(Comparator.comparingDouble((class_238 box)->box.field_1325).reversed());
        return out;
      });
      for (var box : surfaces)
        if (x >= box.field_1323 - 1e-7
            && x <= box.field_1320 + 1e-7
            && z >= box.field_1321 - 1e-7
            && z <= box.field_1324 + 1e-7
            // A block beginning at the probe plane is overhead, not a foundation.
            && box.field_1322 < deckY - 1e-7) return box.field_1325;
      return Double.NaN;
    }

    public boolean joined(V p){return false;}
    public boolean blocked(RoadStructures.Part p){return false;}
  };
 }
 private RoadTerrain(){}
}
