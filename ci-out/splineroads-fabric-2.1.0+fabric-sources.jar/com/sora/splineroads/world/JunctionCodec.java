package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.JunctionSpec.*;
import com.sora.splineroads.core.OneSidedJunction.Cut;
import com.sora.splineroads.core.OneSidedJunction.Source;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

public final class JunctionCodec {
  /** Immutable road receipts are preview context, never client-supplied edit authority. */
  public static class_2487 editCommand(class_2487 payload){
    var command=payload.method_10553();command.method_10551("FreshSpec");
    if(command.method_10577("OneSided")){command.method_10551("OriginalMain");command.method_10551("OriginalMainB");command.method_10551("BranchNode");command.method_10562("Spec").method_10551("OneSide");command.method_10562("PairSpec").method_10551("OneSide");}
    return command;
  }
  public static class_2487 write(JunctionSpec s) {
    class_2487 t=new class_2487();t.method_10569("Version",1);t.method_10566("Center",RoadRecord.writeNode(new Node(s.center(),0,0)));
    t.method_10582("Kind",s.kind().name());t.method_10556("LeftTraffic",s.leftTraffic());
    t.method_10549("Corner",s.cornerRadius());t.method_10549("Island",s.islandRadius());
    t.method_10569("RingLanes",s.ringLanes());t.method_10549("RingWidth",s.ringLaneWidth());t.method_10549("Thickness",s.thickness());
    t.method_10582("Control",s.control().name());t.method_10569("Green",s.greenSeconds());t.method_10569("Yellow",s.yellowSeconds());
    t.method_10569("AllRed",s.allRedSeconds());t.method_10569("Offset",s.timeOffset());t.method_10556("Guides",s.guides());t.method_10556("GreenIsland",s.greenIsland());t.method_10556("OuterRail",s.outerRail());t.method_10556("ParallelApproaches",s.parallelApproaches());
    class_2499 arms=new class_2499();
    for(Arm a:s.arms()) {
      class_2487 p=new class_2487();p.method_10566("Node",RoadRecord.writeNode(a.endpoint()));
      p.method_10549("DX",a.inward().x());p.method_10549("DZ",a.inward().z());p.method_10566("External",RoadRecord.writeSettings(a.external()));
      p.method_10556("Attached",a.attached());p.method_10569("In",a.incoming());p.method_10569("Out",a.outgoing());p.method_10549("Width",a.width());p.method_10549("Median",a.median());p.method_10582("MedianKind",a.medianKind().name());
      p.method_10549("Cycle",a.cycleWidth());p.method_10549("Curb",a.curbWidth());p.method_10556("RightSlip",a.rightSlip());p.method_10556("AdvanceSign",a.advanceSign());p.method_10556("NameSign",a.nameSign());p.method_10556("Crosswalk",a.crosswalk());p.method_10549("CrossWidth",a.crossingWidth());p.method_10549("Setback",a.crossingSetback());p.method_10549("StopGap",a.stopGap());p.method_10569("Phase",a.phase());
      class_2499 lanes=new class_2499();for(Lane l:a.lanes()){class_2487 q=new class_2487();q.method_10569("Mask",l.mask());q.method_10556("SplitLeft",l.splitLeft());q.method_10556("ControlRight",l.controlRight());q.method_10569("LeftPhase",l.leftPhase());q.method_10572("Targets",l.targets());q.method_10572("TargetLanes",l.targetLanes());lanes.add(q);}p.method_10566("Lanes",lanes);arms.add(p);
    }
    t.method_10566("Arms",arms);
    if(s.oneSide()!=null){var source=s.oneSide();var mesh=source.road();var p=new class_2487();
      var record=new RoadRecord(new UUID(0,0),new UUID(0,0),net.minecraft.class_2338.field_10980,net.minecraft.class_2338.field_10980,new Node(mesh.first().center(),0,0),new Node(mesh.last().center(),0,0),mesh.settings()).alignment(null,mesh).structures(source.structures());
      record=record.fragment(new RoadSlicing.Fragment(new UUID(0,0),0,mesh.length(),RoadSlicing.Connection.CONTINUOUS,mesh.settings().options().attachments(),mesh.slicing()==null?new RoadSlicing.Geometry(List.of()):mesh.slicing()));
      p.method_10566("Road",record.save());p.method_10549("From",source.from());p.method_10549("To",source.to());p.method_10569("Side",source.side());t.method_10566("OneSide",p);t.method_10556("MainAdvancePolicy",true);
    }return t;
  }
  public static JunctionSpec read(class_2487 t) {
    if(t.method_10550("Version")!=1)throw new IllegalArgumentException("不支持的路口数据版本");
    var entries=t.method_10554("Arms",class_2520.field_33260);if(t.method_10558("Kind").equals("ROUNDABOUT")?entries.size()>8:entries.size()<2||entries.size()>6)throw new IllegalArgumentException("普通路口支持 2–6 向，环岛支持 0–8 个接入口");
    List<Arm> arms=new ArrayList<>();
    for(class_2520 entry:entries) {
      class_2487 a=(class_2487)entry;var lanes=new ArrayList<Lane>();
      if(a.method_10554("Lanes",class_2520.field_33260).size()>RoadLanes.MAX_DIRECTION)throw new IllegalArgumentException("入口车道过多");
      for(class_2520 item:a.method_10554("Lanes",class_2520.field_33260)){class_2487 l=(class_2487)item;lanes.add(new Lane(l.method_10550("Mask"),Arrays.stream(l.method_10561("Targets")).boxed().toList(),Arrays.stream(l.method_10561("TargetLanes")).boxed().toList(),l.method_10577("SplitLeft"),l.method_10545("LeftPhase")?l.method_10550("LeftPhase"):-1,l.method_10577("ControlRight")));}
      arms.add(new Arm(RoadRecord.readNode(a.method_10562("Node")),new V(a.method_10574("DX"),0,a.method_10574("DZ")),RoadRecord.readSettings(a.method_10562("External")),a.method_10550("In"),a.method_10550("Out"),a.method_10574("Width"),a.method_10574("Median"),RoadProfile.Median.valueOf(a.method_10558("MedianKind")),a.method_10574("Cycle"),a.method_10574("Curb"),a.method_10577("Crosswalk"),a.method_10574("CrossWidth"),a.method_10574("Setback"),a.method_10574("StopGap"),a.method_10550("Phase"),lanes,a.method_10577("Attached"),!a.method_10545("AdvanceSign")||a.method_10577("AdvanceSign"),!a.method_10545("NameSign")||a.method_10577("NameSign"),a.method_10577("RightSlip")));
    }
    var source=readSide(t);
    if(source!=null&&arms.size()==3){
      for(int i=0;i<3;i++){
        var arm=arms.get(i);
        boolean enabled=i==source.incoming()&&arms.get(2).outgoing()>0&&(!t.method_10577("MainAdvancePolicy")||arm.advanceSign());
        arms.set(i,arm.signs(enabled,arm.nameSign()));
      }
    }
    return new JunctionSpec(RoadRecord.readNode(t.method_10562("Center")).position(),Kind.valueOf(t.method_10558("Kind")),t.method_10577("LeftTraffic"),t.method_10574("Corner"),t.method_10574("Island"),t.method_10550("RingLanes"),t.method_10574("RingWidth"),t.method_10574("Thickness"),Control.valueOf(t.method_10558("Control")),t.method_10550("Green"),t.method_10550("Yellow"),t.method_10550("AllRed"),t.method_10550("Offset"),t.method_10577("Guides"),t.method_10577("GreenIsland"),t.method_10577("OuterRail"),arms,t.method_10577("ParallelApproaches")).oneSide(source);
  }
  private static OneSidedJunction.Source readSide(class_2487 t){
    if(!t.method_10545("OneSide"))return null;var p=t.method_10562("OneSide");var saved=p.method_10562("Road");
    if(saved.method_10545("Junction")||saved.method_10545("Toll"))throw new IllegalArgumentException("单边路口主路快照无效");
    var r=RoadRecord.load(saved);
    if(r.junction()!=null||r.toll()!=null)throw new IllegalArgumentException("单边路口主路快照无效");
    return new OneSidedJunction.Source(r.mesh(),r.structures(),p.method_10574("From"),p.method_10574("To"),p.method_10550("Side"));
  }
  public static class_2487 writeRef(JunctionPlanner.Ref ref){var t=write(ref.spec());t.method_10569("Piece",ref.piece());t.method_10569("GeometryVersion",ref.geometryVersion());
    if(!ref.hostCuts().isEmpty()){var cuts=new class_2499();for(var cut:ref.hostCuts()){var c=new class_2487();c.method_10549("From",cut.from());c.method_10549("To",cut.to());c.method_10569("Side",cut.side());cuts.add(c);}t.method_10566("HostCuts",cuts);}return t;}
  public static JunctionPlanner.Ref readRef(class_2487 t){var cuts=new ArrayList<OneSidedJunction.Cut>();for(var value:t.method_10554("HostCuts",class_2520.field_33260)){var c=(class_2487)value;cuts.add(new OneSidedJunction.Cut(c.method_10574("From"),c.method_10574("To"),c.method_10550("Side")));}return new JunctionPlanner.Ref(read(t),t.method_10550("Piece"),t.method_10545("GeometryVersion")?t.method_10550("GeometryVersion"):21,cuts);}
  private JunctionCodec() {}
}
