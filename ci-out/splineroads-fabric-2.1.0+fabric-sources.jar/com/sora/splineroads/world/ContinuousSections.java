package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Options;
import com.sora.splineroads.world.ContinuousRoads.Source;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.core.InterchangePlanner.*;
import com.sora.splineroads.core.LanePoints.Data;
import com.sora.splineroads.core.LanePoints.Link;
import com.sora.splineroads.core.LanePoints.Ref;
import java.nio.charset.StandardCharsets;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Split exact occupied intervals and preserve both ordinary outside continuations. */
final class ContinuousSections {
  static UUID sourceId(String name){
    String value=name.startsWith(ContinuousRoads.MAIN)?name.substring(ContinuousRoads.MAIN.length()):name.startsWith(ContinuousRoads.DONOR)?name.substring(ContinuousRoads.DONOR.length()):null;
    return value==null?null:UUID.fromString(value.split("@")[0]);
  }
  static UUID id(String name){
    UUID source=sourceId(name);
    return name.contains("@")&&ContinuousRoads.donor(name)?UUID.nameUUIDFromBytes(("sr:continuous:"+name).getBytes(StandardCharsets.UTF_8)):source;
  }
  static RoadRecord source(class_2487 tag,String name){
    RoadRecord source=ContinuousRoads.source(tag,sourceId(name));
    if(!name.contains("@"))return source;
    RoadRecord old=source.caps(0);
    String[] range=name.substring(name.indexOf('@')+1).split(",");double from=Double.parseDouble(range[0]),to=Double.parseDouble(range[1]);
    var a=RoadSplitGeometry.node(old.mesh(),from);var b=RoadSplitGeometry.node(old.mesh(),to);
    return RoadSplitGeometry.range(old,from,to,id(name),from==0?old.a():InterchangeJunctions.pos(a.position()),to==old.mesh().length()?old.b():InterchangeJunctions.pos(b.position()),a,b,RoadSlicing.Connection.CONTINUOUS).caps((from==0?source.endCaps()&1:0)|(to==old.mesh().length()?source.endCaps()&2:0));
  }
  static void append(List<Leg> out,Leg leg,RoadRecord original,Mesh generated,double first,double last,boolean moved){
    // End-cap overlap is render padding, not authored path stationing.
    original=original.caps(0);
    double length=moved?generated.length():original.mesh().length();first=Math.max(0,Math.min(length,first));last=Math.max(first,Math.min(length,last));
    // A moved endpoint already carries its adjacent donor; avoid splitting a sub-block remnant.
    if(moved||first<2&&length-last<2){out.add(new Leg(ContinuousRoads.MAIN+original.id(),leg.from(),leg.to(),generated));return;}
    if(first<2)first=0;if(length-last<2)last=length;
    if(first>1e-6)out.add(new Leg(ContinuousRoads.DONOR+original.id()+"@0.0,"+first,leg.from(),leg.to(),RoadSlicing.slice(original.mesh(),0,first,original.settings()).mesh()));
    if(last<length-1e-6)out.add(new Leg(ContinuousRoads.DONOR+original.id()+"@"+last+","+length,leg.from(),leg.to(),RoadSlicing.slice(original.mesh(),last,length,original.settings()).mesh()));
    String name=ContinuousRoads.MAIN+original.id()+"@"+first+","+last;
    Node a=RoadSplitGeometry.node(original.mesh(),first),b=RoadSplitGeometry.node(original.mesh(),last);
    RoadRecord slice=RoadSplitGeometry.range(original,first,last,id(name),first==0?original.a():InterchangeJunctions.pos(a.position()),last==length?original.b():InterchangeJunctions.pos(b.position()),a,b,RoadSlicing.Connection.CONTINUOUS);
    var o=generated.settings().options();var saved=slice.settings().options();
    Settings settings=generated.settings().options(o.attachments(saved.attachments()).lanePoints(saved.lanePoints()).ends(saved.ends()).infrastructure(saved.infrastructure().gantry(o.infrastructure().gantry())));
    out.add(new Leg(name,leg.from(),leg.to(),RoadSlicing.slice(generated,first,last,settings).mesh()));
  }
  static boolean detached(class_2487 tag,UUID id){
    return tag.method_10554("ContinuousSources",class_2520.field_33260).stream().map(t->(class_2487)t)
        .anyMatch(t->t.method_10577("Detached")&&t.method_10562("Road").method_25926("Id").equals(id));
  }
  static void updateSources(class_2487 tag,Plan plan){
    var list=new class_2499();
    for(var source:ContinuousRoads.sources(tag)){
      var previous=tag.method_10554("ContinuousSources",class_2520.field_33260).stream().map(t->(class_2487)t).filter(t->t.method_10562("Road").method_25926("Id").equals(source.road().id())).findFirst().orElseThrow();
      var allLegs=plan.legs().stream().filter(l->source.road().id().equals(sourceId(l.name()))).toList();
      var legs=allLegs.stream().filter(l->l.name().contains("@")).toList();
      if(legs.isEmpty()){
        var retained=previous.method_10553();
        // Captured neighbours outside this plan remain ordinary roads. Their
        // recorded state is a boundary, not permission to refresh later edits.
        if(allLegs.isEmpty()&&!retained.method_10577("Detached")&&!retained.method_10577(ContinuousService.LOGICAL)){
          retained.method_10556("Detached",true);retained.method_10556("DetachedExact",true);
        }
        if(!allLegs.isEmpty()){retained.method_10556("Detached",allLegs.stream().allMatch(l->ContinuousRoads.donor(l.name())));retained.method_10551(ContinuousService.LOGICAL);}
        if(!retained.method_10577("Detached"))retained.method_10551("DetachedExact");
        list.add(retained);continue;
      }
      for(var leg:legs){var item=new class_2487();item.method_10569("Axis",source.axis());item.method_10566("Road",source(tag,leg.name()).header());item.method_10556("Detached",ContinuousRoads.donor(leg.name()));list.add(item);}
    }
    tag.method_10566("ContinuousSources",list);
  }
  static Map<UUID,Map<Integer,UUID>> signOwners(Plan plan,List<RoadIndex.Built> records){
    var out=new HashMap<UUID,Map<Integer,UUID>>();
    for(var leg:plan.legs())if(leg.name().contains("@")){
      var owners=out.computeIfAbsent(sourceId(leg.name()),k->new HashMap<>());var road=records.stream().filter(r->r.record.id().equals(id(leg.name()))).findFirst().orElseThrow();
      for(int slot:RoadGantry.slots(road.mesh))owners.put(slot,road.record.id());
    }return out;
  }
  static RoadRecord remap(RoadRecord road,Map<UUID,UUID> owners){
    var data=road.settings().options().lanePoints();var link=data.link();if(link==null)return road;
    var a=link.from();var b=link.to();var na=owners.get(a.point());var nb=owners.get(b.point());
    if(na!=null&&!na.equals(a.road()))a=LanePoints.Ref.lane(na,a.point());if(nb!=null&&!nb.equals(b.road()))b=LanePoints.Ref.lane(nb,b.point());
    return a==link.from()&&b==link.to()?road:road.withLanePoints(data.link(new LanePoints.Link(a,b,link.options(),link.junctionMouth(),link.targetOffset(),link.protectedMerge(),link.rectangularClosure())));
  }
  private ContinuousSections(){}
}
