package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.ElevatedAccess.Gap;
import com.sora.splineroads.core.ElevatedAccess.Reservation;
import com.sora.splineroads.core.LaneAdditions.Addition;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.LanePoints.*;
import com.sora.splineroads.core.LaneSections.Cut;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import java.util.*;
public final class LanePointCodec {
  public static class_2487 position(V value){return RoadRecord.writeNode(new Node(value,0,0));}
  public static V position(class_2487 tag){return RoadRecord.readNode(tag).position();}
  public static class_2487 ref(Ref r){var t=new class_2487();if(r.junction()!=null)t.method_25927("Junction",r.junction());else {t.method_25927("Road",r.road());t.method_25927("Point",r.point());}return t;}
  public static Ref ref(class_2487 t){return t.method_25928("Junction")?Ref.junction(t.method_25926("Junction")):Ref.lane(t.method_25926("Road"),t.method_25926("Point"));}
  public static class_2487 options(Options o){var t=new class_2487();t.method_10582("Path",o.path().name());t.method_10556("SourceExtra",o.sourceExtra());t.method_10556("TargetExtra",o.targetExtra());t.method_10549("Radius",o.radius());t.method_10549("Transition",o.transition());t.method_10582("Departure",o.departure().name());t.method_10582("Arrival",o.arrival().name());t.method_10582("Elevation",o.elevation().name());t.method_10582("Landing",o.landing().name());t.method_10556("GradeOverride",o.gradeOverride());t.method_10556("AllowTunnel",o.allowTunnel());if(o.lanes()!=1)t.method_10569("Lanes",o.lanes());return t;}
  public static Options options(class_2487 t){
    if(t.method_33133())return Options.DEFAULT;
    return new Options(Path.valueOf(t.method_10558("Path")),
      t.method_10545("Departure")?Departure.valueOf(t.method_10558("Departure")):t.method_10577("SourceExtra")?Departure.EXTRA:Departure.BRANCH,
      t.method_10545("Arrival")?Arrival.valueOf(t.method_10558("Arrival")):t.method_10577("TargetExtra")?Arrival.EXTRA:Arrival.MERGE,
      t.method_10574("Radius"),t.method_10574("Transition"),
      t.method_10545("Elevation")?Elevation.valueOf(t.method_10558("Elevation")):Elevation.AUTO,
      t.method_10545("Landing")?Landing.valueOf(t.method_10558("Landing")):Landing.FLEXIBLE,
      t.method_10577("GradeOverride"),t.method_10577("AllowTunnel"),t.method_10545("Lanes")?t.method_10550("Lanes"):1);
  }
  public static class_2487 link(Link link){var t=new class_2487();t.method_10566("From",ref(link.from()));t.method_10566("To",ref(link.to()));t.method_10566("Options",options(link.options()));t.method_10549("TargetOffset",link.targetOffset());t.method_10556("ProtectedMerge",link.protectedMerge());t.method_10556("RectangularClosure",link.rectangularClosure());if(link.junctionMouth()!=null)t.method_10566("JunctionMouth",position(link.junctionMouth()));return t;}
  public static Link link(class_2487 t){return new Link(ref(t.method_10562("From")),ref(t.method_10562("To")),options(t.method_10562("Options")),t.method_10545("JunctionMouth")?position(t.method_10562("JunctionMouth")):null,t.method_10574("TargetOffset"),t.method_10577("ProtectedMerge"),t.method_10577("RectangularClosure"));}
  public static class_2487 write(Data data){
    var t=new class_2487();var points=new class_2499();for(var p:data.points()){var q=new class_2487();q.method_25927("Id",p.id());q.method_10582("Origin",p.origin().name());q.method_10569("Lane",p.lane());q.method_10549("MergeLength",p.mergeLength());q.method_10566("Position",position(p.position()));if(p.anchor()!=null)q.method_10566("Anchor",position(p.anchor()));points.add(q);}t.method_10566("Points",points);
    t.method_10569("PriorityDepth",data.priorityDepth());if(data.link()!=null)t.method_10566("Link",link(data.link()));var openings=new class_2499();for(var o:data.openings()){var q=new class_2487();q.method_25927("Connection",o.connection());q.method_10549("HalfWidth",o.halfWidth());var path=new class_2499();for(V v:o.centerline())path.add(position(v));q.method_10566("Path",path);openings.add(q);}t.method_10566("Openings",openings);
    var cuts=new class_2499();for(var c:data.cuts()){var q=new class_2487();q.method_25927("Connection",c.connection());q.method_10569("Lane",c.lane());q.method_10569("Sign",c.sign());q.method_10549("Begin",c.begin());q.method_10549("End",c.end());q.method_10549("Transition",c.transition());q.method_10556("Temporary",c.temporary());q.method_10556("ArrivalClosure",c.arrival());q.method_10556("Rectangular",c.rectangular());q.method_10556("Underpass",c.underpass());if(c.replacement()!=null)q.method_25927("Replacement",c.replacement());cuts.add(q);}t.method_10566("LaneCuts",cuts);
    var additions=new class_2499();for(var a:data.additions()){var q=new class_2487();q.method_25927("Connection",a.connection());q.method_10569("Slot",a.slot());q.method_10569("Sign",a.sign());q.method_10549("Station",a.station());q.method_10549("Transition",a.transition());if(Double.isFinite(a.end()))q.method_10549("End",a.end());additions.add(q);}t.method_10566("OuterLaneAdditions",additions);var bands=new class_2499();for(var b:data.bands()){var q=new class_2487();q.method_10549("Station",b.station());q.method_10549("Low",b.low());q.method_10549("High",b.high());bands.add(q);}if(!bands.isEmpty())t.method_10566("MotorBands",bands);
    var access=new class_2499();for(var r:data.access()){
      var q=new class_2487();q.method_25927("Connection",r.connection());q.method_25927("Point",r.point());q.method_10566("Lanes",write(Data.EMPTY.cuts(r.cuts()).additions(r.additions())));
      var gaps=new class_2499();for(var g:r.gaps()){var v=new class_2487();v.method_10549("From",g.from());v.method_10549("To",g.to());v.method_10549("Low",g.low());v.method_10549("High",g.high());gaps.add(v);}q.method_10566("Gaps",gaps);access.add(q);
    }if(!access.isEmpty())t.method_10566("ElevatedAccess",access);return t;
  }
  public static Data read(class_2487 t){
    var points=new ArrayList<Point>();for(class_2520 value:t.method_10554("Points",class_2520.field_33260)){var p=(class_2487)value;points.add(new Point(p.method_25926("Id"),Origin.valueOf(p.method_10558("Origin")),p.method_10550("Lane"),position(p.method_10562("Position")),p.method_10573("Anchor",class_2520.field_33260)?position(p.method_10562("Anchor")):null,p.method_10574("MergeLength")));}
    var openings=new ArrayList<Opening>();for(class_2520 value:t.method_10554("Openings",class_2520.field_33260)){var o=(class_2487)value;var path=new ArrayList<V>();for(class_2520 p:o.method_10554("Path",class_2520.field_33260))path.add(position((class_2487)p));openings.add(new Opening(o.method_25926("Connection"),path,o.method_10574("HalfWidth")));}
    var cuts=new ArrayList<LaneSections.Cut>();for(class_2520 v:t.method_10554("LaneCuts",class_2520.field_33260)){var q=(class_2487)v;cuts.add(new LaneSections.Cut(q.method_25926("Connection"),q.method_10550("Lane"),q.method_10550("Sign"),q.method_10574("Begin"),q.method_10574("End"),q.method_10574("Transition"),q.method_25928("Replacement")?q.method_25926("Replacement"):null,q.method_10577("Temporary"),q.method_10577("ArrivalClosure"),q.method_10577("Rectangular"),q.method_10577("Underpass")));}
    var additions=new ArrayList<LaneAdditions.Addition>();for(class_2520 v:t.method_10554("OuterLaneAdditions",class_2520.field_33260)){var q=(class_2487)v;additions.add(new LaneAdditions.Addition(q.method_25926("Connection"),q.method_10550("Slot"),q.method_10550("Sign"),q.method_10574("Station"),q.method_10574("Transition"),q.method_10545("End")?q.method_10574("End"):Double.NaN));}
    var bands=new ArrayList<Band>();for(class_2520 v:t.method_10554("MotorBands",class_2520.field_33260)){var q=(class_2487)v;bands.add(new Band(q.method_10574("Station"),q.method_10574("Low"),q.method_10574("High")));}
    var access=new ArrayList<ElevatedAccess.Reservation>();for(class_2520 value:t.method_10554("ElevatedAccess",class_2520.field_33260)){
      var q=(class_2487)value;var laneTag=q.method_10562("Lanes").method_10553();laneTag.method_10551("ElevatedAccess");var laneData=read(laneTag);var gaps=new ArrayList<ElevatedAccess.Gap>();
      for(class_2520 item:q.method_10554("Gaps",class_2520.field_33260)){var v=(class_2487)item;gaps.add(new ElevatedAccess.Gap(v.method_10574("From"),v.method_10574("To"),v.method_10574("Low"),v.method_10574("High")));}
      access.add(new ElevatedAccess.Reservation(q.method_25926("Connection"),q.method_25926("Point"),laneData.cuts(),laneData.additions(),gaps));
    }
    return new Data(points,t.method_10545("Link")?link(t.method_10562("Link")):null,openings,t.method_10545("PriorityDepth")?t.method_10550("PriorityDepth"):t.method_10545("Link")?1:0,cuts,additions,bands,access);
  }
  private LanePointCodec(){}
}
