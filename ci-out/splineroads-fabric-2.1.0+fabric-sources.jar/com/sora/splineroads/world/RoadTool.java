package com.sora.splineroads.world;

import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadPlanner;
import com.sora.splineroads.core.RoadProfile.Options;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.AttachedPointTool.Pick;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

public final class RoadTool extends class_1792 {
  public static Consumer<class_2487> openClient = t -> {};

  public static boolean showsNodes(class_1799 stack) {
    return stack.method_7909() instanceof JunctionPointTool || stack.method_7909() instanceof LanePointTool || stack.method_7909() instanceof LaneRampTool || stack.method_7909() instanceof ElevatedPointTool || stack.method_7909() instanceof AttachedPointTool
        || stack.method_7909() instanceof LaneLineTool
        || stack.method_7909() instanceof RoadTool
        || stack.method_7909() instanceof RoadSplitTool
        || stack.method_7909() instanceof JunctionTool
        || stack.method_7909() instanceof YJunctionTool
        || stack.method_7909() instanceof RoundaboutTool
        || stack.method_7909() instanceof TollTool
        || stack.method_7909() instanceof InterchangeTool
        || stack.method_7909() instanceof RoadRemover
        || stack.method_31574(com.sora.splineroads.SplineRoads.NODE_ITEM.get());
  }


  /** Old planted medians may cover the marker; keep their endpoints editable before rebuilding. */
  public static class_2338 endpointAtHit(class_1838 context) {
    return endpointAtHit(context.method_8045(), context.method_8037(), context.method_17698());
  }

  public static class_2338 endpointAtHit(
      class_1937 level, class_2338 clicked, net.minecraft.class_243 hit) {
    if (!RoadBlocks.isCollider(level.method_8320(clicked)))
      return clicked;
    class_2338 best = clicked;
    double nearest = .9;
    for (int dx = -1; dx <= 1; dx++)
      for (int dz = -1; dz <= 1; dz++)
        for (int dy = -2; dy <= 0; dy++) {
          class_2338 p = clicked.method_10069(dx, dy, dz);
          if (level.method_8321(p) instanceof NodeEntity node) {
            V v = node.node().position();
            double distance = Math.hypot(v.x() - hit.field_1352, v.z() - hit.field_1350);
            if (distance < nearest && hit.field_1351 - v.y() >= -.15 && hit.field_1351 - v.y() <= 2) {
              nearest = distance;
              best = p;
            }
          }
        }
    return best;
  }

  public RoadTool() { super(new class_1793().method_7889(1)); }

  @Override
  public class_1269 method_7884(class_1838 context) {
    if (context.method_8045().field_9236) return class_1269.field_5812;
    if (!(context.method_8036() instanceof class_3222 player)) return class_1269.field_5811;
    class_2338 pos = endpointAtHit(context);
    var level = player.method_51469();
    class_2487 tool = context.method_8041().method_7948();
    try (var workChunks = RoadWorkChunks.open(level)) {
      if(!player.method_5715()){var marker=AttachedPointTool.pick(player);if(marker!=null){OneSidedJunctions.selectedAttached(player,tool,marker.road(),marker.point());return class_1269.field_21466;}}
      if(!player.method_5715()&&!(level.method_8321(pos) instanceof NodeEntity)){
        var picked=pick(player);var hit=context.method_17698();
        var attached=picked==null?null:AttachedPointTool.nearest(picked,new V(hit.field_1352,hit.field_1351,hit.field_1350));
        if(attached!=null&&(SideHosts.attachable(picked.record)||attached.elevated()&&ElevatedPointTool.supported(picked.record))){OneSidedJunctions.selectedAttached(player,tool,picked,attached);return class_1269.field_21466;}
      }
      if (level.method_8321(pos) instanceof NodeEntity node) {
        RoadData.requireOwner(player, node.owner);
        if(player.method_5715()&&AutoJunctions.center(RoadData.get(level),pos)!=null)
          throw new IllegalArgumentException("这是路口中心，请用普通路口编辑器编辑；道路连接器用于接入路段");
        if (player.method_5715()) {
          class_2487 t = new class_2487();
          t.method_10582("Kind", "node");

          t.method_10544("Pos", pos.method_10063());
          t.method_10566("Node", RoadRecord.writeNode(node.node()));
          t.method_10566("OriginalNode", RoadRecord.writeNode(node.node()));
          net.minecraft.class_2499 attached = new net.minecraft.class_2499();
          RoadData nodeData = RoadData.get(level);
          for (var built : nodeData.index.roads.values()) {
            var r = built.record;
            if (!r.a().equals(pos) && !r.b().equals(pos)) continue;
            if (r.assembly() != null)
              throw new IllegalArgumentException("自动立交端点请先用立交连接器删除整座，再调整高差后重建");
            class_2487 entry = new class_2487();
            entry.method_10566("Road", r.header());
            entry.method_10566("AutoA", RoadData.writeHint(nodeData.hint(level, r.a(), true, r.id())));
            entry.method_10566("AutoB", RoadData.writeHint(nodeData.hint(level, r.b(), false, r.id())));
            attached.add(entry);
          }
          t.method_10566("Attached", attached);
          RoadNetwork.open(player, t);
          return class_1269.field_21466;
        }
        if(OneSidedJunctions.selectedEndpoint(player,tool,pos))return class_1269.field_21466;
        String dimension = level.method_27983().method_29177().toString();
        if (!tool.method_10545("Start") || !dimension.equals(tool.method_10558("Dimension"))) {
          tool.method_10551(CurveControlNodes.KEY);
          tool.method_10544("Start", pos.method_10063());
          tool.method_10582("Dimension", dimension);
          player.method_7353(
              class_2561.method_43470("已选起点 " + pos.method_23854() + "，请右键另一个端点；Shift＋右键端点可编辑朝向与坡度"),
              true);
        } else {
          class_2338 a = class_2338.method_10092(tool.method_10537("Start"));
          if (a.equals(pos)) throw new IllegalArgumentException("请选另一个端点；Shift＋右键空气清除选择");
          NodeEntity first = RoadData.requireNode(level, a, player);
          JunctionPointTool.requireDifferent(level,a,pos);
          if(TollRoads.reverseConnection(RoadData.get(level),a,pos)){
            class_2338 swap=a;a=pos;pos=swap;NodeEntity swapNode=first;first=node;node=swapNode;
            tool.method_10544("Start",a.method_10063());
          }
          class_2487 t = new class_2487();
          t.method_10582("Kind", "road");

          t.method_10544("A", a.method_10063());
          t.method_10544("B", pos.method_10063());
          RoadData data = RoadData.get(level);
          t.method_10566("StartNode", RoadRecord.writeNode(data.connectionNode(level,a,true,null,node.constructionNode().position())));
          t.method_10566("EndNode", RoadRecord.writeNode(data.connectionNode(level,pos,false,null,first.constructionNode().position())));
          var saved =
              tool.method_10545("Settings")
                  ? RoadRecord.readSettings(tool.method_10562("Settings"))
                  : new Settings(
                      Mode.AUTO, Style.O2_YELLOW, 9, 1, .35, 90);
          if(tool.method_10550("PreferencesVersion")<3)
            saved=saved.options(saved.options().infrastructure(saved.options().infrastructure().grade(.06).autoSpan(true)));
          saved=com.sora.splineroads.core.RoadPreferences.fresh(saved);
          double width =
              tool.method_10550("PreferencesVersion") >= 2 ? saved.width() : saved.style().defaultWidth();
          Style choice = saved.style();
          if (choice.ramp()) {
            choice = Style.TWO_LANE;
            width = 9;
          }
          if (!choice.ramp() && !com.sora.splineroads.core.RoadProfile.modern(choice))
            width = data.inheritedWidth(a, pos, width, null);
          Settings settings =
              new Settings(
                      ManualPlanner.inSession()&&CurveControlNodes.controls(tool).isEmpty()&&!data.linked(a)&&!data.linked(pos)?Mode.STRAIGHT:Mode.AUTO,
                      choice,
                      width,
                      saved.thickness(),
                      saved.tension(),
                      saved.arcDegrees())
                  .options(
                      saved
                          .options()
                          .lanePoints(com.sora.splineroads.core.LanePoints.Data.EMPTY)
                          .attachments(com.sora.splineroads.core.RoadAttachments.Data.EMPTY)
                          .ends(com.sora.splineroads.core.RoadTransitions.Ends.NONE)
                          .infrastructure(saved.options().infrastructure().clearEdits())
                          .lift(.5, 0)
                          .route(saved.options().routing().offset(0, 0).controls(CurveControlNodes.controls(tool)).through(tool.method_10577("CurveThrough")))
                          .outsets(0, 0)
                          .sides(
                              com.sora.splineroads.core.RoadProfile.Side.AUTO,
                              com.sora.splineroads.core.RoadProfile.Side.AUTO))
                  .structure(saved.structure())
                  .rampTurn(RampTurn.LEGACY);
          t.method_10566(
              "Settings",
              RoadRecord.writeSettings(
                  RoadData.joinWidths(
                      settings, data.endpointWidth(a, null), data.endpointWidth(pos, null))));
          t.method_10549("JoinWidthA", data.endpointWidth(a, null));
          t.method_10549("JoinWidthB", data.endpointWidth(pos, null));
          data.jointPayload(t, a, pos, null);
          if(t.method_10545("JoinSectionA")||t.method_10545("JoinSectionB")){
            var port=RoadRecord.readSettings(t.method_10562(t.method_10545("JoinSectionA")?"JoinSectionA":"JoinSectionB"));
            settings=continuation(settings,port);
            t.method_10566("Settings",RoadRecord.writeSettings(settings));
          }

          t.method_10566(
              "AutoA",
              RoadData.writeHint(
                  data.constructionHint(
                      level, a, true, null, node.constructionNode().position(), false)));
          t.method_10566(
              "AutoB",
              RoadData.writeHint(
                  data.constructionHint(
                      level, pos, false, null, first.constructionNode().position(), false)));

          AutoJunctions.enrich(t,data,a,pos,null);
          RoadNetwork.open(player, t);
        }
        return class_1269.field_21466;
      }
      var index = RoadData.get(level).index;
      var ids = index.at(pos.method_10063());
      if (!ids.isEmpty()) {
        var hit = context.method_17698();
        var picked=pick(player);
        var road = picked!=null&&ids.contains(picked.record.id())?picked.record:
            ids.stream()
                .map(index.roads::get)
                .min(
                    java.util.Comparator.comparingDouble(
                        r ->
                            r.mesh.samples().stream()
                                .mapToDouble(
                                    s ->
                                        Math.abs(s.center().y() - hit.field_1351)
                                            + Math.hypot(
                                                    s.center().x() - hit.field_1352, s.center().z() - hit.field_1350)
                                                * .01)
                                .min()
                                .orElse(1e9)))
                .orElseThrow()
                .record;
        requireTool(road);
        openRoad(player, road, false);
        return class_1269.field_21466;
      }
      player.method_7353(class_2561.method_43470("右键端点进行连接，右键已有路面可编辑或删除"), true);
    } catch (IllegalArgumentException e) {
      if(ManualPlanner.inSession())throw e;
      player.method_7353(class_2561.method_43470(e.getMessage()), false);
    }
    return class_1269.field_21466;
  }

  public static RoadIndex.Built pick(class_3222 player) {
    var eye = player.method_33571();
    var look = player.method_5720();
    return RoadData.get(player.method_51469())
        .index
        .pick(new V(eye.field_1352, eye.field_1351, eye.field_1350), new V(look.field_1352, look.field_1351, look.field_1350), 256);
  }

  /** Refresh the authoritative dependency list before opening the shared deletion UI. */
  public static void openDeletion(class_3222 player, UUID id) {openDeletion(player,id,new class_2487());}

  public static void openDeletion(class_3222 player, UUID id,class_2487 command) {
    var data=RoadData.get(player.method_51469());
    RoadRecord road=data.streets.get(id);
    if(road==null){var built=data.index.roads.get(id);if(built!=null)road=built.record;}
    if(road==null)throw new IllegalArgumentException("道路已删除或尚未加载，请重新选择");
    RoadData.requireOwner(player,road.owner());
    openRoad(player,road,true,command);
  }

  public static void openRoad(class_3222 player, RoadRecord road, boolean deletion) {
    openRoad(player,road,deletion,new class_2487());
  }

  private static void openRoad(class_3222 player, RoadRecord road, boolean deletion,class_2487 command) {
    if(!deletion&&ElevatedAccessRoads.saved(RoadData.get(player.method_51469()),road.assembly())){ElevatedAccessRoads.open(player,road.assembly());return;}
    if(road.railway())throw new IllegalArgumentException("铁路路基请使用铁路路基连接器编辑或删除");
    java.util.function.Consumer<class_2487> reply=t->{com.sora.splineroads.net.RoadActionContext.echo(command,t);RoadNetwork.open(player,t);};
    try (var workChunks = RoadWorkChunks.open(player.method_51469())) {
      var level = player.method_51469();
      RoadData.requireOwner(player, road.owner());
      var mixed=JunctionPointConnections.group(RoadData.get(level),road.id());if(mixed!=null){var t=JunctionPointConnections.payload(level,player,mixed);if(!deletion)t=SideRoads.payload(t);t.method_10556("DeleteOnly",deletion);reply.accept(t);return;}
      if(road.junction()!=null&&road.junction().spec().oneSide()!=null){var t=OneSidedJunctions.payload(level,player,road.assembly());if(!deletion)t=SideRoads.payload(t);t.method_10556("DeleteOnly",deletion);reply.accept(t);return;}
      if(road.toll()!=null){var t=TollRoads.payload(level,player,new long[0],road.id());t.method_10556("DeleteOnly",deletion);reply.accept(t);return;}
      if (road.junction() != null && deletion && road.junction().get().arm()>=0) {
        var saved=RoadData.get(level).junctions.get(road.assembly());
        if(saved!=null&&saved.method_10577("Auto")){
          String key=saved.method_10554("ArmRoads",net.minecraft.class_2520.field_33258).method_10608(road.junction().get().arm());
          RoadRecord branch=RoadData.get(level).streets.get(java.util.UUID.fromString(key));if(branch==null&&RoadData.get(level).index.roads.containsKey(java.util.UUID.fromString(key)))branch=RoadData.get(level).index.roads.get(java.util.UUID.fromString(key)).record;
          if(branch!=null){var t=new class_2487();t.method_10582("Kind","road");t.method_10556("DeleteOnly",true);t.method_25927("Id",branch.id());t.method_10566("Road",branch.header());LaneDeletes.payload(RoadData.get(level),branch.id(),t);reply.accept(t);return;}
        }
      }
      if(road.junction()!=null&&!deletion){
        var logical=JunctionRoads.logical(RoadData.get(level),road);
        if(logical!=null){road=logical;var owner=JunctionPointConnections.group(RoadData.get(level),road.id());if(owner!=null){reply.accept(SideRoads.payload(JunctionPointConnections.payload(level,player,owner)));return;}}
        else {reply.accept(JunctionRoads.payload(level,player,road));return;}
      }
      if (road.junction() != null) {
        class_2487 t = Junctions.selectedPayload(level,player,road);
        t.method_10556("DeleteOnly",true); reply.accept(t); return;
      }
      if(!deletion && LaneTopology.metadata(road).link()!=null){reply.accept(LaneRamps.tunnelChoices(LaneRamps.payload(road,true),LaneTopology.records(RoadData.get(level))));return;}
      if(!deletion && RoadData.get(level).streets.containsKey(road.id()))road=RoadData.get(level).editableRoad(road.id());
      if (deletion) {
        class_2487 t = new class_2487();
        t.method_10582("Kind", "road");
        t.method_10556("DeleteOnly", true);
        t.method_25927("Id", road.id());
        t.method_10566("Road", road.header());
        t.method_10556("ElevatedDelete",ElevatedAccessRoads.saved(RoadData.get(level),road.assembly()));
        LaneDeletes.payload(RoadData.get(level),road.id(),t);
        reply.accept( t);
        return;
      }
      if(road.assembly()!=null&&RoadData.get(level).interchanges.getOrDefault(road.assembly(),new class_2487()).method_10577("YJunction"))throw new IllegalArgumentException("请用普通路口编辑器右键此 Y 字路口");
      if (road.assembly() != null) throw new IllegalArgumentException("此路段属于自动立交，请用立交连接器右键整体编辑");

      road=road.localCurveForEditing();
      class_2487 t = new class_2487();
      t.method_10556("DeleteOnly", deletion);

      t.method_10566("Road", road.header());
      t.method_10582("Kind", "road");
      t.method_25927("Id", road.id());
      t.method_10544("A", road.a().method_10063());
      t.method_10544("B", road.b().method_10063());
      t.method_10566(
          "StartNode",
          RoadRecord.writeNode(
              new Node(
                  RoadData.requireNode(level, road.a(), player).constructionNode().position(),
                  road.start().yaw(),
                  road.start().grade())));
      t.method_10566(
          "EndNode",
          RoadRecord.writeNode(
              new Node(
                  RoadData.requireNode(level, road.b(), player).constructionNode().position(),
                  road.end().yaw(),
                  road.end().grade())));
      t.method_10566(
          "Settings",
          RoadRecord.writeSettings(
              road.automatic()
                  ? RoadPlanner.mode(road.settings(), Mode.AUTO, road.settings().arcDegrees())
                  : road.settings()));
      RoadData data = RoadData.get(level);
      t.method_10549("JoinWidthA", data.endpointWidth(road.a(), road.id()));
      t.method_10549("JoinWidthB", data.endpointWidth(road.b(), road.id()));
      data.jointPayload(t, road.a(), road.b(), road.id());
      t.method_10566(
          "AutoA",
          RoadData.writeHint(
              data.constructionHint(
                  level, road.a(), true, road.id(), road.end().position(), false)));
      t.method_10566(
          "AutoB",
          RoadData.writeHint(
              data.constructionHint(
                  level, road.b(), false, road.id(), road.start().position(), false)));

      if(!road.settings().style().ramp())AutoJunctions.enrich(t,data,road.a(),road.b(),road.id());
      reply.accept( t);
    }
  }

  @Override
  public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 hand) {
    class_1799 stack = player.method_5998(hand);
    if(!level.field_9236&&!player.method_5715()){var server=(class_3222)player;var marker=AttachedPointTool.pick(server);if(marker!=null){try{OneSidedJunctions.selectedAttached(server,stack.method_7948(),marker.road(),marker.point());}catch(IllegalArgumentException e){player.method_7353(class_2561.method_43470(e.getMessage()),false);}return class_1271.method_22427(stack);}}
    if (player.method_5715()) {
      if (!level.field_9236) {
        stack.method_7948().method_10551("ElevatedSelection");stack.method_7948().method_10551("SideSelection");stack.method_7948().method_10551("SideMain");stack.method_7948().method_10551("SidePoint");stack.method_7948().method_10551("Start");stack.method_7948().method_10551(CurveControlNodes.KEY);
        class_2487 request = kind("reset");

        RoadNetwork.open((class_3222) player, request);
        player.method_7353(class_2561.method_43470("已清除道路选择与预览"), true);
      }
    } else if (level.field_9236) {
      class_2487 request = kind("resume");

      openClient.accept(request);
    } else if (!stack.method_7948().method_10545("Start")) {
      var road = pick((class_3222) player);
      if (road != null) {
        try{requireTool(road.record);openRoad((class_3222) player, road.record, false);}
        catch(IllegalArgumentException e){player.method_7353(class_2561.method_43470(e.getMessage()),false);}
      }
    }
    return class_1271.method_29237(stack, level.field_9236);
  }

  private static void requireTool(RoadRecord road) {
    if (road.settings().style().ramp() &&
        !(road.settings().style().connectorRamp()&&LaneTopology.metadata(road).link()!=null))
      throw new IllegalArgumentException("此旧路段可用道路删除器移除");
  }

  static Settings continuation(Settings requested,Settings port){
    var options=port.options().lanePoints(com.sora.splineroads.core.LanePoints.Data.EMPTY)
        .attachments(com.sora.splineroads.core.RoadAttachments.Data.EMPTY).laneLines(List.of())
        .streetscape(port.options().streetscape().raisedSpans(List.of()).tunnels(List.of()).crossings(List.of()))
        .infrastructure(port.options().infrastructure().clearEdits()).lift(.5,0).outsets(0,0)
        .route(requested.options().routing()).sides(com.sora.splineroads.core.RoadProfile.Side.AUTO,com.sora.splineroads.core.RoadProfile.Side.AUTO);
    return new Settings(requested.mode(),port.style(),port.width(),port.thickness(),port.tension(),port.arcDegrees())
        .structure(port.structure()).options(options);
  }

  private static class_2487 kind(String kind) {
    class_2487 t = new class_2487();
    t.method_10582("Kind", kind);
    return t;
  }

  @Override
  public void method_7851(class_1799 s, class_1937 l, List<class_2561> lines, class_1836 flag) {
    lines.add(
        class_2561.method_43471(
            "tooltip.splineroads.connector"));
  }
}
