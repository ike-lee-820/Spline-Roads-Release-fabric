package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadRaster.Box;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.world.RoadIndex.Built.Column;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.world.phys.shapes.*;
/** Cache immutable local masks during a transaction; exact footprints also reach the client. */
public final class RailbedTerrainEdge {
  public record Data(List<RoadRaster.Box> boxes,List<List<V>> polygons){}
  private static final Data EMPTY=new Data(List.of(),List.of());
  private record Key(class_2338 pos,List<Mesh> meshes){}
  private static final Map<Key,Data> CACHE=new LinkedHashMap<>(256,.75f,true){protected boolean removeEldestEntry(Map.Entry<Key,Data> e){return size()>4096;}};
  public static boolean present(class_2338 p,class_2680 material,List<RoadIndex.Built> nearby){return !data(p,material,nearby).polygons().isEmpty();}
  public static List<RoadRaster.Box> boxes(class_2338 p,class_2680 material,List<RoadIndex.Built> nearby){return data(p,material,nearby).boxes();}
  public static Data data(class_2338 p,class_2680 material,List<RoadIndex.Built> nearby){
    if(!material.method_26225()||material.method_31709()||!material.method_26227().method_15769())return EMPTY;
    boolean edge=false;var relevant=new ArrayList<Mesh>();
    for(var road:nearby){
      if(road.tunnelAt(p)||road.cycleBodyAt(p))return EMPTY;
      var c=road.column(p);if(c==null||p.method_10264()+1<=c.minTop()+1e-7||p.method_10264()>=c.maxTop()+Math.max(4.25,RoadInfrastructure.clearance(road.record.settings())))continue;
      relevant.add(road.mesh);edge|=road.record.railway();
    }
    if(!edge)return EMPTY;var key=new Key(p.method_10062(),List.copyOf(relevant));
    synchronized(CACHE){var found=CACHE.get(key);if(found!=null)return found;}
    var polygons=TerrainEdgeGeometry.retain(new V(p.method_10263(),p.method_10264(),p.method_10260()),relevant);
    var result=polygons.isEmpty()?EMPTY:new Data(collision(p,nearby),polygons);
    synchronized(CACHE){CACHE.put(key,result);}return result;
  }
  private static List<RoadRaster.Box> collision(class_2338 p,List<RoadIndex.Built> nearby){
    class_265 shape=class_259.method_1077();for(var road:nearby)for(var cells:road.prepareCollision().deckColumn(p.method_10263(),p.method_10260()).values())for(var b:cells)shape=class_259.method_1082(shape,class_259.method_1081(b.x0(),0,b.z0(),b.x1(),1,b.z1()),class_247.field_16886);
    return shape.method_1097().method_1090().stream().map(b->new RoadRaster.Box(b.field_1323,b.field_1322,b.field_1321,b.field_1320,b.field_1325,b.field_1324)).toList();
  }
  private RailbedTerrainEdge(){}
}
