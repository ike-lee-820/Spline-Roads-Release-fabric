package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** Shared ordinary-road and railbed excavation policy. Ownership/rail clearance
 * and region-protection checks remain at the transaction boundary. */
final class RoadClearing {
  static void validate(class_3218 level,class_2338 pos,class_2680 state,boolean placedSidewalk){
    if(!RoadBlocks.isCollider(state)&&!state.method_27852(SplineRoads.TUNNEL_AIR.get())&&!placedSidewalk&&state.method_26214(level,pos)<0)
      throw new IllegalArgumentException("无法清除不可破坏方块："+pos.method_23854());
    if(state.method_31709()&&!RoadBlocks.isCollider(state))
      throw new IllegalArgumentException("道路或隧道范围被方块实体占用，无法清除："+pos.method_23854());
  }
  private RoadClearing(){}
}
