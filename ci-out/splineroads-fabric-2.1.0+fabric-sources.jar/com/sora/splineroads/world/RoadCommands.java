package com.sora.splineroads.world;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.sora.splineroads.SplineRoads;
import java.util.*;
import net.minecraft.class_2168;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.*;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent.BreakEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import static net.minecraft.class_2170.*;

/** Operator world-edit helpers; scans run on the server thread with a shared per-tick budget. */
@Mod.EventBusSubscriber(modid=SplineRoads.ID)
public final class RoadCommands {
  private record Species(class_6862<class_2248> logs,class_2248 leaves){}
  private static final Map<String,Species> SPECIES=Map.of(
      "oak",new Species(class_3481.field_15482,class_2246.field_10503),
      "spruce",new Species(class_3481.field_15489,class_2246.field_9988),
      "birch",new Species(class_3481.field_15498,class_2246.field_10539),
      "jungle",new Species(class_3481.field_15474,class_2246.field_10335),
      "acacia",new Species(class_3481.field_15458,class_2246.field_10098),
      "dark_oak",new Species(class_3481.field_15485,class_2246.field_10035),
      "mangrove",new Species(class_3481.field_37401,class_2246.field_37551),
      "cherry",new Species(class_3481.field_42608,class_2246.field_42731));
  private static final Map<MinecraftServer,ArrayDeque<ClearJob>> JOBS=new IdentityHashMap<>();
  private static final long MAX_CELLS=64_000_000;

  @SubscribeEvent public static void register(RegisterCommandsEvent event){register(event.getDispatcher());}
  public static void register(CommandDispatcher<class_2168> dispatcher){
    var root=method_9247("sr").requires(source->source.method_9259(2));
    String[][] aliases={{"day","time set day"},{"night","time set midnight"},{"rain","weather rain"},
        {"sun","weather clear"},{"kd","kill @e[type=item]"}};
    for(var pair:aliases)root.then(method_9247(pair[0]).executes(c->c.getSource().method_9211().method_3734().method_44252(c.getSource(),pair[1])));
    var treeRadius=method_9244("r",IntegerArgumentType.integer(1,1024)).executes(c->start(c,true,false,""));
    var treeHeight=method_9244("h",IntegerArgumentType.integer(1,1024)).executes(c->start(c,true,true,""));
    // Tree species are literals, so numeric heights can never be consumed as an exception.
    for(String species:new TreeSet<>(SPECIES.keySet())){
      treeRadius.then(method_9247(species).executes(c->start(c,true,false,species)));
      treeHeight.then(method_9247(species).executes(c->start(c,true,true,species)));
    }
    treeRadius.then(treeHeight);
    root.then(method_9247("tree").then(treeRadius));
    root.then(method_9247("plant").then(method_9244("r",IntegerArgumentType.integer(1,1024)).executes(c->start(c,false,false,""))
        .then(method_9244("h",IntegerArgumentType.integer(1,1024)).executes(c->start(c,false,true,"")))));
    dispatcher.register(root);
  }
  private static CommandSyntaxException error(String text){return new SimpleCommandExceptionType(class_2561.method_43470(text)).create();}
  private static int start(CommandContext<class_2168> context,boolean trees,boolean hasHeight,String except)throws CommandSyntaxException{
    var source=context.getSource();var player=source.method_9207();
    int radius=IntegerArgumentType.getInteger(context,"r"),height=hasHeight?IntegerArgumentType.getInteger(context,"h"):radius;
    var queue=JOBS.computeIfAbsent(source.method_9211(),s->new ArrayDeque<>());
    if(queue.stream().anyMatch(j->j.player.method_5667().equals(player.method_5667())))throw error("上一次 SR 清理尚未完成，请稍后再执行");
    var job=new ClearJob(source,player,radius,height,trees,except);
    if((long)(2*radius+1)*(2*radius+1)*(job.high-job.low)>MAX_CELLS)throw error("清理范围超过 6400 万格，请减小半径 r 或高度 h");
    queue.add(job);
    source.method_9226(()->class_2561.method_43470("开始清理"+(trees?"原木和树叶":"杂草和花卉")+"：半径 "+radius+"，高度 "+height+"（从玩家脚下向上）"+(except.isEmpty()?"":"，保留 "+except)),false);
    return 1;
  }
  static boolean matches(class_2680 state,boolean trees,String except){
    if(trees){
      if(!state.method_26164(class_3481.field_15475)&&!state.method_26164(class_3481.field_15503))return false;
      Species keep=SPECIES.get(except);return keep==null||!state.method_26164(keep.logs())&&!state.method_27852(keep.leaves());
    }
    // Vanilla's FLOWERS also includes cherry leaves and mangrove propagules.
    return state.method_26164(class_3481.field_20339)&&!state.method_26164(class_3481.field_15503)&&!state.method_26164(class_3481.field_15462)
        ||state.method_27852(class_2246.field_10479)||state.method_27852(class_2246.field_10214)
        ||state.method_27852(class_2246.field_10112)||state.method_27852(class_2246.field_10313)||state.method_27852(class_2246.field_10428);
  }
  @SubscribeEvent public static void tick(TickEvent.ServerTickEvent event){if(event.phase==TickEvent.Phase.END)tick(event.getServer());}
  static void tick(MinecraftServer server){
    var queue=JOBS.get(server);if(queue==null||queue.isEmpty())return;
    long deadline=System.nanoTime()+2_000_000;int budget=8192;
    while(!queue.isEmpty()&&budget>0&&System.nanoTime()<deadline){
      var job=queue.removeFirst();int used=job.step(Math.min(512,budget),deadline);budget-=used;
      if(job.done())job.finish();else queue.addLast(job);
    }
    if(queue.isEmpty())JOBS.remove(server);
  }
  @SubscribeEvent public static void stopped(ServerStoppedEvent event){JOBS.remove(event.getServer());}
  static boolean pending(MinecraftServer server){var q=JOBS.get(server);return q!=null&&!q.isEmpty();}

  private static final class ClearJob {
    final class_2168 source;final class_3222 player;final class_3218 level;
    final int radius,low,high,cx,cz;final boolean trees;final String except;
    final class_2338.class_2339 pos=new class_2338.class_2339();
    int x,z,y,removed,skipped;boolean columnChecked;
    ClearJob(class_2168 source,class_3222 player,int radius,int height,boolean trees,String except){
      this.source=source;this.player=player;this.level=player.method_51469();this.radius=radius;this.trees=trees;this.except=except;
      var center=player.method_24515();cx=center.method_10263();cz=center.method_10260();
      low=Math.max(level.method_31607(),Math.min(level.method_31600(),center.method_10264()));
      high=Math.max(low,Math.min(level.method_31600(),center.method_10264()+height));x=z=-radius;y=low;
    }
    boolean done(){return x>radius||high<=low;}
    void column(){y=low;columnChecked=false;if(++z>radius){z=-radius;x++;}}
    int step(int budget,long deadline){
      int used=0;
      while(!done()&&used<budget&&(used%32!=0||System.nanoTime()<deadline)){
        used++;
        if(!columnChecked){
          if((long)x*x+(long)z*z>(long)radius*radius){column();continue;}
          pos.method_10103(cx+x,low,cz+z);
          if(!level.method_22340(pos)||!level.method_8621().method_11952(pos)){skipped++;column();continue;}
          columnChecked=true;
        }
        pos.method_10103(cx+x,y,cz+z);
        // A chunk may unload between ticks. Never force terrain generation for this helper.
        if(!level.method_22340(pos)){skipped++;column();continue;}
        class_2680 state=level.method_8320(pos);
        if(matches(state,trees,except)){
          var event=new net.minecraftforge.event.level.BlockEvent.BreakEvent(level,pos.method_10062(),state,player);
          if(level.method_8505(player,pos)&&!net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(event)
              &&level.method_8652(pos,state.method_26227().method_15759(),class_2248.field_31028|class_2248.field_31031))removed++;
        }
        if(++y>=high)column();
      }return used;
    }
    void finish(){source.method_9226(()->class_2561.method_43470("SR 清理完成：移除 "+removed+" 个方块"+(skipped==0?"":"；跳过 "+skipped+" 个未加载或边界外的方块列")),true);}
  }
  private RoadCommands(){}
}
