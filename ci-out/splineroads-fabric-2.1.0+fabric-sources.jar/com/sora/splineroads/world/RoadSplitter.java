package com.sora.splineroads.world;

import D;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Data;
import com.sora.splineroads.core.LanePoints.Link;
import com.sora.splineroads.core.LanePoints.Point;
import com.sora.splineroads.core.LanePoints.Ref;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadSlicing.Connection;
import com.sora.splineroads.core.SmartSigns.State;
import com.sora.splineroads.net.*;
import com.sora.splineroads.world.AutoJunctions.Draft;
import com.sora.splineroads.world.RoadData.NodeMove;
import com.sora.splineroads.world.RoadData.SplitPrepared;
import com.sora.splineroads.world.RoadIndex.Built;
import com.sora.splineroads.world.RoadSplitGeometry.Pair;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** The preview token owns a complete immutable plan, never a delete-and-rebuild command. */
public final class RoadSplitter {
  public record Hit(RoadIndex.Built road,double station,V point,double distance){}
  record Plan(RoadRecord original,RoadSplitGeometry.Pair pair,List<RoadRecord> roads,RoadMetadataPatch<RoadRecord> streets,RoadMetadataPatch<class_2487> junctions,RoadMetadataPatch<class_2487> interchanges,Map<Integer,UUID> signOwners,RoadData.SplitPrepared prepared){}
  private record Pending(String dimension,UUID owner,long created,Plan plan){}
  private static final Map<UUID,Pending> PENDING=new LinkedHashMap<>();
  public static Hit hit(Collection<RoadIndex.Built> roads,V eye,V direction,double limit){
    Hit best=null;for(var road:roads){var m=road.mesh;if(eye.x()+limit<m.min().x()||eye.x()-limit>m.max().x()||eye.z()+limit<m.min().z()||eye.z()-limit>m.max().z()||eye.y()+limit<m.min().y()||eye.y()-limit>m.max().y())continue;var ray=RoadQueries.ray(road.mesh,eye,direction,limit);if(!Double.isFinite(ray))continue;double distance=ray;if(best==null||distance<best.distance()){V point=eye.add(direction.mul(distance));best=new Hit(road,RoadSplitGeometry.station(road.mesh,point),point,distance);}}return best;
  }
  private static Hit hit(class_3222 player){var eye=player.method_33571();var look=player.method_5720();var origin=new V(eye.field_1352,eye.field_1351,eye.field_1350);var direction=new V(look.field_1352,look.field_1351,look.field_1350);return hit(RoadData.get(player.method_51469()).index.rayCandidates(origin,direction,64),origin,direction,64);}
  public static void cancel(UUID owner){PENDING.entrySet().removeIf(e->e.getValue().owner().equals(owner));}
  static void expire(long now){PENDING.entrySet().removeIf(e->now-e.getValue().created()>120_000_000_000L);}
  public static void clear(){PENDING.clear();}
  private static void requireTool(class_3222 player){if(!player.method_7294()||player.method_7325()||!(player.method_6047().method_7909() instanceof RoadSplitTool||player.method_6079().method_7909() instanceof RoadSplitTool))throw new IllegalArgumentException("请手持道路分割器并确保拥有建设权限");}
  public static class_2487 preview(class_3222 player,class_2487 command){
    requireTool(player);cancel(player.method_5667());var reply=new class_2487();reply.method_10582("Kind","splitCheck");reply.method_10544("Request",command.method_10537("Request"));reply.method_10582("Dimension",player.method_37908().method_27983().method_29177().toString());
    var built=RoadData.get(player.method_51469()).index.roads.get(command.method_25926("Id"));
    if(built==null||built.record.header().hashCode()!=command.method_10550("Signature"))throw new IllegalArgumentException("道路已改变，请重新选择");
    var r=built.record;requireReach(player,r,command.method_10574("Station"));
    var mode=RoadSlicing.Connection.valueOf(command.method_10558("Mode"));var plan=plan(player.method_51469(),player,r,command.method_10574("Station"),mode);
    UUID token=UUID.randomUUID();expire(System.nanoTime());PENDING.put(token,new Pending(reply.method_10558("Dimension"),player.method_5667(),System.nanoTime(),plan));while(PENDING.size()>1&&(PENDING.size()>4||PENDING.values().stream().mapToLong(p->p.plan().prepared().cells()).sum()>RoadLimits.MAX_EDIT_CELLS))PENDING.remove(PENDING.keySet().iterator().next());
    reply.method_25927("Token",token);reply.method_25927("Id",r.id());reply.method_10549("Station",plan.pair().station());reply.method_10549("Length",r.mesh().length());reply.method_10566("Node",RoadRecord.writeNode(plan.pair().node()));reply.method_10582("Mode",mode.name());var paths=new class_2499();if(mode==RoadSlicing.Connection.JUNCTION)for(var road:plan.roads())paths.add(road.header());reply.method_10566("PreviewRoads",paths);return reply;
  }
  public static String commit(class_3222 player,class_2487 command){
    requireTool(player);var pending=PENDING.remove(command.method_25926("Token"));if(pending==null||!pending.owner().equals(player.method_5667())||!pending.dimension().equals(player.method_37908().method_27983().method_29177().toString())||System.nanoTime()-pending.created()>120_000_000_000L)throw new IllegalArgumentException("分割预览已过期，请重新选择");
    var plan=pending.plan();var current=RoadData.get(player.method_51469()).index.roads.get(plan.original().id());
    if(current==null||current.record!=plan.original())throw new IllegalArgumentException("道路已改变，请重新选择");
    requireReach(player,plan.original(),plan.pair().station());
    commit(player.method_51469(),player,plan);return "道路已分割为两段，共享端点与原有设施已保存";
  }
  private static void requireReach(class_3222 player,RoadRecord road,double station){
    if(!Double.isFinite(station)||station<=0||station>=road.mesh().length())throw new IllegalArgumentException("分割位置无效");
    var eye=player.method_33571();var sample=RoadSlicing.at(road.mesh(),station);
    // A wide road may be selected at its edge, so measure to the selected cross-section.
    V point=new V(eye.field_1352,eye.field_1351,eye.field_1350);double lateral=Math.max(-sample.halfWidth(),Math.min(sample.halfWidth(),point.sub(sample.center()).dot(sample.left())));
    if(sample.at(lateral,0).distance(point)>64)throw new IllegalArgumentException("已离开分割点的操作范围，请重新选择");
  }
  static Plan plan(class_3218 level,class_3222 player,RoadRecord road,double station,RoadSlicing.Connection mode){return plan(level,player,road,station,mode,null);}
  static Plan plan(class_3218 level,class_3222 player,RoadRecord road,double station,RoadSlicing.Connection mode,UUID junctionSource){
    var data=RoadData.get(level);if(player!=null)RoadData.requireOwner(player,road.owner());var pair=RoadSplitGeometry.split(road,station,mode,UUID.randomUUID());
    var occupied=new ArrayList<RoadSplitGeometry.Range>();boolean managedSource=false;
    for(var descriptor:data.interchanges.values()){
      if(ContinuousRoads.sources(descriptor).stream().anyMatch(s->s.road().id().equals(road.id())))managedSource=true;
      for(var entry:descriptor.method_10554("OccupiedRoads",class_2520.field_33260)){var v=(class_2487)entry;if(v.method_25926("Road").equals(road.id()))occupied.add(new RoadSplitGeometry.Range(v.method_10574("From"),v.method_10574("To"),"这里属于立交生成器实际占用区间"));}
    }
    if(road.assembly()!=null&&!managedSource)throw new IllegalArgumentException("受管立交或组合内部道路不能直接分割");RoadSplitGeometry.requireClear(occupied,station,station);
    if(level.method_8321(pair.pos())!=null&&!RoadBlocks.isCollider(level.method_8320(pair.pos())))throw new IllegalArgumentException("新端点位置被方块实体占用");
    var first=pair.first();var second=pair.second();if(managedSource){if(occupied.stream().noneMatch(v->v.intersects(0,station)))first=assembly(first,null);if(occupied.stream().noneMatch(v->v.intersects(station,road.mesh().length())))second=assembly(second,null);}
    var replacement=new LinkedHashMap<UUID,RoadRecord>();replacement.put(first.id(),first);replacement.put(second.id(),second);
    var streets=new LinkedHashMap<>(data.streets);var logical=AutoJunctions.logical(data).get(road.id());RoadSplitGeometry.Pair full=!streets.containsKey(road.id())?null:RoadSplitGeometry.split(logical,mappedStation(logical,road,pair.station()),mode,second.id());
    if(full!=null){streets.put(first.id(),full.first());streets.put(second.id(),full.second());}
    var junctions=new LinkedHashMap<UUID,class_2487>();data.junctions.forEach((id,v)->junctions.put(id,remapJunction(v,road,pair.second().id())));
    var interchanges=new LinkedHashMap<UUID,class_2487>();for(var entry:data.interchanges.entrySet())interchanges.put(entry.getKey(),remapAssembly(entry.getValue(),road,pair));
    // Explicit point identity is the authority for connector ownership, including both ends.
    Set<UUID> secondPoints=new HashSet<>();for(var p:second.settings().options().lanePoints().points())secondPoints.add(p.id());
    for(var built:data.index.roads.values())if(!built.record.id().equals(road.id())){var r=remapLinks(built.record,road.id(),second.id(),secondPoints);if(r!=built.record)replacement.put(r.id(),r);}
    streets.replaceAll((id,r)->remapLinks(r,road.id(),pair.second().id(),secondPoints));
    if(mode==RoadSlicing.Connection.JUNCTION){
      if(RoadProfile.catalog(road.settings()).type()!=RoadProfile.Type.ORDINARY)throw new IllegalArgumentException("当前道路不支持平交路口，可使用连续模式");
      var config=AutoJunctions.config(pair.pos(),road.owner());var draft=AutoJunctions.plan(List.of(first,second),List.of(config));
      double left=station,right=station;for(var r:draft.roads())if(r.junction()==null){if(r.id().equals(first.id()))left=RoadSplitGeometry.station(road.mesh(),r.mesh().last().center());else if(r.id().equals(second.id()))right=RoadSplitGeometry.station(road.mesh(),r.mesh().first().center());}
      RoadSplitGeometry.requireClear(pair.protection(),left,right);RoadSplitGeometry.requireClear(occupied,left,right);
      for(var r:draft.roads())replacement.put(r.id(),r);streets.put(first.id(),first);streets.put(second.id(),second);for(var c:draft.centers())junctions.put(c.method_25926("Id"),c);
      for(var r:draft.roads())for(var old:data.index.roads.values())if(!old.record.id().equals(road.id())&&!replacement.containsKey(old.record.id())&&RoadIndex.overlapXZ(r.mesh(),old.mesh,1))Interchanges.checkExternal(r.mesh(),old.mesh,null);
    }
    var owners=new HashMap<Integer,UUID>();for(var r:List.of(first,second))for(int slot:RoadGantry.slots(r.mesh()))owners.put(slot,r.id());
    for(var state:data.smartSigns.road(road.id()))if(!owners.containsKey(state.key().slot()))throw new IllegalArgumentException("原标牌缺少可迁移的龙门架站位");
    var nodeTag=new class_2487();nodeTag.method_25927("Owner",road.owner());nodeTag.method_10566("Node",RoadRecord.writeNode(pair.node()));nodeTag.method_10556("HeightExplicit",true);nodeTag.method_10556("HeadingLocked",true);nodeTag.method_10556("GradeLocked",true);
    if(junctionSource!=null)nodeTag.method_25927("JunctionSource",junctionSource);
    var moves=new RoadData.NodeMove(null,pair.pos(),pair.node(),nodeTag);var removed=new HashSet<>(replacement.keySet());removed.retainAll(data.index.roads.keySet());
    var roads=mode==RoadSlicing.Connection.JUNCTION?data.splitJunctionStructures(level,List.copyOf(replacement.values()),road.id()):List.copyOf(replacement.values());var built=roads.stream().map(RoadIndex.Built::new).toList();
    // The encoded batch must fit before the first world write, including all manual text.
    var packet=RoadNetwork.batchPacket(level,roads,removed,pair.pos());RoadWire.split(packet);
    var prepared=data.prepareSplit(level,player,built,removed,moves,mode==RoadSlicing.Connection.JUNCTION);
    return new Plan(road,pair,roads,RoadMetadataPatch.between(data.streets,streets,r->r),RoadMetadataPatch.between(data.junctions,junctions,class_2487::method_10553),RoadMetadataPatch.between(data.interchanges,interchanges,class_2487::method_10553),Map.copyOf(owners),prepared);
  }
  static void commit(class_3218 level,class_3222 player,Plan plan){var data=RoadData.get(level);
    // Validate every changed metadata entry before prepare/commit can write a block.
    plan.streets().validate(data.streets);plan.junctions().validate(data.junctions);plan.interchanges().validate(data.interchanges);
    data.commitSplit(level,player,plan.prepared(),()->{
    plan.streets().apply(data.streets);plan.junctions().apply(data.junctions);plan.interchanges().apply(data.interchanges);data.smartSigns.splitKeys(plan.original().id(),plan.signOwners());
  });}
  private static RoadRecord assembly(RoadRecord r,UUID group){return new RoadRecord(r.id(),r.owner(),r.a(),r.b(),r.start(),r.end(),r.settings(),r.automatic(),r.clearance(),r.structures(),r.endCaps(),r.buildVersion(),group,r.alignment(),r.furniturePhase(),r.junction(),r.toll(),r.fragment());}
  private static LanePoints.Ref ref(LanePoints.Ref ref,UUID source,UUID second,Set<UUID> points){return source.equals(ref.road())&&points.contains(ref.point())?LanePoints.Ref.lane(second,ref.point()):ref;}
  /** Map the saved path station, never reproject its laterally offset median marker. */
  private static double mappedStation(RoadRecord whole,RoadRecord visible,double station){
    double mapped=station+visible.settings().options().ends().trimmedStart()-whole.settings().options().ends().trimmedStart();
    V point=RoadSlicing.at(visible.mesh(),station).center();
    if(mapped>=0&&mapped<=whole.mesh().length()&&RoadSlicing.at(whole.mesh(),mapped).center().distance(point)<1e-6)return mapped;
    return RoadSplitGeometry.station(whole.mesh(),point);
  }
  static RoadRecord remapLinks(RoadRecord road,UUID source,UUID second,Set<UUID> points){var data=road.settings().options().lanePoints();var old=data.link();if(old==null)return road;var from=ref(old.from(),source,second,points);var to=ref(old.to(),source,second,points);return from==old.from()&&to==old.to()?road:road.withLanePoints(data.link(new LanePoints.Link(from,to,old.options(),old.junctionMouth(),old.targetOffset(),old.protectedMerge(),old.rectangularClosure())));}
  static class_2487 remapJunction(class_2487 before,RoadRecord old,UUID second){var tag=before.method_10553();if(tag.method_10537("CenterPos")==old.b().method_10063()||Arrays.stream(tag.method_10565("Ports")).anyMatch(v->v==old.b().method_10063())){var arms=tag.method_10554("ArmRoads",class_2520.field_33258);for(int i=0;i<arms.size();i++)if(arms.method_10608(i).equals(old.id().toString()))arms.method_10606(i,class_2519.method_23256(second.toString()));}return tag;}
  static class_2487 remapAssembly(class_2487 before,RoadRecord old,RoadSplitGeometry.Pair pair){
    boolean hasSource=before.method_10554("ContinuousSources",class_2520.field_33260).stream().anyMatch(v->{var t=((class_2487)v).method_10562("Road");return t.method_25928("Id")&&t.method_25926("Id").equals(old.id());});
    boolean occupiedSource=before.method_10554("OccupiedRoads",class_2520.field_33260).stream().anyMatch(v->{var t=(class_2487)v;return t.method_25928("Road")&&t.method_25926("Road").equals(old.id());});
    if(!hasSource&&!occupiedSource)return before;
    var result=before.method_10553();var sources=new class_2499();for(var entry:before.method_10554("ContinuousSources",class_2520.field_33260)){var source=(class_2487)entry;var r=RoadRecord.load(source.method_10562("Road"));if(!r.id().equals(old.id())){sources.add(source.method_10553());continue;}
      var split=RoadSplitGeometry.split(r,mappedStation(r,old,pair.station()),pair.first().fragment().connection(),pair.second().id());for(var half:List.of(split.first(),split.second())){var next=source.method_10553();next.method_10566("Road",half.header());sources.add(next);}}
    result.method_10566("ContinuousSources",sources);var occupied=new class_2499();var owners=new HashSet<UUID>();
    for(var entry:before.method_10554("OccupiedRoads",class_2520.field_33260)){var t=((class_2487)entry).method_10553();if(t.method_25926("Road").equals(old.id())){if(Math.min(t.method_10574("From"),t.method_10574("To"))>=pair.station()){t.method_25927("Road",pair.second().id());t.method_10549("From",t.method_10574("From")-pair.station());t.method_10549("To",t.method_10574("To")-pair.station());}owners.add(t.method_25926("Road"));}occupied.add(t);}result.method_10566("OccupiedRoads",occupied);
    for(String key:List.of("SignTopology","CorridorRoles")){var list=new class_2499();for(var entry:before.method_10554(key,class_2520.field_33260)){var t=(class_2487)entry;if(!t.method_25926("Road").equals(old.id())){list.add(t.method_10553());continue;}for(UUID owner:owners){var next=t.method_10553();next.method_25927("Road",owner);list.add(next);}}if(before.method_10545(key))result.method_10566(key,list);}
    if(sources.stream().anyMatch(t->((class_2487)t).method_10562("Road").method_25928("Id")&&((class_2487)t).method_10562("Road").method_25926("Id").equals(pair.second().id()))){var nodes=new LinkedHashSet<Long>();for(long v:before.method_10565("PreservedNodes"))nodes.add(v);nodes.add(pair.pos().method_10063());result.method_10564("PreservedNodes",nodes.stream().mapToLong(Long::longValue).toArray());}
    return result;
  }
  private RoadSplitter(){}
}
