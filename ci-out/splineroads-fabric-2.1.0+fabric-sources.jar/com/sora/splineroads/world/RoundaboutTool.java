package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.JunctionSpec.*;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
public final class RoundaboutTool extends class_1792 {
 public RoundaboutTool(){super(new class_1793().method_7889(1));}
 @Override public class_1269 method_7884(class_1838 c){if(c.method_8045().field_9236)return class_1269.field_5812;if(!(c.method_8036() instanceof class_3222 p))return class_1269.field_5811;try(var work=RoadWorkChunks.open(p.method_51469())){
   class_2338 pos=RoadTool.endpointAtHit(c);var data=RoadData.get(p.method_51469());var ring=AutoJunctions.center(data,pos);if(ring==null)ring=AutoJunctions.ringAt(data,pos);
   if(ring!=null){RoadNetwork.open(p,Junctions.payload(p.method_51469(),p,new long[0],ring.method_25926("Id")));return class_1269.field_21466;}
   NodeEntity node=RoadData.requireNode(p.method_51469(),pos,p);if(data.linked(pos))throw new IllegalArgumentException("请选择空闲端点作为环岛圆心");var tool=c.method_8041().method_7948();tool.method_10544("Center",pos.method_10063());tool.method_10582("Dimension",p.method_37908().method_27983().method_29177().toString());
   class_2487 t=new class_2487();t.method_10582("Kind","roundabout");t.method_10544("Center",pos.method_10063());t.method_10566("Node",RoadRecord.writeNode(node.constructionNode()));t.method_10549("Radius",20);t.method_10569("Lanes",1);RoadNetwork.open(p,t);
 }catch(IllegalArgumentException e){if(ManualPlanner.inSession())throw e;p.method_7353(class_2561.method_43470(e.getMessage()),false);}return class_1269.field_21466;}
 @Override public class_1271<class_1799> method_7836(class_1937 l,class_1657 p,class_1268 h){if(!l.field_9236&&p instanceof class_3222 s){var hit=RoadTool.pick(s);if(hit!=null&&hit.record.junction()!=null)RoadNetwork.open(s,Junctions.selectedPayload(s.method_51469(),s,hit.record));}return class_1271.method_29237(p.method_5998(h),l.field_9236);}
 public static JunctionSpec specification(class_2487 t){double radius=t.method_10574("Radius");int lanes=t.method_10550("Lanes");if(lanes<1||lanes>2||radius<10||radius>48)throw new IllegalArgumentException("环岛中心线半径 10–48 格，支持单／双车道");V center=RoadRecord.readNode(t.method_10562("Node")).position();return new JunctionSpec(center,Kind.ROUNDABOUT,t.method_10577("LeftTraffic"),4,radius-lanes*2,lanes,4,1,Control.YIELD,20,3,1,0,true,true,t.method_10577("OuterRail"),List.of());}
 public static List<Node> ports(JunctionSpec spec){double radius=spec.islandRadius()+spec.ringLanes()*spec.ringLaneWidth();var nodes=new ArrayList<Node>();int[] directions={0,4,6,2,7,1,5,3};for(int i:directions){double angle=-Math.PI/2+i*Math.PI/4;V out=new V(Math.cos(angle),0,Math.sin(angle));nodes.add(new Node(spec.center().add(out.mul(radius)),RoadPlanner.yaw(out),0));}return nodes;}
 public static String build(class_3218 l,class_3222 p,class_2487 t,class_1799 stack){try(var work=RoadWorkChunks.open(l)){
   if(!(stack.method_7909() instanceof RoundaboutTool)||stack.method_7948().method_10537("Center")!=t.method_10537("Center")||!l.method_27983().method_29177().toString().equals(stack.method_7969().method_10558("Dimension")))throw new IllegalArgumentException("请用环岛生成器重新选择圆心");class_2338 center=class_2338.method_10092(t.method_10537("Center"));var node=RoadData.requireNode(l,center,p);if(RoadData.get(l).linked(center))throw new IllegalArgumentException("圆心已有道路");if(!node.constructionNode().equals(RoadRecord.readNode(t.method_10562("Node"))))throw new IllegalArgumentException("圆心已变化，请重新选择");var spec=specification(t);AutoJunctions.createRing(l,p,center,spec);stack.method_7948().method_10551("Center");return "环岛已生成；用道路连接器从 A–H 八个方向端点接路";
 }}
 @Override public void method_7851(class_1799 s,class_1937 l,List<class_2561> lines,class_1836 f){lines.add(class_2561.method_43470("右键空闲端点作为圆心，设置半径及单双车道"));lines.add(class_2561.method_43470("生成东南西北及四个斜向接路点，用道路连接器接路"));}
}
