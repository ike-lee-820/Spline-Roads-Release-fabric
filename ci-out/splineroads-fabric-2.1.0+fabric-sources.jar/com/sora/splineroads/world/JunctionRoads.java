package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionSpec.*;
import com.sora.splineroads.core.RoadGeometry.Mesh;
import com.sora.splineroads.core.RoadGeometry.Settings;
import com.sora.splineroads.core.RoadGeometry.Style;
import com.sora.splineroads.core.RoadProfile.Median;
import com.sora.splineroads.core.RoadProfile.Options;
import com.sora.splineroads.core.RoadProfile.Type;
import com.sora.splineroads.core.RoadSidewalks.Config;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Road-tool routing and edits are distinct from junction controls and movements. */
public final class JunctionRoads {
  public static RoadRecord logical(RoadData data,RoadRecord road){
    if(road.junction()==null)return road;
    int arm=road.junction().get().arm();var saved=data.junctions.get(road.assembly());
    if(saved==null||!saved.method_10577("Auto")||arm<0)return null;
    var ids=saved.method_10554("ArmRoads",class_2520.field_33258);if(arm>=ids.size())return null;
    try{return data.streets.get(UUID.fromString(ids.method_10608(arm)));}catch(IllegalArgumentException e){return null;}
  }
  public static class_2487 payload(class_3218 level,class_3222 player,RoadRecord road){
    if(road.junction()==null||road.junction().get().arm()<0)
      throw new IllegalArgumentException("这里是路口中心，请使用普通路口编辑器；道路连接器只编辑接入路段");
    var t=Junctions.payload(level,player,new long[0],road.assembly());
    if(t.method_10577("Auto"))throw new IllegalArgumentException("接入道路记录已变化，请重新选择路口外侧路段");
    t.method_10582("Kind","armRoad");t.method_10569("Arm",road.junction().get().arm());
    t.method_10569("Signature",t.method_10562("Spec").hashCode());
    var spec=JunctionCodec.read(t.method_10562("Spec"));var a=spec.arms().get(t.method_10550("Arm"));var settings=editable(a);settings=settings.options(settings.options().traffic(spec.leftTraffic()));
    t.method_10566("Settings",RoadRecord.writeSettings(settings));t.method_10566("StartNode",RoadRecord.writeNode(a.endpoint()));
    var m=road.mesh();t.method_10566("EndNode",RoadRecord.writeNode(new com.sora.splineroads.core.RoadGeometry.Node(m.last().center(),a.endpoint().yaw(),0)));
    return t;
  }
  public static com.sora.splineroads.core.RoadGeometry.Settings editable(Arm a){
    var type=RoadProfile.Type.ORDINARY;boolean two=a.incoming()>0&&a.outgoing()>0;
    int count=two?Math.max(2,Math.min(8,2*Math.max(a.incoming(),a.outgoing()))):Math.min(4,a.incoming()+a.outgoing());
    var median=two?a.medianKind():RoadProfile.Median.NONE;
    if(median==RoadProfile.Median.NONE||median==RoadProfile.Median.DASHED_YELLOW&&count!=2)median=two?RoadProfile.Median.DOUBLE_YELLOW:RoadProfile.Median.NONE;
    var style=RoadProfile.choose(type,count,two,median,false);
    var options=a.external().options().extras(a.cycleWidth()>0,a.external().options().cycleRail(),a.curbWidth()>0);
    options=options.lanes(a.incoming()>0?new RoadLanes.Counts(a.incoming(),a.outgoing()):new RoadLanes.Counts(a.outgoing(),0));
    if(!a.attached())options=options.ends(RoadTransitions.Ends.NONE);
    return new com.sora.splineroads.core.RoadGeometry.Settings(com.sora.splineroads.core.RoadGeometry.Mode.STRAIGHT,style,RoadProfile.width(style,options,a.laneWidth()),a.external().thickness(),a.external().tension(),a.external().arcDegrees()).structure(a.external().structure()).options(options);
  }
  public static Arm change(Arm old,com.sora.splineroads.core.RoadGeometry.Settings settings){
    settings.validate();if(RoadProfile.catalog(settings.style()).type()!=RoadProfile.Type.ORDINARY)throw new IllegalArgumentException("平交接入段请选择普通道路");
    var fresh=JunctionSpec.arm(old.endpoint(),old.inward(),settings,old.incoming()>0,old.phase());
    var lanes=new ArrayList<Lane>();for(int i=0;i<fresh.incoming();i++)lanes.add(i<old.lanes().size()?old.lanes().get(i):Lane.AUTO);
    // Keep attached outside ports fixed; the selected approach tapers to its new width.
    var external=old.attached()?settings.taper(old.external().startWidth(),settings.width()):settings;
    return new Arm(old.endpoint(),old.inward(),external,fresh.incoming(),fresh.outgoing(),fresh.width(),fresh.median(),fresh.medianKind(),fresh.cycleWidth(),fresh.curbWidth(),old.crosswalk(),old.crossingWidth(),old.crossingSetback(),old.stopGap(),old.phase(),lanes,old.attached(),old.advanceSign(),old.nameSign(),old.rightSlip());
  }
  public static Arm change(Arm old,class_2487 edit){
    int in=edit.method_10550("Incoming"),out=edit.method_10550("Outgoing");
    var lanes=new ArrayList<Lane>();for(int i=0;i<in&&i<RoadLanes.MAX_DIRECTION;i++)lanes.add(i<old.lanes().size()?old.lanes().get(i):Lane.AUTO);
    var walk=old.external().options().sidewalk();
    walk=new RoadSidewalks.Config(edit.method_10577("Walk"),RoadSidewalks.Side.valueOf(edit.method_10558("WalkSide")),edit.method_10550("WalkWidth"),edit.method_10558("WalkMaterial"),true,edit.method_10577("Tactile"));
    var options=old.external().options().sidewalk(walk).cycleFinish(edit.method_10574("CycleWidth")==0?RoadProfile.Options.CycleFinish.NONE:edit.method_10577("CycleAsphalt")?RoadProfile.Options.CycleFinish.ASPHALT:RoadProfile.Options.CycleFinish.GREEN);
    // Preserve the outside connection's actual port, grade and width. Only this approach changes.
    return new Arm(old.endpoint(),old.inward(),old.external().options(options),in,out,edit.method_10574("Width"),edit.method_10574("Median"),RoadProfile.Median.valueOf(edit.method_10558("MedianKind")),edit.method_10574("CycleWidth"),edit.method_10574("CurbWidth"),old.crosswalk(),old.crossingWidth(),old.crossingSetback(),old.stopGap(),old.phase(),lanes,old.attached(),old.advanceSign(),old.nameSign(),old.rightSlip());
  }
  public static class_2487 fields(Arm a){
    var t=new class_2487();t.method_10569("Incoming",a.incoming());t.method_10569("Outgoing",a.outgoing());t.method_10549("Width",a.width());t.method_10549("Median",a.median());t.method_10582("MedianKind",a.medianKind().name());t.method_10549("CycleWidth",a.cycleWidth());t.method_10549("CurbWidth",a.curbWidth());
    var w=a.external().options().sidewalk();t.method_10556("Walk",w.enabled());t.method_10569("WalkWidth",w.width());t.method_10582("WalkSide",w.side().name());t.method_10582("WalkMaterial",w.material());t.method_10556("Tactile",w.tactile());t.method_10556("CycleAsphalt",a.external().options().cycleAsphalt());return t;
  }
  public static String build(class_3218 level,class_3222 player,class_2487 command){
    var fresh=Junctions.payload(level,player,new long[0],command.method_25926("Id"));
    if(fresh.method_10577("Auto"))throw new IllegalArgumentException("自动路口的道路请重新用道路连接器选择");
    if(command.method_10550("Signature")!=fresh.method_10562("Spec").hashCode())throw new IllegalArgumentException("路口已改变，请重新打开这段道路");
    int arm=command.method_10550("Arm");var spec=JunctionCodec.read(fresh.method_10562("Spec"));
    if(arm<0||arm>=spec.arms().size())throw new IllegalArgumentException("接入路段已不存在");
    var arms=new ArrayList<>(spec.arms());arms.set(arm,command.method_10545("Settings")?change(arms.get(arm),RoadRecord.readSettings(command.method_10562("Settings"))):change(arms.get(arm),command.method_10562("Fields")));
    fresh.method_10566("Spec",JunctionCodec.write(spec.arms(arms)));Junctions.buildRoad(level,player,fresh,arm);
    return "所选接入道路已更新；信号配时和通行关系由普通路口编辑器管理";
  }
  private JunctionRoads(){}
}
