package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.core.RoadRaster.Box;
import com.sora.splineroads.world.RailbedTerrainEdge.Data;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1922;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_247;
import net.minecraft.class_2487;
import net.minecraft.class_2489;
import net.minecraft.class_2499;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2622;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_7923;
import net.minecraft.nbt.*;
import net.minecraft.world.phys.shapes.*;

/** Material data only: every infill is baked in its chunk, with no entity renderer. */
public final class RoadFillEntity extends class_2586 {
  public static final net.minecraftforge.client.model.data.ModelProperty<class_2680> MATERIAL=new net.minecraftforge.client.model.data.ModelProperty<>();
  public static final net.minecraftforge.client.model.data.ModelProperty<Double> CAP=new net.minecraftforge.client.model.data.ModelProperty<>();
  public static final net.minecraftforge.client.model.data.ModelProperty<java.util.List<com.sora.splineroads.core.RoadRaster.Box>> EDGE=new net.minecraftforge.client.model.data.ModelProperty<>();
  public static final net.minecraftforge.client.model.data.ModelProperty<java.util.List<java.util.List<com.sora.splineroads.core.RoadGeometry.V>>> OUTLINE=new net.minecraftforge.client.model.data.ModelProperty<>();
  private record Fill(class_2680 material,double cap,java.util.List<com.sora.splineroads.core.RoadRaster.Box> edge,java.util.List<java.util.List<com.sora.splineroads.core.RoadGeometry.V>> outline) {}
  private record Collision(Fill fill,class_265 raw,class_265 road,class_265 shape) {}
  private volatile Fill contents=new Fill(class_2246.field_10124.method_9564(),1,java.util.List.of(),java.util.List.of());
  private volatile Collision cached;
  public java.util.List<java.util.List<com.sora.splineroads.core.RoadGeometry.V>> outline(){return contents.outline();}
  public double cap(){return contents.cap();}
  public java.util.List<com.sora.splineroads.core.RoadRaster.Box> edge(){return contents.edge();}
  public net.minecraftforge.client.model.data.ModelData getModelData(){var fill=contents;return net.minecraftforge.client.model.data.ModelData.builder().with(MATERIAL,fill.material()).with(CAP,fill.cap()).with(EDGE,fill.edge()).with(OUTLINE,fill.outline()).build();}
  public RoadFillEntity(class_2338 pos,class_2680 state){super(SplineRoads.FILL_ENTITY.get(),pos,state);}
  public class_2680 fill(){return contents.material();}
  /** Stable cheap fallback even if another renderer queries the entity. Never ask collision for bounds. */
  public class_238 getRenderBoundingBox(){return new class_238(field_11867).method_1014(.002);}
  public class_265 collision(class_1922 world,class_2338 pos,class_3726 context,class_265 road){
    // Chunk mesh/light workers and the main thread can query/update the same entity.
    // Read each immutable snapshot once; never expose partially cleared shape fields.
    var fill=contents;var previous=cached;
    class_265 raw=fill.material().method_26194(world,pos,context);
    if(previous!=null&&previous.fill()==fill&&previous.raw()==raw&&previous.road()==road)return previous.shape();
    class_265 clipped=fill.cap()>=1||raw.method_1110()?raw:class_259.method_1082(raw,class_259.method_1081(0,0,0,1,fill.cap(),1),class_247.field_16896);
    if(!fill.edge().isEmpty()||!fill.outline().isEmpty()){class_265 mask=class_259.method_1073();for(var box:fill.edge())mask=class_259.method_1084(mask,class_259.method_1081(box.x0(),box.y0(),box.z0(),box.x1(),box.y1(),box.z1()));clipped=class_259.method_1082(clipped,mask,class_247.field_16896);}
    class_265 shape=class_2248.method_9614(clipped)?class_259.method_1077():clipped.method_1110()?road:road.method_1110()?clipped:class_259.method_1082(road,clipped,class_247.field_1366);
    // A concurrent update may make this result old, but its complete key prevents
    // it being reused for another material, cap or caller's road collision.
    if(contents==fill)cached=new Collision(fill,raw,road,shape);
    return shape;
  }
  private void refresh(){
    cached=null;
    // Fabric: sendBlockUpdated below is the chunk remesh trigger.
    if(field_11863!=null)field_11863.method_8413(field_11867,method_11010(),method_11010(),3);
  }
  public void fill(class_2680 state){fill(state,1);}
  public void fill(class_2680 state,double height){
    var index=field_11863==null?null:RoadBlocks.index(field_11863);var nearby=index==null?java.util.List.<RoadIndex.Built>of():index.inChunk(new net.minecraft.class_1923(field_11867).method_8324()).stream().map(index.roads::get).filter(java.util.Objects::nonNull).toList();
    var edge=RailbedTerrainEdge.data(field_11867,state,nearby);contents=new Fill(state,Math.max(.01,Math.min(1,height)),edge.boxes(),edge.polygons());refresh();method_5431();
  }
  @Override protected void method_11007(class_2487 t){super.method_11007(t);var fill=contents;t.method_10566("Fill",class_2512.method_10686(fill.material()));t.method_10549("TerrainCap",fill.cap());var boxes=new class_2499();for(var box:fill.edge()){var values=new class_2499();for(double v:new double[]{box.x0(),box.y0(),box.z0(),box.x1(),box.y1(),box.z1()})values.add(class_2489.method_23241(v));boxes.add(values);}if(!boxes.isEmpty())t.method_10566("TerrainEdge",boxes);var outline=new class_2499();for(var poly:fill.outline()){var points=new class_2499();for(var point:poly){points.add(class_2489.method_23241(point.x()));points.add(class_2489.method_23241(point.z()));}outline.add(points);}if(!outline.isEmpty())t.method_10566("TerrainOutline",outline);}
  @Override public void method_11014(class_2487 t){super.method_11014(t);var boxes=new java.util.ArrayList<com.sora.splineroads.core.RoadRaster.Box>();var list=t.method_10554("TerrainEdge",class_2520.field_33259);if(list.size()<=256)for(var item:list){var v=(class_2499)item;if(v.size()!=6)continue;double a=v.method_10611(0),b=v.method_10611(1),c=v.method_10611(2),d=v.method_10611(3),e=v.method_10611(4),f=v.method_10611(5);if(a>=0&&b>=0&&c>=0&&d<=1&&e<=1&&f<=1&&a<d&&b<e&&c<f)boxes.add(new com.sora.splineroads.core.RoadRaster.Box(a,b,c,d,e,f));}var outlines=new java.util.ArrayList<java.util.List<com.sora.splineroads.core.RoadGeometry.V>>();var polygons=t.method_10554("TerrainOutline",class_2520.field_33259);if(polygons.size()<=128)for(var item:polygons){var v=(class_2499)item;if(v.size()<6||v.size()>64||v.size()%2!=0)continue;var points=new java.util.ArrayList<com.sora.splineroads.core.RoadGeometry.V>();for(int i=0;i<v.size();i+=2){double x=v.method_10611(i),z=v.method_10611(i+1);if(!Double.isFinite(x)||!Double.isFinite(z)||x< -1e-7||x>1.0000001||z< -1e-7||z>1.0000001){points.clear();break;}points.add(new com.sora.splineroads.core.RoadGeometry.V(x,0,z));}if(points.size()>2)outlines.add(java.util.List.copyOf(points));}contents=new Fill(class_2512.method_10681(class_7923.field_41175.method_46771(),t.method_10562("Fill")),t.method_10545("TerrainCap")?Math.max(.01,Math.min(1,t.method_10574("TerrainCap"))):1,java.util.List.copyOf(boxes),java.util.List.copyOf(outlines));refresh();}
  @Override public class_2487 method_16887(){return method_38244();}
  @Override public class_2622 method_38235(){return class_2622.method_38585(this);}
}
