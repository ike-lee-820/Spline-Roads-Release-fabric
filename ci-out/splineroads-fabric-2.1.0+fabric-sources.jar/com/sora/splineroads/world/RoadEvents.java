package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraftforge.common.util.BlockSnapshot;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.level.*;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SplineRoads.ID)
public final class RoadEvents {
  @SubscribeEvent
  public static void infill(net.minecraftforge.event.entity.player.PlayerInteractEvent.RightClickBlock e) {
    if(!(e.getItemStack().method_7909() instanceof net.minecraft.class_1747 item)||e.getFace()==null)return;
    var level=e.getLevel();var fill=item.method_7711().method_9564();
    var target=e.getPos().method_10093(e.getFace());
    var hit=e.getHitVec().method_17784();double coordinate=switch(e.getFace().method_10166()){case field_11048->hit.field_1352-e.getPos().method_10263();case field_11052->hit.field_1351-e.getPos().method_10264();case field_11051->hit.field_1350-e.getPos().method_10260();};
    boolean inside=coordinate>.001&&coordinate<.999;
    var index=RoadBlocks.index(level);
    // Complete a partial equipment beam cell first, so the attached block touches its surface.
    if(inside&&index!=null&&RoadBlocks.gantryCell(index,e.getPos())&&RoadBlocks.canInfill(level,e.getPos(),fill))target=e.getPos();
    else if(!RoadBlocks.canInfill(level,target,fill)) {
      if(!inside)return;
      target=e.getPos();if(!RoadBlocks.canInfill(level,target,fill))return;
    }
    var context=net.minecraft.class_1750.method_16355(
        new net.minecraft.class_1750(e.getEntity(),e.getHand(),e.getItemStack(),e.getHitVec()),target,e.getFace());
    fill=item.method_7711().method_9605(context);
    if(fill==null||!RoadBlocks.canInfill(level,target,fill))return;
    if(!e.getEntity().method_7294()||!e.getEntity().method_7343(target,e.getFace(),e.getItemStack()))return;
    if(level instanceof class_3218 server&&e.getEntity() instanceof net.minecraft.class_3222 player) {
      var snapshot=net.minecraftforge.common.util.BlockSnapshot.create(level.method_27983(),level,target);
      final var placed=fill;
      var placeEvent=new BlockEvent.EntityPlaceEvent(snapshot,level.method_8320(target.method_10093(e.getFace().method_10153())),player){
        @Override public net.minecraft.class_2680 getPlacedBlock(){return placed;}
        @Override public net.minecraft.class_2680 getState(){return placed;}
      };
      if(net.minecraftforge.common.MinecraftForge.EVENT_BUS.post(placeEvent))return;
      if(!RoadData.get(server).infill(server,target,fill,player))return;
      if(!player.method_7337())e.getItemStack().method_7934(1);
      level.method_8396(null,target,fill.method_26231().method_10598(),net.minecraft.class_3419.field_15245,1,.8f);
    }
    e.setCanceled(true);e.setCancellationResult(net.minecraft.class_1269.method_29236(level.field_9236));
  }
  @SubscribeEvent
  public static void watch(ChunkWatchEvent.Watch e) {
    RoadNetwork.watch(e.getPlayer(), e.getPos().method_8324(), true);
    RoadData data = RoadData.get(e.getLevel());
    data.repairChunk(e.getLevel(), e.getPos());
    RoadIndex index = data.index;
    for (UUID id : index.inChunk(e.getPos().method_8324()))
      RoadNetwork.road(e.getPlayer(), index.roads.get(id).record);
  }

  @SubscribeEvent
  public static void unwatch(ChunkWatchEvent.UnWatch e) {
    RoadNetwork.watch(e.getPlayer(), e.getPos().method_8324(), false);
  }

  @SubscribeEvent
  public static void dimension(PlayerEvent.PlayerChangedDimensionEvent e) {
    if (e.getEntity() instanceof net.minecraft.class_3222 player){
      RoadSplitter.cancel(player.method_5667());RoadData.forgetPreviews(player.method_5667());RoadNetwork.dimensionChanged(player);
    }
  }

  @SubscribeEvent
  public static void breakBlock(BlockEvent.BreakEvent e) {
    if(RailbedBuildQueue.protectionProbe()||RoadEditProtection.probing)return;
    if (e.getLevel() instanceof class_3218 level) {
      RoadData data = RoadData.get(level);
      if (RoadBlocks.isCollider(e.getState())
          && e.getPlayer() instanceof net.minecraft.class_3222 player
          && data.excavateSupport(level, e.getPos(), player)) {
        e.setCanceled(true);
        return;
      }
      if (RoadBlocks.isCollider(e.getState()) || data.linked(e.getPos())) {
        e.setCanceled(true);
        e.getPlayer().method_7353(class_2561.method_43470("请用道路连接器删除相连道路，再拆除端点"), true);
      } else if (level.method_8321(e.getPos()) instanceof NodeEntity n
          && n.owner != null
          && !n.owner.equals(e.getPlayer().method_5667())
          && !e.getPlayer().method_5687(2)) e.setCanceled(true);
    }
  }

  @SubscribeEvent
  public static void explosion(ExplosionEvent.Detonate e) {
    if (e.getLevel() instanceof class_3218 level) {
      RoadData d = RoadData.get(level);
      e.getAffectedBlocks()
          .removeIf(p -> d.linked(p) || RoadBlocks.isCollider(level.method_8320(p)));
    }
  }

  @SubscribeEvent
  public static void tick(net.minecraftforge.event.TickEvent.ServerTickEvent e){
    if(e.phase==net.minecraftforge.event.TickEvent.Phase.END){RoadNetwork.tick(e.getServer());ManualPlanner.tick();RailbedBuildQueue.tick(e.getServer());if(e.getServer().method_3780()%100==0)RoadData.expirePreviews();}
  }
  @SubscribeEvent
  public static void stop(net.minecraftforge.event.server.ServerStoppingEvent e){ManualPlanner.stop();RailbedBuildQueue.stop();RoadSplitter.clear();RoadData.clearPreviews();RoadNetwork.stop();}
  @SubscribeEvent
  public static void logout(PlayerEvent.PlayerLoggedOutEvent e) {
    if(e.getEntity() instanceof net.minecraft.class_3222 p)ManualPlanner.forget(p);RoadNetwork.forget(e.getEntity().method_5667());RoadData.forgetPreviews(e.getEntity().method_5667());
  }
}
