package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.JunctionPlanner.Piece;
import com.sora.splineroads.core.JunctionPlanner.Plan;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.nio.charset.StandardCharsets;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Two attached points share a branch seam and one atomic assembly/restore receipt. */
public final class PairedSideJunctions {
  static boolean saved(RoadData data,UUID id){return id!=null&&data.junctions.getOrDefault(id,new class_2487()).method_10577("Paired");}
  public static class_2487 create(class_3218 level,class_3222 player,UUID a,UUID pa,UUID b,UUID pb,Settings settings){
    if(a.equals(b))throw new IllegalArgumentException("请选择两条不同主路的附属点");
    var data=RoadData.get(level);var first=data.index.roads.get(a);var second=data.index.roads.get(b);
    for(var road:Arrays.asList(first,second))if(road==null||!SideHosts.attachable(road.record))throw new IllegalArgumentException("请选择两条普通主路路段的附属点");
    var t=new class_2487();t.method_10556("OneSided",true);t.method_10556("Paired",true);t.method_25927("Main",a);t.method_25927("AttachedPoint",pa);t.method_25927("MainB",b);t.method_25927("AttachedPointB",pb);t.method_10556("MainFirst",true);
    t.method_10566("OriginalMain",SideHosts.original(data,first.record).save());t.method_10566("OriginalMainB",SideHosts.original(data,second.record).save());t.method_10566("Fallback",RoadRecord.writeSettings(settings));
    return fresh(level,player,t);
  }
  public static class_2487 payload(class_3218 level,class_3222 player,UUID id){
    var t=RoadData.get(level).junctions.get(id);if(t==null||!t.method_10577("Paired"))throw new IllegalArgumentException("双附属点连接已不存在");
    if(player!=null)RoadData.requireOwner(player,t.method_25926("Owner"));return fresh(level,player,t.method_10553());
  }
  private static V point(RoadRecord road,UUID id){return road.settings().options().attachments().points().stream().filter(p->p.id().equals(id)).findFirst().orElseThrow(()->new IllegalArgumentException("附属点已变化，请重新选择")).position();}
  private static class_2487 fresh(class_3218 level,class_3222 player,class_2487 t){
    var a=RoadRecord.load(t.method_10562("OriginalMain"));var b=RoadRecord.load(t.method_10562("OriginalMainB"));
    V av=point(a,t.method_25926("AttachedPoint")),bv=point(b,t.method_25926("AttachedPointB")),mid=av.add(bv).mul(.5);
    if(av.distance(bv)<48)throw new IllegalArgumentException("两附属点距离不足，请至少预留48格连接空间");
    var node=new Node(mid,RoadPlanner.yaw(bv.sub(av)),0);var pos=class_2338.method_49637(mid.x(),mid.y(),mid.z());
    t.method_10544("Branch",pos.method_10063());t.method_10566("BranchNode",RoadRecord.writeNode(node));
    for(int side=0;side<2;side++){
      var input=t.method_10553();input.method_10551("Paired");input.method_25927("Main",side==0?a.id():b.id());input.method_25927("AttachedPoint",t.method_25926(side==0?"AttachedPoint":"AttachedPointB"));input.method_10556("MainFirst",side==0);
      if(side==1){input.method_10551("Spec");if(t.method_10545("PairSpec"))input.method_10566("Spec",t.method_10562("PairSpec").method_10553());}
      var result=OneSidedJunctions.fresh(level,player,input,side==0?a:b,node);
      t.method_10566(side==0?"Spec":"PairSpec",result.method_10562("Spec"));t.method_10569(side==0?"MainSignature":"MainSignatureB",result.method_10550("MainSignature"));
    }
    t.method_10582("Kind","junction");t.method_10569("SelectedArm",2);t.method_10564("Points",new long[]{a.a().method_10063(),a.b().method_10063(),b.a().method_10063(),b.b().method_10063(),pos.method_10063()});return t;
  }
  public static String build(class_3218 level,class_3222 player,class_2487 command){
    return build(level,player,command,null);
  }
  static String build(class_3218 level,class_3222 player,class_2487 command,Settings roadSettings){
    try(var work=RoadWorkChunks.open(level)){
      var data=RoadData.get(level);boolean editing=command.method_25928("Id");UUID group=editing?command.method_25926("Id"):UUID.randomUUID();
      var t=editing?payload(level,player,group):create(level,player,command.method_25926("Main"),command.method_25926("AttachedPoint"),command.method_25926("MainB"),command.method_25926("AttachedPointB"),RoadRecord.readSettings(command.method_10562("Fallback")));
      if(t.method_10550("MainSignature")!=command.method_10550("MainSignature")||t.method_10550("MainSignatureB")!=command.method_10550("MainSignatureB"))throw new IllegalArgumentException("道路在预览后发生变化，请重新选择");
      if(roadSettings!=null){
        if(SideRoads.signature(t)!=command.method_10550("Signature"))throw new IllegalArgumentException("连接道路或路口已变化，请重新打开道路编辑器");
        t.method_10566("ConnectionSettings",RoadRecord.writeSettings(roadSettings));t=fresh(level,player,t);
      }
      var originals=List.of(RoadRecord.load(t.method_10562("OriginalMain")),RoadRecord.load(t.method_10562("OriginalMainB")));
      var removed=new HashSet<UUID>();originals.forEach(r->removed.add(r.id()));if(editing)data.index.roads.values().stream().filter(r->group.equals(r.record.assembly())).forEach(r->removed.add(r.record.id()));
      var built=new ArrayList<RoadIndex.Built>();var nodes=new HashSet<class_2338>();var seam=class_2338.method_10092(t.method_10537("Branch"));nodes.add(seam);
      for(int side=0;side<2;side++){
        String key=side==0?"Spec":"PairSpec";var authority=t.method_10553();authority.method_10566("Spec",t.method_10562(key));var request=command.method_10553();request.method_10566("Spec",command.method_10562(key));
        var spec=roadSettings==null?OneSidedJunctions.validated(authority,request):JunctionCodec.read(t.method_10562(key));OneSidedJunction.prepare(spec);t.method_10566(key,JunctionCodec.write(spec));
        var original=originals.get(side);nodes.add(original.a());nodes.add(original.b());var plan=JunctionPlanner.plan(spec);var center=class_2338.method_49637(spec.center().x(),spec.center().y(),spec.center().z());
        for(int i=0;i<plan.pieces().size();i++){
          var p=plan.pieces().get(i);var mesh=p.mesh();boolean retained=p.arm()==-3;
          if(retained){built.add(new RoadIndex.Built(SideHosts.retained(data,original,group,spec)));continue;}
          UUID id=retained?original.id():UUID.nameUUIDFromBytes((group+":paired:"+side+":"+i).getBytes(StandardCharsets.UTF_8));
          var start=retained?original.start():new Node(mesh.first().center(),RoadPlanner.yaw(mesh.first().left().left().mul(-1)),0);
          var end=retained?original.end():new Node(mesh.last().center(),RoadPlanner.yaw(mesh.last().left().left().mul(-1)),0);
          built.add(new RoadIndex.Built(new RoadRecord(id,original.owner(),retained?original.a():p.arm()==2?seam:center,retained?original.b():center,start,end,retained?original.settings():mesh.settings(),false,4).junction(group,new JunctionPlanner.Ref(spec,i))));
        }
      }
      for(var proposed:built)for(var old:data.index.roads.values())if(!removed.contains(old.record.id())&&RoadIndex.overlapXZ(proposed.mesh,old.mesh,1))Interchanges.checkExternal(proposed.mesh,old.mesh,null);
      // The seam is an internal logical port, not a player endpoint block.
      data.replaceAssembly(level,player,built,removed,nodes);
      t.method_25927("Id",group);t.method_25927("Owner",originals.get(0).owner());data.junctions.put(group,t);data.method_80();return "双附属点连接已保存：两端单边路口，单行方向 A→B";
    }
  }
  public static void remove(class_3218 level,class_3222 player,UUID group){
    SideHosts.remove(level,player,group);
  }
  private PairedSideJunctions(){}
}
