package com.sora.splineroads.world;

import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.core.RoadRaster;
import com.sora.splineroads.core.RoadRaster.Cell;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_247;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_7923;
import net.minecraft.core.*;
import net.minecraft.world.phys.shapes.*;

/** Derived contact only. Vanilla states, inventories, drops and the road ledger are untouched. */
public final class SidewalkBlockContact {
  public static boolean eligible(class_1922 level,class_2338 pos,class_2680 state){
    return class_7923.field_41175.method_10221(state.method_26204()).method_12836().equals("minecraft")
        && !state.method_26215()&&!state.method_31709()&&state.method_26227().method_15769()
        && class_2248.method_9614(state.method_26220(level,pos));
  }
  public static double bottom(class_1922 level,RoadIndex index,class_2338 pos,class_2680 state){
    if(index==null||!RoadBlocks.isCollider(level.method_8320(pos.method_10074()))||!eligible(level,pos,state))return 0;
    var faces=new ArrayList<List<V>>();var cell=new RoadRaster.Cell(pos.method_10263(),pos.method_10264()-1,pos.method_10260());
    synchronized(index){
      for(var id:index.inChunk(new class_1923(pos).method_8324())){
        var built=index.roads.get(id);if(built!=null)faces.addAll(built.prepareCollision().structureTops(cell,p->p.material().name().startsWith("WALK_")));
      }
    }
    return com.sora.splineroads.core.SidewalkBlockContact.bottom(pos.method_10263(),pos.method_10264(),pos.method_10260(),faces);
  }
  public static class_265 collision(class_1922 level,class_2338 pos,RoadIndex index,class_265 road){
    var upper=pos.method_10084();double bottom=bottom(level,index,upper,level.method_8320(upper));
    return bottom<0?class_259.method_1082(road,class_259.method_1081(0,1+bottom,0,1,1,1),class_247.field_1366):road;
  }
  private SidewalkBlockContact(){}
}
