package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.LanePoints.Data;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadSlicing.Fragment;
import com.sora.splineroads.core.RoadTransitions.Ends;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Reclaim only unchanged, still connected continuations recorded by this assembly. */
final class ContinuousReclaim {
  /** Only this transaction may snapshot its own incidental normalization of an
   * ordinary source that was byte-for-byte unchanged immediately before commit.
   * This does not authorize reclamation or relax any later topology check. */
  static Set<UUID> snapshotCandidates(RoadData data,class_2487 tag,UUID owner){
    var result=new HashSet<UUID>();
    for(var value:tag.method_10554("ContinuousSources",class_2520.field_33260)){
      var q=(class_2487)value;if(!q.method_10577("Detached"))continue;
      var saved=RoadRecord.load(q.method_10562("Road"));var built=data.index.roads.get(saved.id());
      if(built==null)continue;var live=built.record;
      if(live.assembly()==null&&live.junction()==null&&live.toll()==null&&owner.equals(live.owner())
          &&saved.header().equals(live.header()))result.add(live.id());
    }
    return Set.copyOf(result);
  }
  static boolean eligible(class_2487 tag,UUID id){
    for(class_2520 value:tag.method_10554("ContinuousSources",class_2520.field_33260)){
      var q=(class_2487)value;
      if(q.method_10562("Road").method_25928("Id")&&q.method_10562("Road").method_25926("Id").equals(id))
        return !q.method_10577("Detached")||q.method_10577("Reclaimable");
    }return false;
  }

  static void refresh(RoadData data,class_2487 tag){
    var result=new class_2499();var candidates=new HashMap<UUID,class_2487>();
    var records=new HashMap<UUID,RoadRecord>();var roots=new HashSet<UUID>();var axes=new HashMap<UUID,Integer>();
    for(class_2520 value:tag.method_10554("ContinuousSources",class_2520.field_33260)){
      var q=((class_2487)value).method_10553();q.method_10551("Reclaimable");
      var old=RoadRecord.load(q.method_10562("Road"));var built=data.index.roads.get(old.id());
      var live=built==null?null:built.record;axes.put(old.id(),q.method_10550("Axis"));
      // Old descriptors left unused captured neighbours active. Only a live
      // member of this saved parent may refresh an active source in place.
      // Brand-new captures have no parent ID and are not reclassified here.
      boolean outside=tag.method_25928("Id")&&!q.method_10577(ContinuousService.LOGICAL)
          &&(live==null||!InterchangeJunctions.belongs(data,tag.method_25926("Id"),live.assembly()));
      if(q.method_10577("Detached")||outside){
        q.method_10556("Detached",true);
        // Retain missing/edited provenance as a protected range, never recreate it.
        if(live!=null&&live.assembly()==null&&live.junction()==null&&live.toll()==null
            &&live.owner().equals(old.owner())&&(!tag.method_25928("Owner")||live.owner().equals(tag.method_25926("Owner")))
            &&RoadContinuity.eligible(live.caps(0).mesh())&&unchanged(q,old,live)){
          candidates.put(old.id(),q);records.put(old.id(),live);
        }
      }else{
        if(live!=null&&!q.method_10577(ContinuousService.LOGICAL)){var refreshed=ContinuousRoads.updatedSource(old,live);q.method_10566("Road",refreshed.header());
          if(tag.method_25928("Id")&&InterchangeJunctions.belongs(data,tag.method_25926("Id"),live.assembly())){roots.add(old.id());records.put(old.id(),refreshed);}}
      }
      result.add(q);
    }
    ContinuousService.refresh(data,tag,roots,records,axes);
    var reached=new HashSet<UUID>(roots);boolean changed;
    do{changed=false;
      for(var item:candidates.entrySet())if(!reached.contains(item.getKey())){
        var road=records.get(item.getKey());
        for(UUID prior:List.copyOf(reached)){
          if(!Objects.equals(axes.get(prior),axes.get(road.id())))continue;
          var other=records.get(prior);class_2338 shared=shared(road,other);if(shared==null)continue;
          var topology=data.index.atNode(shared);
          if(topology.size()!=2||!topology.contains(road.id())||!topology.contains(prior))continue;
          if(!road.owner().equals(other.owner())||!sameProfile(road,other))continue;
          V port=road.a().equals(shared)?road.start().position():road.end().position();
          if(!RoadContinuity.compatible(road.caps(0).mesh(),other.caps(0).mesh(),port))continue;
          reached.add(road.id());item.getValue().method_10556("Reclaimable",true);
          item.getValue().method_10566("Road",road.header());changed=true;break;
        }
      }
    }while(changed);
    tag.method_10566("ContinuousSources",result);
  }

  private static class_2338 shared(RoadRecord a,RoadRecord b){
    if(a.a().equals(b.a())||a.a().equals(b.b()))return a.a();
    return a.b().equals(b.a())||a.b().equals(b.b())?a.b():null;
  }
  private static RoadRecord profile(RoadRecord road){
    var tag=road.header();var infra=tag.method_10562("Settings").method_10562("Infrastructure");
    // sameSettings already removes generated automatic station entries. Their
    // fixed/list mode is generated by range slicing too; authored edits remain.
    if(infra.method_10554("GantryEdits",class_2520.field_33260).stream().allMatch(v->((class_2487)v).method_10577("Automatic")))
      infra.method_10556("FixedStations",false);
    return RoadRecord.load(tag);
  }
  private static boolean sameProfile(RoadRecord a,RoadRecord b){return ContinuousRoads.sameSettings(profile(a),profile(b));}

  static boolean unchanged(class_2487 item,RoadRecord saved,RoadRecord live){
    if(saved.header().equals(live.header()))return true;
    if(item.method_10577("DetachedExact"))return false;
    // Pre-fix saves kept the range descriptor rather than the committed donor.
    // Only this known materialization is accepted; all other fields stay exact.
    var fragment=saved.fragment();
    if(fragment==null||live.fragment()!=null||fragment.connection()!=RoadSlicing.Connection.CONTINUOUS
        ||!fragment.supports().isEmpty()||!fragment.curveAnchors().isEmpty()
        ||!fragment.applied().points().isEmpty()||!fragment.applied().spans().isEmpty()
        ||!saved.caps(0).mesh().samples().equals(live.caps(0).mesh().samples()))return false;
    var a=saved.header();var b=live.header();var old=a.method_10562("Settings");var now=b.method_10562("Settings");
    var ends=saved.settings().options().ends();var current=live.settings().options().ends();
    double length=saved.caps(0).mesh().length();
    if(ends.start()!=null||ends.end()!=null||ends.port()!=null||ends.persistent()||ends.startHold()!=0||ends.endHold()!=0
        ||!current.equals(RoadTransitions.Ends.NONE)||ends.paintPhase()!=0
        ||Math.abs(ends.trimmedStart()-fragment.origin())>1e-9
        ||Math.abs(ends.trimmedEnd()-(fragment.total()-fragment.origin()-length))>1e-9)return false;
    old.method_10551("TrimmedStart");old.method_10551("TrimmedEnd");
    var oi=old.method_10562("Infrastructure");var ni=now.method_10562("Infrastructure");
    if(oi.method_10577("FixedStations")&&!ni.method_10577("FixedStations")
        &&ni.method_10554("GantryEdits",class_2520.field_33260).isEmpty()
        &&oi.method_10554("GantryEdits",class_2520.field_33260).stream().allMatch(v->((class_2487)v).method_10577("Automatic"))){
      oi.method_10556("FixedStations",false);oi.method_10566("GantryEdits",new class_2499());
    }
    var md=saved.settings().options().lanePoints();var mesh=live.mesh();
    var snapped=md.points().stream().map(p->p.automatic()
        ?LanePoints.point(p.id(),p.origin(),mesh,p.origin()==LanePoints.Origin.AUTOMATIC_START?0:mesh.length(),p.lane()):p).toList();
    old.method_10566("LanePointsV2",RoadRecord.writeSettings(saved.settings().options(saved.settings().options().lanePoints(md.points(snapped)))).method_10562("LanePointsV2"));
    a.method_10551("Alignment");b.method_10551("Alignment");a.method_10551("Slice");
    return a.equals(b);
  }

  /** A deleted, edited or disconnected old donor remains outside our authority. */
  static void requireClear(class_2487 tag,int axis,Mesh generated){
    V origin=generated.first().center(),direction=generated.last().center().sub(origin).horizontalUnit();
    double total=generated.last().center().sub(origin).dot(direction);
    for(class_2520 value:tag.method_10554("ContinuousSources",class_2520.field_33260)){
      var q=(class_2487)value;if(q.method_10550("Axis")!=axis||!q.method_10577("Detached")||q.method_10577("Reclaimable"))continue;
      var road=RoadRecord.load(q.method_10562("Road"));double a=road.start().position().sub(origin).dot(direction),b=road.end().position().sub(origin).dot(direction);
      if(Math.min(Math.max(a,b),total)-Math.max(Math.min(a,b),0)>1e-5)
        throw new IllegalArgumentException("原立交外侧余段已修改、删除或不再连续，不能自动占用；请先单独处理该道路");
    }
  }
  private ContinuousReclaim(){}
}
