package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RailbedPath.Point;
import com.sora.splineroads.core.RailbedPath.Segment;
import com.sora.splineroads.core.RoadGeometry.*;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import java.util.*;

/** SR owns these snapshots; loading them never asks MTR to recreate a rail. */
public final class RailbedCodec {
  public static class_2487 options(RailbedOptions value){
    var t=new class_2487();t.method_10556("LeftRail",value.leftRail());t.method_10556("RightRail",value.rightRail());t.method_10556("Catenary",value.catenary());
    t.method_10549("PoleSpacing",value.poleSpacing());t.method_10549("WireHeight",value.wireHeight());t.method_10569("SingleSide",value.singleSide());t.method_10582("Bridge",value.bridge().name());t.method_10582("Tunnel",value.tunnel().name());t.method_10582("Fence",value.fence().name());return t;
  }
  public static RailbedOptions options(class_2487 tag){
    if(tag.method_33133())return RailbedOptions.DEFAULT;
    return new RailbedOptions(tag.method_10577("LeftRail"),tag.method_10577("RightRail"),tag.method_10577("Catenary"),tag.method_10574("PoleSpacing"),tag.method_10574("WireHeight"),tag.method_10550("SingleSide"),tag.method_10545("Bridge")?RoadInfrastructure.Bridge.valueOf(tag.method_10558("Bridge")):RoadInfrastructure.Bridge.STANDARD,tag.method_10545("Tunnel")?RoadInfrastructure.Tunnel.valueOf(tag.method_10558("Tunnel")):RoadInfrastructure.Tunnel.BOX,tag.method_10545("Fence")?RailbedOptions.Fence.valueOf(tag.method_10558("Fence")):RailbedOptions.Fence.SOLID);
  }
  public static class_2487 write(RailbedPath.Path path){var out=new class_2487();var segments=new class_2499();
    for(var s:path.segments()){var t=new class_2487();t.method_10582("Id",s.id());t.method_10544("From",pos(s.from()).method_10063());t.method_10544("To",pos(s.to()).method_10063());t.method_10556("Reverse",s.reverse());t.method_10549("Length",s.length());
      var styles=new class_2499();s.styles().forEach(style->styles.add(class_2519.method_23256(style)));t.method_10566("Styles",styles);
      var points=new class_2499();for(var p:s.points()){var q=new class_2487();q.method_10549("S",p.parameter());q.method_10549("X",p.position().x());q.method_10549("Y",p.position().y());q.method_10549("Z",p.position().z());points.add(q);}t.method_10566("Points",points);segments.add(t);}
    out.method_10566("Segments",segments);return out;}
  public static RailbedPath.Path read(class_2487 tag){var segments=new ArrayList<RailbedPath.Segment>();var list=tag.method_10554("Segments",class_2520.field_33260);if(list.size()>RailbedPath.MAX_SEGMENTS)throw new IllegalArgumentException("铁路快照轨段数量超限");int count=0;
    for(class_2520 raw:list){var t=(class_2487)raw;var source=t.method_10554("Points",class_2520.field_33260);count+=source.size();if(count>RailbedPath.MAX_POINTS)throw new IllegalArgumentException("铁路快照采样数量超限");var points=new ArrayList<RailbedPath.Point>();for(class_2520 r:source){var p=(class_2487)r;points.add(new RailbedPath.Point(p.method_10574("S"),new V(p.method_10574("X"),p.method_10574("Y"),p.method_10574("Z"))));}
      var styles=t.method_10554("Styles",class_2520.field_33258).stream().map(class_2520::method_10714).toList();segments.add(new RailbedPath.Segment(t.method_10558("Id"),node(class_2338.method_10092(t.method_10537("From"))),node(class_2338.method_10092(t.method_10537("To"))),t.method_10577("Reverse"),t.method_10574("Length"),styles,points));}
    return new RailbedPath.Path(segments);}
  public static class_2338 pos(RailbedPath.Node p){return new class_2338(p.x(),p.y(),p.z());}
  public static RailbedPath.Node node(class_2338 p){return new RailbedPath.Node(p.method_10263(),p.method_10264(),p.method_10260());}
  public static net.minecraft.class_2487 profile(com.sora.splineroads.core.RailbedProfile value){
    var tag=new net.minecraft.class_2487();var paths=new net.minecraft.class_2499();value.paths().forEach(p->paths.add(write(p)));tag.method_10566("Paths",paths);tag.method_10549("Width",value.requestedWidth());tag.method_10566("Fittings",options(value.fittings()));return tag;
  }
  public static com.sora.splineroads.core.RailbedProfile profile(net.minecraft.class_2487 tag){return new com.sora.splineroads.core.RailbedProfile(tag.method_10554("Paths",net.minecraft.class_2520.field_33260).stream().map(t->read((net.minecraft.class_2487)t)).toList(),tag.method_10574("Width"),options(tag.method_10562("Fittings")));}
  private RailbedCodec(){}
}
