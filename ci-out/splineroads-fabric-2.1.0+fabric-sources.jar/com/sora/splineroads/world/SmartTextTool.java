package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.core.SmartSigns.*;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import java.util.*;

/** Ray tests the integrated board plane; signs need no independent block entities. */
public final class SmartTextTool extends class_1792 {
  public SmartTextTool(){super(new class_1793().method_7889(1));}
  public record Hit(State state,Field field,double distance){}
  public static Hit hit(V eye,V direction,Collection<State> states,RoadIndex index){Hit best=null;for(var s:states){var b=index.roads.get(s.key().road());if(b==null||s.target()==null||!SmartSigns.valid(b.mesh,s))continue;if(SmartSigns.anchor(b.mesh,s).distance(eye)>144)continue;for(var layout:SmartSigns.views(SmartSigns.layout(b.mesh,s),s.mode())){double facing=direction.dot(layout.front());if(facing>=-1e-5)continue;double t=layout.origin().add(layout.front().mul(SmartSigns.TEXT)).sub(eye).dot(layout.front())/facing;if(t<0||t>96||best!=null&&t>=best.distance())continue;V at=eye.add(direction.mul(t)).sub(layout.origin());double x=at.dot(layout.right()),y=at.y();for(var board:layout.boards())if(!board.branch().equals("emergency")&&Math.abs(x-board.x())<=board.width()/2&&y>=board.bottom()&&y<=board.top()){Field field=s.mode()==Mode.LANE_INDICATOR?new Field(board.branch()+"/status",board.x(),(board.bottom()+board.top())/2,board.width(),board.height(),1):layout.fields().stream().filter(f->f.editable()&&Math.abs(x-f.x())<=f.width()/2&&Math.abs(y-f.y())<=f.height()/2).findFirst().orElseGet(()->layout.fields().stream().filter(Field::editable).min(Comparator.comparingDouble(f->Math.hypot(x-f.x(),y-f.y()))).orElse(null));if(field!=null)best=new Hit(s,field,t);}}}
    return best;
  }
  private static void open(class_3222 p){if(!p.method_7294()||p.method_7325())return;try{var t=new class_2487();if(p.method_5715()){t.method_10582("Kind","smartTextReset");RoadNetwork.open(p,t);return;}
      var data=RoadData.get(p.method_51469());var eye=p.method_33571();var dir=p.method_5720();var candidates=new LinkedHashSet<State>();var ids=new HashSet<UUID>();var at=p.method_24515();for(int x=(at.method_10263()>>4)-6;x<=(at.method_10263()>>4)+6;x++)for(int z=(at.method_10260()>>4)-6;z<=(at.method_10260()>>4)+6;z++)ids.addAll(data.index.inChunk(net.minecraft.class_1923.method_8331(x,z)));for(UUID id:ids)candidates.addAll(data.smartSigns.road(id));candidates.addAll(data.smartSigns.nearSupports(new V(eye.field_1352,eye.field_1351,eye.field_1350)));
      var hit=hit(new V(eye.field_1352,eye.field_1351,eye.field_1350),new V(dir.field_1352,dir.field_1351,dir.field_1350),candidates,data.index);if(hit==null){t.method_10582("Kind","smartTextResume");RoadNetwork.open(p,t);p.method_7353(class_2561.method_43470("请对准智能标牌或车道指示牌正面右键"),true);return;}
      var b=data.index.roads.get(hit.state().key().road());RoadData.requireOwner(p,b.record.owner());t.method_10582("Kind","smartText");t.method_10566("Sign",SmartSignCodec.write(hit.state()));t.method_10566("Road",b.record.header());t.method_10582("Field",hit.field().id());RoadNetwork.open(p,t);
    }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}}
  @Override public class_1269 method_7884(class_1838 c){if(c.method_8036() instanceof class_3222 p)open(p);return class_1269.method_29236(c.method_8045().field_9236);}
  @Override public class_1271<class_1799> method_7836(class_1937 l,class_1657 p,class_1268 h){if(p instanceof class_3222 s)open(s);return class_1271.method_29237(p.method_5998(h),l.field_9236);}
  @Override public void method_7851(class_1799 s,class_1937 l,List<class_2561> lines,class_1836 f){lines.add(class_2561.method_43470("右键智能标牌填写文字；右键车道指示牌设置通行／禁行"));lines.add(class_2561.method_43470("Shift＋右键清除临时选择，不删除已保存文字"));}
}
