package com.sora.splineroads.world;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

public final class TollTool extends class_1792 {
  private record Preview(long request,UUID token) {}
  private static final Map<class_3222,Preview> PREVIEWS=new WeakHashMap<>();
  public TollTool(){super(new class_1793().method_7889(1));}
  public static void rememberPreview(class_3222 player,class_1799 stack,class_2487 command,class_2487 inputs){
    var saved=new class_2487();saved.method_10544("Request",command.method_10537("Request"));saved.method_25927("Token",inputs.method_25926("Token"));
    stack.method_7948().method_10566("TollPreview",saved);PREVIEWS.put(player,new Preview(saved.method_10537("Request"),saved.method_25926("Token")));
  }
  public static void cancelPreview(class_3222 player,class_2487 command){
    var saved=PREVIEWS.get(player);
    if(saved==null||!command.method_10545("Request")||saved.request()!=command.method_10537("Request")
        ||command.method_25928("Token")&&!saved.token().equals(command.method_25926("Token")))return;
    RoadData.forgetPreview(player.method_5667(),saved.token());PREVIEWS.remove(player);
  }
  public static void clearPreviews(){PREVIEWS.clear();}
  private static void clear(class_3222 player,class_1799 stack){
    var state=stack.method_7948();var previous=state.method_10562("TollPreview");
    if(previous.method_25928("Token"))RoadData.forgetPreview(player.method_5667(),previous.method_25926("Token"));
    cancelPreview(player,previous);state.method_10551("Points");state.method_10551("InlineSelection");state.method_10551("TollPreview");
    var t=new class_2487();t.method_10582("Kind","tollReset");t.method_10544("Request",previous.method_10537("Request"));RoadNetwork.open(player,t);
  }
  static void inlineSelection(class_1799 stack,class_2487 payload){var tag=stack.method_7948();tag.method_10551("Points");tag.method_10582("Dimension",payload.method_10558("Dimension"));tag.method_10566("InlineSelection",payload.method_10553());}
  private static void edit(class_3222 p,RoadRecord r){RoadNetwork.open(p,TollRoads.payload(p.method_51469(),p,new long[0],r.id()));}
  private static void clearClient(){var reset=new class_2487();reset.method_10582("Kind","tollReset");RoadTool.openClient.accept(reset);}
  @Override public class_1269 method_7884(class_1838 context){
    if(context.method_8045().field_9236){if(context.method_8036()!=null&&context.method_8036().method_5715())clearClient();return class_1269.field_5812;}
    if(!(context.method_8036() instanceof class_3222 p))return class_1269.field_5811;
    if(p.method_5715()){clear(p,context.method_8041());return class_1269.field_21466;}
    try(var chunks=RoadWorkChunks.open(p.method_51469())){
      var level=p.method_51469();var at=RoadTool.endpointAtHit(context);var data=RoadData.get(level);
      var station=TollRoads.at(data,at);if(station!=null){edit(p,station);return class_1269.field_21466;}
      var hit=RoadTool.pick(p);if(!(level.method_8321(at) instanceof NodeEntity)){if(hit!=null&&hit.record.toll()!=null){edit(p,hit.record);return class_1269.field_21466;}if(hit!=null){var location=context.method_17698();var t=InlineTollRoads.payload(level,p,hit.record.id(),RoadSplitGeometry.station(hit.mesh,new com.sora.splineroads.core.RoadGeometry.V(location.field_1352,location.field_1351,location.field_1350)));inlineSelection(context.method_8041(),t);RoadNetwork.open(p,t);return class_1269.field_21466;}throw new IllegalArgumentException("收费站生成器：右键道路断面，或依次选择端点 A、B");}
      RoadData.requireNode(level,at,p);var tag=context.method_8041().method_7948();String dimension=level.method_27983().method_29177().toString();
      long[] selected=dimension.equals(tag.method_10558("Dimension"))?tag.method_10565("Points"):new long[0];if(selected.length>=2)selected=new long[0];
      if(selected.length==1&&selected[0]==at.method_10063())throw new IllegalArgumentException("请选择另一个端点 B");
      long[] next=Arrays.copyOf(selected,selected.length+1);next[selected.length]=at.method_10063();tag.method_10564("Points",next);tag.method_10582("Dimension",dimension);tag.method_10551("InlineSelection");
      if(next.length==2)RoadNetwork.open(p,TollRoads.payload(level,p,next,null));else p.method_7353(class_2561.method_43470("已选 A；请选择站区另一端 B"),true);
    }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}return class_1269.field_21466;
  }
  @Override public class_1271<class_1799> method_7836(class_1937 level,class_1657 who,class_1268 hand){
    var stack=who.method_5998(hand);if(level.field_9236&&who.method_5715())clearClient();if(!level.field_9236&&who instanceof class_3222 p){
      if(p.method_5715())clear(p,stack);else try{
        var hit=RoadTool.pick(p);if(hit!=null&&hit.record.toll()!=null)edit(p,hit.record);
        else {var t=stack.method_7948();if(t.method_10565("Points").length==2&&level.method_27983().method_29177().toString().equals(t.method_10558("Dimension")))RoadNetwork.open(p,TollRoads.payload(p.method_51469(),p,t.method_10565("Points"),null));else {var reply=new class_2487();reply.method_10582("Kind","tollResume");RoadNetwork.open(p,reply);}}
      }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}
    }return class_1271.method_29237(stack,level.field_9236);
  }
  public static void selection(class_3222 p,class_1799 tool,class_2487 t){
    if(t.method_25928("InlineRoad")){var selection=tool.method_7948().method_10562("InlineSelection");if(!selection.method_25928("InlineRoad")||!selection.method_25926("InlineRoad").equals(t.method_25926("InlineRoad"))||selection.method_10574("InlineStation")!=t.method_10574("InlineStation")||selection.method_10550("InlineSignature")!=t.method_10550("InlineSignature"))throw new IllegalArgumentException("收费站断面选择已失效，请重新点击道路");return;}
    if(t.method_25928("Id"))return;var tag=tool.method_7948();
    if(!Arrays.equals(t.method_10565("Points"),tag.method_10565("Points"))||!p.method_37908().method_27983().method_29177().toString().equals(tag.method_10558("Dimension")))throw new IllegalArgumentException("收费站选择已失效，请重新选 A/B");
  }
  @Override public void method_7851(class_1799 s,class_1937 l,List<class_2561> lines,class_1836 f){lines.add(class_2561.method_43470("右键道路断面原位生成；也可选择端点 A、B 独立生成"));lines.add(class_2561.method_43470("Shift＋右键清除临时选择；右键收费站编辑"));}
}
