package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadLanes.Counts;
import com.sora.splineroads.core.RoadProfile.*;
import com.sora.splineroads.core.YJunctionPlanner.Plan;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
public final class YJunctionTool extends class_1792 {
  public YJunctionTool(){super(new class_1793().method_7889(1));}
  @Override public class_1269 method_7884(class_1838 c){
    if(c.method_8045().field_9236)return class_1269.field_5812;
    if(c.method_8036() instanceof class_3222 p)try(var work=RoadWorkChunks.open(p.method_51469())){
      var d=RoadData.get(p.method_51469());class_2338 pos=RoadTool.endpointAtHit(c);var tag=c.method_8041().method_7948();
      if(p.method_5715()){tag.method_10551("Points");p.method_7353(class_2561.method_43470("Y 字选点已清空"),true);return class_1269.field_21466;}
      if(p.method_51469().method_8321(pos) instanceof NodeEntity){
        RoadData.requireNode(p.method_51469(),pos,p);String dim=p.method_37908().method_27983().method_29177().toString();long[] old=dim.equals(tag.method_10558("Dimension"))?tag.method_10565("Points"):new long[0];if(old.length>=3)old=new long[0];for(long k:old)if(k==pos.method_10063())throw new IllegalArgumentException("请选择不同的端点");
        long[] next=Arrays.copyOf(old,old.length+1);next[old.length]=pos.method_10063();tag.method_10564("Points",next);tag.method_10582("Dimension",dim);
        if(next.length==3)RoadNetwork.open(p,payload(p.method_51469(),p,next,null));else p.method_7353(class_2561.method_43470("已选 "+(char)('A'+old.length)+"；接着选择 "+(char)('A'+next.length)+"（A 双向，B 出向，C 入向）"),true);
      }else{var r=RoadTool.pick(p);var saved=r==null?null:d.interchanges.get(r.record.assembly());if(saved==null||!saved.method_10577("YJunction"))throw new IllegalArgumentException("依次选 A/B/C 端点，或右键已有 Y 字路口");RoadNetwork.open(p,payload(p.method_51469(),p,saved.method_10565("Points"),saved.method_25926("Id")));}
    }catch(IllegalArgumentException e){p.method_7353(class_2561.method_43470(e.getMessage()),false);}return class_1269.field_21466;
  }
  @Override public class_1271<class_1799> method_7836(class_1937 l,class_1657 p,class_1268 hand){if(p.method_5715()){p.method_5998(hand).method_7948().method_10551("Points");if(!l.field_9236)p.method_7353(class_2561.method_43470("Y 字选点已清空"),true);}return class_1271.method_29237(p.method_5998(hand),l.field_9236);}
  static class_2487 payload(class_3218 l,class_3222 p,long[] points,UUID id){
    if(points.length!=3||Arrays.stream(points).distinct().count()!=3)throw new IllegalArgumentException("需要 A/B/C 三个不同端点");
    var d=RoadData.get(l);var t=id==null?new class_2487():Interchanges.descriptor(d,id);if(id!=null&&p!=null)RoadData.requireOwner(p,t.method_25926("Owner"));
    t.method_10582("Kind","yJunction");t.method_10556("YJunction",true);t.method_10564("Points",points);if(!t.method_10545("Tension"))t.method_10549("Tension",.4);
    var nodes=new class_2499();int signature=1;
    for(int i=0;i<3;i++){
      var pos=class_2338.method_10092(points[i]);var entity=RoadData.requireNode(l,pos,p);var node=entity.constructionNode();
      var hosts=d.index.atNode(pos).stream().map(d.index.roads::get).filter(r->id==null||!id.equals(r.record.assembly())).toList();
      if(hosts.size()>1)throw new IllegalArgumentException("所选端点已接多条道路，请选道路尽头");
      Settings settings=t.method_10545("Profile"+i)?RoadRecord.readSettings(t.method_10562("Profile"+i)):new Settings(Mode.CURVE,i==0?Style.O4_YELLOW:Style.O2_ONE,(i==0?Style.O4_YELLOW:Style.O2_ONE).defaultWidth(),1,.4,90);
      if(!hosts.isEmpty()){
        var host=hosts.get(0);if(p!=null)RoadData.requireOwner(p,host.record.owner());settings=RoadData.endpointSection(host,pos);
        if(host.record.assembly()==null)settings=settings.options(settings.options().sidewalk(host.record.settings().options().sidewalk()));
        var actual=host.record.caps(0).mesh();var end=host.record.a().equals(pos)?actual.first():actual.last();V outward=end.left().left().mul(host.record.a().equals(pos)?1:-1);
        V direction=i==1?outward.mul(-1):outward; // A points toward junction, B away, C toward junction.
        if(i==0)direction=outward;
        double grade=(host.record.a().equals(pos)?host.record.start().grade():host.record.end().grade())*(host.record.a().equals(pos)?-1:1)*(i==1?-1:1);
        V endpoint=end.center();
        node=new Node(endpoint,YJunctionPlanner.yaw(direction),grade);
        if(direction.left().dot(end.left())<0)settings=RoadEndpointSections.orient(settings,true);
        if(i>0&&((i==1&&!host.record.a().equals(pos))||(i==2&&!host.record.b().equals(pos))))throw new IllegalArgumentException((i==1?"B":"C")+" 单行道方向不符：B 应从端点驶出，C 应驶入端点");
        signature=31*signature+GantryTool.signature(host.record);
      }else {
        if(i>0&&!t.method_10545("Profile"+i)){var main=RoadRecord.readSettings(t.method_10562("Profile0"));var cp=RoadProfile.catalog(main);var count=new RoadLanes.Counts(i==1?RoadLanes.counts(main).forward():RoadLanes.counts(main).reverse(),0);var style=RoadLanes.carrier(cp.type(),count,Median.NONE);var o=main.options().lanes(count).ends(RoadTransitions.Ends.NONE).laneLines(List.of());settings=new Settings(Mode.CURVE,style,RoadProfile.width(style,o,RoadProfile.layout(main,main.width()).laneWidth()),main.thickness(),.4,90).structure(main.structure()).options(o);}
        if(!entity.headingLocked){V av=RoadData.requireNode(l,class_2338.method_10092(points[0]),p).constructionNode().position();V bv=RoadData.requireNode(l,class_2338.method_10092(points[1]),p).constructionNode().position();V cv=RoadData.requireNode(l,class_2338.method_10092(points[2]),p).constructionNode().position();V direction=i==0?bv.add(cv).mul(.5).sub(av):i==1?bv.sub(av):av.sub(cv);node=new Node(node.position(),YJunctionPlanner.yaw(direction),0);}
      }
      t.method_10556("LockedProfile"+i,!hosts.isEmpty());nodes.add(RoadRecord.writeNode(node));t.method_10566("Profile"+i,RoadRecord.writeSettings(settings));signature=31*signature+node.hashCode();
    }
    t.method_10566("Nodes",nodes);t.method_10569("Signature",signature);return t;
  }
  public static String build(class_3218 l,class_3222 p,class_2487 command,class_1799 tool){
    if(!(tool.method_7909() instanceof YJunctionTool)&&!(command.method_25928("Id")&&tool.method_7909() instanceof JunctionTool))throw new IllegalArgumentException("请手持 Y 字路口编辑器");
    var d=RoadData.get(l);UUID id=command.method_25928("Id")?command.method_25926("Id"):null;long[] points=command.method_10565("Points");
    if(id==null&&(!Arrays.equals(points,tool.method_7948().method_10565("Points"))||!l.method_27983().method_29177().toString().equals(tool.method_7969().method_10558("Dimension"))))throw new IllegalArgumentException("选点已失效，请重新选择 A/B/C");
    if(id!=null){var saved=Interchanges.descriptor(d,id);if(!saved.method_10577("YJunction")||!Arrays.equals(points,saved.method_10565("Points")))throw new IllegalArgumentException("Y 字路口已改变");}
    if(command.method_10577("Delete")){if(id==null)throw new IllegalArgumentException("尚未建造");Interchanges.remove(l,p,id);return "Y 字路口已删除";}
    try(var work=RoadWorkChunks.open(l)){
      var t=payload(l,p,points,id);if(t.method_10550("Signature")!=command.method_10550("Signature"))throw new IllegalArgumentException("端点或相接道路已改变，请重新选择");
      for(int i=0;i<3;i++)if(!t.method_10577("LockedProfile"+i)&&command.method_10545("Profile"+i)){var requested=RoadRecord.readSettings(command.method_10562("Profile"+i));requested.validate();t.method_10566("Profile"+i,RoadRecord.writeSettings(requested));}
      double tension=command.method_10574("Tension");t.method_10549("Tension",tension);var n=t.method_10554("Nodes",class_2520.field_33260);var plan=YJunctionPlanner.plan(RoadRecord.readNode(n.method_10602(0)),RoadRecord.readNode(n.method_10602(1)),RoadRecord.readNode(n.method_10602(2)),RoadRecord.readSettings(t.method_10562("Profile0")),RoadRecord.readSettings(t.method_10562("Profile1")),RoadRecord.readSettings(t.method_10562("Profile2")),tension);
      UUID group=id==null?UUID.randomUUID():id,owner=id==null?(p==null?new UUID(0,0):p.method_5667()):t.method_25926("Owner");t.method_25927("Id",group);t.method_25927("Owner",owner);
      class_2338 a=class_2338.method_10092(points[0]),b=class_2338.method_10092(points[1]),c=class_2338.method_10092(points[2]),throat=class_2338.method_49637(plan.throat().position().x(),plan.throat().position().y(),plan.throat().position().z());
      var built=new ArrayList<RoadIndex.Built>();var meshes=List.of(plan.stem(),plan.outbound(),plan.inbound());var from=List.of(a,throat,c);var to=List.of(throat,b,throat);
      for(int i=0;i<3;i++){var m=meshes.get(i);var first=m.first();var last=m.last();var r=new RoadRecord(UUID.nameUUIDFromBytes((group+":"+i).getBytes(java.nio.charset.StandardCharsets.UTF_8)),owner,from.get(i),to.get(i),new Node(first.center(),YJunctionPlanner.yaw(first.left().left().mul(-1)),i==2?RoadRecord.readNode(n.method_10602(2)).grade():plan.throat().grade()),new Node(last.center(),YJunctionPlanner.yaw(last.left().left().mul(-1)),i==1?RoadRecord.readNode(n.method_10602(1)).grade():i==2?-plan.throat().grade():plan.throat().grade()),m.settings(),true,4).alignment(group,m);built.add(new RoadIndex.Built(r));}
      Set<UUID> removed=new HashSet<>();if(id!=null)for(var r:d.index.roads.values())if(id.equals(r.record.assembly()))removed.add(r.record.id());
      if(l.method_8321(throat) instanceof NodeEntity&&!Set.of(a,b,c).contains(throat))throw new IllegalArgumentException("Y 字分流处有其他端点，请调整选点");
      // These three hosts lose only the free-end cap at the port being joined.
      // Check against their final decks, including any untouched far-end cap.
      var ports=Set.of(a,b,c);
      for(var old:d.index.roads.values()){
        if(removed.contains(old.record.id()))continue;
        int mask=old.record.endCaps();
        if(ports.contains(old.record.a()))mask&=~1;
        if(ports.contains(old.record.b()))mask&=~2;
        var deck=mask==old.record.endCaps()?old.mesh:old.record.caps(mask).mesh();
        for(var proposed:built)if(RoadIndex.overlapXZ(proposed.mesh,deck,1))Interchanges.checkExternal(proposed.mesh,deck);
      }
      d.replaceAssembly(l,p,built,removed,Set.of(a,b,c));d.interchanges.put(group,t);d.method_80();tool.method_7948().method_10551("Points");return "Y 字路口已更新：A→B、C→A";
    }
  }
}
