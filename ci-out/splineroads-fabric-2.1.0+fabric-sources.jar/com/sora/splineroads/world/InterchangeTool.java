package com.sora.splineroads.world;

import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.net.RoadNetwork;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.world.*;
import net.minecraft.world.item.*;

public final class InterchangeTool extends class_1792 {
  private final int arms;
  private final com.sora.splineroads.core.CorridorPlanner.Kind corridor;

  public InterchangeTool() {
    this(4);
  }

  public InterchangeTool(int arms) {
    this(arms,null);
  }
  public InterchangeTool(int arms,com.sora.splineroads.core.CorridorPlanner.Kind corridor) {
    super(new class_1793().method_7889(1));
    if (arms < 2 || arms > 6 || arms==2&&corridor==null) throw new IllegalArgumentException("invalid generator arms");
    this.arms = arms;
    this.corridor = corridor;
  }

  public int arms() {
    return arms;
  }

  public boolean available() {
    return arms <= 6;
  }

  private String selection() {
    if(corridor!=null)return arms==2?"A/B 主路两端（自动生成同向辅路）":"A/B 第一层两端＋C/D 第二层两端（平行双层路）";
    return arms == 3 ? "A/B 主路两端＋C 支路端点" : arms == 4 ? "A/B 主路两端＋C/D 另一条主路两端" : arms == 5 ? "A/B、C/D 两条贯通主路＋E 支路端点" : "A/B、C/D、E/F 三条贯通主路两端";
  }

  private class_2487 tagged(class_2487 payload) {
    payload.method_10569("GeneratorArms", arms);
    if(corridor!=null){
      payload.method_10582("GeneratorMode",corridor.name());
      payload.method_10582("Kind",payload.method_10558("Kind").replace("interchange","corridor"));
      if(payload.method_10545("Nodes"))Corridors.initialize(payload,corridor);
    }
    return payload;
  }

  public void requireDescriptor(class_2487 t){
    if(t==null)throw new IllegalArgumentException("道路组合已不存在");
    requireLayout(t.method_10565("Points"));
    String mode=t.method_10545("Corridor")?t.method_10562("Corridor").method_10558("Mode"):"";
    if(!mode.equals(corridor==null?"":corridor.name()))
      throw new IllegalArgumentException("请使用与当前道路组合对应的生成器");
  }

  public void requireLayout(long[] points) {
    if (!available()) throw new IllegalArgumentException(arms + " 向立交生成器暂未开放建造");
    if (points.length != arms)
      throw new IllegalArgumentException(corridor!=null?"请使用与此组合对应的主辅路或双层出入口工具":"请使用 " + points.length + " 向立交生成器编辑此立交");
  }

  private boolean placeholder(class_1657 player) {
    if (available()) return false;
    if (!player.method_37908().field_9236)
      player.method_7353(class_2561.method_43470(arms + " 向立交生成器：预留物品，暂未开放建造"), true);
    return true;
  }

  @Override
  public class_1269 method_7884(class_1838 context) {
    if (context.method_8045().field_9236) return class_1269.field_5812;
    if (!(context.method_8036() instanceof class_3222 player)) return class_1269.field_5811;
    if (placeholder(player)) return class_1269.field_21466;
    try (var workChunks = RoadWorkChunks.open(player.method_51469())) {
      var level = player.method_51469();
      var tool = context.method_8041().method_7948();
      var hitRoad=RoadTool.pick(player);var hit=context.method_17698();
      var attached=hitRoad==null?null:AttachedPointTool.nearest(hitRoad,new com.sora.splineroads.core.RoadGeometry.V(hit.field_1352,hit.field_1351,hit.field_1350));
      if(attached!=null){
        if(hitRoad.record.assembly()!=null)throw new IllegalArgumentException("立交主路附属点仅用于标线分段，不能用来选择整路");
        RoadData.requireOwner(player,hitRoad.record.owner());String dimension=level.method_27983().method_29177().toString();
        long[] selected=dimension.equals(tool.method_10558("Dimension"))?tool.method_10565("Points"):new long[0];if(selected.length>=arms)selected=new long[0];
        if(selected.length%2!=0||selected.length+2>arms)throw new IllegalArgumentException("附属点一次选择完整道路；请先完成或清除当前单端点选择");
        long a=hitRoad.record.a().method_10063(),b=hitRoad.record.b().method_10063();for(long old:selected)if(old==a||old==b)throw new IllegalArgumentException("该道路与已选端点重复");
        long[] next=Arrays.copyOf(selected,selected.length+2);next[selected.length]=a;next[selected.length+1]=b;tool.method_10564("Points",next);tool.method_10582("Dimension",dimension);
        if(next.length==arms)RoadNetwork.open(player,tagged(Interchanges.payload(level,player,next,null)));else player.method_7353(class_2561.method_43470("已通过附属点选中完整道路；继续选择另一条道路或支路端点"),true);
        return class_1269.field_21466;
      }
      class_2338 p = RoadTool.endpointAtHit(context);
      if (level.method_8321(p) instanceof NodeEntity) {
        RoadData.requireNode(level, p, player);
        String dimension = level.method_27983().method_29177().toString();
        long[] selected =
            dimension.equals(tool.method_10558("Dimension"))
                ? tool.method_10565("Points")
                : new long[0];
        if (selected.length >= arms) selected = new long[0];
        for (long point : selected)
          if (point == p.method_10063()) throw new IllegalArgumentException("请选择另一个端点");
        long[] next = Arrays.copyOf(selected, selected.length + 1);
        next[selected.length] = p.method_10063();
        tool.method_10564("Points", next);
        tool.method_10582("Dimension", dimension);
        if (next.length == arms)
          RoadNetwork.open(player, tagged(Interchanges.payload(level, player, next, null)));
        else
          player.method_7353(
              class_2561.method_43470(
                  "已选 "
                      + (char) ('A' + selected.length)
                      + "；接着选择 "
                      + (char) ('A' + next.length)
                      + "（"
                      + selection()
                      + "）"),
              true);
      } else edit(player);
    } catch (IllegalArgumentException e) {
      player.method_7353(class_2561.method_43470(e.getMessage()), false);
    }
    return class_1269.field_21466;
  }

  private void edit(class_3222 player) {
    var hit = RoadTool.pick(player);
    if (hit == null || hit.record.assembly() == null)
      throw new IllegalArgumentException("选择 " + selection() + "；或右键已有立交");
    var data=RoadData.get(player.method_51469());
    UUID group=InterchangeJunctions.parent(data,hit.record.assembly());
    var saved = data.interchanges.get(group);
    if (saved == null) throw new IllegalArgumentException("立交描述已缺失，请删除残留路段后重建");
    requireDescriptor(saved);
    RoadNetwork.open(
        player,
        tagged(
            Interchanges.payload(
                player.method_51469(),
                player,
                saved.method_10565("Points"),
                group)));
  }

  @Override
  public class_1271<class_1799> method_7836(class_1937 level, class_1657 who, class_1268 hand) {
    class_1799 stack = who.method_5998(hand);
    if (placeholder(who)) return class_1271.method_29237(stack, level.field_9236);
    if (who.method_5715()) {
      if (!level.field_9236) {
        stack.method_7948().method_10551("Points");
        class_2487 t = new class_2487();
        t.method_10582("Kind", "interchangeReset");
        RoadNetwork.open((class_3222) who, tagged(t));
      }
    } else if (level.field_9236) {
      class_2487 t = new class_2487();
      t.method_10582("Kind", "interchangeResume");
      RoadTool.openClient.accept(tagged(t));
    } else
      try {
        var player = (class_3222) who;
        var hit = RoadTool.pick(player);
        if (hit != null && hit.record.assembly() != null) edit(player);
        else {
          long[] points = stack.method_7948().method_10565("Points");
          if (points.length == arms
              && level
                  .method_27983()
                  .method_29177()
                  .toString()
                  .equals(stack.method_7969().method_10558("Dimension")))
            RoadNetwork.open(
                player, tagged(Interchanges.payload(player.method_51469(), player, points, null)));
        }
      } catch (IllegalArgumentException e) {
        who.method_7353(class_2561.method_43470(e.getMessage()), false);
      }
    return class_1271.method_29237(stack, level.field_9236);
  }

  @Override
  public void method_7851(class_1799 s, class_1937 l, List<class_2561> lines, class_1836 f) {
    if (!available()) {
      lines.add(class_2561.method_43470("预留物品 · 暂未开放建造"));
      lines.add(class_2561.method_43470(arms == 5 ? "规划：A/B＋C/D＋E 端点" : "规划：A/B＋C/D＋E/F"));
      return;
    }
    lines.add(class_2561.method_43470("选择 " + selection() + " 后打开设置"));
    lines.add(class_2561.method_43470("Shift＋右键空气重新选点；右键已有立交可整体编辑"));
  }
}
