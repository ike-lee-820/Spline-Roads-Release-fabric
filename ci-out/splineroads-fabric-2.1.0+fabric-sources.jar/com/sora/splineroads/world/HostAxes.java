package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.CorridorPlanner.Config;
import com.sora.splineroads.core.RoadGeometry.*;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;

/** Server-derived host paths travel with the preview and the saved assembly descriptor. */
public final class HostAxes {
  public static Node[] nodes(class_2487 t){return t.method_10554("Nodes",class_2520.field_33260).stream().map(v->RoadRecord.readNode((class_2487)v)).toArray(Node[]::new);}
  public static List<RoadAxis> read(class_2487 t){
    var out=new ArrayList<RoadAxis>();
    for(class_2520 value:t.method_10554("HostAxes",class_2520.field_33260)){
      var points=new ArrayList<V>();for(class_2520 p:((class_2487)value).method_10554("Points",class_2520.field_33260))points.add(RoadRecord.readNode((class_2487)p).position());
      out.add(new RoadAxis(points));
    }
    if(!out.isEmpty())return List.copyOf(out);
    Node[] n=nodes(t);for(int i=0;i+1<n.length;i+=2)out.add(RoadAxis.straight(n[i].position(),n[i+1].position()));
    if(n.length==3){V a=n[0].position(),u=n[1].position().sub(a).horizontalUnit(),c=n[2].position();V foot=a.add(u.mul(c.sub(a).dot(u)));out.add(RoadAxis.straight(c,new V(foot.x(),c.y(),foot.z())));}
    return List.copyOf(out);
  }
  public static void write(class_2487 t,List<RoadAxis> axes){
    class_2499 list=new class_2499();for(RoadAxis axis:axes){var a=new class_2487();var points=new class_2499();for(V p:axis.points()){var q=new class_2487();q.method_10549("X",p.x());q.method_10549("Y",p.y());q.method_10549("Z",p.z());points.add(q);}a.method_10566("Points",points);list.add(a);}t.method_10566("HostAxes",list);
  }
  static RoadAxis chain(List<RoadRecord> chain,class_2338 start){
    var points=new ArrayList<V>();class_2338 at=start;
    for(var road:chain){boolean forward=road.a().equals(at);var samples=road.mesh().samples();
      for(int j=0;j<samples.size();j++){V p=samples.get(forward?j:samples.size()-1-j).center();if(points.isEmpty()||p.distance(points.get(points.size()-1))>1e-5)points.add(p);}
      at=forward?road.b():road.a();
    }return new RoadAxis(points);
  }
  public static int signature(class_2487 t){return t.method_10554("HostAxes",class_2520.field_33260).hashCode();}
  public static boolean curved(class_2487 t){return read(t).stream().anyMatch(RoadAxis::curved);}
  public static boolean retiredInterchange(class_2487 t){return !t.method_10545("Corridor")&&curved(t);}
  public static final String RETIRED_MESSAGE="请选择两条直线主路";
  public static List<InterchangePlanner.Preset> presets(class_2487 t){return ParallelSpui.present(t)?List.of(InterchangePlanner.Preset.SPUI):CurvedRoadPlans.presets(t.method_10565("Points").length,curved(t));}
  public static boolean fixedFrontage(class_2487 t){return t.method_10545("Corridor")&&CurvedRoadPlans.fixedFrontageHeight(nodes(t),Corridors.read(t.method_10562("Corridor")),read(t).get(0));}
  public static void normalizeCorridor(class_2487 t){
    if(!fixedFrontage(t))return;var c=Corridors.read(t.method_10562("Corridor"));
    t.method_10566("Corridor",Corridors.write(new CorridorPlanner.Config(c.kind(),c.sides(),CorridorPlanner.Access.NONE,c.gap(),nodes(t)[0].position().y(),c.adjustment())));
  }
  static void fit(class_2487 t,List<Node> target){
    if(target.size()>4)return;
    var axes=read(t);var fitted=new ArrayList<RoadAxis>();
    for(int i=0;i<axes.size();i++){
      RoadAxis axis=axes.get(i);double start=axis.project(target.get(i*2).position()),end=i*2+1<target.size()?axis.project(target.get(i*2+1).position()):axis.length();
      fitted.add(axis.slice(start,end,target.get(i*2).position().y()-axis.at(start).y()));
    }write(t,fitted);
  }
  private HostAxes(){}
}
