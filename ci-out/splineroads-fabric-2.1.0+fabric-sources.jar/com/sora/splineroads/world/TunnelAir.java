package com.sora.splineroads.world;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2189;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.world.level.*;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.material.*;
/** Excavated air with no collision, visibility or ticking, but no liquid refill. */
public final class TunnelAir extends class_2189 implements class_2402 {
  // This marker must count as a stored block. LevelChunk discards air writes in an
  // otherwise empty section, which would silently lose the liquid barrier.
  public TunnelAir(){super(class_2251.method_9637().method_9634().method_22488().method_51371().method_9629(-1,3600000).method_42327());}
  /** Logical empty space, independent of Minecraft's section storage air flag. */
  public static boolean isAirSpace(class_2680 state){return state.method_26215()||state.method_26204() instanceof TunnelAir;}
  @Override public boolean method_10310(class_1922 world,class_2338 pos,class_2680 state,class_3611 fluid){return false;}
  @Override public boolean method_10311(class_1936 world,class_2338 pos,class_2680 state,class_3610 fluid){return false;}
}
