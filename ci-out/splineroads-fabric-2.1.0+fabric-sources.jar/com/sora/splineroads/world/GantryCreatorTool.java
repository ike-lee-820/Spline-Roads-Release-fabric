package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadGeometry.V;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.world.item.*;

/** The hit position creates a persistent independent station; Shift opens its editor. */
public final class GantryCreatorTool extends GantryTool {
  @Override public class_1269 method_7884(class_1838 context){
    if(context.method_8036()!=null&&context.method_8036().method_5715())return super.method_7884(context);
    if(context.method_8045().field_9236)return class_1269.field_5812;
    if(!(context.method_8036() instanceof class_3222 player))return class_1269.field_5811;
    try{
      var data=RoadData.get(player.method_51469());var hit=context.method_17698();V point=new V(hit.field_1352,hit.field_1351,hit.field_1350);
      var built=data.index.at(context.method_8037().method_10063()).stream().map(data.index.roads::get).filter(Objects::nonNull)
          .filter(b->b.record.junction()==null&&b.record.toll()==null&&!b.mesh.settings().style().ramp())
          .min(Comparator.comparingDouble(b->Math.abs(RoadQueries.horizontal(b.mesh,point).sample().center().y()-point.y()))).orElseThrow(()->new IllegalArgumentException("请右键道路表面，在点击位置创建独立龙门架"));
      data.createGantry(player.method_51469(),player,built.record.id(),point);
      player.method_7353(class_2561.method_43470("独立龙门架已创建；Shift＋右键可编辑，也可使用龙门架编辑器"),true);
    }catch(IllegalArgumentException e){player.method_7353(class_2561.method_43470(e.getMessage()),false);}
    return class_1269.field_21466;
  }
  @Override public void method_7851(class_1799 s,class_1937 level,List<class_2561> lines,class_1836 flag){lines.add(class_2561.method_43471("tooltip.splineroads.gantry_creator"));}
}
