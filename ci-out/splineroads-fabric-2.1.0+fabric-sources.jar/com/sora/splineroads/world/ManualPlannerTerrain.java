package com.sora.splineroads.world;

import com.sora.splineroads.net.RoadNetwork;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
import net.minecraft.world.level.chunk.*;

/** Bounded native chunk requests. The map retains sampled tiles, not 50,000 ticking chunks. */
final class ManualPlannerTerrain implements AutoCloseable {
  private static final class_3230<UUID> TICKET=class_3230.method_14291("sr_planner_map",UUID::compareTo);
  private final class_3222 player;private final class_3218 level;private final UUID session;
  private final ArrayDeque<class_1923> waiting=new ArrayDeque<>();private final Set<Long> sampled=new HashSet<>();
  private final Map<class_1923,Long> pending=new LinkedHashMap<>();
  private int radius=256,total;private double centerX,centerZ;private boolean closed;
  ManualPlannerTerrain(class_3222 p,UUID id){player=p;level=p.method_51469();session=id;configure(256);}
  final Map<Long,class_2487> nodes=new HashMap<>();
  int radius(){return radius;}int completed(){return sampled.size();}int total(){return total;}
  void configure(int value){
    if(value<16||value>2048)throw new IllegalArgumentException("地表加载半径应为16–2048格");
    radius=value;centerX=player.method_23317();centerZ=player.method_23321();waiting.clear();var next=new ArrayList<class_1923>();
    sampled.removeIf(key->{var c=new class_1923(key);return Math.hypot(c.field_9181*16+8-centerX,c.field_9180*16+8-centerZ)>2080;});
    nodes.keySet().removeIf(key->{var p=class_2338.method_10092(key);return Math.hypot(p.method_10263()-centerX,p.method_10260()-centerZ)>2080;});
    for(int x=((int)Math.floor(centerX-radius))>>4;x<=((int)Math.floor(centerX+radius))>>4;x++)
      for(int z=((int)Math.floor(centerZ-radius))>>4;z<=((int)Math.floor(centerZ+radius))>>4;z++){
        var pos=new class_1923(x,z);double dx=Math.max(0,Math.max(x*16-centerX,centerX-(x*16+16))),dz=Math.max(0,Math.max(z*16-centerZ,centerZ-(z*16+16)));
        if(dx*dx+dz*dz<=radius*(double)radius&&level.method_8621().method_11951(pos)&&!sampled.contains(pos.method_8324()))next.add(pos);
      }
    next.sort(Comparator.comparingDouble(p->Math.pow(p.field_9181*16+8-centerX,2)+Math.pow(p.field_9180*16+8-centerZ,2)));
    waiting.addAll(next);total=sampled.size()+next.size();
  }
  void changed(Set<Long> chunks){
    for(var e:nodes.entrySet()){var pos=class_2338.method_10092(e.getKey());if(chunks.contains(new class_1923(pos).method_8324())&&level.method_22340(pos)){var be=level.method_8321(pos);if(be instanceof NodeEntity n)e.setValue(nodeTag(n));else e.setValue(new class_2487());}}
    nodes.values().removeIf(class_2487::method_33133);
    // Keep the session cache and scan progress. Only changed columns need a new sample.
    for(long key:chunks){var pos=new class_1923(key);if(Math.hypot(pos.field_9181*16+8-centerX,pos.field_9180*16+8-centerZ)>2080)continue;sampled.remove(key);waiting.remove(pos);if(!pending.containsKey(pos))waiting.addFirst(pos);}
    total=sampled.size()+waiting.size()+pending.size();
  }
  static class_2487 nodeTag(NodeEntity n){var item=new class_2487();item.method_10544("Pos",n.method_11016().method_10063());item.method_10566("Node",RoadRecord.writeNode(n.node()));item.method_10556("JunctionMarker",n.junctionSource!=null&&AutoJunctions.center(RoadData.get((class_3218)n.method_10997()),n.method_11016())==null);return item;}
  void tick(){
    if(closed)return;
    if(Math.hypot(player.method_23317()-centerX,player.method_23321()-centerZ)>=16)configure(radius);
    long end=System.nanoTime()+3_000_000;
    for(var iterator=pending.entrySet().iterator();iterator.hasNext();){var entry=iterator.next();var pos=entry.getKey();var loaded=level.method_14178().method_21730(pos.field_9181,pos.field_9180);
      if(loaded==null&&level.method_8510()-entry.getValue()<2400)continue;
      try{if(loaded!=null){send(loaded);sampled.add(pos.method_8324());}else{var t=new class_2487();t.method_10582("Kind","manualTerrain");t.method_25927("PlannerSession",session);t.method_10582("Error","地表分块加载超时，可在设置中重新加载");RoadNetwork.open(player,t);}}
      catch(RuntimeException failure){com.mojang.logging.LogUtils.getLogger().warn("Planner terrain tile failed at {}",pos,failure);}
      finally{level.method_14178().method_17300(TICKET,pos,0,session);iterator.remove();}
      if(System.nanoTime()>=end)break;
    }
    int submitted=0;
    while(pending.size()<32&&!waiting.isEmpty()&&submitted++<64&&System.nanoTime()<end){
      var pos=waiting.removeFirst();if(sampled.contains(pos.method_8324())||pending.containsKey(pos))continue;
      // Already available chunks need neither a ticket nor another scheduler tick.
      var loaded=level.method_14178().method_21730(pos.field_9181,pos.field_9180);
      if(loaded!=null){try{send(loaded);sampled.add(pos.method_8324());}catch(RuntimeException failure){com.mojang.logging.LogUtils.getLogger().warn("Planner terrain tile failed at {}",pos,failure);}continue;}
      // FULL ticket advancement is owned by Minecraft's chunk scheduler. getChunkFuture
      // would managedBlock on the server thread, so completion is polled with getChunkNow.
      level.method_14178().method_17297(TICKET,pos,0,session);pending.put(pos,level.method_8510());
    }
  }
  private void send(class_2818 chunk){
    int[] colors=new int[256],heights=new int[256];var origin=chunk.method_12004();
    for(int z=0;z<16;z++)for(int x=0;x<16;x++){
      int y=chunk.method_12005(class_2902.class_2903.field_13202,x,z);var pos=new class_2338(origin.field_9181*16+x,y,origin.field_9180*16+z);
      int color=chunk.method_8320(pos).method_26205(level,pos).field_16011;if(color==0)color=0x777777;
      int north=chunk.method_12005(class_2902.class_2903.field_13202,x,Math.max(0,z-1));int shade=y>north?255:y<north?175:220;
      colors[z*16+x]=0xff000000|(((color&255)*shade/255)<<16)|((((color>>8)&255)*shade/255)<<8)|(((color>>16)&255)*shade/255);heights[z*16+x]=y+1;
    }
    var t=new class_2487();t.method_10582("Kind","manualTerrain");t.method_25927("PlannerSession",session);t.method_10569("ChunkX",origin.field_9181);t.method_10569("ChunkZ",origin.field_9180);t.method_10539("Colors",colors);t.method_10539("Heights",heights);t.method_10569("Loaded",sampled.size()+1);t.method_10569("Total",total);
    nodes.entrySet().removeIf(e->new class_1923(class_2338.method_10092(e.getKey())).equals(origin));var found=new class_2499();for(var be:chunk.method_12214().values())if(be instanceof NodeEntity n){var item=nodeTag(n);nodes.put(n.method_11016().method_10063(),item);found.add(item);}t.method_10566("Nodes",found);RoadNetwork.open(player,t);
  }
  private void releasePending(){for(var pos:pending.keySet())level.method_14178().method_17300(TICKET,pos,0,session);pending.clear();}
  @Override public void close(){closed=true;releasePending();waiting.clear();sampled.clear();nodes.clear();}
}
