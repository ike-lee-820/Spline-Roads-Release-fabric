package com.sora.splineroads.world;
import com.sora.splineroads.world.RoadIndex.Built;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;
/** Review exact dependency IDs; stale confirmations cannot delete newly added dependents. */
public final class LaneDeletes {
  static Set<UUID> junctionDependencies(RoadData data,UUID group){var seeds=new HashSet<UUID>();data.index.roads.values().stream().filter(b->group.equals(b.record.assembly())).forEach(b->seeds.add(b.record.id()));var c=data.junctions.get(group);if(c!=null&&c.method_10577("Auto")&&!c.method_10577("GeneratedRing")){long pos=c.method_10537("CenterPos");data.streets.values().stream().filter(r->r.a().method_10063()==pos||r.b().method_10063()==pos).forEach(r->seeds.add(r.id()));}return LaneTopology.dependents(data,seeds);}
  static void junctionPayload(RoadData data,UUID group,class_2487 t){var list=new class_2499();junctionDependencies(data,group).stream().sorted().forEach(v->list.add(class_2519.method_23256(v.toString())));t.method_10566("Dependencies",list);}
  public static void removeJunction(class_3218 level,class_3222 player,class_2487 t){var data=RoadData.get(level);UUID group=t.method_25926("Id");var deps=junctionDependencies(data,group);requireConfirmation(t,deps);UUID representative=data.index.roads.values().stream().filter(b->group.equals(b.record.assembly())).map(b->b.record.id()).findFirst().orElseThrow(()->new IllegalArgumentException("路口已不存在"));data.removeWithDependents(level,player,representative,deps);}
  public static void payload(RoadData data,UUID id,class_2487 t){var list=new class_2499();LaneTopology.dependents(data,Set.of(id)).stream().sorted().forEach(v->list.add(class_2519.method_23256(v.toString())));t.method_10566("Dependencies",list);}
  public static void requireConfirmation(class_2487 t,Set<UUID> dependencies){if(dependencies.isEmpty())return;var confirmed=new HashSet<UUID>();for(class_2520 value:t.method_10554("ConfirmDependencies",class_2520.field_33258))try{confirmed.add(UUID.fromString(value.method_10714()));}catch(IllegalArgumentException e){throw new IllegalArgumentException("依赖确认无效");}if(!confirmed.equals(dependencies))throw new IllegalArgumentException("依赖匝道已变化，请重新打开删除界面，确认级联删除清单");}
  public static void remove(class_3218 level,class_3222 player,class_2487 t){var data=RoadData.get(level);UUID id=t.method_25926("Id");var dependent=LaneTopology.dependents(data,Set.of(id));requireConfirmation(t,dependent);if(dependent.isEmpty()){data.remove(level,player,id);return;}var target=data.index.roads.get(id);if(target==null)throw new IllegalArgumentException("道路已不存在");data.removeWithDependents(level,player,id,dependent);}
  private LaneDeletes(){}
}
