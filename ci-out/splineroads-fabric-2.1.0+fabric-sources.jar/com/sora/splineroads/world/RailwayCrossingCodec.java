package com.sora.splineroads.world;
import com.sora.splineroads.core.RailwayCrossings;
import com.sora.splineroads.core.RailwayCrossings.Surface;
import com.sora.splineroads.core.RoadGeometry.V;
import java.util.*;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
final class RailwayCrossingCodec{
 static class_2499 write(List<RailwayCrossings.Surface> values){var out=new class_2499();for(var p:values){var t=new class_2487();t.method_10549("From",p.from());t.method_10549("To",p.to());t.method_10549("X",p.origin().x());t.method_10549("Y",p.origin().y());t.method_10549("Z",p.origin().z());t.method_10549("SlopeX",p.slopeX());t.method_10549("SlopeZ",p.slopeZ());t.method_10549("Transition",p.transition());out.add(t);}return out;}
 static List<RailwayCrossings.Surface> read(class_2499 tags){if(tags.size()>64)throw new IllegalArgumentException("Too many railway crossings");var out=new ArrayList<RailwayCrossings.Surface>();for(var item:tags){var t=(class_2487)item;out.add(new RailwayCrossings.Surface(t.method_10574("From"),t.method_10574("To"),new V(t.method_10574("X"),t.method_10574("Y"),t.method_10574("Z")),t.method_10574("SlopeX"),t.method_10574("SlopeZ"),t.method_10545("Transition")?t.method_10574("Transition"):4));}return List.copyOf(out);}
 private RailwayCrossingCodec(){}
}
