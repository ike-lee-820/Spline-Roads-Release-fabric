package com.sora.splineroads.world;

import com.sora.splineroads.SplineRoads;
import com.sora.splineroads.core.StreetPlan.Cell;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Per connected unit history, including removed objects, exact block entities and terrain ledgers. */
final class StreetJournal {
  static final class Snapshot {
    final Map<Long,class_2680> blocks=new LinkedHashMap<>();final Map<Long,class_2487> entities=new HashMap<>();final Map<Long,RoadData.StreetLedger> ledger=new HashMap<>();
    Snapshot(){}
    Snapshot(class_3218 level,Collection<Long> keys){var data=RoadData.get(level);for(long key:keys){var p=class_2338.method_10092(key);var state=level.method_8320(p);blocks.put(key,state);var be=state.method_31709()?level.method_8321(p):null;if(be!=null)entities.put(key,be.method_38242());ledger.put(key,data.streetLedger(key));}}
    void keep(Set<Long> keys){blocks.keySet().retainAll(keys);entities.keySet().retainAll(keys);ledger.keySet().retainAll(keys);}
    boolean cellEquals(Snapshot other,long key){return Objects.equals(blocks.get(key),other.blocks.get(key))&&Objects.equals(entities.get(key),other.entities.get(key));}
    class_2487 save(){
      var t=new class_2487();t.method_10566("Blocks",RoadBlockStorage.write(new Long2ObjectOpenHashMap<>(blocks)));var bes=new class_2499();entities.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(e->{var v=new class_2487();v.method_10544("Pos",e.getKey());v.method_10566("Data",e.getValue().method_10553());bes.add(v);});t.method_10566("Entities",bes);
      for(String kind:List.of("Fill","Original","Sidewalk")){var states=new Long2ObjectOpenHashMap<class_2680>();for(var e:ledger.entrySet()){var s=switch(kind){case "Fill"->e.getValue().fill();case "Original"->e.getValue().original();default->e.getValue().sidewalk();};if(s!=null)states.put(e.getKey().longValue(),s);}t.method_10566(kind,RoadBlockStorage.write(states));}
      t.method_10564("Aprons",ledger.entrySet().stream().filter(e->e.getValue().apron()).mapToLong(Map.Entry::getKey).toArray());return t;
    }
    static Snapshot load(class_2487 t){
      var s=new Snapshot();var blocks=new Long2ObjectOpenHashMap<class_2680>();RoadBlockStorage.read(t.method_10554("Blocks",class_2520.field_33260),blocks);s.blocks.putAll(blocks);
      for(class_2520 v:t.method_10554("Entities",class_2520.field_33260)){var e=(class_2487)v;s.entities.put(e.method_10537("Pos"),e.method_10562("Data").method_10553());}
      var fill=new Long2ObjectOpenHashMap<class_2680>();var original=new Long2ObjectOpenHashMap<class_2680>();var sidewalk=new Long2ObjectOpenHashMap<class_2680>();RoadBlockStorage.read(t.method_10554("Fill",class_2520.field_33260),fill);RoadBlockStorage.read(t.method_10554("Original",class_2520.field_33260),original);RoadBlockStorage.read(t.method_10554("Sidewalk",class_2520.field_33260),sidewalk);var aprons=new HashSet<Long>();for(long p:t.method_10565("Aprons"))aprons.add(p);
      for(long key:s.blocks.keySet())s.ledger.put(key,new RoadData.StreetLedger(fill.get(key),original.get(key),sidewalk.get(key),aprons.contains(key)));return s;
    }
  }
  final Set<UUID> roads,centers;final Snapshot before,after;final class_2487 oldObjects,newObjects;
  StreetJournal(Set<UUID> roads,Set<UUID> centers,Snapshot before,Snapshot after,class_2487 oldObjects,class_2487 newObjects){this.roads=Set.copyOf(roads);this.centers=Set.copyOf(centers);this.before=before;this.after=after;this.oldObjects=oldObjects.method_10553();this.newObjects=newObjects.method_10553();}
  class_2487 save(){var t=new class_2487();t.method_10566("RoadIds",ids(roads));t.method_10566("CenterIds",ids(centers));t.method_10566("Before",before.save());t.method_10566("After",after.save());t.method_10566("OldObjects",oldObjects);t.method_10566("NewObjects",newObjects);return t;}
  static StreetJournal load(class_2487 t){return new StreetJournal(ids(t.method_10554("RoadIds",class_2520.field_33258)),ids(t.method_10554("CenterIds",class_2520.field_33258)),Snapshot.load(t.method_10562("Before")),Snapshot.load(t.method_10562("After")),t.method_10562("OldObjects"),t.method_10562("NewObjects"));}
  static class_2499 ids(Set<UUID> values){var t=new class_2499();values.stream().sorted().forEach(id->t.add(class_2519.method_23256(id.toString())));return t;}
  static Set<UUID> ids(class_2499 values){var result=new HashSet<UUID>();for(int i=0;i<values.size();i++)result.add(UUID.fromString(values.method_10608(i)));return result;}
  record Undo(boolean restored,int conflicts){}
  Undo undo(class_3218 level,class_3222 player){
    var data=RoadData.get(level);if(!data.streetObjects(roads,centers).equals(newObjects))return new Undo(false,1);
    var nodes=new HashSet<class_2338>();for(class_2520 value:newObjects.method_10554("Centers",class_2520.field_33260))nodes.add(class_2338.method_10092(((class_2487)value).method_10537("CenterPos")));
    for(long key:before.blocks.keySet())if(after.blocks.get(key).method_27852(SplineRoads.NODE.get())&&!before.blocks.get(key).method_27852(SplineRoads.NODE.get()))nodes.add(class_2338.method_10092(key));
    if(data.index.roads.values().stream().anyMatch(r->!roads.contains(r.record.id())&&(nodes.contains(r.record.a())||nodes.contains(r.record.b()))))return new Undo(false,1);
    if(data.index.roads.values().stream().anyMatch(r->!roads.contains(r.record.id())&&before.blocks.keySet().stream().anyMatch(k->!before.cellEquals(after,k)&&r.cells.containsKey(k))))return new Undo(false,1);
    try(var lease=RoadWorkChunks.open(level)){
      var chunks=new HashSet<Long>();for(long key:before.blocks.keySet())chunks.add(new net.minecraft.class_1923(class_2338.method_10092(key)).method_8324());lease.load(chunks);
      var current=new Snapshot(level,before.blocks.keySet());var restores=new LinkedHashMap<Long,class_2680>();var entities=new HashMap<Long,class_2487>();int conflicts=0;
      for(long key:before.blocks.keySet()){
        var p=class_2338.method_10092(key);if(player!=null&&!level.method_8505(player,p))return new Undo(false,1);
        if(after.cellEquals(current,key)){restores.put(key,before.blocks.get(key));if(before.entities.containsKey(key))entities.put(key,before.entities.get(key));}
        else {conflicts++;var state=current.blocks.get(key);if(RoadBlocks.isCollider(state)||state.method_27852(SplineRoads.NODE.get()))return new Undo(false,conflicts);}
      }
      for(var e:restores.entrySet())if(player!=null)RoadEditProtection.check(level,player,class_2338.method_10092(e.getKey()),current.blocks.get(e.getKey()),e.getValue());
      // Restore as one bounded unit. If a write fails, restore the exact current
      // world/metadata rather than publishing half an undone junction.
      try{
        RoadData.restoreStreetBlocks(level,restores,entities);
        for(long key:before.blocks.keySet())data.streetLedger(key,before.ledger.get(key));
        data.restoreStreetObjects(level,roads,centers,oldObjects);
      }catch(RuntimeException failure){
        try{RoadData.restoreStreetBlocks(level,current.blocks,current.entities);for(long key:current.blocks.keySet())data.streetLedger(key,current.ledger.get(key));data.restoreStreetObjects(level,roads,centers,newObjects);}catch(RuntimeException rollback){failure.addSuppressed(rollback);}throw failure;
      }
      return new Undo(true,conflicts);
    }
  }
}
