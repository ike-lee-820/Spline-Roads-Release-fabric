package com.sora.splineroads.world;

import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadProfile.Control;
import java.util.*;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.nbt.*;
import net.minecraft.server.level.*;

/** Selection receipts stay on the tool; marker retirement shares the road transaction. */
public final class CurveControlNodes {
  public static final String KEY="CurveControlNodes";
  public static String add(class_3218 level,class_3222 player,class_1799 tool,class_2338 pos){
    return add(level,player,tool,pos,false);
  }
  static String add(class_3218 level,class_3222 player,class_1799 tool,class_2338 pos,boolean map){
    var tag=tool.method_7948();
    if(!tag.method_10545("Start")||!level.method_27983().method_29177().toString().equals(tag.method_10558("Dimension")))throw new IllegalArgumentException("请先普通右键选择起点，再用左 Alt＋右键添加控制点");
    if(pos.method_10063()==tag.method_10537("Start"))throw new IllegalArgumentException("起点不能同时作为控制点");
    if(!map&&player.method_5707(pos.method_46558())>64)throw new IllegalArgumentException("控制点离玩家太远");
    var marker=RoadData.requireNode(level,pos,player);
    if(RoadData.get(level).linked(pos))throw new IllegalArgumentException("已有道路使用的端点不能转换为曲线控制点");
    var list=tag.method_10554(KEY,class_2520.field_33260);
    if(list.size()>=32)throw new IllegalArgumentException("最多添加32个控制点");
    for(var entry:list)if(((class_2487)entry).method_10537("Pos")==pos.method_10063())throw new IllegalArgumentException("这个控制点已选中");
    var entry=new class_2487();entry.method_10544("Pos",pos.method_10063());entry.method_25927("Id",UUID.randomUUID());entry.method_10566("Node",RoadRecord.writeNode(marker.constructionNode()));list.add(entry);tag.method_10566(KEY,list);
    return map?"已添加"+(tag.method_10577("CurveThrough")?"经过点 ":"控制点 ")+list.size()+"；继续加点或选择终点 B":"已添加控制点 "+list.size()+"；继续左 Alt＋右键添加，普通右键选择终点";
  }
  public static List<RoadProfile.Control> controls(class_2487 tool){
    var out=new ArrayList<RoadProfile.Control>();
    for(var value:tool.method_10554(KEY,class_2520.field_33260)){var c=(class_2487)value;out.add(new RoadProfile.Control(c.method_25926("Id"),RoadRecord.readNode(c.method_10562("Node")).position()));}
    return List.copyOf(out);
  }
  public static List<class_2338> validate(class_3218 level,class_3222 player,class_2487 tool,Settings settings,class_2338 a,class_2338 b){
    var selected=tool.method_10554(KEY,class_2520.field_33260);var controls=settings.options().routing().controls();
    if(!controls.isEmpty()&&settings.options().routing().through()!=tool.method_10577("CurveThrough"))throw new IllegalArgumentException("经过点/控制点类型与当前选择不一致");
    if(selected.size()!=controls.size())throw new IllegalArgumentException("控制点选择已失效，请重新选择");
    var out=new ArrayList<class_2338>();
    for(int i=0;i<selected.size();i++){
      var c=selected.method_10602(i);var pos=class_2338.method_10092(c.method_10537("Pos"));var node=RoadData.requireNode(level,pos,player);
      if(!c.method_25926("Id").equals(controls.get(i).id())||!node.constructionNode().equals(RoadRecord.readNode(c.method_10562("Node")))||pos.equals(a)||pos.equals(b)||out.contains(pos)||RoadData.get(level).linked(pos))throw new IllegalArgumentException("控制端点已移动、被使用或重复，请重新选择");
      out.add(pos);
    }
    return List.copyOf(out);
  }
  public static RoadAttachments.Data attachments(RoadAttachments.Data old,List<RoadProfile.Control> before,List<RoadProfile.Control> after){
    var ids=new HashSet<UUID>();for(var c:before)ids.add(c.id());for(var c:after)ids.add(c.id());
    var points=new ArrayList<RoadAttachments.Point>();for(var p:old.points())if(!ids.contains(p.id()))points.add(p);
    return old.points(points);
  }
  private CurveControlNodes(){}
}
