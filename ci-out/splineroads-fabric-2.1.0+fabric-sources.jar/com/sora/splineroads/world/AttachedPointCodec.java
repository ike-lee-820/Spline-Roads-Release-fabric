package com.sora.splineroads.world;
import com.sora.splineroads.core.*;
import com.sora.splineroads.core.RoadAttachments.Point;
import com.sora.splineroads.core.RoadAttachments.Span;
import com.sora.splineroads.core.RoadGeometry.*;
import com.sora.splineroads.core.RoadLaneLines.Edit;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.nbt.*;
import java.util.*;
/** The on-disk type is explicitly an attached road point, never a lane point. */
public final class AttachedPointCodec {
  private static class_2487 v(V p){return RoadRecord.writeNode(new Node(p,0,0));}
  private static V v(class_2487 t){return RoadRecord.readNode(t).position();}
  public static class_2487 write(RoadAttachments.Data data){
    var t=new class_2487();t.method_10569("ControlVersion",2);var points=new class_2499();var spans=new class_2499();
    for(var p:data.points()){var q=new class_2487();q.method_25927("Id",p.id());q.method_10566("Position",v(p.position()));q.method_10566("Anchor",v(p.anchor()));q.method_10566("Origin",v(p.origin()));q.method_10556("Controlled",p.controlled());if(p.elevated())q.method_10556("Elevated",true);points.add(q);}
    for(var s:data.spans()){var q=new class_2487();q.method_10566("Start",v(s.start()));q.method_10566("End",v(s.end()));q.method_10556("HideArrows",s.paint().hideArrows());var lines=new class_2499();for(var e:s.paint().lines()){var l=new class_2487();l.method_10582("Key",e.key());l.method_10582("Pattern",e.pattern().name());l.method_10549("Width",e.width());lines.add(l);}q.method_10566("Lines",lines);spans.add(q);}
    t.method_10566("Points",points);t.method_10566("Spans",spans);return t;
  }
  public static RoadAttachments.Data read(class_2487 t){
    var points=new ArrayList<RoadAttachments.Point>();var spans=new ArrayList<RoadAttachments.Span>();
    for(class_2520 tag:t.method_10554("Points",class_2520.field_33260)){var p=(class_2487)tag;points.add(new RoadAttachments.Point(p.method_25926("Id"),v(p.method_10562("Position")),v(p.method_10562("Anchor")),p.method_10577("Controlled"),p.method_10545("Origin")?v(p.method_10562("Origin")):v(p.method_10562("Anchor")),p.method_10577("Elevated")));}
    for(class_2520 tag:t.method_10554("Spans",class_2520.field_33260)){var s=(class_2487)tag;var lines=new ArrayList<RoadLaneLines.Edit>();for(class_2520 e:s.method_10554("Lines",class_2520.field_33260)){var q=(class_2487)e;lines.add(new RoadLaneLines.Edit(q.method_10558("Key"),RoadLaneLines.Pattern.valueOf(q.method_10558("Pattern")),q.method_10574("Width")));}spans.add(new RoadAttachments.Span(v(s.method_10562("Start")),v(s.method_10562("End")),new RoadAttachments.Paint(lines,s.method_10577("HideArrows"))));}
    // Older deformation treated every marker as a knot once any point was controlled.
    // Preserve that stored shape on migration; new ordinary markers do not become knots.
    if(t.method_10550("ControlVersion")<2&&points.stream().anyMatch(RoadAttachments.Point::controlled))
      points.replaceAll(p->p.controlled()?p:new RoadAttachments.Point(p.id(),p.position(),p.anchor(),true,p.origin(),p.elevated()));
    return new RoadAttachments.Data(points,spans);
  }
  private AttachedPointCodec(){}
}
